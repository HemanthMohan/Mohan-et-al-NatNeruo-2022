clear all; close all;clear mem; clc
%% load data
fez.frontal = load(['G:\Hemanth_CSHL\OptoWiredInhibition\Data_Analysis\ManipInterFingerDistance\' ...
    'InterFingerDistance_Frontal_FezF2Gtacr1.mat']);
fez.frontal = fez.frontal.data;

fez.fla = load(['G:\Hemanth_CSHL\OptoWiredInhibition\Data_Analysis\ManipInterFingerDistance\' ...
    'InterFingerDistance_Fla_FezF2Gtacr1.mat']);
fez.fla = fez.fla.data;

plex.frontal = load(['G:\Hemanth_CSHL\OptoWiredInhibition\Data_Analysis\ManipInterFingerDistance\' ...
    'InterFingerDistance_Frontal_PlexinD1Gtacr1.mat']);
plex.frontal = plex.frontal.data;

plex.fla = load(['G:\Hemanth_CSHL\OptoWiredInhibition\Data_Analysis\ManipInterFingerDistance\' ...
'InterFingerDistance_Fla_PlexinD1Gtacr1.mat']);
plex.fla = plex.fla.data;
%% get parameters and data

sgTm = fez.frontal.sigTm;
durBefStim = fez.frontal.durBefStim;
durAftStim = fez.frontal.durAftStim;
hlIdx = getInhOnOffHandliftTrialIndex();

% get counts of trials
hlcnt.fez.front.inhOff = sum(~isnan(hlIdx.fez.frontal.inhOff_handliftIdx));
hlcnt.fez.front.inhOn = sum(~isnan(hlIdx.fez.frontal.inhOn_handliftIdx));

hlcnt.plex.front.inhOff = sum(~isnan(hlIdx.plex.frontal.inhOff_handliftIdx));
hlcnt.plex.front.inhOn = sum(~isnan(hlIdx.plex.frontal.inhOn_handliftIdx));

hlcnt.fez.fla.inhOff = sum(~isnan(hlIdx.fez.fla.inhOff_handliftIdx));
hlcnt.fez.fla.inhOn = sum(~isnan(hlIdx.fez.fla.inhOn_handliftIdx));

hlcnt.plex.fla.inhOff = sum(~isnan(hlIdx.plex.fla.inhOff_handliftIdx));
hlcnt.plex.fla.inhOn = sum(~isnan(hlIdx.plex.fla.inhOn_handliftIdx));

% get distance between fing 1 and 2  traces
inhOff.fez.front.fing12 = fez.frontal.inhOffFingerDist.fing12(:,~isnan(hlIdx.fez.frontal.inhOff_handliftIdx));
inhOn.fez.front.fing12 = fez.frontal.inhOnFingerDist.fing12(:,~isnan(hlIdx.fez.frontal.inhOn_handliftIdx));

inhOff.plex.front.fing12 = plex.frontal.inhOffFingerDist.fing12(:,~isnan(hlIdx.plex.frontal.inhOff_handliftIdx));
inhOn.plex.front.fing12 = plex.frontal.inhOnFingerDist.fing12(:,~isnan(hlIdx.plex.frontal.inhOn_handliftIdx));

inhOff.fez.fla.fing12 = fez.fla.inhOffFingerDist.fing12(:,~isnan(hlIdx.fez.fla.inhOff_handliftIdx));
inhOn.fez.fla.fing12 = fez.fla.inhOnFingerDist.fing12(:,~isnan(hlIdx.fez.fla.inhOn_handliftIdx));

inhOff.plex.fla.fing12 = plex.fla.inhOffFingerDist.fing12(:,~isnan(hlIdx.plex.fla.inhOff_handliftIdx));
inhOn.plex.fla.fing12 = plex.fla.inhOnFingerDist.fing12(:,~isnan(hlIdx.plex.fla.inhOn_handliftIdx));

% get distance between fing 1 and 3  traces
inhOff.fez.front.fing13 = fez.frontal.inhOffFingerDist.fing13(:,~isnan(hlIdx.fez.frontal.inhOff_handliftIdx));
inhOn.fez.front.fing13 = fez.frontal.inhOnFingerDist.fing13(:,~isnan(hlIdx.fez.frontal.inhOn_handliftIdx));

inhOff.plex.front.fing13 = plex.frontal.inhOffFingerDist.fing13(:,~isnan(hlIdx.plex.frontal.inhOff_handliftIdx));
inhOn.plex.front.fing13 = plex.frontal.inhOnFingerDist.fing13(:,~isnan(hlIdx.plex.frontal.inhOn_handliftIdx));

inhOff.fez.fla.fing13 = fez.fla.inhOffFingerDist.fing13(:,~isnan(hlIdx.fez.fla.inhOff_handliftIdx));
inhOn.fez.fla.fing13 = fez.fla.inhOnFingerDist.fing13(:,~isnan(hlIdx.fez.fla.inhOn_handliftIdx));

inhOff.plex.fla.fing13 = plex.fla.inhOffFingerDist.fing13(:,~isnan(hlIdx.plex.fla.inhOff_handliftIdx));
inhOn.plex.fla.fing13 = plex.fla.inhOnFingerDist.fing13(:,~isnan(hlIdx.plex.fla.inhOn_handliftIdx));
%% clear jumps in data
inhOff.fez.front.fing12(inhOff.fez.front.fing12>0.2) = nan;
inhOn.fez.front.fing12(inhOn.fez.front.fing12>0.2) = nan;

inhOff.plex.front.fing12(inhOff.plex.front.fing12>0.2) = nan;
inhOn.plex.front.fing12(inhOn.plex.front.fing12>0.2) = nan;

inhOff.fez.fla.fing12(inhOff.fez.fla.fing12>0.2) = nan;
inhOn.fez.fla.fing12(inhOn.fez.fla.fing12>0.2) = nan;

inhOff.plex.fla.fing12(inhOff.plex.fla.fing12>0.2) = nan;
inhOn.plex.fla.fing12(inhOn.plex.fla.fing12>0.2) = nan;

inhOff.fez.front.fing13(inhOff.fez.front.fing13>0.35) = nan;
inhOn.fez.front.fing13(inhOn.fez.front.fing13>0.35) = nan;

inhOff.plex.front.fing13(inhOff.plex.front.fing13>0.35) = nan;
inhOn.plex.front.fing13(inhOn.plex.front.fing13>0.35) = nan;

inhOff.fez.fla.fing13(inhOff.fez.fla.fing13>0.35) = nan;
inhOn.fez.fla.fing13(inhOn.fez.fla.fing13>0.35) = nan;

inhOff.plex.fla.fing13(inhOff.plex.fla.fing13>0.35) = nan;
inhOn.plex.fla.fing13(inhOn.plex.fla.fing13>0.35) = nan;

%% compute data for boxplot stats
aftStimTm = 5; %%% how much seconds after stimulation do you want to consider for stats
stimIdx = find(sgTm>0 & sgTm<aftStimTm);
inhOffAvg_fez_front_fing12 = nanmean(inhOff.fez.front.fing12(stimIdx,:));
inhOnAvg_fez_front_fing12 = nanmean(inhOn.fez.front.fing12(stimIdx,:));

inhOffAvg_plex_front_fing12 = nanmean(inhOff.plex.front.fing12(stimIdx,:));
inhOnAvg_plex_front_fing12 = nanmean(inhOn.plex.front.fing12(stimIdx,:));

inhOffAvg_fez_fla_fing12 = nanmean(inhOff.fez.fla.fing12(stimIdx,:));
inhOnAvg_fez_fla_fing12 = nanmean(inhOn.fez.fla.fing12(stimIdx,:));

inhOffAvg_plex_fla_fing12 = nanmean(inhOff.plex.fla.fing12(stimIdx,:));
inhOnAvg_plex_fla_fing12 = nanmean(inhOn.plex.fla.fing12(stimIdx,:));

inhOffAvg_fez_front_fing13 = nanmean(inhOff.fez.front.fing13(stimIdx,:));
inhOnAvg_fez_front_fing13 = nanmean(inhOn.fez.front.fing13(stimIdx,:));

inhOffAvg_plex_front_fing13 = nanmean(inhOff.plex.front.fing13(stimIdx,:));
inhOnAvg_plex_front_fing13 = nanmean(inhOn.plex.front.fing13(stimIdx,:));

inhOffAvg_fez_fla_fing13 = nanmean(inhOff.fez.fla.fing13(stimIdx,:));
inhOnAvg_fez_fla_fing13 = nanmean(inhOn.fez.fla.fing13(stimIdx,:));

inhOffAvg_plex_fla_fing13 = nanmean(inhOff.plex.fla.fing13(stimIdx,:));
inhOnAvg_plex_fla_fing13 = nanmean(inhOn.plex.fla.fing13(stimIdx,:));

%% 1 way analysis of variance of box plot

g2 = [repmat("frontal",hlcnt.plex.front.inhOff,1); repmat("frontal",hlcnt.plex.front.inhOn,1); ...
    repmat("fla",hlcnt.plex.fla.inhOff,1); repmat("fla",hlcnt.plex.fla.inhOn,1)];

g1 = [repmat("inhOff",hlcnt.plex.front.inhOff,1); repmat("inhOn",hlcnt.plex.front.inhOn,1); ...
    repmat("inhOff",hlcnt.plex.fla.inhOff,1); repmat("inhOn",hlcnt.plex.fla.inhOn,1)];
% finger 12 calculation
dataIn.fing12 = [inhOffAvg_plex_front_fing12 inhOnAvg_plex_front_fing12 ...
inhOffAvg_plex_fla_fing12 inhOnAvg_plex_fla_fing12];

grpId = join([g1 g2],"-");

[p.fing12,tbl.fing12,stats.fing12] = anova1(dataIn.fing12,grpId);

[results.fing12,~,~,gnames.fing12] = multcompare(stats.fing12);

plex_front_inhOffVsOn.fing12 = results.fing12(find(results.fing12(:,1) == 1 & results.fing12(:,2) == 2),6);
plex_fla_inhOffVsOn.fing12 = results.fing12(find(results.fing12(:,1) == 3 & results.fing12(:,2) == 4),6);

% % finger 13 calculation
% dataIn.fing13 = [inhOffAvg_fez_front_fing13 inhOnAvg_fez_front_fing13 ...
%     inhOffAvg_plex_front_fing13 inhOnAvg_plex_front_fing13 ...
%     inhOffAvg_fez_fla_fing13 inhOnAvg_fez_fla_fing13 ...
%     inhOffAvg_plex_fla_fing13 inhOnAvg_plex_fla_fing13];
% 
% [p.fing13,tbl.fing13,stats.fing13] = anovan(dataIn.fing13,{g1 g2 g3},"Model","interaction", ...
%     "Varnames",["cellType","Area","inhibition"],'display','off');
% 
% [results.fing13,~,~,gnames.fing13] = multcompare(stats.fing13,"Dimension",[1 2 3]);
% 
% 
% 
% fez_front_inhOffVsOn.fing13 = results.fing13(find(results.fing13(:,1) == 1 & results.fing13(:,2)==2),6);
% plex_front_inhOffVsOn.fing13 = results.fing13(find(results.fing13(:,1) == 3 & results.fing13(:,2) == 4),6);
% fez_fla_inhOffVsOn.fing13 = results.fing13(find(results.fing13(:,1) == 5 & results.fing13(:,2) == 6),6);
% plex_fla_inhOffVsOn.fing13 = results.fing13(find(results.fing13(:,1) == 7 & results.fing13(:,2) == 8),6);
%% compute means and sems for plots
% fing12
% inhOff_fez_frontMn.fing12 = nanmean(inhOff.fez.front.fing12,2);
% inhOff_fez_frontSem.fing12 = nanstd(inhOff.fez.front.fing12,[],2)./sqrt(hlcnt.fez.front.inhOff);
% inhOn_fez_frontMn.fing12 = nanmean(inhOn.fez.front.fing12,2);
% inhOn_fez_frontSem.fing12 = nanstd(inhOn.fez.front.fing12,[],2)./sqrt(hlcnt.fez.front.inhOn);

inhOff_plex_frontMn.fing12 = nanmean(inhOff.plex.front.fing12,2);
inhOff_plex_frontSem.fing12 = nanstd(inhOff.plex.front.fing12,[],2)./sqrt(hlcnt.plex.front.inhOff);
inhOn_plex_frontMn.fing12 = nanmean(inhOn.plex.front.fing12,2);
inhOn_plex_frontSem.fing12 = nanstd(inhOn.plex.front.fing12,[],2)./sqrt(hlcnt.plex.front.inhOn);

% inhOff_fez_flaMn.fing12 = nanmean(inhOff.fez.fla.fing12,2);
% inhOff_fez_flaSem.fing12 = nanstd(inhOff.fez.fla.fing12,[],2)./sqrt(hlcnt.fez.fla.inhOff);
% inhOn_fez_flaMn.fing12 = nanmean(inhOn.fez.fla.fing12,2);
% inhOn_fez_flaSem.fing12 = nanstd(inhOn.fez.fla.fing12,[],2)./sqrt(hlcnt.fez.fla.inhOn);

inhOff_plex_flaMn.fing12 = nanmean(inhOff.plex.fla.fing12,2);
inhOff_plex_flaSem.fing12 = nanstd(inhOff.plex.fla.fing12,[],2)./sqrt(hlcnt.plex.fla.inhOff);
inhOn_plex_flaMn.fing12 = nanmean(inhOn.plex.fla.fing12,2);
inhOn_plex_flaSem.fing12 = nanstd(inhOn.plex.fla.fing12,[],2)./sqrt(hlcnt.plex.fla.inhOn);

% fing13
% inhOff_fez_frontMn.fing13 = nanmean(inhOff.fez.front.fing13,2);
% inhOff_fez_frontSem.fing13 = nanstd(inhOff.fez.front.fing13,[],2)./sqrt(hlcnt.fez.front.inhOff);
% inhOn_fez_frontMn.fing13 = nanmean(inhOn.fez.front.fing13,2);
% inhOn_fez_frontSem.fing13 = nanstd(inhOn.fez.front.fing13,[],2)./sqrt(hlcnt.fez.front.inhOn);
% 
% inhOff_plex_frontMn.fing13 = nanmean(inhOff.plex.front.fing13,2);
% inhOff_plex_frontSem.fing13 = nanstd(inhOff.plex.front.fing13,[],2)./sqrt(hlcnt.plex.front.inhOff);
% inhOn_plex_frontMn.fing13 = nanmean(inhOn.plex.front.fing13,2);
% inhOn_plex_frontSem.fing13 = nanstd(inhOn.plex.front.fing13,[],2)./sqrt(hlcnt.plex.front.inhOn);
% 
% inhOff_fez_flaMn.fing13 = nanmean(inhOff.fez.fla.fing13,2);
% inhOff_fez_flaSem.fing13 = nanstd(inhOff.fez.fla.fing13,[],2)./sqrt(hlcnt.fez.fla.inhOff);
% inhOn_fez_flaMn.fing13 = nanmean(inhOn.fez.fla.fing13,2);
% inhOn_fez_flaSem.fing13 = nanstd(inhOn.fez.fla.fing13,[],2)./sqrt(hlcnt.fez.fla.inhOn);
% 
% inhOff_plex_flaMn.fing13 = nanmean(inhOff.plex.fla.fing13,2);
% inhOff_plex_flaSem.fing13 = nanstd(inhOff.plex.fla.fing13,[],2)./sqrt(hlcnt.plex.fla.inhOff);
% inhOn_plex_flaMn.fing13 = nanmean(inhOn.plex.fla.fing13,2);
% inhOn_plex_flaSem.fing13 = nanstd(inhOn.plex.fla.fing13,[],2)./sqrt(hlcnt.plex.fla.inhOn);


%% plot traces
% positon
close all
nTraces = 1;
h(1) = figure;h(1).Position = [1975 62 1042 934];

% traceIdx = randi(hlcnt.fez.front.inhOff,nTraces,1);
% ax(1) = subplot(4,2,1);
% plot(sgTm,inhOff.fez.front.fing12(:,traceIdx ),'color',[0.5 0.5 0.5])
% hold on
% plot([0,durAftStim],[0 0],'c-','LineWidth',4)
% ylabel('norm finger 12 distance')
% xlabel('time (sec)')
% title('FezF2-Frontal-InhOff')

% traceIdx = randi(hlcnt.fez.front.inhOn,nTraces,1);
% ax(2) = subplot(4,2,2);
% plot(sgTm,inhOn.fez.front.fing12(:,traceIdx ),'color','g')
% hold on
% plot([0,durAftStim],[0 0],'c-','LineWidth',4)
% ylabel('norm finger 12 distance')
% xlabel('time (sec)')
% title('FezF2-Frontal-InhOn')
% 
% traceIdx = randi(hlcnt.plex.front.inhOff,nTraces,1);
% ax(3) = subplot(4,2,3);
% plot(sgTm,inhOff.plex.front.fing12(:,traceIdx ),'color',[0.5 0.5 0.5])
% hold on
% plot([0,durAftStim],[0 0],'c-','LineWidth',4)
% ylabel('norm finger 12 distance')
% xlabel('time (sec)')
% title('PlexinD1-Frontal-InhOff')
% 
% traceIdx = randi(hlcnt.plex.front.inhOn,nTraces,1);
% ax(4) = subplot(4,2,4);
% plot(sgTm,inhOn.plex.front.fing12(:,traceIdx ),'color','b')
% hold on
% plot([0,durAftStim],[0 0],'c-','LineWidth',4)
% ylabel('norm finger 12 distance')
% xlabel('time (sec)')
% title('PlexinD1-Frontal-InhOn')
% 
% traceIdx = randi(hlcnt.fez.fla.inhOff,nTraces,1);
% ax(5) = subplot(4,2,5);
% plot(sgTm,inhOff.fez.fla.fing12(:,traceIdx ),'color',[0.5 0.5 0.5])
% hold on
% plot([0,durAftStim],[0 0],'c-','LineWidth',4)
% ylabel('norm finger 12 distance')
% xlabel('time (sec)')
% title('FezF2-FLA-InhOff')
% 
% traceIdx = randi(hlcnt.fez.fla.inhOn,nTraces,1);
% ax(6) = subplot(4,2,6);
% plot(sgTm,inhOn.fez.fla.fing12(:,traceIdx ),'color','g')
% hold on
% plot([0,durAftStim],[0 0],'c-','LineWidth',4)
% ylabel('norm finger 12 distance')
% xlabel('time (sec)')
% title('FezF2-FLA-InhOn')
% 
% traceIdx = randi(hlcnt.plex.fla.inhOff,nTraces,1);
% ax(7) = subplot(4,2,7);
% plot(sgTm,inhOff.plex.fla.fing12(:,traceIdx ),'color',[0.5 0.5 0.5])
% hold on
% plot([0,durAftStim],[0 0],'c-','LineWidth',4)
% ylabel('norm finger 12 distance')
% xlabel('time (sec)')
% title('PlexinD1-FLA-InhOff')
% 
% traceIdx = randi(hlcnt.plex.fla.inhOn,nTraces,1);
% ax(8) = subplot(4,2,8);
% plot(sgTm,inhOn.plex.fla.fing12(:,traceIdx ),'color','b')
% hold on
% plot([0,durAftStim],[0 0],'c-','LineWidth',4)
% ylabel('norm finger 12 distance')
% xlabel('time (sec)')
% title('PlexinD1-FLA-InhOff')
% sgtitle("FINGER 1 2 Distance")
% linkaxes(ax)
%% plot average trace
h(1) = figure;h(1).Position = [1100 50 1117 687];
% ax1(1) = subplot(2,2,1);
% patch([sgTm fliplr(sgTm)],[inhOff_fez_frontMn.fing12 - 2*inhOff_fez_frontSem.fing12; ...
%     flipud(inhOff_fez_frontMn.fing12 + 2*inhOff_fez_frontSem.fing12)],'k','FaceAlpha',0.3,'EdgeColor','none')
% hold on
% plot(sgTm,inhOff_fez_frontMn.fing12,'k-','LineWidth',1)
% 
% patch([sgTm fliplr(sgTm)],[inhOn_fez_frontMn.fing12 - 2*inhOn_fez_frontSem.fing12; ...
%     flipud(inhOn_fez_frontMn.fing12 + 2*inhOn_fez_frontSem.fing12)],'g','FaceAlpha',0.3,'EdgeColor','none')
% plot(sgTm,inhOn_fez_frontMn.fing12,'g-','LineWidth',1)

% plot([0,durAftStim],[0.1 0.1],'c-','LineWidth',4)

% ylabel('norm finger 12 distance')
% xlabel('time (sec)')
% xlim([-1,durAftStim])
% title('FezF2-Frontal')

ax1(1) = subplot(2,2,2);
patch([sgTm fliplr(sgTm)],[inhOff_plex_frontMn.fing12 - 2*inhOff_plex_frontSem.fing12; ...
    flipud(inhOff_plex_frontMn.fing12 + 2*inhOff_plex_frontSem.fing12)],'k','FaceAlpha',0.3,'EdgeColor','none')
hold on
plot(sgTm,inhOff_plex_frontMn.fing12,'k-','LineWidth',1)

patch([sgTm fliplr(sgTm)],[inhOn_plex_frontMn.fing12 - 2*inhOn_plex_frontSem.fing12; ...
    flipud(inhOn_plex_frontMn.fing12 + 2*inhOn_plex_frontSem.fing12)],'b','FaceAlpha',0.3,'EdgeColor','none')
plot(sgTm,inhOn_plex_frontMn.fing12,'b-','LineWidth',1)

plot([0,durAftStim],[0.1 0.1],'c-','LineWidth',4)
ylabel('norm finger 12 distance')
xlabel('time (sec)')
xlim([-1,durAftStim])
title('PlexinD1-Frontal')

% ax1(3) = subplot(2,2,3);
% patch([sgTm fliplr(sgTm)],[inhOff_fez_flaMn.fing12 - 2*inhOff_fez_flaSem.fing12; ...
%     flipud(inhOff_fez_flaMn.fing12 + 2*inhOff_fez_flaSem.fing12)],'k','FaceAlpha',0.3,'EdgeColor','none')
% hold on
% plot(sgTm,inhOff_fez_flaMn.fing12,'k-','LineWidth',1)
% 
% patch([sgTm fliplr(sgTm)],[inhOn_fez_flaMn.fing12 - 2*inhOn_fez_flaSem.fing12; ...
%     flipud(inhOn_fez_flaMn.fing12 + 2*inhOn_fez_flaSem.fing12)],'g','FaceAlpha',0.3,'EdgeColor','none')
% plot(sgTm,inhOn_fez_flaMn.fing12,'g-','LineWidth',1)
% 
% plot([0,durAftStim],[0.1 0.1],'c-','LineWidth',4)
% ylabel('norm finger 12 distance')
% xlabel('time (sec)')
% xlim([-1,durAftStim])
% title('FezF2-FLA')

ax1(2) = subplot(2,2,4);
patch([sgTm fliplr(sgTm)],[inhOff_plex_flaMn.fing12 - 2*inhOff_plex_flaSem.fing12; ...
    flipud(inhOff_plex_flaMn.fing12 + 2*inhOff_plex_flaSem.fing12)],'k','FaceAlpha',0.3,'EdgeColor','none')
hold on
plot(sgTm,inhOff_plex_flaMn.fing12,'k-','LineWidth',1)

patch([sgTm fliplr(sgTm)],[inhOn_plex_flaMn.fing12 - 2*inhOn_plex_flaSem.fing12; ...
    flipud(inhOn_plex_flaMn.fing12 + 2*inhOn_plex_flaSem.fing12)],'b','FaceAlpha',0.3,'EdgeColor','none')
plot(sgTm,inhOn_plex_flaMn.fing12,'b-','LineWidth',1)

plot([0,durAftStim],[0.1 0.1],'c-','LineWidth',4)
ylabel('norm finger 12 distance')
xlabel('time (sec)')
xlim([-1,durAftStim])
title('PlexinD1-FLA')
linkaxes(ax1)
sgtitle('Finger 1 2 distance')
%% box plot
h(2) = figure;h(2).Position = [1070 158 1242 695];
grpId = [repmat("plex-frontal-inhOff",hlcnt.plex.front.inhOff,1); repmat("plex-frontal-inhOn",hlcnt.plex.front.inhOn,1); ...
    repmat("plex-fla-inhOff",hlcnt.plex.fla.inhOff,1); repmat("plex-fla-inhOn",hlcnt.plex.fla.inhOn,1)];



boxplot(dataIn.fing12,grpId);
ylabel('finger 1 2 distance')
text(1.2,0.125,['pVal = ' num2str(plex_front_inhOffVsOn.fing12)])
text(3.2,0.125,['pVal = ' num2str(plex_fla_inhOffVsOn.fing12)])
text(2.5,0.14 , '1 Way anova')
sgtitle('finger 12 distance')

%% finger 13 distance
% nTraces = 1;
% h(4) = figure;h(4).Position = [1259 40 1042 934];
% 
% traceIdx = randi(hlcnt.fez.front.inhOff,nTraces,1);
% ax2(1) = subplot(4,2,1);
% plot(sgTm,inhOff.fez.front.fing13(:,traceIdx ),'color',[0.5 0.5 0.5])
% hold on
% plot([0,durAftStim],[0.3 0.3],'c-','LineWidth',4)
% ylabel('norm finger 13 distance ')
% xlabel('time (sec)')
% title('FezF2-Frontal-InhOff')
% 
% traceIdx = randi(hlcnt.fez.front.inhOn,nTraces,1);
% ax2(2) = subplot(4,2,2);
% plot(sgTm,inhOn.fez.front.fing13(:,traceIdx ),'color','g')
% hold on
% plot([0,durAftStim],[0.3 0.3],'c-','LineWidth',4)
% ylabel('norm finger 13 distance')
% xlabel('time (sec)')
% title('FezF2-Frontal-InhOn')
% 
% traceIdx = randi(hlcnt.plex.front.inhOff,nTraces,1);
% ax2(3) = subplot(4,2,3);
% plot(sgTm,inhOff.plex.front.fing13(:,traceIdx ),'color',[0.5 0.5 0.5])
% hold on
% plot([0,durAftStim],[0.3 0.3],'c-','LineWidth',4)
% ylabel('norm finger 13 distance')
% xlabel('time (sec)')
% title('PlexinD1-Frontal-InhOff')
% 
% traceIdx = randi(hlcnt.plex.front.inhOn,nTraces,1);
% ax2(4) = subplot(4,2,4);
% plot(sgTm,inhOn.plex.front.fing13(:,traceIdx ),'color','b')
% hold on
% plot([0,durAftStim],[0.3 0.3],'c-','LineWidth',4)
% ylabel('norm finger 13 distance')
% xlabel('time (sec)')
% title('PlexinD1-Frontal-InhOn')
% 
% traceIdx = randi(hlcnt.fez.fla.inhOff,nTraces,1);
% ax2(5) = subplot(4,2,5);
% plot(sgTm,inhOff.fez.fla.fing13(:,traceIdx ),'color',[0.5 0.5 0.5])
% hold on
% plot([0,durAftStim],[0.3 0.3],'c-','LineWidth',4)
% ylabel('norm finger 13 distance')
% xlabel('time (sec)')
% title('FezF2-FLA-InhOff')
% 
% traceIdx = randi(hlcnt.fez.fla.inhOn,nTraces,1);
% ax2(6) = subplot(4,2,6);
% plot(sgTm,inhOn.fez.fla.fing13(:,traceIdx ),'color','g')
% hold on
% plot([0,durAftStim],[0.3 0.3],'c-','LineWidth',4)
% ylabel('norm finger 13 distance')
% xlabel('time (sec)')
% title('FezF2-FLA-InhOn')
% 
% traceIdx = randi(hlcnt.plex.fla.inhOff,nTraces,1);
% ax2(7) = subplot(4,2,7);
% plot(sgTm,inhOff.plex.fla.fing13(:,traceIdx ),'color',[0.5 0.5 0.5])
% hold on
% plot([0,durAftStim],[0.3 0.3],'c-','LineWidth',4)
% ylabel('norm finger 13 distance')
% xlabel('time (sec)')
% title('PlexinD1-FLA-InhOff')
% 
% traceIdx = randi(hlcnt.plex.fla.inhOn,nTraces,1);
% ax2(8) = subplot(4,2,8);
% plot(sgTm,inhOn.plex.fla.fing13(:,traceIdx ),'color','b')
% hold on
% plot([0,durAftStim],[0.3 0.3],'c-','LineWidth',4)
% ylabel('norm finger 13 distance')
% xlabel('time (sec)')
% title('Plexind1-FLA-InhOn')
% sgtitle("Finger 1 3 distance")
% linkaxes(ax2)
% %% plot average trace
% h(5) = figure;h(5).Position = [1100 50 1117 687];
% ax3(1) = subplot(2,2,1);
% patch([sgTm fliplr(sgTm)],[inhOff_fez_frontMn.fing13 - 2*inhOff_fez_frontSem.fing13; ...
%     flipud(inhOff_fez_frontMn.fing13 + 2*inhOff_fez_frontSem.fing13)],'k','FaceAlpha',0.3,'EdgeColor','none')
% hold on
% plot(sgTm,inhOff_fez_frontMn.fing13,'k-','LineWidth',1)
% 
% patch([sgTm fliplr(sgTm)],[inhOn_fez_frontMn.fing13 - 2*inhOn_fez_frontSem.fing13; ...
%     flipud(inhOn_fez_frontMn.fing13 + 2*inhOn_fez_frontSem.fing13)],'g','FaceAlpha',0.3,'EdgeColor','none')
% plot(sgTm,inhOn_fez_frontMn.fing13,'g-','LineWidth',1)
% 
% plot([0,durAftStim],[0.2 0.2],'c-','LineWidth',4)
% ylabel('norm finger 13 distance')
% xlabel('time (sec)')
% xlim([-1,durAftStim])
% title('FezF2-Frontal')
% 
% ax3(2) = subplot(2,2,2);
% patch([sgTm fliplr(sgTm)],[inhOff_plex_frontMn.fing13 - 2*inhOff_plex_frontSem.fing13; ...
%     flipud(inhOff_plex_frontMn.fing13 + 2*inhOff_plex_frontSem.fing13)],'k','FaceAlpha',0.3,'EdgeColor','none')
% hold on
% plot(sgTm,inhOff_plex_frontMn.fing13,'k-','LineWidth',1)
% 
% patch([sgTm fliplr(sgTm)],[inhOn_plex_frontMn.fing13 - 2*inhOn_plex_frontSem.fing13; ...
%     flipud(inhOn_plex_frontMn.fing13 + 2*inhOn_plex_frontSem.fing13)],'b','FaceAlpha',0.3,'EdgeColor','none')
% plot(sgTm,inhOn_plex_frontMn.fing13,'b-','LineWidth',1)
% 
% plot([0,durAftStim],[0.2 0.2],'c-','LineWidth',4)
% ylabel('norm finger 13 distance')
% xlabel('time (sec)')
% xlim([-1,durAftStim])
% title('PlexinD1-Frontal')
% 
% ax3(3) = subplot(2,2,3);
% patch([sgTm fliplr(sgTm)],[inhOff_fez_flaMn.fing13 - 2*inhOff_fez_flaSem.fing13; ...
%     flipud(inhOff_fez_flaMn.fing13 + 2*inhOff_fez_flaSem.fing13)],'k','FaceAlpha',0.3,'EdgeColor','none')
% hold on
% plot(sgTm,inhOff_fez_flaMn.fing13,'k-','LineWidth',1)
% 
% patch([sgTm fliplr(sgTm)],[inhOn_fez_flaMn.fing13 - 2*inhOn_fez_flaSem.fing13; ...
%     flipud(inhOn_fez_flaMn.fing13 + 2*inhOn_fez_flaSem.fing13)],'g','FaceAlpha',0.3,'EdgeColor','none')
% plot(sgTm,inhOn_fez_flaMn.fing13,'g-','LineWidth',1)
% 
% plot([0,durAftStim],[0.2 0.2],'c-','LineWidth',4)
% ylabel('norm finger 13 distance')
% xlabel('time (sec)')
% xlim([-1,durAftStim])
% title('FezF2-FLA')
% 
% ax3(4) = subplot(2,2,4);
% patch([sgTm fliplr(sgTm)],[inhOff_plex_flaMn.fing13 - 2*inhOff_plex_flaSem.fing13; ...
%     flipud(inhOff_plex_flaMn.fing13 + 2*inhOff_plex_flaSem.fing13)],'k','FaceAlpha',0.3,'EdgeColor','none')
% hold on
% plot(sgTm,inhOff_plex_flaMn.fing13,'k-','LineWidth',1)
% 
% patch([sgTm fliplr(sgTm)],[inhOn_plex_flaMn.fing13 - 2*inhOn_plex_flaSem.fing13; ...
%     flipud(inhOn_plex_flaMn.fing13 + 2*inhOn_plex_flaSem.fing13)],'b','FaceAlpha',0.3,'EdgeColor','none')
% plot(sgTm,inhOn_plex_flaMn.fing13,'b-','LineWidth',1)
% 
% plot([0,durAftStim],[0.2 0.2],'c-','LineWidth',4)
% ylabel('norm finger 13 distance')
% xlabel('time (sec)')
% xlim([-1,durAftStim])
% title('PlexinD1-FLA')
% linkaxes(ax3)
% sgtitle('Finger 13 distance')
% %% box plot
% h(6) = figure;h(6).Position = [1070 158 1242 695];
% grpId = [repmat("fez-frontal-inhOff",hlcnt.fez.front.inhOff,1); repmat("fez-frontal-inhOn",hlcnt.fez.front.inhOn,1); ...
%     repmat("plex-frontal-inhOff",hlcnt.plex.front.inhOff,1); repmat("plex-frontal-inhOn",hlcnt.plex.front.inhOn,1); ...
%     repmat("fez-fla-inhOff",hlcnt.fez.fla.inhOff,1); repmat("fez-fla-inhOn",hlcnt.fez.fla.inhOn,1); ...
%     repmat("plex-fla-inhOff",hlcnt.plex.fla.inhOff,1); repmat("plex-fla-inhOn",hlcnt.plex.fla.inhOn,1)];
% 
% 
% 
% boxplot(dataIn.fing13,grpId);
% ylabel('finger 1 3 distance')
% text(1.2,0.22,['pVal = ' num2str(fez_front_inhOffVsOn.fing13)])
% text(3.2,0.22,['pVal = ' num2str(plex_front_inhOffVsOn.fing13)])
% text(5.2,0.22,['pVal = ' num2str(fez_fla_inhOffVsOn.fing13)])
% text(7.2,0.22,['pVal = ' num2str(plex_fla_inhOffVsOn.fing13)])
% text(4.5,0.24 , '3 Way anova')
% sgtitle('Finger 1 3 distance')
%% %%%%%%%%%%%%% saving the figures %%%%%%%%%%

saveFig = input('Do you want to save the current figures : ');
if saveFig == 1
    %%% saving figures
    savepath = fullfile(['G:\Hemanth_CSHL\OptoWiredInhibition\Data_Figures\InterFingDistPlots\'], ...
        ['interFingDist_FezPlex.fig']);
    savefig(h,savepath)
end
