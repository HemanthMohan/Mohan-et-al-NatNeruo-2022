clear all; close all; clc
[fname fpath] = uigetfile('*.csv');
%% %%%%%%%%%%%%%%% enter details to group sessions %%%%%%%%%%%%%
roiName = {'Fla'}; %% Frontal; Fla;
%%% fez properties %%%
% mouseIds = {'c16m1';'c17m1';'c17m2';};
% handedness= {'right';'left';'right'};
% mouseType = ['FezF2Gtacr1'];
% sessionType = ['optowire'];
%   dateIn = {'20220601';'20220602';'20220603';'20220606';'20220607';'20220608';'20220609';'20220610'; ...
%       '20220611';'20220614';'20220615';'20220616';'20220617';'20220708';'20220711';'20220712'; ...
%       '20220713';'20220714';'20220715';'20220718';'20220719';'20220720';'20220721';'20220722';'20220723'; ...
%       '20220725';'20220727';'20220728';'20220729'};

%%% plex properties %%%
mouseIds = {'c15m2';'c15m3';'c17m1';'c17m2'};
handedness= {'left';'right';'left';'left'};
mouseType = ['PlexinD1Gtacr1']; %% fe
sessionType = ['optowire'];
  dateIn = {'20220601';'20220602';'20220603';'20220606';'20220607';'20220608';'20220609';'20220610'; ...
      '20220611';'20220614';'20220615';'20220616';'20220617';'20220708';'20220711';'20220712'; ...
      '20220713';'20220714';'20220715';'20220718';'20220719';'20220720';'20220721';'20220722';'20220723'; ...
      '20220725';'20220727';'20220728';'20220729'};
%% %%%%%%%%%%%%%%%%%%% get file  name structure %%%%%%%%%%%%
parentFold = fileparts(fileparts(fpath));
foldNames = [];
for jj = 1:length(mouseIds)
    for ii = 1:length(dateIn)
        FoldCont = dir(fullfile(fileparts(fileparts(fpath)),[dateIn{ii} '*', mouseType '*', mouseIds{jj} '*',sessionType '*']));
        foldNames = [foldNames;{FoldCont.name}'];
    end
end
%% %%%%%%%%%%%%%%% get Trial IDs and trajectories of control and inbhibition handlift trials
for kk = 1:length(foldNames)
    fpath1 = [fullfile(parentFold,foldNames{kk}) '\']
    [inhOn_PimOn{kk,1},inhOff_PimOn{kk,1}] = getTrajData(fpath1,roiName,mouseIds,handedness);
end
%% extract inhibition on and off first finger trajectorires
inhOnTj.Fing1.y = [];
inhOnTj.Fing2.y = [];
inhOnTj.Fing3.y = [];
inhOnTj.Fing1.x = [];
inhOnTj.Fing2.x = [];
inhOnTj.Fing3.x = [];
inhOnTj.fileTrialRefIdx = {};

inhOffTj.Fing1.y = [];
inhOffTj.Fing2.y = [];
inhOffTj.Fing3.y = [];
inhOffTj.Fing1.x = [];
inhOffTj.Fing2.x = [];
inhOffTj.Fing3.x = [];
stimStartEnd = [];
inhOffTj.fileTrialRefIdx = {};
k = 1;
for ii = 1:length(inhOn_PimOn)
    tempInhOnIdx = inhOn_PimOn{ii}.pimOnIdx(~isnan(inhOn_PimOn{ii}.pimOnIdx));
    tempInhOffIdx = inhOff_PimOn{ii}.pimOnIdx;
    handUsed = inhOn_PimOn{ii}.handUsed;
    for jj = 1:length(tempInhOffIdx)    
        inhOnTj.fileTrialRefIdx = [inhOnTj.fileTrialRefIdx; [k,foldNames(ii),tempInhOnIdx(jj)]];
        if strcmp('right',handUsed)
            inhOnTj.Fing1.y = [inhOnTj.Fing1.y inhOn_PimOn{ii}.ulNormTraj.C1(jj).rfing1(:,2)];
            inhOnTj.Fing2.y = [inhOnTj.Fing2.y inhOn_PimOn{ii}.ulNormTraj.C1(jj).rfing2(:,2)];
            inhOnTj.Fing3.y = [inhOnTj.Fing3.y inhOn_PimOn{ii}.ulNormTraj.C1(jj).rfing3(:,2)];
            inhOnTj.Fing1.x = [inhOnTj.Fing1.x inhOn_PimOn{ii}.ulNormTraj.C1(jj).rfing1(:,1)];
            inhOnTj.Fing2.x = [inhOnTj.Fing2.x inhOn_PimOn{ii}.ulNormTraj.C1(jj).rfing2(:,1)];
            inhOnTj.Fing3.x = [inhOnTj.Fing3.x inhOn_PimOn{ii}.ulNormTraj.C1(jj).rfing3(:,1)];
        elseif strcmp('left',handUsed)
            inhOnTj.Fing1.y = [inhOnTj.Fing1.y inhOn_PimOn{ii}.ulNormTraj.C1(jj).lfing1(:,2)];
            inhOnTj.Fing2.y = [inhOnTj.Fing2.y inhOn_PimOn{ii}.ulNormTraj.C1(jj).lfing2(:,2)];
            inhOnTj.Fing3.y = [inhOnTj.Fing3.y inhOn_PimOn{ii}.ulNormTraj.C1(jj).lfing3(:,2)];
            inhOnTj.Fing1.x = [inhOnTj.Fing1.x inhOn_PimOn{ii}.ulNormTraj.C1(jj).lfing1(:,1)];
            inhOnTj.Fing2.x = [inhOnTj.Fing2.x inhOn_PimOn{ii}.ulNormTraj.C1(jj).lfing2(:,1)];
            inhOnTj.Fing3.x = [inhOnTj.Fing3.x inhOn_PimOn{ii}.ulNormTraj.C1(jj).lfing3(:,1)];
        end
            
        
        
        inhOffTj.fileTrialRefIdx = [inhOffTj.fileTrialRefIdx; [k,foldNames(ii),tempInhOffIdx(jj)]];
        if strcmp('right',handUsed)
            inhOffTj.Fing1.y = [inhOffTj.Fing1.y inhOff_PimOn{ii}.ulNormTraj.C1(jj).rfing1(:,2)];
            inhOffTj.Fing2.y = [inhOffTj.Fing2.y inhOff_PimOn{ii}.ulNormTraj.C1(jj).rfing2(:,2)];
            inhOffTj.Fing3.y = [inhOffTj.Fing3.y inhOff_PimOn{ii}.ulNormTraj.C1(jj).rfing3(:,2)];
            inhOffTj.Fing1.x = [inhOffTj.Fing1.x inhOff_PimOn{ii}.ulNormTraj.C1(jj).rfing1(:,1)];
            inhOffTj.Fing2.x = [inhOffTj.Fing2.x inhOff_PimOn{ii}.ulNormTraj.C1(jj).rfing2(:,1)];
            inhOffTj.Fing3.x = [inhOffTj.Fing3.x inhOff_PimOn{ii}.ulNormTraj.C1(jj).rfing3(:,1)];
        elseif strcmp('left',handUsed)
            inhOffTj.Fing1.y = [inhOffTj.Fing1.y inhOff_PimOn{ii}.ulNormTraj.C1(jj).lfing1(:,2)];
            inhOffTj.Fing2.y = [inhOffTj.Fing2.y inhOff_PimOn{ii}.ulNormTraj.C1(jj).lfing2(:,2)];
            inhOffTj.Fing3.y = [inhOffTj.Fing3.y inhOff_PimOn{ii}.ulNormTraj.C1(jj).lfing3(:,2)];
            inhOffTj.Fing1.x = [inhOffTj.Fing1.x inhOff_PimOn{ii}.ulNormTraj.C1(jj).lfing1(:,1)];
            inhOffTj.Fing2.x = [inhOffTj.Fing2.x inhOff_PimOn{ii}.ulNormTraj.C1(jj).lfing2(:,1)];
            inhOffTj.Fing3.x = [inhOffTj.Fing3.x inhOff_PimOn{ii}.ulNormTraj.C1(jj).lfing3(:,1)];
        end
        
        k = k+1;
        stimStartEnd = [stimStartEnd;inhOn_PimOn{ii}.stimStartEnd(jj,:)];
    end
    
    disp( [num2str(ii) ' length StimStartEnd : ' num2str(size(inhOn_PimOn{ii}.stimStartEnd,1)) ...
        ', length Traces : ' num2str(length(tempInhOffIdx))])
end
%% %%%%%%%%%% extract inter finger distances
durBefStim = 2;
durAftStim = 5;
trCnt = size(stimStartEnd,1);
fs = 100;
tm = linspace(0,15,1500);
sigTm = -durBefStim:1/fs:durAftStim;sigTm(end) = [];
inhOnFingDist.fing12 =[];
inhOnFingDist.fing13 = [];
inhOnFingDist.fing23 = [];

inhOffFingDist.fing12 = [];
inhOffFingDist.fing13 = [];
inhOffFingDist.fing23 = [];

for j = 1:trCnt
    inIdx = find(tm > stimStartEnd(j,1)-durBefStim & tm < stimStartEnd(j,1)+durAftStim);
    inhOnFingDist.fing12(:,j) = sqrt((inhOnTj.Fing1.x(inIdx,j) - inhOnTj.Fing2.x(inIdx,j)).^2 + (inhOnTj.Fing1.y(inIdx,j) - inhOnTj.Fing2.y(inIdx,j)).^2);
    inhOnFingDist.fing13(:,j) = sqrt((inhOnTj.Fing1.x(inIdx,j) - inhOnTj.Fing3.x(inIdx,j)).^2 + (inhOnTj.Fing1.y(inIdx,j) - inhOnTj.Fing3.y(inIdx,j)).^2);
    inhOnFingDist.fing23(:,j) = sqrt((inhOnTj.Fing2.x(inIdx,j) - inhOnTj.Fing3.x(inIdx,j)).^2 + (inhOnTj.Fing2.y(inIdx,j) - inhOnTj.Fing3.y(inIdx,j)).^2);
    
    inhOffFingDist.fing12(:,j) = sqrt((inhOffTj.Fing1.x(inIdx,j) - inhOffTj.Fing2.x(inIdx,j)).^2 + (inhOffTj.Fing1.y(inIdx,j) - inhOffTj.Fing2.y(inIdx,j)).^2);
    inhOffFingDist.fing13(:,j) = sqrt((inhOffTj.Fing1.x(inIdx,j) - inhOffTj.Fing3.x(inIdx,j)).^2 + (inhOffTj.Fing1.y(inIdx,j) - inhOffTj.Fing3.y(inIdx,j)).^2);
    inhOffFingDist.fing23(:,j) = sqrt((inhOffTj.Fing2.x(inIdx,j) - inhOffTj.Fing3.x(inIdx,j)).^2 + (inhOffTj.Fing2.y(inIdx,j) - inhOffTj.Fing3.y(inIdx,j)).^2);
end

%% clean jumps in data
inhOnFingDist.fing12(inhOnFingDist.fing12>0.2) = nan;
inhOnFingDist.fing13(inhOnFingDist.fing13>0.35) = nan;
inhOnFingDist.fing23(inhOnFingDist.fing23>0.2) = nan;

inhOffFingDist.fing12(inhOffFingDist.fing12>0.2) = nan;
inhOffFingDist.fing13(inhOffFingDist.fing13>0.35) = nan;
inhOffFingDist.fing23(inhOffFingDist.fing23>0.2) = nan;


% inhOnFingDist.fing12(isnan(inhOnFingDist.fing12)) = nanmin(inhOnFingDist.fing12(:));
% inhOffFingDist.fing12(isnan(inhOffFingDist.fing12)) = nanmin(inhOffFingDist.fing12(:));
%%
inhOnFingDist.fing12Mn = nanmean(inhOnFingDist.fing12,2);
inhOnFingDist.fing12Sem = nanstd(inhOnFingDist.fing12,[],2)./sqrt(size(inhOnFingDist.fing12,2)) ;
inhOnFingDist.fing13Mn = nanmean(inhOnFingDist.fing13,2);
inhOnFingDist.fing13Sem = nanstd(inhOnFingDist.fing13,[],2)./sqrt(size(inhOnFingDist.fing13,2)) ;

inhOffFingDist.fing12Mn = nanmean(inhOffFingDist.fing12,2);
inhOffFingDist.fing12Sem = nanstd(inhOffFingDist.fing12,[],2)./sqrt(size(inhOffFingDist.fing12,2)) ;
inhOffFingDist.fing13Mn = nanmean(inhOffFingDist.fing13,2);
inhOffFingDist.fing13Sem = nanstd(inhOffFingDist.fing13,[],2)./sqrt(size(inhOffFingDist.fing13,2)) ;


inhOnFingDist.fing12Avg = nanmean(inhOnFingDist.fing12((sigTm>0),:),1);
inhOnFingDist.fing13Avg = nanmean(inhOnFingDist.fing13((sigTm>0),:),1);
inhOnFingDist.fing23Avg = nanmean(inhOnFingDist.fing23((sigTm>0),:),1);

inhOffFingDist.fing12Avg = nanmean(inhOffFingDist.fing12((sigTm>0),:),1);
inhOffFingDist.fing13Avg = nanmean(inhOffFingDist.fing13((sigTm>0),:),1);
inhOffFingDist.fing23Avg = nanmean(inhOffFingDist.fing23((sigTm>0),:),1);
%% plotting data
close all
h1 = figure; h1.Position = [424 104 1147 803];
subplot(2,2,1)
patch([sigTm fliplr(sigTm)],[inhOffFingDist.fing12Mn-2*inhOffFingDist.fing12Sem ;  ...
    flipud(inhOffFingDist.fing12Mn+2*inhOffFingDist.fing12Sem)],'k','FaceAlpha',0.3,'EdgeColor','none' )
hold on
plot(sigTm, inhOffFingDist.fing12Mn,'k','LineWidth',1)
patch([sigTm fliplr(sigTm)],[inhOnFingDist.fing12Mn-2*inhOnFingDist.fing12Sem ;  flipud(inhOnFingDist.fing12Mn+2*inhOnFingDist.fing12Sem)],'g','FaceAlpha',0.3,'EdgeColor','none' )
plot(sigTm, inhOnFingDist.fing12Mn,'g','LineWidth',1)
plot([0,durAftStim],[0.1,0.1],'g-','LineWidth',5)
xlim([sigTm(1) sigTm(end)])
hold off
xlabel('time (sec)')
ylabel('Inter fing1 - fing 2 distance')


subplot(2,2,2)
[hPos,pPos] = ttest2(inhOffFingDist.fing12Avg,inhOnFingDist.fing12Avg)
boxId = [repmat("inhOff",length(inhOffFingDist.fing12Avg),1); repmat("inhOn",length(inhOnFingDist.fing12Avg),1)];
boxplot([inhOffFingDist.fing12Avg;inhOnFingDist.fing12Avg],boxId)
text(1.2,0.1,['ttest pVal = ' num2str(pPos)])

subplot(2,2,3)
patch([sigTm fliplr(sigTm)],[inhOffFingDist.fing13Mn-2*inhOffFingDist.fing13Sem ;  ...
    flipud(inhOffFingDist.fing13Mn+2*inhOffFingDist.fing13Sem)],'k','FaceAlpha',0.3,'EdgeColor','none' )
hold on
plot(sigTm, inhOffFingDist.fing13Mn,'k','LineWidth',1)
patch([sigTm fliplr(sigTm)],[inhOnFingDist.fing13Mn-2*inhOnFingDist.fing13Sem ; ...
    flipud(inhOnFingDist.fing13Mn+2*inhOnFingDist.fing13Sem)],'g','FaceAlpha',0.3,'EdgeColor','none' )
plot(sigTm, inhOnFingDist.fing13Mn,'g','LineWidth',1)
plot([0,durAftStim],[0.1,0.1],'g-','LineWidth',5)
xlim([sigTm(1) sigTm(end)])
hold off
xlabel('time (sec)')
ylabel('Inter fing1 - fing 3 distance')

subplot(2,2,4)
[hPos,pPos] = ttest2(inhOffFingDist.fing13Avg,inhOnFingDist.fing13Avg)
boxId = [repmat("inhOff",length(inhOffFingDist.fing13Avg),1); repmat("inhOn",length(inhOnFingDist.fing13Avg),1)];
boxplot([inhOffFingDist.fing13Avg;inhOnFingDist.fing13Avg],boxId)
text(1.2,0.2,['ttest pVal = ' num2str(pPos)])

%% saving data
data.durBefStim = durBefStim;
data.durAftStim = durAftStim;
data.sigTm = sigTm;
data.inhOnFingTraj = inhOnTj;
data.inhOn_TrialRef = inhOnTj.fileTrialRefIdx;
data.inhOnFingerDist = inhOnFingDist;

data.inhOffFingTraj = inhOffTj;
data.inhOff_TrialRef = inhOffTj.fileTrialRefIdx;
data.inhOffFingerDist = inhOffFingDist;

data.roiName = roiName;
data.mouseIds = mouseIds;
data.mouseType = mouseType;
data.handedness = handedness;
data.datesAnalyzed = dateIn;
data.FoldersAnalyzed = foldNames;

%% %%%%%%%%% saving the data %%%%%%%%%%

filename = ['InterFingerDistance_' roiName{1} '_' mouseType '.mat'];
saveData = input('Do you want to save the current data : ');
if saveData == 1
    %%% saving data
    savePath = fullfile('G:\Hemanth_CSHL\OptoWiredInhibition\Data_Analysis\ManipInterFingerDistance\' ,filename);
    save(savePath,'data')
end

%% %%%%%%%% main function
function [inhOn_pimOn,inhOff_pimOn] = getTrajData(fpath,roiName,mouseIds,handedness)
%% %%%%%%%%%%%%%%%% get file  name structure %%%%%%%%%%%%

[fnFeat, usFeat ] = getOptoFileNameProperties(fpath);%%% get all fileNames variables
%% check handedness id
for h = 1:length(mouseIds)
    if contains(lower(fpath),mouseIds{h})
        handUsed = handedness{h};
    end
end

%% %%%%%%%%%%%%%%% Get Lick, Pim, Handlift Behavior Trial IDs %%%%%%%%%%%%%%%
disp('Extracting Behavior Temporal features .... ')
ExtractManipulaion = 0;%%%%% Enter zero to not extract manipulation times and 1 to extract
[BData] = GetBehavEventTimesOptoWire(fpath,ExtractManipulaion);
allTrialIdx = cell2mat(BData.Data(:,1));
lickOnsetAll = BData.Data(:,9);
pimOnsetAll = BData.Data(:,10);
hlOnsetAll = BData.Data(:,11);
lickOnIdx = find(cell2mat(BData.Data(:,2)) == 1);
pimOnIdx = find(cell2mat(BData.Data(:,2)) == 1 & cell2mat(BData.Data(:,3)) == 1);
% hlOnIdx = find(cell2mat(BData.Data(:,2)) == 1 & cell2mat(BData.Data(:,3)) == 1 & cell2mat(BData.Data(:,4)) == 1);
hlOnIdx = find(~cellfun(@isempty,hlOnsetAll));

bTime = linspace(0,15,1500);
%% %%% get roi stimulation index and parameters
roiParms = getRoiStimTrialIdx(fnFeat);
inhOn_Idx = roiParms.LzOnIdx;
%% Get trials with Hand lift event during frontal inhibition.
inhOn_pimOn_idx = nan(length(roiParms.(['LzOn' roiName{1} 'Idx'])),1);
inhOn_pimOff_idx = nan(length(roiParms.(['LzOn' roiName{1} 'Idx'])),1);
inhOn_ulNormTrajC2 = [];
inhOn_ulNormTrajC1 = [];
stimStartEnd = [];

for ii = 1:length(roiParms.(['LzOn' roiName{1} 'Idx']))
    inIdx = roiParms.(['LzOn' roiName{1} 'Idx'])(ii); %%% which index is being analyzed
    stimOnset = roiParms.(['LzOn' roiName{1} 'Parm']){ii,3}; %% stim onset time in seconds
    stimDur = roiParms.(['LzOn' roiName{1} 'Parm']){ii,4}; %% stim duration time in seconds
    stimEndTime = stimOnset + stimDur; %%% stim end time in seconds
    stimStartEnd = [stimStartEnd; [stimOnset stimEndTime]];
    %%
    [trajDataC1,trajDataC2,bodyPartsC1,bodyPartsC2 ] = getBehaviorTrajectory(fpath,fnFeat,usFeat,inIdx);
    %% collect upperlip normalized trajectories
    for jj = 1:length(fieldnames(trajDataC1))
        inhOn_ulNormTrajC1(ii).(bodyPartsC1{jj}) = (trajDataC1.(bodyPartsC1{jj})(:,1:2) - nanmean(trajDataC1.upperlip(:,1:2)))./nanmean(trajDataC1.upperlip(:,1:2));
    end
    
    for jj = 1:length(fieldnames(trajDataC2))
        inhOn_ulNormTrajC2(ii).(bodyPartsC2{jj}) = (trajDataC2.(bodyPartsC2{jj})(:,1:2) - nanmean(trajDataC2.upperlip(:,1:2)))./nanmean(trajDataC2.upperlip(:,1:2));
    end
    
    %%
    if sum(inIdx == pimOnIdx) == 1 %% check if the animal picks the pellet in mouth
        pimOnTime = pimOnsetAll{inIdx};
        if pimOnTime < stimEndTime % check if pim happend before end of stimulation and not after
            inhOn_pimOn_idx(ii) = inIdx; %%% trials with pim where inhibition starts within 0.5 seconds of pim
        else
            inhOn_pimOff_idx(ii) = inIdx;
        end
    else
        inhOn_pimOff_idx(ii) = inIdx;
    end
    
end

inhOn_pimOn.ulNormTraj.C1 = inhOn_ulNormTrajC1(~isnan(inhOn_pimOn_idx));
inhOn_pimOn.ulNormTraj.C2 = inhOn_ulNormTrajC2(~isnan(inhOn_pimOn_idx));
inhOn_pimOn.stimStartEnd = stimStartEnd(~isnan(inhOn_pimOn_idx),:);
inhOn_pimOn.pimOnIdx = inhOn_pimOn_idx;
inhOn_pimOn.pimOffIdx = inhOn_pimOff_idx;
inhOn_pimOn.handUsed = handUsed;
%% Get Trials with hand lift during control trials
inhOff_pimOnIdxAll = intersect(roiParms.LzOffIdx,pimOnIdx); %% get trials with pim duirng no inhibition
%% remove inhintion on trials if it is more than inhibtiobn off trials
if length(inhOff_pimOnIdxAll)< sum(~isnan(inhOn_pimOn_idx))
    inhOn_pimOn_idx(1:end-length(inhOff_pimOnIdxAll)) = nan;
end


%% remove late pim trials
pimOnTh = max(stimStartEnd(:));
for p = 1:length(inhOff_pimOnIdxAll)
    inIdx = inhOff_pimOnIdxAll(p);
    if pimOnsetAll{inIdx} > pimOnTh 
        inhOff_pimOnIdxAll(p) = nan;
    end
end
inhOff_pimOnIdxAll(isnan(inhOff_pimOnIdxAll)) = [];
%% get Pim On Indices of trials just before the inhibition on trials
inhOff_pimOn_idx = []; 
for kk = 1:length(inhOn_pimOn_idx)
    inhOff_pimOn_idx = [inhOff_pimOn_idx; inhOff_pimOnIdxAll(find(inhOff_pimOnIdxAll<inhOn_pimOn_idx(kk),1,'last'))]; %% get index id of pim on trial just before the inhibition trial
end

% find repeat trials and replace it with an older trial idx
[unqVal unqLoc] = unique(inhOff_pimOn_idx,'first');
repeatLoc = find(not(ismember(1:numel(inhOff_pimOn_idx),unqLoc)));
for kk = 1:length(repeatLoc)
    temp1 =  setdiff(inhOff_pimOnIdxAll(find(inhOff_pimOnIdxAll<inhOff_pimOn_idx(repeatLoc(kk)))), inhOff_pimOn_idx);
    if ~isempty(temp1)
    inhOff_pimOn_idx(repeatLoc(kk)) = temp1(end); %% unique indices of lazer off indices
    else
     inhOff_pimOn_idx(repeatLoc(kk)) =  inhOff_pimOnIdxAll(randi(length(inhOff_pimOnIdxAll)));
    end
end
%% get inh off trajectories
for pp = 1:length(inhOff_pimOn_idx)
    [trajDataC1,trajDataC2,bodyPartsC1,bodyPartsC2 ] = getBehaviorTrajectory(fpath,fnFeat,usFeat,inhOff_pimOn_idx(pp));
    
    for jj = 1:length(fieldnames(trajDataC1))
        inhOff_pimOn.ulNormTraj.C1(pp).(bodyPartsC1{jj}) = (trajDataC1.(bodyPartsC1{jj})(:,1:2) - nanmean(trajDataC1.upperlip(:,1:2)))./nanmean(trajDataC1.upperlip(:,1:2));
    end
    
    for jj = 1:length(fieldnames(trajDataC2))
        inhOff_pimOn.ulNormTraj.C2(pp).(bodyPartsC2{jj}) = (trajDataC2.(bodyPartsC2{jj})(:,1:2) - nanmean(trajDataC2.upperlip(:,1:2)))./nanmean(trajDataC2.upperlip(:,1:2));
    end
end
inhOff_pimOn.pimOnIdx = inhOff_pimOn_idx;
inhOff_pimOn.handUsed = handUsed;
%%

end

%% extract inhition off trajectory
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Functions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [TrajDataC1,TrajDataC2,BodyPartsC1,BodyPartsC2 ] = getBehaviorTrajectory(fpath,fnFeat,usFeat,FileId)
pcutoffC1 = 0.9;
pcutoffC2 = 0.8;
fnameinC1 = [fnFeat.fname_exC1(1:usFeat.bidx_stC1) num2str(FileId) fnFeat.fname_exC1(usFeat.bidx_endC1:end)];
filepathC1 = fullfile(fpath,fnameinC1);
[TrajDataC1 BodyPartsC1] =  ExtractBodyTraj(filepathC1,pcutoffC1);

fnameinC2 = [fnFeat.fname_exC2(1:usFeat.bidx_stC2) num2str(FileId) fnFeat.fname_exC2(usFeat.bidx_endC2:end)];
filepathC2 = fullfile(fpath,fnameinC2);
[TrajDataC2 BodyPartsC2] =  ExtractBodyTraj(filepathC2,pcutoffC2);
end

function [parms] = getRoiStimTrialIdx(fnFeat)
%% %%%%%%%%%% get laser stimulation parameters and trials
[stimParm,stimHead] = getLaserStimParam(fnFeat);
parms.LzOnIdx = find(cell2mat(stimParm(:,1)) == 1);
parms.LzOffIdx = find(cell2mat(stimParm(:,1)) == 0);
parms.stimHeading = stimHead;
parms.stimParmAll = stimParm;
%% %%%%% Roi Laser On Idx
if strcmp(lower(stimParm(1,2)), 'frontal')
    parms.LzOnFrontalIdx = find(cell2mat(stimParm(:,1)) == 1);
    parms.LzOnFlaIdx = [];
elseif strcmp(lower(stimParm(1,2)), 'fla')
    parms.LzOnFlaIdx = find(cell2mat(stimParm(:,1)) == 1);
    parms.LzOnFrontalIdx = [];
end
%% Roi Laser Parameters
parms.LzOnParm = stimParm(parms.LzOnIdx,:);
parms.LzOnFrontalParm = stimParm(parms.LzOnFrontalIdx,:);
parms.LzOnFlaParm = stimParm(parms.LzOnFlaIdx,:);
end

function [stimParm,stimHead] = getLaserStimParam(fnFeat)
for ii = 1:length(fnFeat.sname_all)
    data = load(fullfile(fnFeat.spath,fnFeat.sname_all{ii})); data = data.data;
    stimParm(ii,:) = data(2,:);
end
stimHead = data(1,:);
end

function [fnFeat, usFeat ] = getOptoFileNameProperties(fpath)
%%%%%%%%%%%%% getting signal file name %%%%%%%%%%%%%%
listing_csv = dir([fpath '\*.csv']);
[~, sflname] = fileparts(fileparts(fpath));
spath = fullfile(fileparts(fileparts(fileparts(fpath))), 'OptoWiredData', sflname);
listing_sig = dir([spath '\*.mat']);
sname_all = natsortfiles({listing_sig.name}');
sname_ex = sname_all{1};
us_idx = find(sname_ex == '_',1,'last');

%%%%%%%% getting body trajectory file name %%%%%%%%%%%%
fname_all = natsortfiles({listing_csv.name}');
fname_allC1 = fname_all( contains(fname_all,'c1_T'));
fname_allC2 = fname_all( contains(fname_all,'c2_T'));

fname_exC1 = fname_allC1{1};
fname_us_idxC1 = find(fname_exC1 == '_');
fname_deep_idxC1 = strfind(fname_exC1, 'Deep');
bidx_stC1 = fname_us_idxC1(end-3);
bidx_endC1 = fname_deep_idxC1;

fname_exC2 = fname_allC2{1};
fname_us_idxC2 = find(fname_exC2 == '_');
fname_deep_idxC2 = strfind(fname_exC2, 'Deep');
bidx_stC2 = fname_us_idxC2(end-3);
bidx_endC2 = fname_deep_idxC2;


%%% updating all properties
fnFeat.sname_all = sname_all;
fnFeat.fname_allC1 = fname_allC1;
fnFeat.fname_allC2 = fname_allC2;
fnFeat.sname_ex = sname_ex;
fnFeat.fname_exC1 = fname_exC1;
fnFeat.fname_exC2 = fname_exC2;
fnFeat.spath = spath;

usFeat.us_idx = us_idx;
usFeat.bidx_stC1 = bidx_stC1;
usFeat.bidx_endC1 = bidx_endC1;
usFeat.bidx_stC2 = bidx_stC2;
usFeat.bidx_endC2 = bidx_endC2;
end