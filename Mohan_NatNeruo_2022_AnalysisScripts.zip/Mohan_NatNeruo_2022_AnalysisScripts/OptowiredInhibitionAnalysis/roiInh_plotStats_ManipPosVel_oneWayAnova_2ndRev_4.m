clear all; close all;clear mem; clc
%% load data
fez.frontal = load(['G:\Hemanth_CSHL\OptoWiredInhibition\Data_Analysis\ManipulationPositionVelocity\' ...
    'ManipulationPosVel_Frontal_FezF2Gtacr1.mat']);
fez.frontal = fez.frontal.data;

fez.fla = load(['G:\Hemanth_CSHL\OptoWiredInhibition\Data_Analysis\ManipulationPositionVelocity\' ...
    'ManipulationPosVel_Fla_FezF2Gtacr1.mat']);
fez.fla = fez.fla.data;

plex.frontal = load(['G:\Hemanth_CSHL\OptoWiredInhibition\Data_Analysis\ManipulationPositionVelocity\' ...
    'ManipulationPosVel_Frontal_PlexinD1Gtacr1.mat']);
plex.frontal = plex.frontal.data;

plex.fla = load(['G:\Hemanth_CSHL\OptoWiredInhibition\Data_Analysis\ManipulationPositionVelocity\' ...
'ManipulationPosVel_Fla_PlexinD1Gtacr1.mat']);
plex.fla = plex.fla.data;
%% get parameters and data

sgTm = fez.frontal.sigTm;
durBefStim = fez.frontal.durBefStim;
durAftStim = fez.frontal.durAftStim;

% get counts of trials
% hlcnt.fez.front.inhOff = sum(~isnan(fez.frontal.inhOff_handliftIdx));
hlcnt.fez.front.inhOn = sum(~isnan(fez.frontal.inhOn_handliftIdx));

% hlcnt.plex.front.inhOff = sum(~isnan(plex.frontal.inhOff_handliftIdx));
hlcnt.plex.front.inhOn = sum(~isnan(plex.frontal.inhOn_handliftIdx));

% hlcnt.fez.fla.inhOff = sum(~isnan(fez.fla.inhOff_handliftIdx));
hlcnt.fez.fla.inhOn = sum(~isnan(fez.fla.inhOn_handliftIdx));

% hlcnt.plex.fla.inhOff = sum(~isnan(plex.fla.inhOff_handliftIdx));
hlcnt.plex.fla.inhOn = sum(~isnan(plex.fla.inhOn_handliftIdx));

% get position traces
inhOn.fez.front.pos = fez.frontal.inhOn_manipulationPosition(:,~isnan(fez.frontal.inhOn_handliftIdx));
inhOff.fez.front.pos = fez.frontal.inhOff_manipulationPosition(:,~isnan(fez.frontal.inhOff_handliftIdx));
inhOff.fez.front.pos = inhOff.fez.front.pos(:,1:hlcnt.fez.front.inhOn);

inhOn.plex.front.pos = plex.frontal.inhOn_manipulationPosition(:,~isnan(plex.frontal.inhOn_handliftIdx));
inhOff.plex.front.pos = plex.frontal.inhOff_manipulationPosition(:,~isnan(plex.frontal.inhOff_handliftIdx));
inhOff.plex.front.pos = inhOff.plex.front.pos(:,1:hlcnt.plex.front.inhOn);

inhOn.fez.fla.pos = fez.fla.inhOn_manipulationPosition(:,~isnan(fez.fla.inhOn_handliftIdx));
inhOff.fez.fla.pos = fez.fla.inhOff_manipulationPosition(:,~isnan(fez.fla.inhOff_handliftIdx));
inhOff.fez.fla.pos = inhOff.fez.fla.pos(:,1:hlcnt.fez.fla.inhOn);

inhOn.plex.fla.pos = plex.fla.inhOn_manipulationPosition(:,~isnan(plex.fla.inhOn_handliftIdx));
inhOff.plex.fla.pos = plex.fla.inhOff_manipulationPosition(:,~isnan(plex.fla.inhOff_handliftIdx));
inhOff.plex.fla.pos = inhOff.plex.fla.pos(:,1:hlcnt.plex.fla.inhOn);

% get velocity traces
inhOn.fez.front.vel = fez.frontal.inhOn_manipulationVelocity(:,~isnan(fez.frontal.inhOn_handliftIdx));
inhOff.fez.front.vel = fez.frontal.inhOff_manipulationVelocity(:,~isnan(fez.frontal.inhOff_handliftIdx));
inhOff.fez.front.vel = inhOff.fez.front.vel(:,1:hlcnt.fez.front.inhOn);

inhOn.plex.front.vel = plex.frontal.inhOn_manipulationVelocity(:,~isnan(plex.frontal.inhOn_handliftIdx));
inhOff.plex.front.vel = plex.frontal.inhOff_manipulationVelocity(:,~isnan(plex.frontal.inhOff_handliftIdx));
inhOff.plex.front.vel =  inhOff.plex.front.vel(:,1:hlcnt.plex.front.inhOn);

inhOn.fez.fla.vel = fez.fla.inhOn_manipulationVelocity(:,~isnan(fez.fla.inhOn_handliftIdx));
inhOff.fez.fla.vel = fez.fla.inhOff_manipulationVelocity(:,~isnan(fez.fla.inhOff_handliftIdx));
inhOff.fez.fla.vel = inhOff.fez.fla.vel(:,1:hlcnt.fez.fla.inhOn);

inhOn.plex.fla.vel = plex.fla.inhOn_manipulationVelocity(:,~isnan(plex.fla.inhOn_handliftIdx));
inhOff.plex.fla.vel = plex.fla.inhOff_manipulationVelocity(:,~isnan(plex.fla.inhOff_handliftIdx));
inhOff.plex.fla.vel = inhOff.plex.fla.vel(:,1:hlcnt.plex.fla.inhOn);


%% extract maximum position and minimum velocity value
% maxPosVal = nanmax([ inhOff.fez.front.pos(:);inhOn.fez.front.pos(:);inhOff.plex.front.pos(:);inhOn.plex.front.pos(:); ...
%     inhOff.fez.fla.pos(:);inhOn.fez.fla.pos(:);inhOff.plex.fla.pos(:);inhOn.plex.fla.pos(:)]);
% minVelVal = nanmin([ inhOff.fez.front.vel(:);inhOn.fez.front.vel(:);inhOff.plex.front.vel(:);inhOn.plex.front.vel(:); ...
%     inhOff.fez.fla.vel(:);inhOn.fez.fla.vel(:);inhOff.plex.fla.vel(:);inhOn.plex.fla.vel(:)]);
% 
% % replace position nan with maximum value
% inhOff.fez.front.pos(isnan(inhOff.fez.front.pos)) = maxPosVal;
% inhOn.fez.front.pos(isnan(inhOn.fez.front.pos)) = maxPosVal;
% 
% inhOff.plex.front.pos(isnan(inhOff.plex.front.pos)) = maxPosVal;
% inhOn.plex.front.pos(isnan(inhOn.plex.front.pos)) = maxPosVal;
% 
% inhOff.fez.fla.pos(isnan(inhOff.fez.fla.pos)) = maxPosVal;
% inhOn.fez.fla.pos(isnan(inhOn.fez.fla.pos)) = maxPosVal;
% 
% inhOff.plex.fla.pos(isnan(inhOff.plex.fla.pos)) = maxPosVal;
% inhOn.plex.fla.pos(isnan(inhOn.plex.fla.pos)) = maxPosVal;
% 
% % replace velocity nan with minimum value
% inhOff.fez.front.vel(isnan(inhOff.fez.front.vel)) = minVelVal;
% inhOn.fez.front.vel(isnan(inhOn.fez.front.vel)) = minVelVal;
% 
% inhOff.plex.front.vel(isnan(inhOff.plex.front.vel)) = minVelVal;
% inhOn.plex.front.vel(isnan(inhOn.plex.front.vel)) = minVelVal;
% 
% inhOff.fez.fla.vel(isnan(inhOff.fez.fla.vel)) = minVelVal;
% inhOn.fez.fla.vel(isnan(inhOn.fez.fla.vel)) = minVelVal;
% 
% inhOff.plex.fla.vel(isnan(inhOff.plex.fla.vel)) = minVelVal;
% inhOn.plex.fla.vel(isnan(inhOn.plex.fla.vel)) = minVelVal;
%% compute data for boxplot stats
aftStimTm = 5; %%% how much seconds after stimulation do you want to consider for stats
stimIdx = find(sgTm>0 & sgTm<aftStimTm);
inhOffAvg_fez_front_pos = nanmean(inhOff.fez.front.pos(stimIdx,:));
inhOnAvg_fez_front_pos = nanmean(inhOn.fez.front.pos(stimIdx,:));

inhOffAvg_plex_front_pos = nanmean(inhOff.plex.front.pos(stimIdx,:));
inhOnAvg_plex_front_pos = nanmean(inhOn.plex.front.pos(stimIdx,:));

inhOffAvg_fez_fla_pos = nanmean(inhOff.fez.fla.pos(stimIdx,:));
inhOnAvg_fez_fla_pos = nanmean(inhOn.fez.fla.pos(stimIdx,:));

inhOffAvg_plex_fla_pos = nanmean(inhOff.plex.fla.pos(stimIdx,:));
inhOnAvg_plex_fla_pos = nanmean(inhOn.plex.fla.pos(stimIdx,:));

inhOffAvg_fez_front_vel = nanmean(inhOff.fez.front.vel(stimIdx(1:end-1),:));
inhOnAvg_fez_front_vel = nanmean(inhOn.fez.front.vel(stimIdx(1:end-1),:));

inhOffAvg_plex_front_vel = nanmean(inhOff.plex.front.vel(stimIdx(1:end-1),:));
inhOnAvg_plex_front_vel = nanmean(inhOn.plex.front.vel(stimIdx(1:end-1),:));

inhOffAvg_fez_fla_vel = nanmean(inhOff.fez.fla.vel(stimIdx(1:end-1),:));
inhOnAvg_fez_fla_vel = nanmean(inhOn.fez.fla.vel(stimIdx(1:end-1),:));

inhOffAvg_plex_fla_vel = nanmean(inhOff.plex.fla.vel(stimIdx(1:end-1),:));
inhOnAvg_plex_fla_vel = nanmean(inhOn.plex.fla.vel(stimIdx(1:end-1),:));
%% diffrence in values between control and inhibition
inhOffOnDiff_fez_front_pos = inhOffAvg_fez_front_pos - inhOnAvg_fez_front_pos;
inhOffOnDiff_plex_front_pos = inhOffAvg_plex_front_pos - inhOnAvg_plex_front_pos;
inhOffOnDiff_fez_fla_pos = inhOffAvg_fez_fla_pos - inhOnAvg_fez_fla_pos;
inhOffOnDiff_plex_fla_pos = inhOffAvg_plex_fla_pos - inhOnAvg_plex_fla_pos;

inhOffOnDiff_fez_front_vel = inhOffAvg_fez_front_vel - inhOnAvg_fez_front_vel;
inhOffOnDiff_plex_front_vel = inhOffAvg_plex_front_vel - inhOnAvg_plex_front_vel;
inhOffOnDiff_fez_fla_vel = inhOffAvg_fez_fla_vel - inhOnAvg_fez_fla_vel;
inhOffOnDiff_plex_fla_vel = inhOffAvg_plex_fla_vel - inhOnAvg_plex_fla_vel;
%% %%%%%%%%%% ttest for individual distribuiton
[~,tTst.fez_front_pos] = ttest(inhOffOnDiff_fez_front_pos);
[~,tTst.plex_front_pos] = ttest(inhOffOnDiff_plex_front_pos);

[~,tTst.fez_fla_pos] = ttest(inhOffOnDiff_fez_fla_pos);
[~,tTst.plex_fla_pos] = ttest(inhOffOnDiff_plex_fla_pos);


[~,tTst.fez_front_vel] = ttest(inhOffOnDiff_fez_front_vel);
[~,tTst.plex_front_vel] = ttest(inhOffOnDiff_plex_front_vel);

[~,tTst.fez_fla_vel] = ttest(inhOffOnDiff_fez_fla_vel);
[~,tTst.plex_fla_vel] = ttest(inhOffOnDiff_plex_fla_vel);
%% 1 way analysis of variance of box plot
g1 = [repmat("fez",hlcnt.fez.front.inhOn,1); repmat("plex",hlcnt.plex.front.inhOn,1); ...
    repmat("fez",hlcnt.fez.fla.inhOn,1); repmat("plex",hlcnt.plex.fla.inhOn,1)];

g2 = [repmat("frontal",hlcnt.fez.front.inhOn,1); repmat("frontal",hlcnt.plex.front.inhOn,1); ...
    repmat("fla",hlcnt.fez.fla.inhOn,1); repmat("fla",hlcnt.plex.fla.inhOn,1)];

% position calculation
dataIn.pos = [inhOffOnDiff_fez_front_pos ...
    inhOffOnDiff_plex_front_pos ...
    inhOffOnDiff_fez_fla_pos ...
    inhOffOnDiff_plex_fla_pos];

grpId = join([g1 g2],"-");
% [p.pos,tbl.pos,stats.pos] = anovan(dataIn.pos,{g1 g2 g3},"Model","full", ...
%     "Varnames",["cellType","Area","inhibition"]);
[p.pos,tbl.pos,stats.pos] = anova1(dataIn.pos,grpId);

[results.pos,~,~,gnames.pos] = multcompare(stats.pos);

fezVsPlex_front_inhOffOnDiff.pos = results.pos(find(results.pos(:,1) == 1 & results.pos(:,2)==2),6);
fezVsPlex_fla_inhOffOnDiff.pos = results.pos(find(results.pos(:,1) == 3 & results.pos(:,2)==4),6);

% velocity calculation
dataIn.vel = [inhOffOnDiff_fez_front_vel ...
    inhOffOnDiff_plex_front_vel ...
    inhOffOnDiff_fez_fla_vel ...
    inhOffOnDiff_plex_fla_vel];

[p.vel,tbl.vel,stats.vel] = anova1(dataIn.vel,grpId);

[results.vel,~,~,gnames.vel] = multcompare(stats.vel);



fezVsPlex_front_inhOffOnDiff.vel = results.vel(find(results.vel(:,1) == 1 & results.vel(:,2)==2),6);
fezVsPlex_fla_inhOffOnDiff.vel = results.vel(find(results.vel(:,1) == 3 & results.vel(:,2)==4),6);
%% compute means and sems for plots
% position
inhOff_fez_frontMn.pos = nanmean(inhOff.fez.front.pos,2);
inhOff_fez_frontSem.pos = nanstd(inhOff.fez.front.pos,[],2)./sqrt(hlcnt.fez.front.inhOn);
inhOn_fez_frontMn.pos = nanmean(inhOn.fez.front.pos,2);
inhOn_fez_frontSem.pos = nanstd(inhOn.fez.front.pos,[],2)./sqrt(hlcnt.fez.front.inhOn);

inhOff_plex_frontMn.pos = nanmean(inhOff.plex.front.pos,2);
inhOff_plex_frontSem.pos = nanstd(inhOff.plex.front.pos,[],2)./sqrt(hlcnt.plex.front.inhOn);
inhOn_plex_frontMn.pos = nanmean(inhOn.plex.front.pos,2);
inhOn_plex_frontSem.pos = nanstd(inhOn.plex.front.pos,[],2)./sqrt(hlcnt.plex.front.inhOn);

inhOff_fez_flaMn.pos = nanmean(inhOff.fez.fla.pos,2);
inhOff_fez_flaSem.pos = nanstd(inhOff.fez.fla.pos,[],2)./sqrt(hlcnt.fez.fla.inhOn);
inhOn_fez_flaMn.pos = nanmean(inhOn.fez.fla.pos,2);
inhOn_fez_flaSem.pos = nanstd(inhOn.fez.fla.pos,[],2)./sqrt(hlcnt.fez.fla.inhOn);

inhOff_plex_flaMn.pos = nanmean(inhOff.plex.fla.pos,2);
inhOff_plex_flaSem.pos = nanstd(inhOff.plex.fla.pos,[],2)./sqrt(hlcnt.plex.fla.inhOn);
inhOn_plex_flaMn.pos = nanmean(inhOn.plex.fla.pos,2);
inhOn_plex_flaSem.pos = nanstd(inhOn.plex.fla.pos,[],2)./sqrt(hlcnt.plex.fla.inhOn);

% velocity
inhOff_fez_frontMn.vel = nanmean(inhOff.fez.front.vel,2);
inhOff_fez_frontSem.vel = nanstd(inhOff.fez.front.vel,[],2)./sqrt(hlcnt.fez.front.inhOn);
inhOn_fez_frontMn.vel = nanmean(inhOn.fez.front.vel,2);
inhOn_fez_frontSem.vel = nanstd(inhOn.fez.front.vel,[],2)./sqrt(hlcnt.fez.front.inhOn);

inhOff_plex_frontMn.vel = nanmean(inhOff.plex.front.vel,2);
inhOff_plex_frontSem.vel = nanstd(inhOff.plex.front.vel,[],2)./sqrt(hlcnt.plex.front.inhOn);
inhOn_plex_frontMn.vel = nanmean(inhOn.plex.front.vel,2);
inhOn_plex_frontSem.vel = nanstd(inhOn.plex.front.vel,[],2)./sqrt(hlcnt.plex.front.inhOn);

inhOff_fez_flaMn.vel = nanmean(inhOff.fez.fla.vel,2);
inhOff_fez_flaSem.vel = nanstd(inhOff.fez.fla.vel,[],2)./sqrt(hlcnt.fez.fla.inhOn);
inhOn_fez_flaMn.vel = nanmean(inhOn.fez.fla.vel,2);
inhOn_fez_flaSem.vel = nanstd(inhOn.fez.fla.vel,[],2)./sqrt(hlcnt.fez.fla.inhOn);

inhOff_plex_flaMn.vel = nanmean(inhOff.plex.fla.vel,2);
inhOff_plex_flaSem.vel = nanstd(inhOff.plex.fla.vel,[],2)./sqrt(hlcnt.plex.fla.inhOn);
inhOn_plex_flaMn.vel = nanmean(inhOn.plex.fla.vel,2);
inhOn_plex_flaSem.vel = nanstd(inhOn.plex.fla.vel,[],2)./sqrt(hlcnt.plex.fla.inhOn);


%% plot traces
% positon
close all
nTraces = 1;
h(1) = figure;h(1).Position = [-1624        -270         817         912];

traceIdx = randi(hlcnt.fez.front.inhOn,nTraces,1);
ax(1) = subplot(4,2,1);
plot(sgTm,inhOff.fez.front.pos(:,traceIdx ),'color',[0.5 0.5 0.5])
set(gca,'YDir','reverse')
hold on
plot([0,durAftStim],[-0.1 -0.1],'c-','LineWidth',4)
ylabel('norm finger Position')
xlabel('time (sec)')
title('FezF2-Frontal-InhOff')

traceIdx = randi(hlcnt.fez.front.inhOn,nTraces,1);
ax(2) = subplot(4,2,2);
plot(sgTm,inhOn.fez.front.pos(:,traceIdx ),'color','g')
set(gca,'YDir','reverse')
hold on
plot([0,durAftStim],[-0.1 -0.1],'c-','LineWidth',4)
ylabel('norm finger Position')
xlabel('time (sec)')
title('FezF2-Frontal-InhOff')
text(-1.5,0.5, [fez.frontal.inhOn_handlifTrialRef{traceIdx,2} '-' ...
    num2str(fez.frontal.inhOn_handlifTrialRef{traceIdx,3})],'interpreter','none');

traceIdx = randi(hlcnt.plex.front.inhOn,nTraces,1);
ax(3) = subplot(4,2,3);
plot(sgTm,inhOff.plex.front.pos(:,traceIdx ),'color',[0.5 0.5 0.5])
set(gca,'YDir','reverse')
hold on
plot([0,durAftStim],[-0.1 -0.1],'c-','LineWidth',4)
ylabel('norm finger Position')
xlabel('time (sec)')
title('PlexinD1-Frontal-InhOff')

traceIdx = randi(hlcnt.plex.front.inhOn,nTraces,1);
ax(4) = subplot(4,2,4);
plot(sgTm,inhOn.plex.front.pos(:,traceIdx ),'color','b')
set(gca,'YDir','reverse')
hold on
plot([0,durAftStim],[-0.1 -0.1],'c-','LineWidth',4)
ylabel('norm finger Position')
xlabel('time (sec)')
title('PlexinD1-Frontal-InhOn')
text(-1.5,0.5, [plex.frontal.inhOn_handlifTrialRef{traceIdx,2} '-' ...
    num2str(plex.frontal.inhOn_handlifTrialRef{traceIdx,3})],'interpreter','none');


traceIdx = randi(hlcnt.fez.fla.inhOn,nTraces,1);
ax(5) = subplot(4,2,5);
plot(sgTm,inhOff.fez.fla.pos(:,traceIdx ),'color',[0.5 0.5 0.5])
set(gca,'YDir','reverse')
hold on
plot([0,durAftStim],[-0.1 -0.1],'c-','LineWidth',4)
ylabel('norm finger Position')
xlabel('time (sec)')
title('FezF2-FLA-InhOff')

traceIdx = randi(hlcnt.fez.fla.inhOn,nTraces,1);
ax(6) = subplot(4,2,6);
plot(sgTm,inhOn.fez.fla.pos(:,traceIdx ),'color','g')
set(gca,'YDir','reverse')
hold on
plot([0,durAftStim],[-0.1 -0.1],'c-','LineWidth',4)
ylabel('norm finger Position')
xlabel('time (sec)')
title('FezF2-FLA-InhOn')
text(-1.5,0.5, [fez.fla.inhOn_handlifTrialRef{traceIdx,2} '-' ...
    num2str(fez.fla.inhOn_handlifTrialRef{traceIdx,3})],'interpreter','none');


traceIdx = randi(hlcnt.plex.fla.inhOn,nTraces,1);
ax(7) = subplot(4,2,7);
plot(sgTm,inhOff.plex.fla.pos(:,traceIdx ),'color',[0.5 0.5 0.5])
set(gca,'YDir','reverse')
hold on
plot([0,durAftStim],[-0.1 -0.1],'c-','LineWidth',4)
ylabel('norm finger Position')
xlabel('time (sec)')
title('PlexinD1-FLA-InhOff')

traceIdx = randi(hlcnt.plex.fla.inhOn,nTraces,1);
ax(8) = subplot(4,2,8);
plot(sgTm,inhOn.plex.fla.pos(:,traceIdx ),'color','b')
set(gca,'YDir','reverse')
hold on
plot([0,durAftStim],[-0.1 -0.1],'c-','LineWidth',4)
ylabel('norm finger Position')
xlabel('time (sec)')
title('PlexinD1-FLA-InhOn')
text(-1.5,0.5, [plex.fla.inhOn_handlifTrialRef{traceIdx,2} '-' ...
    num2str(plex.fla.inhOn_handlifTrialRef{traceIdx,3})],'interpreter','none');

sgtitle("POSITION")
linkaxes(ax)
%% plot average trace
h(2) = figure;h(2).Position = [-1100 50 1117 687];
ax1(1) = subplot(2,2,1);
patch([sgTm fliplr(sgTm)],[inhOff_fez_frontMn.pos - 2*inhOff_fez_frontSem.pos; ...
    flipud(inhOff_fez_frontMn.pos + 2*inhOff_fez_frontSem.pos)],'k','FaceAlpha',0.3,'EdgeColor','none')
hold on
plot(sgTm,inhOff_fez_frontMn.pos,'k-','LineWidth',1)

patch([sgTm fliplr(sgTm)],[inhOn_fez_frontMn.pos - 2*inhOn_fez_frontSem.pos; ...
    flipud(inhOn_fez_frontMn.pos + 2*inhOn_fez_frontSem.pos)],'g','FaceAlpha',0.3,'EdgeColor','none')
plot(sgTm,inhOn_fez_frontMn.pos,'g-','LineWidth',1)

plot([0,durAftStim],[0.05 0.05],'c-','LineWidth',4)
set(gca,'YDir','reverse')
ylabel('norm finger Position')
xlabel('time (sec)')
xlim([-1,durAftStim])
title('FezF2-Frontal')

ax1(2) = subplot(2,2,2);
patch([sgTm fliplr(sgTm)],[inhOff_plex_frontMn.pos - 2*inhOff_plex_frontSem.pos; ...
    flipud(inhOff_plex_frontMn.pos + 2*inhOff_plex_frontSem.pos)],'k','FaceAlpha',0.3,'EdgeColor','none')
hold on
plot(sgTm,inhOff_plex_frontMn.pos,'k-','LineWidth',1)

patch([sgTm fliplr(sgTm)],[inhOn_plex_frontMn.pos - 2*inhOn_plex_frontSem.pos; ...
    flipud(inhOn_plex_frontMn.pos + 2*inhOn_plex_frontSem.pos)],'b','FaceAlpha',0.3,'EdgeColor','none')
plot(sgTm,inhOn_plex_frontMn.pos,'b-','LineWidth',1)

plot([0,durAftStim],[0 0],'c-','LineWidth',4)

set(gca,'YDir','reverse')
ylabel('norm finger Position')
xlabel('time (sec)')
xlim([-1,durAftStim])
title('PlexinD1-Frontal')

ax1(3) = subplot(2,2,3);
patch([sgTm fliplr(sgTm)],[inhOff_fez_flaMn.pos - 2*inhOff_fez_flaSem.pos; ...
    flipud(inhOff_fez_flaMn.pos + 2*inhOff_fez_flaSem.pos)],'k','FaceAlpha',0.3,'EdgeColor','none')
hold on
plot(sgTm,inhOff_fez_flaMn.pos,'k-','LineWidth',1)

patch([sgTm fliplr(sgTm)],[inhOn_fez_flaMn.pos - 2*inhOn_fez_flaSem.pos; ...
    flipud(inhOn_fez_flaMn.pos + 2*inhOn_fez_flaSem.pos)],'g','FaceAlpha',0.3,'EdgeColor','none')
plot(sgTm,inhOn_fez_flaMn.pos,'g-','LineWidth',1)

plot([0,durAftStim],[0 0],'c-','LineWidth',4)
set(gca,'YDir','reverse')
ylabel('norm finger Position')
xlabel('time (sec)')
xlim([-1,durAftStim])
title('FezF2-FLA')

ax1(4) = subplot(2,2,4);
patch([sgTm fliplr(sgTm)],[inhOff_plex_flaMn.pos - 2*inhOff_plex_flaSem.pos; ...
    flipud(inhOff_plex_flaMn.pos + 2*inhOff_plex_flaSem.pos)],'k','FaceAlpha',0.3,'EdgeColor','none')
hold on
plot(sgTm,inhOff_plex_flaMn.pos,'k-','LineWidth',1)

patch([sgTm fliplr(sgTm)],[inhOn_plex_flaMn.pos - 2*inhOn_plex_flaSem.pos; ...
    flipud(inhOn_plex_flaMn.pos + 2*inhOn_plex_flaSem.pos)],'b','FaceAlpha',0.3,'EdgeColor','none')
plot(sgTm,inhOn_plex_flaMn.pos,'b-','LineWidth',1)

plot([0,durAftStim],[0 0],'c-','LineWidth',4)
set(gca,'YDir','reverse')
ylabel('norm finger Position')
xlabel('time (sec)')
xlim([-1,durAftStim])
title('PlexinD1-FLA')
linkaxes(ax1)
sgtitle('Position')
%% box plot
h(3) = figure; h(3).Position = [-1070 158 1242 695];
% grpId = [repmat("fez-frontal-inhOff",hlcnt.fez.front.inhOff,1); repmat("fez-frontal-inhOn",hlcnt.fez.front.inhOn,1); ...
%     repmat("plex-frontal-inhOff",hlcnt.plex.front.inhOff,1); repmat("plex-frontal-inhOn",hlcnt.plex.front.inhOn,1); ...
%     repmat("fez-fla-inhOff",hlcnt.fez.fla.inhOff,1); repmat("fez-fla-inhOn",hlcnt.fez.fla.inhOn,1); ...
%     repmat("plex-fla-inhOff",hlcnt.plex.fla.inhOff,1); repmat("plex-fla-inhOn",hlcnt.plex.fla.inhOn,1)];



boxplot(dataIn.pos,grpId);
ylabel('ctrl - inh hand mouth distance')
text(0.7,0.2,['tTest = ' num2str(tTst.fez_front_pos)])
text(1.7,0.2,['tTest = ' num2str(tTst.plex_front_pos)])
text(2.7,0.2,['tTest = ' num2str(tTst.fez_fla_pos)])
text(3.7,0.2,['tTest = ' num2str(tTst.plex_fla_pos)])

text(1.3,0.23,['multComp = ' num2str(fezVsPlex_front_inhOffOnDiff.pos)])
text(3.3,0.23,['multComp = ' num2str(fezVsPlex_fla_inhOffOnDiff.pos)])

text(2.3,0.24 , '1 Way anova')
sgtitle('Position')

%% VELOCITY

nTraces = 1;
h(4) = figure;h(4).Position = [-1259 40 1042 934];

traceIdx = randi(hlcnt.fez.front.inhOn,nTraces,1);
ax2(1) = subplot(4,2,1);
plot(sgTm(2:end),inhOff.fez.front.vel(:,traceIdx ),'color',[0.5 0.5 0.5])
hold on
plot([0,durAftStim],[0.15 0.15],'c-','LineWidth',4)
ylabel('norm finger Position')
xlabel('time (sec)')
title('FezF2-Frontal-InhOff')

traceIdx = randi(hlcnt.fez.front.inhOn,nTraces,1);
ax2(2) = subplot(4,2,2);
plot(sgTm(2:end),inhOn.fez.front.vel(:,traceIdx ),'color','g')
hold on
plot([0,durAftStim],[0.15 0.15],'c-','LineWidth',4)
ylabel('norm finger Position')
xlabel('time (sec)')
title('FezF2-Frontal-InhOff')

traceIdx = randi(hlcnt.plex.front.inhOn,nTraces,1);
ax2(3) = subplot(4,2,3);
plot(sgTm(2:end),inhOff.plex.front.vel(:,traceIdx ),'color',[0.5 0.5 0.5])
hold on
plot([0,durAftStim],[0.15 0.15],'c-','LineWidth',4)
ylabel('norm finger Position')
xlabel('time (sec)')
title('PlexinD1-Frontal-InhOff')

traceIdx = randi(hlcnt.plex.front.inhOn,nTraces,1);
ax2(4) = subplot(4,2,4);
plot(sgTm(2:end),inhOn.plex.front.vel(:,traceIdx ),'color','b')
hold on
plot([0,durAftStim],[0.15 0.15],'c-','LineWidth',4)
ylabel('norm finger Position')
xlabel('time (sec)')
title('FezF2-Frontal-InhOff')

traceIdx = randi(hlcnt.fez.fla.inhOn,nTraces,1);
ax2(5) = subplot(4,2,5);
plot(sgTm(2:end),inhOff.fez.fla.vel(:,traceIdx ),'color',[0.5 0.5 0.5])
hold on
plot([0,durAftStim],[0.15 0.15],'c-','LineWidth',4)
ylabel('norm finger Position')
xlabel('time (sec)')
title('FezF2-FLA-InhOff')

traceIdx = randi(hlcnt.fez.fla.inhOn,nTraces,1);
ax2(6) = subplot(4,2,6);
plot(sgTm(2:end),inhOn.fez.fla.vel(:,traceIdx ),'color','g')
hold on
plot([0,durAftStim],[0.15 0.15],'c-','LineWidth',4)
ylabel('norm finger Position')
xlabel('time (sec)')
title('FezF2-FLA-InhOff')

traceIdx = randi(hlcnt.plex.fla.inhOn,nTraces,1);
ax2(7) = subplot(4,2,7);
plot(sgTm(2:end),inhOff.plex.fla.vel(:,traceIdx ),'color',[0.5 0.5 0.5])
hold on
plot([0,durAftStim],[0.15 0.15],'c-','LineWidth',4)
ylabel('norm finger Position')
xlabel('time (sec)')
title('PlexinD1-FLA-InhOff')

traceIdx = randi(hlcnt.plex.fla.inhOn,nTraces,1);
ax2(8) = subplot(4,2,8);
plot(sgTm(2:end),inhOn.plex.fla.vel(:,traceIdx ),'color','b')
hold on
plot([0,durAftStim],[0.15 0.15],'c-','LineWidth',4)
ylabel('norm finger Position')
xlabel('time (sec)')
title('FezF2-FLA-InhOff')
sgtitle("VELOCITY")
linkaxes(ax2)
%% plot average trace
h(5) = figure;h(5).Position = [-1100 50 1117 687];
ax3(1) = subplot(2,2,1);
patch([sgTm(2:end) fliplr(sgTm(2:end))],[inhOff_fez_frontMn.vel - 2*inhOff_fez_frontSem.vel; ...
    flipud(inhOff_fez_frontMn.vel + 2*inhOff_fez_frontSem.vel)],'k','FaceAlpha',0.3,'EdgeColor','none')
hold on
plot(sgTm(2:end),inhOff_fez_frontMn.vel,'k-','LineWidth',1)

patch([sgTm(2:end) fliplr(sgTm(2:end))],[inhOn_fez_frontMn.vel - 2*inhOn_fez_frontSem.vel; ...
    flipud(inhOn_fez_frontMn.vel + 2*inhOn_fez_frontSem.vel)],'g','FaceAlpha',0.3,'EdgeColor','none')
plot(sgTm(2:end),inhOn_fez_frontMn.vel,'g-','LineWidth',1)

plot([0,durAftStim],[0.03 0.03],'c-','LineWidth',4)
ylabel('norm finger velocity')
xlabel('time (sec)')
xlim([-1,durAftStim])
title('FezF2-Frontal')

ax3(2) = subplot(2,2,2);
patch([sgTm(2:end) fliplr(sgTm(2:end))],[inhOff_plex_frontMn.vel - 2*inhOff_plex_frontSem.vel; ...
    flipud(inhOff_plex_frontMn.vel + 2*inhOff_plex_frontSem.vel)],'k','FaceAlpha',0.3,'EdgeColor','none')
hold on
plot(sgTm(2:end),inhOff_plex_frontMn.vel,'k-','LineWidth',1)

patch([sgTm(2:end) fliplr(sgTm(2:end))],[inhOn_plex_frontMn.vel - 2*inhOn_plex_frontSem.vel; ...
    flipud(inhOn_plex_frontMn.vel + 2*inhOn_plex_frontSem.vel)],'b','FaceAlpha',0.3,'EdgeColor','none')
plot(sgTm(2:end),inhOn_plex_frontMn.vel,'b-','LineWidth',1)

plot([0,durAftStim],[0.03 0.03],'c-','LineWidth',4)
ylabel('norm finger velocity')
xlabel('time (sec)')
xlim([-1,durAftStim])
title('PlexinD1-Frontal')

ax3(3) = subplot(2,2,3);
patch([sgTm(2:end) fliplr(sgTm(2:end))],[inhOff_fez_flaMn.vel - 2*inhOff_fez_flaSem.vel; ...
    flipud(inhOff_fez_flaMn.vel + 2*inhOff_fez_flaSem.vel)],'k','FaceAlpha',0.3,'EdgeColor','none')
hold on
plot(sgTm(2:end),inhOff_fez_flaMn.vel,'k-','LineWidth',1)

patch([sgTm(2:end) fliplr(sgTm(2:end))],[inhOn_fez_flaMn.vel - 2*inhOn_fez_flaSem.vel; ...
    flipud(inhOn_fez_flaMn.vel + 2*inhOn_fez_flaSem.vel)],'g','FaceAlpha',0.3,'EdgeColor','none')
plot(sgTm(2:end),inhOn_fez_flaMn.vel,'g-','LineWidth',1)

plot([0,durAftStim],[0.03 0.03],'c-','LineWidth',4)
ylabel(' finger Velocity')
xlabel('time (sec)')
xlim([-1,durAftStim])
title('FezF2-FLA')

ax3(4) = subplot(2,2,4);
patch([sgTm(2:end) fliplr(sgTm(2:end))],[inhOff_plex_flaMn.vel - 2*inhOff_plex_flaSem.vel; ...
    flipud(inhOff_plex_flaMn.vel + 2*inhOff_plex_flaSem.vel)],'k','FaceAlpha',0.3,'EdgeColor','none')
hold on
plot(sgTm(2:end),inhOff_plex_flaMn.vel,'k-','LineWidth',1)

patch([sgTm(2:end) fliplr(sgTm(2:end))],[inhOn_plex_flaMn.vel - 2*inhOn_plex_flaSem.vel; ...
    flipud(inhOn_plex_flaMn.vel + 2*inhOn_plex_flaSem.vel)],'b','FaceAlpha',0.3,'EdgeColor','none')
plot(sgTm(2:end),inhOn_plex_flaMn.vel,'b-','LineWidth',1)

plot([0,durAftStim],[0.03 0.03],'c-','LineWidth',4)
ylabel('norm finger velocity')
xlabel('time (sec)')
xlim([-1,durAftStim])
title('PlexinD1-FLA')
linkaxes(ax3)
sgtitle('Velocity')
%% box plot
h(6) = figure;h(6).Position = [-1070 158 1242 695];


boxplot(dataIn.vel,grpId);
ylabel('ctrl - inh Hand Velocity')

text(0.7,0.02,['tTest = ' num2str(tTst.fez_front_vel)])
text(1.7,0.02,['tTest = ' num2str(tTst.plex_front_vel)])
text(2.7,0.02,['tTest = ' num2str(tTst.fez_fla_vel)])
text(3.7,0.02,['tTest = ' num2str(tTst.plex_fla_vel)])

text(1.3,0.023,['multComp = ' num2str(fezVsPlex_front_inhOffOnDiff.vel)])
text(3.3,0.023,['multComp = ' num2str(fezVsPlex_fla_inhOffOnDiff.vel)])

text(2.3,0.024 , '1 Way anova')
sgtitle('Velocity')


%% %%%%%%%%%%%%% saving the figures %%%%%%%%%%

saveFig = input('Do you want to save the current figures : ');
if saveFig == 1
    %%% saving figures
    savepath = fullfile(['G:\Hemanth_CSHL\OptoWiredInhibition\Data_Figures\ManiPositionVelocityPlots\'], ...
        ['maniPosVel_FezPlex_2ndRev.fig']);
    savefig(h,savepath)
end
