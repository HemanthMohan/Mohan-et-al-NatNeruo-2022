clear all; close all; clc
[fname fpath] = uigetfile('*.csv');
%% %%%%%%%%%%%%%%% enter details to group sessions %%%%%%%%%%%%%
roiName = {'Frontal'}; %% Frontal; Fla;
mouseIds = {'c15m2';'c15m3';'c17m1';'c17m2'};
mouseType = ['PlexinD1Gtacr1'];
% mouseIds = {'c15m2';'c15m3';'c17m1';'c17m2'}; 
% mouseType = ['PlexinD1Gtacr1'];
sessionType = ['optowire'];
% dateIn = {'20220601';'20220602';'20220603';'20220606';'20220607';'20220608';'20220609';'20220610'; ...
%      '20220611';'20220614';'20220615';'20220616';'20220617'};

dateIn = {'20220601';'20220602';'20220603';'20220606';'20220607';'20220608';'20220609';'20220610'; ...
      '20220611';'20220614';'20220615';'20220616';'20220617';'20220708';'20220711';'20220712'; ...
      '20220713';'20220714';'20220715';'20220718';'20220719';'20220720';'20220721';'20220722';'20220723'; ...
      '20220725';'20220727';'20220728';'20220729'};

%% %%%%%%%%%%%%%%%%%%% get file  name structure %%%%%%%%%%%%
parentFold = fileparts(fileparts(fpath));
foldNames = [];
for jj = 1:length(mouseIds)
    for ii = 1:length(dateIn)
        FoldCont = dir(fullfile(fileparts(fileparts(fpath)),[dateIn{ii} '*', mouseType '*', mouseIds{jj} '*',sessionType '*']));
        foldNames = [foldNames;{FoldCont.name}'];
    end
end
%% Collect all traces and parameters
inhOn_tongUlTraj_all = [];
inhOn_isPellet_all = [];
inhOn_pimOnTime_all = [];
inhOn_hlOnTime_all = [];
stimStartEnd_all = [];
inhOff_tongUlTraj_all = [];
inhOff_isPellet_all = [];
inhOff_pimOnTime_all = [];
inhOff_hlOnTime_all = [];

for kk = 1:length(foldNames)
    fpath1 = [fullfile(parentFold,foldNames{kk}) '\'];
    [traces{kk,1}, params{kk,1} ] = getTongTraj(fpath1,roiName);
    inhOn_tongUlTraj_all = [inhOn_tongUlTraj_all  traces{kk}.inhOn_tongUlTraj];
    inhOn_isPellet_all = [inhOn_isPellet_all ; params{kk}.inhOn_isPellet];
    inhOn_pimOnTime_all = [inhOn_pimOnTime_all ; params{kk}.inhOn_pimOnTime];
    inhOn_hlOnTime_all = [inhOn_hlOnTime_all ; params{kk}.inhOn_hlOnTime];
    stimStartEnd_all = [stimStartEnd_all;params{kk}.stimStartEnd];
    
    inhOff_tongUlTraj_all = [inhOff_tongUlTraj_all  traces{kk}.inhOff_tongUlTraj];
    inhOff_isPellet_all = [inhOff_isPellet_all ; params{kk}.inhOff_isPellet];
    inhOff_pimOnTime_all = [inhOff_pimOnTime_all ; params{kk}.inhOff_pimOnTime];
    inhOff_hlOnTime_all = [inhOff_hlOnTime_all ; params{kk}.inhOff_hlOnTime];
end
%% replace nans with minimum value
inhOn_tongUlTraj_all(isnan(inhOn_tongUlTraj_all)) = min(inhOn_tongUlTraj_all(:));
inhOff_tongUlTraj_all(isnan(inhOff_tongUlTraj_all)) = min(inhOn_tongUlTraj_all(:));

%% %%%%%%%%%% extract total and mean lick length before and after Inhibition
bTime = linspace(0,15,1500);
sigDur = 1; %%% duration in seconds before and after inhibition to consider for analysis
for ii = 1:size(inhOn_tongUlTraj_all,2)
    inhOffIdx = find(bTime > stimStartEnd_all(ii,1)-sigDur & bTime < stimStartEnd_all(ii,1));
    inhOnIdx = find(bTime > stimStartEnd_all(ii,1) & bTime < stimStartEnd_all(ii,1)+sigDur);
    inhOn_befStimTngLen(ii,1) = nansum(inhOn_tongUlTraj_all(inhOffIdx,ii)); %%% total tongue length before inhibtion
    inhOn_aftStimTngLen(ii,1) = nansum(inhOn_tongUlTraj_all(inhOnIdx,ii));%%% total tongue length after inhibtion
    inhOn_befStimMeanTngLen(ii,1) = nanmean(inhOn_tongUlTraj_all(inhOffIdx,ii)); %%% mean tongue length before inhibtion
    inhOn_aftStimMeanTngLen(ii,1)= nanmean(inhOn_tongUlTraj_all(inhOnIdx,ii));%%% mean tongue length after inhibtion
    
    inhOff_befStimTngLen(ii,1) = nansum(inhOff_tongUlTraj_all(inhOffIdx,ii)); %%% total tongue length before inhibtion
    inhOff_aftStimTngLen(ii,1) = nansum(inhOff_tongUlTraj_all(inhOnIdx,ii));%%% total tongue length after inhibtion
    inhOff_befStimMeanTngLen(ii,1) = nanmean(inhOff_tongUlTraj_all(inhOffIdx,ii)); %%% mean tongue length before inhibtion
    inhOff_aftStimMeanTngLen(ii,1)= nanmean(inhOff_tongUlTraj_all(inhOnIdx,ii));%%% mean tongue length after inhibtion
end
inhOn_befMinAftTngLen = inhOn_befStimTngLen - inhOn_aftStimTngLen;
inhOff_befMinAftTngLen = inhOff_befStimTngLen - inhOff_aftStimTngLen;
inhOn_befMinAftMeanTngLen = inhOn_befStimMeanTngLen - inhOn_aftStimMeanTngLen;
inhOff_befMinAftMeanTngLen = inhOff_befStimMeanTngLen - inhOff_aftStimMeanTngLen;
%% %%%%%%%%%%% get stimon centered tongue trajectories
bFs = 100;
durBef = 1.5;%%% duration before stim on to consider for signal
durAft = 1.5;%%% duration after stim on to consider for signal
trajTm = linspace(-durBef,durAft,(durBef+durAft)*bFs);
inhOn_TngTraj = [];
inhOff_TngTraj = [];
skippedTraj = [];
for ii =1:size(stimStartEnd_all,1)
    durIdx = find(bTime>=stimStartEnd_all(ii,1)-durBef & bTime<stimStartEnd_all(ii,1)+durAft);
    if length(durIdx)<length(trajTm)
        inhOn_TngTraj(:,ii) = nan(length(trajTm),1);
        inhOff_TngTraj(:,ii)= nan(length(trajTm),1);
        skippedTraj = [skippedTraj;ii];
    else
        inhOn_TngTraj(:,ii) = inhOn_tongUlTraj_all(durIdx,ii); %%% normalized tongue trajectory around inhibition onset
        inhOff_TngTraj(:,ii) = inhOff_tongUlTraj_all(durIdx,ii); %%% normalized tongue trajectory around inhibition onset
    end
end
%% perfrom stats
[pVal_totalTngLen_inhOff,~,stats_totalTngLen_inhOff]= signrank(inhOff_befStimTngLen,inhOff_aftStimTngLen);
[pVal_totalTngLen_inhOn,~,stats_totalTngLen_inhOn] = signrank(inhOn_befStimTngLen,inhOn_aftStimTngLen);

pVal_meanTngLen_inhOff = signrank(inhOff_befStimMeanTngLen,inhOff_aftStimMeanTngLen);
pVal_meanTngLen_inhOn = signrank(inhOn_befStimMeanTngLen,inhOn_aftStimMeanTngLen);
%% plotting figures
close all
trialCnt = size(stimStartEnd_all,1);
inhOffOnGrp = [repmat({'inhOff-befStim'},length(inhOff_befStimMeanTngLen),1); ...
    repmat({'inhOff-afterStim'},length(inhOff_aftStimMeanTngLen),1); ...
    repmat({'inhOn-befStim'},length(inhOn_befStimMeanTngLen),1); ...
    repmat({'inhOn-afterStim'},length(inhOn_aftStimMeanTngLen),1)];

meanTongLen_InhOffOn = [inhOff_befStimMeanTngLen;inhOff_aftStimMeanTngLen; ...
    inhOn_befStimMeanTngLen;inhOn_aftStimMeanTngLen];
totalTongLen_InhOffOn = [inhOff_befStimTngLen;inhOff_aftStimTngLen; ...
    inhOn_befStimTngLen;inhOn_aftStimTngLen];

h1 = figure;h1.Position = [139 51 1569 927];
subplot(2,2,1)
plot(trajTm,inhOff_TngTraj,'color',[0.5,0.5,0.5])
hold on
plot(trajTm,nanmean(inhOff_TngTraj,2),'k','LineWidth',1.5)
plot([0,durAft],[0,0],'c-','LineWidth',6)
set(gca,'YDir','reverse','Ylim',[-0.1 0.6])
hold off
ylabel('upperlip Norm Tng Len')
title(['Control Trials. Trial Count: ' num2str(trialCnt)] )

subplot(2,2,2)
plot(trajTm,inhOn_TngTraj,'color',[0 0.5 1])
hold on
plot(trajTm,nanmean(inhOn_TngTraj,2),'b','LineWidth',1.5)
plot([0,durAft],[0,0],'c-','LineWidth',6)
set(gca,'YDir','reverse','Ylim',[-0.1 0.6])
hold off
ylabel('upperlip Norm Tng Len')
title('Inhibition Trials')

subplot(2,2,3)
boxplot(meanTongLen_InhOffOn, inhOffOnGrp);
ylabel(' Normalized Mean Tongue Length ')
title(['Dur bef Aft Stim On: ' num2str(sigDur) ' sec. Inh Off signrank PVal : ' ...
    num2str(pVal_meanTngLen_inhOff) ' . Inh On signrank PVal : '  num2str(pVal_meanTngLen_inhOn)]);
set(gca,'Ylim',[0.05 0.45])
ylabel('upperlip Norm Mean Tng Len')
annotation(h1,'textbox', [0, 0.9, 0, 0], 'string', [foldNames],'FontSize',7, 'Interpreter', 'none')

subplot(2,2,4)
boxplot(totalTongLen_InhOffOn, inhOffOnGrp);
ylabel(' Normalized Total Tongue Length ')
title(['Dur bef Aft Stim On: ' num2str(sigDur) ' sec. Inh Off signrank PVal : ' ...
    num2str(pVal_totalTngLen_inhOff) ' . Inh On signrank PVal : '  num2str(pVal_totalTngLen_inhOn)]);
% set(gca,'Ylim',[0.05 0.45])
ylabel('upperlip Norm Total Tng Len')
annotation(h1,'textbox', [0, 0.9, 0, 0], 'string', [foldNames],'FontSize',7, 'Interpreter', 'none')

%% saving data
data.inhOn_TngTraj = inhOn_TngTraj;
data.inhOff_TngTraj = inhOff_TngTraj;
data.durBefStim = durBef;
data.durAftStim = durAft;
data.trajTime = trajTm;
data.TrajSkipped = skippedTraj;
data.allInhParams = params;
data.roiName = roiName;
data.mouseIds = mouseIds;
data.mouseType = mouseType;
data.datesAnalyzed = dateIn;
data.FoldersAnalyzed = foldNames;

%% %%%%%%%%% saving the data %%%%%%%%%%

filename = ['LickTongueLength_' roiName{1} '_' mouseType '.mat'];
saveData = input('Do you want to save the current data : ');
if saveData == 1
    %%% saving data
    savePath = fullfile('G:\Hemanth_CSHL\OptoWiredInhibition\Data_Analysis\LickTrajectory\' ,filename);
    save(savePath,'data')
end
%% Main funciton %%%%%%%%%%%
function [traces, params] = getTongTraj(fpath,roiName)
%% %%%%%%%%%%%%%%%% get file  name structure %%%%%%%%%%%%
[fnFeat, usFeat ] = getOptoFileNameProperties(fpath);%%% get all fileNames variables
%% %%%%%%%%%%%%%%% Get Lick, Pim, Handlift Behavior Trial IDs %%%%%%%%%%%%%%%
disp('Extracting Behavior Temporal features .... ')
ExtractManipulaion = 0;%%%%% Enter zero to not extract manipulation times and 1 to extract
[BData] = GetBehavEventTimesOptoWire(fpath,ExtractManipulaion);
allTrialIdx = cell2mat(BData.Data(:,1));
lickOnsetAll = BData.Data(:,9);
pimOnsetAll = BData.Data(:,10);
hlOnsetAll = BData.Data(:,11);
lickOnIdx = find(cell2mat(BData.Data(:,2)) == 1);
pimOnIdx = find(cell2mat(BData.Data(:,2)) == 1 & cell2mat(BData.Data(:,3)) == 1);
hlOnIdx = find(cell2mat(BData.Data(:,2)) == 1 & cell2mat(BData.Data(:,3)) == 1 & cell2mat(BData.Data(:,4)) == 1);
% hlOnIdx = find(~cellfun(@isempty,hlOnsetAll));

bTime = linspace(0,15,1500);
%% %%% get roi stimulation index and parameters
roiParms = getRoiStimTrialIdx(fnFeat);
%% Get trials with Hand lift event during inhibition.
inhOn_lickOn_Idx = [];
inhOn_isPellet = [];%%% is there a pellet to lick
inhOn_pimOnTime = [];
inhOn_hlOnTime = [];
inhOn_tongUlTraj = []; %% tongue trajectory nomalized to location of upperlip
stimStartEnd = []; %%%%% get all stimulation start end time
allInhOnIdx = [];
for ii = 1:length(roiParms.(['LzOn' roiName{1} 'Idx']))
    inIdx = roiParms.(['LzOn' roiName{1} 'Idx'])(ii); %%% which index is being analyzed
    allInhOnIdx = [allInhOnIdx;inIdx];
    stimOnset = roiParms.(['LzOn' roiName{1} 'Parm']){ii,3}; %% stim onset time in seconds
    stimDur = roiParms.(['LzOn' roiName{1} 'Parm']){ii,4}; %% stim duration time in seconds
    stimEndTime = stimOnset + stimDur; %%% stim end time in second
%     if inIdx > length(lickOnsetAll)
%         continue
%     end
    [trajDataC1,trajDataC2,bodyPartsC1,bodyPartsC2 ] = getBehaviorTrajectory(fpath,fnFeat,usFeat,inIdx);
    %%
    if sum(inIdx == lickOnIdx) == 1 %% check if the animal licks
        if ~isempty(pimOnsetAll{inIdx}) & stimOnset>pimOnsetAll{inIdx}
            % if pim exists and stimulation happens after pim onset ie
            % during manipulation, do not consider that trial
            continue
        else
            inhOn_lickOn_Idx = [inhOn_lickOn_Idx; inIdx];
            inhOn_isPellet = [inhOn_isPellet;sum(~isnan(trajDataC1.pellet(:,2))) > 100 ]; %%% is there a pellet to lick
            if isempty(pimOnsetAll{inIdx}) %%% chekc if pim onset is there or not
                inhOn_pimOnTime = [inhOn_pimOnTime;nan]; %%% If pim onset is there, what is the onset time
            else
                inhOn_pimOnTime = [inhOn_pimOnTime;pimOnsetAll{inIdx}];%%% If pim onset is there, what is the onset time
            end
            
            if isempty(hlOnsetAll{inIdx})%%% check if handlift onset is there or not
                inhOn_hlOnTime = [inhOn_hlOnTime; nan];%%% If handlift onset is there, what is the onset time
            else
                inhOn_hlOnTime = [inhOn_hlOnTime; hlOnsetAll{inIdx}];%%% If handlift onset is there, what is the onset time
            end
            stimStartEnd = [stimStartEnd ; [stimOnset stimEndTime]];
            
            tongTrajC1 = trajDataC1.tongue(:,2); %%% get the tongue trajectory
            upLipLocC1 = nanmean(trajDataC1.upperlip(:,2)); %% mean location of upperlip
            tongUlTraj = (tongTrajC1 - upLipLocC1)./upLipLocC1; %% tongue trajectory normalized to upper lip location
            inhOn_tongUlTraj = [inhOn_tongUlTraj tongUlTraj];%% tongue trajectory normalized to upper lip location
            
        end
    end
    
end

%% Get Trials with licking during control trials
LzOff_lickOnIdx = intersect(roiParms.LzOffIdx,lickOnIdx); %% get trials with handlift during no inhibition
% get Lick On Indices of trials just before the inhibition on trials
inhOff_lickOn_Idx = []; 
for ii = 1:length(inhOn_lickOn_Idx)
    inhOff_lickOn_Idx = [inhOff_lickOn_Idx; LzOff_lickOnIdx(find(LzOff_lickOnIdx<inhOn_lickOn_Idx(ii),1,'last'))]; %% get index id of pim on trial just before the inhibition trial
end

% find repeat trials and replace it with an older trial idx
[unqVal unqLoc] = unique(inhOff_lickOn_Idx,'first');
repeatLoc = find(not(ismember(1:numel(inhOff_lickOn_Idx),unqLoc)));
for ii = 1:length(repeatLoc)
    temp1 =  setdiff(LzOff_lickOnIdx(find(LzOff_lickOnIdx<inhOff_lickOn_Idx(repeatLoc(ii)))), inhOff_lickOn_Idx);
    inhOff_lickOn_Idx(repeatLoc(ii)) = temp1(end); %% unique indices of lazer off indices
end
% get lick trajectiory during inhibition off trials
inhOff_tongUlTraj = []; %%% tongue trajectory normalied to upperlip loc
inhOff_isPellet = [];%%% is there a pellet to lick
inhOff_pimOnTime = [];
inhOff_hlOnTime = [];
for ii = 1:length(inhOff_lickOn_Idx)
    [trajDataC1,trajDataC2,bodyPartsC1,bodyPartsC2 ] = getBehaviorTrajectory(fpath,fnFeat,usFeat,inhOff_lickOn_Idx(ii));
    inhOff_isPellet = [inhOff_isPellet;sum(~isnan(trajDataC1.pellet(:,2))) > 100 ]; %%% is there a pellet to lick
    
    if isempty(pimOnsetAll{inhOff_lickOn_Idx(ii)}) %%% chekc if pim onset is there or not
        inhOff_pimOnTime = [inhOff_pimOnTime;nan]; %%% If pim onset is there, what is the onset time
    else
        inhOff_pimOnTime = [inhOff_pimOnTime;pimOnsetAll{inhOff_lickOn_Idx(ii)}];%%% If pim onset is there, what is the onset time
    end
    
    if isempty(hlOnsetAll{inhOff_lickOn_Idx(ii)})%%% check if handlift onset is there or not
        inhOff_hlOnTime = [inhOff_hlOnTime; nan];%%% If handlift onset is there, what is the onset time
    else
        inhOff_hlOnTime = [inhOff_hlOnTime; hlOnsetAll{inhOff_lickOn_Idx(ii)}];%%% If handlift onset is there, what is the onset time
    end
    
    
    
    tongTrajC1 = trajDataC1.tongue(:,2); %%% get the tongue trajectory
    upLipLocC1 = nanmean(trajDataC1.upperlip(:,2)); %% mean location of upperlip
    tongUlTraj = (tongTrajC1 - upLipLocC1)./upLipLocC1; %% tongue trajectory normalized to upper lip location
    inhOff_tongUlTraj = [inhOff_tongUlTraj tongUlTraj];
end

%% %%%%%%%% collect data
traces.inhOn_tongUlTraj = inhOn_tongUlTraj;
traces.inhOff_tongUlTraj = inhOff_tongUlTraj;
params.inhOn_lickOn_Idx = inhOn_lickOn_Idx;
params.inhOn_isPellet = inhOn_isPellet;
params.inhOn_pimOnTime = inhOn_pimOnTime;
params.inhOn_hlOnTime = inhOn_hlOnTime;
params.stimStartEnd = stimStartEnd;
params.inhOff_lickOn_Idx = inhOff_lickOn_Idx;
params.inhOff_isPellet = inhOff_isPellet;
params.inhOff_pimOnTime = inhOff_pimOnTime;
params.inhOff_hlOnTime  = inhOff_hlOnTime ;
params.allInhOnIdx = allInhOnIdx;


end

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Functions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function[hlStartStop,hlSSBin] = getHandLiftStartStop(sig,thresh);
bFs = 100;
minDur = 0.2; %%% minimum duration in sec of hand being lifted to be considered as a significant hand lift event
bTime = linspace(0,15,1500);
sigIn = sig;sigIn(1480:1500) = nan;
sigCorr = sigIn;
sigCorr(isnan(sigIn)) = max(sigIn);
sigFilt = lowpass(sigCorr, 1,bFs);
sigFilt(isnan(sigIn)) = nan;
hlBin = sigFilt<=thresh;
hlOnOff = [bTime(find(diff(hlBin)>0))' bTime(find(diff(hlBin)<0))'];
hlDur = hlOnOff(:,2) - hlOnOff(:,1);
hlStartStop = hlOnOff; 
hlStartStop(hlDur<minDur,:) = [];
hlSSBin = zeros(length(bTime),1);
for ii = 1:size(hlStartStop,1)
    hlSSBin(bTime>=hlStartStop(ii,1) & bTime<=hlStartStop(ii,2)) = 1;
end

end
function [TrajDataC1,TrajDataC2,BodyPartsC1,BodyPartsC2 ] = getBehaviorTrajectory(fpath,fnFeat,usFeat,FileId)
pcutoffC1 = 0.9;
pcutoffC2 = 0.8;
fnameinC1 = [fnFeat.fname_exC1(1:usFeat.bidx_stC1) num2str(FileId) fnFeat.fname_exC1(usFeat.bidx_endC1:end)];
filepathC1 = fullfile(fpath,fnameinC1);
[TrajDataC1 BodyPartsC1] =  ExtractBodyTraj(filepathC1,pcutoffC1);

fnameinC2 = [fnFeat.fname_exC2(1:usFeat.bidx_stC2) num2str(FileId) fnFeat.fname_exC2(usFeat.bidx_endC2:end)];
filepathC2 = fullfile(fpath,fnameinC2);
[TrajDataC2 BodyPartsC2] =  ExtractBodyTraj(filepathC2,pcutoffC2);
end

function [parms] = getRoiStimTrialIdx(fnFeat)
%% %%%%%%%%%% get laser stimulation parameters and trials
[stimParm,stimHead] = getLaserStimParam(fnFeat);
parms.LzOnIdx = find(cell2mat(stimParm(:,1)) == 1);
parms.LzOffIdx = find(cell2mat(stimParm(:,1)) == 0);
parms.stimHeading = stimHead;
parms.stimParmAll = stimParm;
%% %%%%% Roi Laser On Idx
if strcmp(lower(stimParm(1,2)), 'frontal')
    parms.LzOnFrontalIdx = find(cell2mat(stimParm(:,1)) == 1);
    parms.LzOnFlaIdx = [];
elseif strcmp(lower(stimParm(1,2)), 'fla')
    parms.LzOnFlaIdx = find(cell2mat(stimParm(:,1)) == 1);
    parms.LzOnFrontalIdx = [];
end
%% Roi Laser Parameters
parms.LzOnParm = stimParm(parms.LzOnIdx,:);
parms.LzOnFrontalParm = stimParm(parms.LzOnFrontalIdx,:);
parms.LzOnFlaParm = stimParm(parms.LzOnFlaIdx,:);
end
function [stimParm,stimHead] = getLaserStimParam(fnFeat)
for ii = 1:length(fnFeat.sname_all)
    data = load(fullfile(fnFeat.spath,fnFeat.sname_all{ii})); data = data.data;
    stimParm(ii,:) = data(2,:);
end
stimHead = data(1,:);
end

function [fnFeat, usFeat ] = getOptoFileNameProperties(fpath)
%%%%%%%%%%%%% getting signal file name %%%%%%%%%%%%%%
listing_csv = dir([fpath '\*.csv']);
[~, sflname] = fileparts(fileparts(fpath));
spath = fullfile(fileparts(fileparts(fileparts(fpath))), 'OptoWiredData', sflname);
listing_sig = dir([spath '\*.mat']);
sname_all = natsortfiles({listing_sig.name}');
sname_ex = sname_all{1};
us_idx = find(sname_ex == '_',1,'last');

%%%%%%%% getting body trajectory file name %%%%%%%%%%%%
fname_all = natsortfiles({listing_csv.name}');
fname_allC1 = fname_all( contains(fname_all,'c1_T'));
fname_allC2 = fname_all( contains(fname_all,'c2_T'));

fname_exC1 = fname_allC1{1};
fname_us_idxC1 = find(fname_exC1 == '_');
fname_deep_idxC1 = strfind(fname_exC1, 'Deep');
bidx_stC1 = fname_us_idxC1(end-3);
bidx_endC1 = fname_deep_idxC1;

fname_exC2 = fname_allC2{1};
fname_us_idxC2 = find(fname_exC2 == '_');
fname_deep_idxC2 = strfind(fname_exC2, 'Deep');
bidx_stC2 = fname_us_idxC2(end-3);
bidx_endC2 = fname_deep_idxC2;


%%% updating all properties
fnFeat.sname_all = sname_all;
fnFeat.fname_allC1 = fname_allC1;
fnFeat.fname_allC2 = fname_allC2;
fnFeat.sname_ex = sname_ex;
fnFeat.fname_exC1 = fname_exC1;
fnFeat.fname_exC2 = fname_exC2;
fnFeat.spath = spath;

usFeat.us_idx = us_idx;
usFeat.bidx_stC1 = bidx_stC1;
usFeat.bidx_endC1 = bidx_endC1;
usFeat.bidx_stC2 = bidx_stC2;
usFeat.bidx_endC2 = bidx_endC2;
end