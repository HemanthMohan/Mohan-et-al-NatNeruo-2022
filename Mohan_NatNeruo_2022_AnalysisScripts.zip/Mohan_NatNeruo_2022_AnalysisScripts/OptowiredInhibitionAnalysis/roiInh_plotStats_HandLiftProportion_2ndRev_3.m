clear all; close all;clear mem; clc
%% load data
fez.frontal = load(['G:\Hemanth_CSHL\OptoWiredInhibition\Data_Analysis\HandliftProportion\' ...
    'HandliftProportion_Frontal_FezF2Gtacr1.mat']);
fez.frontal = fez.frontal.data;

fez.fla = load(['G:\Hemanth_CSHL\OptoWiredInhibition\Data_Analysis\HandliftProportion\' ...
    'HandliftProportion_Fla_FezF2Gtacr1.mat']);
fez.fla = fez.fla.data;

plex.frontal = load(['G:\Hemanth_CSHL\OptoWiredInhibition\Data_Analysis\HandliftProportion\' ...
    'HandliftProportion_Frontal_PlexinD1Gtacr1.mat']);
plex.frontal = plex.frontal.data;

plex.fla = load(['G:\Hemanth_CSHL\OptoWiredInhibition\Data_Analysis\HandliftProportion\' ...
'HandliftProportion_Fla_PlexinD1Gtacr1.mat']);
plex.fla = plex.fla.data;
%% %%%%%%%%% extract relevant data
cnt.fez.front.all = size(fez.frontal.inhOn_TrialRef,1);
cnt.fez.front.inhOff.Hl = length(fez.frontal.inhOff_handliftIdx);
cnt.fez.front.inhOff.NoHl = length(fez.frontal.inhOff_noHandliftIdx);
cnt.fez.front.inhOn.Hl = length(fez.frontal.inhOn_handliftIdx);
cnt.fez.front.inhOn.NoHl = length(fez.frontal.inhOn_noHandliftIdx);

cnt.fez.fla.all = size(fez.fla.inhOn_TrialRef,1);
cnt.fez.fla.inhOff.Hl = length(fez.fla.inhOff_handliftIdx);
cnt.fez.fla.inhOff.NoHl = length(fez.fla.inhOff_noHandliftIdx);
cnt.fez.fla.inhOn.Hl = length(fez.fla.inhOn_handliftIdx);
cnt.fez.fla.inhOn.NoHl = length(fez.fla.inhOn_noHandliftIdx);

cnt.plex.front.all = size(plex.frontal.inhOn_TrialRef,1);
cnt.plex.front.inhOff.Hl = length(plex.frontal.inhOff_handliftIdx);
cnt.plex.front.inhOff.NoHl = length(plex.frontal.inhOff_noHandliftIdx);
cnt.plex.front.inhOn.Hl = length(plex.frontal.inhOn_handliftIdx);
cnt.plex.front.inhOn.NoHl = length(plex.frontal.inhOn_noHandliftIdx);

cnt.plex.fla.all = size(plex.fla.inhOn_TrialRef,1);
cnt.plex.fla.inhOff.Hl = length(plex.fla.inhOff_handliftIdx);
cnt.plex.fla.inhOff.NoHl = length(plex.fla.inhOff_noHandliftIdx);
cnt.plex.fla.inhOn.Hl = length(plex.fla.inhOn_handliftIdx);
cnt.plex.fla.inhOn.NoHl = length(plex.fla.inhOn_noHandliftIdx);
%% calulate handlift probability
inhOff_fez_front_hlProb = cnt.fez.front.inhOff.Hl/cnt.fez.front.all;
inhOn_fez_front_hlProb = cnt.fez.front.inhOn.Hl/cnt.fez.front.all ;

inhOff_plex_front_hlProb = cnt.plex.front.inhOff.Hl/cnt.plex.front.all;
inhOn_plex_front_hlProb = cnt.plex.front.inhOn.Hl/cnt.plex.front.all;

inhOff_fez_fla_hlProb = cnt.fez.fla.inhOff.Hl/cnt.fez.fla.all;
inhOn_fez_fla_hlProb = cnt.fez.fla.inhOn.Hl/cnt.fez.fla.all;

inhOff_plex_fla_hlProb = cnt.plex.fla.inhOff.Hl/cnt.plex.fla.all;
inhOn_plex_fla_hlProb = cnt.plex.fla.inhOn.Hl/cnt.plex.fla.all;
%% perform stats
inhOff_fez_front_hlOnOff = zeros(cnt.fez.front.all,1);
inhOff_fez_front_hlOnOff(1:cnt.fez.front.inhOff.Hl) = 1;
inhOn_fez_front_hlOnOff = zeros(cnt.fez.front.all,1);
inhOn_fez_front_hlOnOff(1:cnt.fez.front.inhOn.Hl) = 1;

inhOff_plex_front_hlOnOff = zeros(cnt.plex.front.all,1);
inhOff_plex_front_hlOnOff(1:cnt.plex.front.inhOff.Hl) = 1;
inhOn_plex_front_hlOnOff = zeros(cnt.plex.front.all,1);
inhOn_plex_front_hlOnOff(1:cnt.plex.front.inhOn.Hl) = 1;

inhOff_fez_fla_hlOnOff = zeros(cnt.fez.fla.all,1);
inhOff_fez_fla_hlOnOff(1:cnt.fez.fla.inhOff.Hl) = 1;
inhOn_fez_fla_hlOnOff = zeros(cnt.fez.fla.all,1);
inhOn_fez_fla_hlOnOff(1:cnt.fez.fla.inhOn.Hl) = 1;

inhOff_plex_fla_hlOnOff = zeros(cnt.plex.fla.all,1);
inhOff_plex_fla_hlOnOff(1:cnt.plex.fla.inhOff.Hl) = 1;
inhOn_plex_fla_hlOnOff = zeros(cnt.plex.fla.all,1);
inhOn_plex_fla_hlOnOff(1:cnt.plex.fla.inhOn.Hl) = 1;

fez_front_inhOnOff = [repmat("InhOff",cnt.fez.front.all,1);repmat("InhOn",cnt.fez.front.all,1)];
fez_front_hlOnOff = logical([inhOff_fez_front_hlOnOff;inhOn_fez_front_hlOnOff]);

plex_front_inhOnOff = [repmat("InhOff",cnt.plex.front.all,1);repmat("InhOn",cnt.plex.front.all,1)];
plex_front_hlOnOff = logical([inhOff_plex_front_hlOnOff;inhOn_plex_front_hlOnOff]);

fez_fla_inhOnOff = [repmat("InhOff",cnt.fez.fla.all,1);repmat("InhOn",cnt.fez.fla.all,1)];
fez_fla_hlOnOff = logical([inhOff_fez_fla_hlOnOff;inhOn_fez_fla_hlOnOff]);

plex_fla_inhOnOff = [repmat("InhOff",cnt.plex.fla.all,1);repmat("InhOn",cnt.plex.fla.all,1)];
plex_fla_hlOnOff = logical([inhOff_plex_fla_hlOnOff;inhOn_plex_fla_hlOnOff]);


cntData.fez.front = table(fez_front_inhOnOff, fez_front_hlOnOff );
[cntTbl.fez.front, chi2.fez.front, pVal.fez.front] = crosstab(fez_front_inhOnOff, fez_front_hlOnOff);
hlProp.fez.front = cntTbl.fez.front/cnt.fez.front.all;

cntData.plex.front = table(plex_front_inhOnOff, plex_front_hlOnOff );
[cntTbl.plex.front, chi2.plex.front, pVal.plex.front] = crosstab(plex_front_inhOnOff, plex_front_hlOnOff);
hlProp.plex.front = cntTbl.plex.front/cnt.plex.front.all;

cntData.fez.fla = table(fez_fla_inhOnOff,fez_fla_hlOnOff );
[cntTbl.fez.fla, chi2.fez.fla, pVal.fez.fla] = crosstab(fez_fla_inhOnOff, fez_fla_hlOnOff);
hlProp.fez.fla = cntTbl.fez.fla/cnt.fez.fla.all;

cntData.plex.fla = table(plex_fla_inhOnOff, plex_fla_hlOnOff );
[cntTbl.plex.fla, chi2.plex.fla, pVal.plex.fla] = crosstab(plex_fla_inhOnOff, plex_fla_hlOnOff);
hlProp.plex.fla = cntTbl.plex.fla/cnt.plex.fla.all;
%% %%%%%%%%%%%%%% chi2 test for comparing  inh on plex vs Fez
plexFez_front = [repmat("Plex",cnt.plex.front.all,1);repmat("Fez",cnt.fez.front.all,1)];
plexFez_front_inhOnHlOnOff = [inhOn_plex_front_hlOnOff;inhOn_fez_front_hlOnOff];

plexFez_fla = [repmat("Plex",cnt.plex.fla.all,1);repmat("Fez",cnt.fez.fla.all,1)];
plexFez_fla_inhOnHlOnOff = [inhOn_plex_fla_hlOnOff;inhOn_fez_fla_hlOnOff];

plexFezCntData.front = table(plexFez_front,plexFez_front_inhOnHlOnOff);
[cntTbl.plexFez.front, chi2.plexFez.front, pVal.plexFez.front] = crosstab(plexFez_front,plexFez_front_inhOnHlOnOff);
hlProp.plexFez.front = cntTbl.plexFez.front./sum(cntTbl.plexFez.front,2);

plexFezCntData.fla = table(plexFez_fla,plexFez_fla_inhOnHlOnOff);
[cntTbl.plexFez.fla, chi2.plexFez.fla, pVal.plexFez.fla] = crosstab(plexFez_fla,plexFez_fla_inhOnHlOnOff);
hlProp.plexFez.fla = cntTbl.plexFez.fla./sum(cntTbl.plexFez.fla,2);
%% %%%%%% plotting the data
close all
h(1) = figure;h(1).Position = [115   131   919   680];
subplot(2,2,1)
heatmap({'No Handlift'; 'HandLift'},{'Inh Off';'Inh On'},hlProp.fez.front) ;
colormap parula
caxis([0,1])
title(['FezF2 Frontal. chi2 PVal : ' num2str(pVal.fez.front)]);

subplot(2,2,2)
heatmap({'No Handlift'; 'HandLift'},{'Inh Off';'Inh On'},hlProp.plex.front) ;
colormap parula
caxis([0,1])
title(['PlexinD1 Frontal. chi2 PVal : ' num2str(pVal.plex.front)]);

subplot(2,2,3)
heatmap({'No Handlift'; 'HandLift'},{'Inh Off';'Inh On'},hlProp.fez.fla) ;
colormap parula
caxis([0,1])
title(['FezF2 FLA. chi2 PVal : ' num2str(pVal.fez.fla)]);

subplot(2,2,4)
heatmap({'No Handlift'; 'HandLift'},{'Inh Off';'Inh On'},hlProp.plex.fla) ;
colormap parula
caxis([0,1])
title(['PlexinD1 FLA. chi2 PVal : ' num2str(pVal.plex.fla)]);

h(2) = figure;h(2).Position = [1993         409        1179         368];
subplot(1,2,1)
heatmap({'No Handlift'; 'HandLift'},{'Plex';'Fez'},hlProp.plexFez.front); 
colormap parula
caxis([0,1])
title(['PlexinD1 Vs Fez Frontal. chi2 PVal : ' num2str(pVal.plexFez.front)]);

subplot(1,2,2)
heatmap({'No Handlift'; 'HandLift'},{'Plex';'Fez'},hlProp.plexFez.fla); 
colormap parula
caxis([0,1])
title(['PlexinD1 Vs Fez FLA. chi2 PVal : ' num2str(pVal.plexFez.fla)]);


%% %%%%%%%%%%%%% saving the figures %%%%%%%%%%

saveFig = input('Do you want to save the current figures : ');
if saveFig == 1
    %%% saving figures
    savepath = fullfile(['G:\Hemanth_CSHL\OptoWiredInhibition\Data_Figures\HandliftProportionPlots\'], ...
        ['handliftProportion_FezPlex_2ndRev.fig']);
    savefig(h,savepath)
end
