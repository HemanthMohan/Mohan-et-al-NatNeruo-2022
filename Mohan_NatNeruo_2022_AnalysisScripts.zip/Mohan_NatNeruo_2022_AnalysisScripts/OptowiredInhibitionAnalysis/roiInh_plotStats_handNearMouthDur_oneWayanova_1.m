clear all; close all;clear mem; clc
%% load data
fez.frontal = load(['G:\Hemanth_CSHL\OptoWiredInhibition\Data_Analysis\HandNearMouthDuration\' ...
    'HandNearMouthDur_Frontal_FezF2Gtacr1.mat']);
fez.frontal = fez.frontal.data;

fez.fla = load(['G:\Hemanth_CSHL\OptoWiredInhibition\Data_Analysis\HandNearMouthDuration\' ...
    'HandNearMouthDur_Fla_FezF2Gtacr1.mat']);
fez.fla = fez.fla.data;

plex.frontal = load(['G:\Hemanth_CSHL\OptoWiredInhibition\Data_Analysis\HandNearMouthDuration\' ...
    'HandNearMouthDur_Frontal_PlexinD1Gtacr1.mat']);
plex.frontal = plex.frontal.data;

plex.fla = load(['G:\Hemanth_CSHL\OptoWiredInhibition\Data_Analysis\HandNearMouthDuration\' ...
'HandNearMouthDur_Fla_PlexinD1Gtacr1.mat']);
plex.fla = plex.fla.data;
%% get parameters and data

sgTm = fez.frontal.sigTm;
durBefStim = fez.frontal.durBefStim;
durAftStim = fez.frontal.durAftStim;

% get counts of trials
hlcnt.fez.front.inhOff = sum(~isnan(fez.frontal.inhOff_handliftIdx));
hlcnt.fez.front.inhOn = sum(~isnan(fez.frontal.inhOn_handliftIdx));

hlcnt.plex.front.inhOff = sum(~isnan(plex.frontal.inhOff_handliftIdx));
hlcnt.plex.front.inhOn = sum(~isnan(plex.frontal.inhOn_handliftIdx));

hlcnt.fez.fla.inhOff = sum(~isnan(fez.fla.inhOff_handliftIdx));
hlcnt.fez.fla.inhOn = sum(~isnan(fez.fla.inhOn_handliftIdx));

hlcnt.plex.fla.inhOff = sum(~isnan(plex.fla.inhOff_handliftIdx));
hlcnt.plex.fla.inhOn = sum(~isnan(plex.fla.inhOn_handliftIdx));

% get hand near mouth duration
inhOff.fez.front.hmdur = fez.frontal.inhOff_handNearMouthDur(~isnan(fez.frontal.inhOff_handliftIdx));
inhOn.fez.front.hmdur = fez.frontal.inhOn_handNearMouthDur(~isnan(fez.frontal.inhOn_handliftIdx));

inhOff.plex.front.hmdur = plex.frontal.inhOff_handNearMouthDur(~isnan(plex.frontal.inhOff_handliftIdx));
inhOn.plex.front.hmdur = plex.frontal.inhOn_handNearMouthDur(~isnan(plex.frontal.inhOn_handliftIdx));

inhOff.fez.fla.hmdur = fez.fla.inhOff_handNearMouthDur(~isnan(fez.fla.inhOff_handliftIdx));
inhOn.fez.fla.hmdur = fez.fla.inhOn_handNearMouthDur(~isnan(fez.fla.inhOn_handliftIdx));

inhOff.plex.fla.hmdur = plex.fla.inhOff_handNearMouthDur(~isnan(plex.fla.inhOff_handliftIdx));
inhOn.plex.fla.hmdur = plex.fla.inhOn_handNearMouthDur(~isnan(plex.fla.inhOn_handliftIdx));


%% 3 way analysis of variance of box plot


g2 = [repmat("frontal",hlcnt.plex.front.inhOff,1); repmat("frontal",hlcnt.plex.front.inhOn,1); ...
    repmat("fla",hlcnt.plex.fla.inhOff,1); repmat("fla",hlcnt.plex.fla.inhOn,1)];

g1 = [repmat("inhOff",hlcnt.plex.front.inhOff,1); repmat("inhOn",hlcnt.plex.front.inhOn,1); ...
    repmat("inhOff",hlcnt.plex.fla.inhOff,1); repmat("inhOn",hlcnt.plex.fla.inhOn,1)];
% position calculation
dataIn = [inhOff.plex.front.hmdur; inhOn.plex.front.hmdur; ...
    inhOff.plex.fla.hmdur; inhOn.plex.fla.hmdur];

grpId = join([g1 g2],"-");
[p,tbl,stats] = anova1(dataIn,grpId);

[results,~,~,gnames] = multcompare(stats);


plex_front_inhOffVsOn = results(find(results(:,1) == 1 & results(:,2) == 2),6);

plex_fla_inhOffVsOn = results(find(results(:,1) == 3 & results(:,2) == 4),6);

%% box plot
close all
h(1) = figure;h(1).Position = [1070 158 1242 695];
grpId = [repmat("plex-frontal-inhOff",hlcnt.plex.front.inhOff,1); repmat("plex-frontal-inhOn",hlcnt.plex.front.inhOn,1); ...
    repmat("plex-fla-inhOff",hlcnt.plex.fla.inhOff,1); repmat("plex-fla-inhOn",hlcnt.plex.fla.inhOn,1)];

boxplot(dataIn,grpId);
ylabel('duration (sec)')
text(1.2,3.25,['pVal = ' num2str(plex_front_inhOffVsOn)])
text(3.2,3.25,['pVal = ' num2str(plex_fla_inhOffVsOn)])
text(2.5,4.0 , '1 Way anova')
sgtitle('Position')

%% %%%%%%%%%%%%% saving the figures %%%%%%%%%%

saveFig = input('Do you want to save the current figures : ');
if saveFig == 1
    %%% saving figures
    savepath = fullfile(['G:\Hemanth_CSHL\OptoWiredInhibition\Data_Figures\HandNearMouthDurPlots\'], ...
        ['handNearMouthDur_FezPlex.fig']);
    savefig(h,savepath)
end
