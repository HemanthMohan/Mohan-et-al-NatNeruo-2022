clear all; close all; clc
[fname fpath] = uigetfile('*.csv');
%% %%%%%%%%%%%%%%% enter details to group sessions %%%%%%%%%%%%%
roiName = {'Fla'}; %% Frontal; Fla;
% mouseIds = {'c16m1';'c17m1';'c17m2'}; %%%% enter the mouse ID to concatenate activity or even a part of it to concatedate across differenct mice
mouseIds = {'c15m2';'c15m3';'c17m1';'c17m2'}; 
% mouseIds = {'c15m3'}; 
mouseType = ['PlexinD1Gtacr1'];
sessionType = ['optowire'];
% dateIn = {'20220610'};
% dateIn = {'20220601';'20220602';'20220603';'20220606';'20220607';'20220608';'20220609';'20220610'; ...
%      '20220611';'20220614';'20220615';'20220616';'20220617'};
dateIn = {'20220601';'20220602';'20220603';'20220606';'20220607';'20220608';'20220609';'20220610'; ...
      '20220611';'20220614';'20220615';'20220616';'20220617';'20220708';'20220711';'20220712'; ...
      '20220713';'20220714';'20220715';'20220718';'20220719';'20220720';'20220721';'20220722';'20220723'; ...
      '20220725';'20220727';'20220728';'20220729'};
%% %%%%%%%%%%%%%%%%%%% get file  name structure %%%%%%%%%%%%
parentFold = fileparts(fileparts(fpath));
foldNames = [];
for jj = 1:length(mouseIds)
    for ii = 1:length(dateIn)
        FoldCont = dir(fullfile(fileparts(fileparts(fpath)),[dateIn{ii} '*', mouseType '*', mouseIds{jj} '*',sessionType '*']));
        foldNames = [foldNames;{FoldCont.name}'];
    end
end
%% %%%%%%%%%%%%%%% get Trial IDs and trajectories of control and inbhibition handlift trials
for kk = 1:length(foldNames)
    fpath1 = [fullfile(parentFold,foldNames{kk}) '\']
    [inhOn_PimOn{kk,1},inhOff_PimOn{kk,1}] = getTrajData(fpath1,roiName);
end
%% identify trials where one of the hand is brought to the mouth
inhOnTj.lfing1x = [];
inhOnTj.lfing1y = [];
inhOnTj.rfing1x = [];
inhOnTj.rfing1y = [];
inhOnTj.fileTrialRefIdx = {};

inhOffTj.lfing1x = [];
inhOffTj.lfing1y = [];
inhOffTj.rfing1x = [];
inhOffTj.rfing1y = [];
stimStartEnd = [];
inhOffTj.fileTrialRefIdx = {};
k  =1;
for ii = 1:length(inhOn_PimOn)
    tempInhOnIdx = inhOn_PimOn{ii}.pimOnIdx(~isnan(inhOn_PimOn{ii}.pimOnIdx));
    tempInhOffIdx = inhOff_PimOn{ii}.pimOnIdx;
    for jj = 1:length(inhOn_PimOn{ii}.ulNormTraj.C1)
        
        inhOnTj.lfing1x = [inhOnTj.lfing1x inhOn_PimOn{ii}.ulNormTraj.C1(jj).lfing1(:,1)];
        inhOnTj.lfing1y = [inhOnTj.lfing1y inhOn_PimOn{ii}.ulNormTraj.C1(jj).lfing1(:,2)];
        inhOnTj.rfing1x = [inhOnTj.rfing1x inhOn_PimOn{ii}.ulNormTraj.C1(jj).rfing1(:,1)];
        inhOnTj.rfing1y = [inhOnTj.rfing1y inhOn_PimOn{ii}.ulNormTraj.C1(jj).rfing1(:,2)];
        inhOnTj.fileTrialRefIdx = [inhOnTj.fileTrialRefIdx; [k,foldNames(ii),tempInhOnIdx(jj)]];
        
        
        inhOffTj.lfing1x = [inhOffTj.lfing1x inhOff_PimOn{ii}.ulNormTraj.C1(jj).lfing1(:,1)];
        inhOffTj.lfing1y = [inhOffTj.lfing1y inhOff_PimOn{ii}.ulNormTraj.C1(jj).lfing1(:,2)];
        inhOffTj.rfing1x = [inhOffTj.rfing1x inhOff_PimOn{ii}.ulNormTraj.C1(jj).rfing1(:,1)];
        inhOffTj.rfing1y = [inhOffTj.rfing1y inhOff_PimOn{ii}.ulNormTraj.C1(jj).rfing1(:,2)];
        inhOffTj.fileTrialRefIdx = [inhOffTj.fileTrialRefIdx; [k,foldNames(ii),tempInhOffIdx(jj)]];
        k = k+1;
        
    end
    stimStartEnd = [stimStartEnd;inhOn_PimOn{ii}.stimStartEnd];
end

%% %%%% indentify if hand is brought close to  the mouth after pellet is picked
fs = 100;
rfing1_yTh = 0.15;
rfing1_xTh = -0.2;
lfing1_yTh = 0.15;
lfing1_xTh = 0.2;
durTh = 0.3; %% duration threhsold for the hand to be close to mouth to be considerd as a successfull lift
trCnt = size(inhOnTj.rfing1y,2);

inhOn_hlIdx = [];
inhOn_noHlIdx = [];
inhOn_hlRef = [];
inhOn_noHlRef = [];

inhOff_hlIdx = [];
inhOff_noHlIdx = [];
inhOff_hlRef = [];
inhOff_noHlRef = [];

% check if either the left hand or right hand is near the mouth after
% picking pellet in mouth

for j = 1:trCnt
    % right finger near mouth duration
    inhOnTjX_r = inhOnTj.rfing1x(:,j);
    inhOnTjY_r = inhOnTj.rfing1y(:,j);
    handNearMouthTm_r = find(inhOnTjX_r > rfing1_xTh & inhOnTjY_r<rfing1_yTh)/fs; %% find the time points when the right finger was close to mouth based on the thrsholds
    handNearMouthDur_r = length(find(handNearMouthTm_r > stimStartEnd(j,1) & handNearMouthTm_r < stimStartEnd(j,2)))/fs; %durion of hand being close ot mouth
   % left finger near mouth duration
    inhOnTjX_l = inhOnTj.lfing1x(:,j);
    inhOnTjY_l = inhOnTj.lfing1y(:,j);
    handNearMouthTm_l = find(inhOnTjX_l < lfing1_xTh & inhOnTjY_l<lfing1_yTh)/fs; %% find the time points when the left finger was close to mouth based on the thrsholds
    handNearMouthDur_l = length(find(handNearMouthTm_l > stimStartEnd(j,1) & handNearMouthTm_l < stimStartEnd(j,2)))/fs; %durion of hand being close ot mouth
    
    % check if either the left or right finger was close to mouth 
    if handNearMouthDur_r>=durTh | handNearMouthDur_l>=durTh 
        inhOn_hlIdx  = [inhOn_hlIdx;j];
        inhOn_hlRef= [inhOn_hlRef; inhOnTj.fileTrialRefIdx(j,:)];
    else
        inhOn_noHlIdx = [inhOn_noHlIdx,j];
        inhOn_noHlRef = [inhOn_noHlRef; inhOnTj.fileTrialRefIdx(j,:)];
    end
    
    % inhibition off condition %
    % right finger near mouth duration
    inhOffTjX = inhOffTj.rfing1x(:,j);
    inhOffTjY = inhOffTj.rfing1y(:,j);
    handNearMouthTm_r = find(inhOffTjX > rfing1_xTh & inhOffTjY<rfing1_yTh)/fs; %% find the time points when the right finger was close to mouth based on the thrsholds
    handNearMouthDur_r = length(find(handNearMouthTm_r > stimStartEnd(j,1) & handNearMouthTm_r < stimStartEnd(j,2)))/fs; %durion of hand being close ot mouth
    % left finger near mouth duration
    inhOffTjX = inhOffTj.lfing1x(:,j);
    inhOffTjY = inhOffTj.lfing1y(:,j);
    handNearMouthTm_l = find(inhOffTjX < lfing1_xTh & inhOffTjY<lfing1_yTh)/fs; %% find the time points when the left finger was close to mouth based on the thrsholds
    handNearMouthDur_l = length(find(handNearMouthTm_l > stimStartEnd(j,1) & handNearMouthTm_l < stimStartEnd(j,2)))/fs; %durion of hand being close ot mouth
    
    % check if either the left or right finger was close to mouth 
    if handNearMouthDur_r>=durTh | handNearMouthDur_l>=durTh 
        inhOff_hlIdx  = [inhOff_hlIdx;j];
        inhOff_hlRef = [inhOff_hlRef; inhOffTj.fileTrialRefIdx(j,:)];
    else
        inhOff_noHlIdx = [inhOff_noHlIdx,j];
        inhOff_noHlRef = [inhOff_noHlRef; inhOffTj.fileTrialRefIdx(j,:)];
    end
end
%% %%%%%%%%%%%%%% calculate the proportion of handlifts
inhOn_hlProb = length(inhOn_hlIdx)/trCnt
inhOff_hlProb = length(inhOff_hlIdx)/trCnt
%% saving data
data.inhOn_TrialRef = inhOnTj.fileTrialRefIdx;
data.inhOn_handliftIdx = inhOn_hlIdx;
data.inhOn_handliftTrialRef = inhOn_hlRef;
data.inhOn_noHandliftIdx = inhOn_noHlIdx;
data.inhOn_noHandliftTrialRef = inhOn_noHlRef;
data.inhOff_TrialRef = inhOffTj.fileTrialRefIdx;
data.inhOff_handliftIdx = inhOff_hlIdx;
data.inhOff_handliftTrialRef = inhOff_hlRef;
data.inhOff_noHandliftIdx = inhOff_noHlIdx;
data.inhOff_noHandliftTrialRef = inhOff_noHlRef;
data.roiName = roiName;
data.mouseIds = mouseIds;
data.mouseType = mouseType;
data.datesAnalyzed = dateIn;
data.FoldersAnalyzed = foldNames;
%% %%%%%%%%% saving the data %%%%%%%%%%

filename = ['HandliftProportion_' roiName{1} '_' mouseType '.mat'];
saveData = input('Do you want to save the current data : ');
if saveData == 1
    %%% saving data
    savePath = fullfile('G:\Hemanth_CSHL\OptoWiredInhibition\Data_Analysis\HandliftProportion\' ,filename);
    save(savePath,'data')
end
%% plot sample trajectories
close all
tm = linspace(0,15,1500); 
id = 15;
h1 = figure;h1.Position = [238,92,1097,892];
ax(1) = subplot(4,2,1);
plot(tm,inhOffTj.lfing1x(:,id),'k')
hold on
plot([0,15],[lfing1_xTh,lfing1_xTh],'r--')
area([0,15],[lfing1_xTh,lfing1_xTh],'FaceColor','r','FaceAlpha',0.2)
plot([stimStartEnd(id,1) stimStartEnd(id,2)],[0.5 0.5],'c-','LineWidth',4)

title('inh off left fing x')

ax(2) = subplot(4,2,3);
plot(tm,inhOffTj.lfing1y(:,id),'k')
hold on
plot([0,15],[lfing1_yTh,lfing1_yTh],'r--')
area([0,15],[lfing1_yTh,lfing1_yTh],'FaceColor','r','FaceAlpha',0.2)
plot([stimStartEnd(id,1) stimStartEnd(id,2)],[0.5 0.5],'c-','LineWidth',4)
title('inh off left fing y')

ax(3) = subplot(4,2,5);
plot(tm,inhOffTj.rfing1x(:,id),'k')
hold on
plot([0,15],[rfing1_xTh,rfing1_xTh],'r--')
area([0,15],[rfing1_xTh,rfing1_xTh],'FaceColor','r','FaceAlpha',0.2)
plot([stimStartEnd(id,1) stimStartEnd(id,2)],[-0.5 -0.5],'c-','LineWidth',4)
title('inh off right fing x')

ax(4) = subplot(4,2,7);
plot(tm,inhOffTj.rfing1y(:,id),'k')
hold on
plot([0,15],[rfing1_yTh,rfing1_yTh],'r--')
area([0,15],[rfing1_yTh,rfing1_yTh],'FaceColor','r','FaceAlpha',0.2)
plot([stimStartEnd(id,1) stimStartEnd(id,2)],[-0.5 -0.5],'c-','LineWidth',4)
title('inh off right fing y')

ax(5) = subplot(4,2,2);
plot(tm,inhOnTj.lfing1x(:,id),'g')
hold on
plot([0,15],[lfing1_xTh,lfing1_xTh],'r--')
area([0,15],[lfing1_xTh,lfing1_xTh],'FaceColor','r','FaceAlpha',0.2)
plot([stimStartEnd(id,1) stimStartEnd(id,2)],[0.5 0.5],'c-','LineWidth',4)
title('inh on left fing x')

ax(6) = subplot(4,2,4);
plot(tm,inhOnTj.lfing1y(:,id),'g')
hold on
plot([0,15],[lfing1_yTh,lfing1_yTh],'r--')
area([0,15],[lfing1_yTh,lfing1_yTh],'FaceColor','r','FaceAlpha',0.2)
plot([stimStartEnd(id,1) stimStartEnd(id,2)],[0.5 0.5],'c-','LineWidth',4)
title('inh on left fing y')

ax(7) = subplot(4,2,6);
plot(tm,inhOnTj.rfing1x(:,id),'g')
hold on
plot([0,15],[rfing1_xTh,rfing1_xTh],'r--')
area([0,15],[rfing1_xTh,rfing1_xTh],'FaceColor','r','FaceAlpha',0.2)
plot([stimStartEnd(id,1) stimStartEnd(id,2)],[-0.5 -0.5],'c-','LineWidth',4)
title('inh on right fing x')

ax(8) = subplot(4,2,8);
plot(tm,inhOnTj.rfing1y(:,id),'g')
hold on
plot([0,15],[rfing1_yTh,rfing1_yTh],'r--')
area([0,15],[rfing1_yTh,rfing1_yTh],'FaceColor','r','FaceAlpha',0.2)
plot([stimStartEnd(id,1) stimStartEnd(id,2)],[-0.5 -0.5],'c-','LineWidth',4)
title('inh on right fing y')
sgtitle (['ID = ' num2str(id)])

linkaxes(ax)
%% %%%%%%%% main function
function [inhOn_pimOn,inhOff_pimOn] = getTrajData(fpath,roiName)
%% %%%%%%%%%%%%%%%% get file  name structure %%%%%%%%%%%%

[fnFeat, usFeat ] = getOptoFileNameProperties(fpath);%%% get all fileNames variables
%% %%%%%%%%%%%%%%% Get Lick, Pim, Handlift Behavior Trial IDs %%%%%%%%%%%%%%%
disp('Extracting Behavior Temporal features .... ')
ExtractManipulaion = 0;%%%%% Enter zero to not extract manipulation times and 1 to extract
[BData] = GetBehavEventTimesOptoWire(fpath,ExtractManipulaion);
allTrialIdx = cell2mat(BData.Data(:,1));
lickOnsetAll = BData.Data(:,9);
pimOnsetAll = BData.Data(:,10);
hlOnsetAll = BData.Data(:,11);
lickOnIdx = find(cell2mat(BData.Data(:,2)) == 1);
pimOnIdx = find(cell2mat(BData.Data(:,2)) == 1 & cell2mat(BData.Data(:,3)) == 1);
% hlOnIdx = find(cell2mat(BData.Data(:,2)) == 1 & cell2mat(BData.Data(:,3)) == 1 & cell2mat(BData.Data(:,4)) == 1);
hlOnIdx = find(~cellfun(@isempty,hlOnsetAll));

bTime = linspace(0,15,1500);
%% %%% get roi stimulation index and parameters
roiParms = getRoiStimTrialIdx(fnFeat);
inhOn_Idx = roiParms.LzOnIdx;
%% Get trials with Hand lift event during frontal inhibition.
inhOn_pimOn_idx = nan(length(roiParms.(['LzOn' roiName{1} 'Idx'])),1);
inhOn_pimOff_idx = nan(length(roiParms.(['LzOn' roiName{1} 'Idx'])),1);
inhOn_ulNormTrajC2 = [];
inhOn_ulNormTrajC1 = [];
stimStartEnd = [];

for ii = 1:length(roiParms.(['LzOn' roiName{1} 'Idx']))
    inIdx = roiParms.(['LzOn' roiName{1} 'Idx'])(ii); %%% which index is being analyzed
    stimOnset = roiParms.(['LzOn' roiName{1} 'Parm']){ii,3}; %% stim onset time in seconds
    stimDur = roiParms.(['LzOn' roiName{1} 'Parm']){ii,4}; %% stim duration time in seconds
    stimEndTime = stimOnset + stimDur; %%% stim end time in seconds
    stimStartEnd = [stimStartEnd; [stimOnset stimEndTime]];
    %%
    [trajDataC1,trajDataC2,bodyPartsC1,bodyPartsC2 ] = getBehaviorTrajectory(fpath,fnFeat,usFeat,inIdx);
    %% collect upperlip normalized trajectories
    for jj = 1:length(fieldnames(trajDataC1))
        inhOn_ulNormTrajC1(ii).(bodyPartsC1{jj}) = (trajDataC1.(bodyPartsC1{jj})(:,1:2) - nanmean(trajDataC1.upperlip(:,1:2)))./nanmean(trajDataC1.upperlip(:,1:2));
    end
    
    for jj = 1:length(fieldnames(trajDataC2))
        inhOn_ulNormTrajC2(ii).(bodyPartsC2{jj}) = (trajDataC2.(bodyPartsC2{jj})(:,1:2) - nanmean(trajDataC2.upperlip(:,1:2)))./nanmean(trajDataC2.upperlip(:,1:2));
    end
    
        %%
    if sum(inIdx == pimOnIdx) == 1 %% check if the animal picks the pellet in mouth
        pimOnTime = pimOnsetAll{inIdx};
        if pimOnTime < stimEndTime % check if pim happend before end of stimulation and not after
            if stimOnset <= pimOnTime+0.5 % check if stim onset is before pimOnset + 0.5 sec so that it before expected handlift time
                inhOn_pimOn_idx(ii) = inIdx; %%% trials with pim where inhibition starts within 0.5 seconds of pim  
            else
                inhOn_pimOff_idx(ii) = inIdx;
            end
        else
            inhOn_pimOff_idx(ii) = inIdx;
        end
    end
    
end

inhOn_pimOn.ulNormTraj.C1 = inhOn_ulNormTrajC1(~isnan(inhOn_pimOn_idx));
inhOn_pimOn.ulNormTraj.C2 = inhOn_ulNormTrajC2(~isnan(inhOn_pimOn_idx));
inhOn_pimOn.stimStartEnd = stimStartEnd(~isnan(inhOn_pimOn_idx),:);
inhOn_pimOn.pimOnIdx = inhOn_pimOn_idx;
inhOn_pimOn.pimOffIdx = inhOn_pimOff_idx;
%% Get Trials with hand lift during control trials
inhOff_pimOnIdxAll = intersect(roiParms.LzOffIdx,pimOnIdx); %% get trials with pim duirng no inhibition
%% remove late pim trials
pimOnTh = max(stimStartEnd(:));
for p = 1:length(inhOff_pimOnIdxAll)
    inIdx = inhOff_pimOnIdxAll(p);
    if pimOnsetAll{inIdx} > pimOnTh 
        inhOff_pimOnIdxAll(p) = nan;
    end
end
inhOff_pimOnIdxAll(isnan(inhOff_pimOnIdxAll)) = [];
%% get Pim On Indices of trials just before the inhibition on trials
inhOff_pimOn_idx = []; 
for kk = 1:length(inhOn_pimOn_idx)
    inhOff_pimOn_idx = [inhOff_pimOn_idx; inhOff_pimOnIdxAll(find(inhOff_pimOnIdxAll<inhOn_pimOn_idx(kk),1,'last'))]; %% get index id of pim on trial just before the inhibition trial
end

% find repeat trials and replace it with an older trial idx
[unqVal unqLoc] = unique(inhOff_pimOn_idx,'first');
repeatLoc = find(not(ismember(1:numel(inhOff_pimOn_idx),unqLoc)));
for kk = 1:length(repeatLoc)
    temp1 =  setdiff(inhOff_pimOnIdxAll(find(inhOff_pimOnIdxAll<inhOff_pimOn_idx(repeatLoc(kk)))), inhOff_pimOn_idx);
    inhOff_pimOn_idx(repeatLoc(kk)) = temp1(end); %% unique indices of lazer off indices
end
%% get inh off trajectories
for pp = 1:length(inhOff_pimOn_idx)
    [trajDataC1,trajDataC2,bodyPartsC1,bodyPartsC2 ] = getBehaviorTrajectory(fpath,fnFeat,usFeat,inhOff_pimOn_idx(pp));
    
    for jj = 1:length(fieldnames(trajDataC1))
        inhOff_pimOn.ulNormTraj.C1(pp).(bodyPartsC1{jj}) = (trajDataC1.(bodyPartsC1{jj})(:,1:2) - nanmean(trajDataC1.upperlip(:,1:2)))./nanmean(trajDataC1.upperlip(:,1:2));
    end
    
    for jj = 1:length(fieldnames(trajDataC2))
        inhOff_pimOn.ulNormTraj.C2(pp).(bodyPartsC2{jj}) = (trajDataC2.(bodyPartsC2{jj})(:,1:2) - nanmean(trajDataC2.upperlip(:,1:2)))./nanmean(trajDataC2.upperlip(:,1:2));
    end
end
inhOff_pimOn.pimOnIdx = inhOff_pimOn_idx;
%%

end

%% extract inhition off trajectory
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Functions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [TrajDataC1,TrajDataC2,BodyPartsC1,BodyPartsC2 ] = getBehaviorTrajectory(fpath,fnFeat,usFeat,FileId)
pcutoffC1 = 0.9;
pcutoffC2 = 0.8;
fnameinC1 = [fnFeat.fname_exC1(1:usFeat.bidx_stC1) num2str(FileId) fnFeat.fname_exC1(usFeat.bidx_endC1:end)];
filepathC1 = fullfile(fpath,fnameinC1);
[TrajDataC1 BodyPartsC1] =  ExtractBodyTraj(filepathC1,pcutoffC1);

fnameinC2 = [fnFeat.fname_exC2(1:usFeat.bidx_stC2) num2str(FileId) fnFeat.fname_exC2(usFeat.bidx_endC2:end)];
filepathC2 = fullfile(fpath,fnameinC2);
[TrajDataC2 BodyPartsC2] =  ExtractBodyTraj(filepathC2,pcutoffC2);
end

function [parms] = getRoiStimTrialIdx(fnFeat)
%% %%%%%%%%%% get laser stimulation parameters and trials
[stimParm,stimHead] = getLaserStimParam(fnFeat);
parms.LzOnIdx = find(cell2mat(stimParm(:,1)) == 1);
parms.LzOffIdx = find(cell2mat(stimParm(:,1)) == 0);
parms.stimHeading = stimHead;
parms.stimParmAll = stimParm;
%% %%%%% Roi Laser On Idx
if strcmp(lower(stimParm(1,2)), 'frontal')
    parms.LzOnFrontalIdx = find(cell2mat(stimParm(:,1)) == 1);
    parms.LzOnFlaIdx = [];
elseif strcmp(lower(stimParm(1,2)), 'fla')
    parms.LzOnFlaIdx = find(cell2mat(stimParm(:,1)) == 1);
    parms.LzOnFrontalIdx = [];
end
%% Roi Laser Parameters
parms.LzOnParm = stimParm(parms.LzOnIdx,:);
parms.LzOnFrontalParm = stimParm(parms.LzOnFrontalIdx,:);
parms.LzOnFlaParm = stimParm(parms.LzOnFlaIdx,:);
end

function [stimParm,stimHead] = getLaserStimParam(fnFeat)
for ii = 1:length(fnFeat.sname_all)
    data = load(fullfile(fnFeat.spath,fnFeat.sname_all{ii})); data = data.data;
    stimParm(ii,:) = data(2,:);
end
stimHead = data(1,:);
end

function [fnFeat, usFeat ] = getOptoFileNameProperties(fpath)
%%%%%%%%%%%%% getting signal file name %%%%%%%%%%%%%%
listing_csv = dir([fpath '\*.csv']);
[~, sflname] = fileparts(fileparts(fpath));
spath = fullfile(fileparts(fileparts(fileparts(fpath))), 'OptoWiredData', sflname);
listing_sig = dir([spath '\*.mat']);
sname_all = natsortfiles({listing_sig.name}');
sname_ex = sname_all{1};
us_idx = find(sname_ex == '_',1,'last');

%%%%%%%% getting body trajectory file name %%%%%%%%%%%%
fname_all = natsortfiles({listing_csv.name}');
fname_allC1 = fname_all( contains(fname_all,'c1_T'));
fname_allC2 = fname_all( contains(fname_all,'c2_T'));

fname_exC1 = fname_allC1{1};
fname_us_idxC1 = find(fname_exC1 == '_');
fname_deep_idxC1 = strfind(fname_exC1, 'Deep');
bidx_stC1 = fname_us_idxC1(end-3);
bidx_endC1 = fname_deep_idxC1;

fname_exC2 = fname_allC2{1};
fname_us_idxC2 = find(fname_exC2 == '_');
fname_deep_idxC2 = strfind(fname_exC2, 'Deep');
bidx_stC2 = fname_us_idxC2(end-3);
bidx_endC2 = fname_deep_idxC2;


%%% updating all properties
fnFeat.sname_all = sname_all;
fnFeat.fname_allC1 = fname_allC1;
fnFeat.fname_allC2 = fname_allC2;
fnFeat.sname_ex = sname_ex;
fnFeat.fname_exC1 = fname_exC1;
fnFeat.fname_exC2 = fname_exC2;
fnFeat.spath = spath;

usFeat.us_idx = us_idx;
usFeat.bidx_stC1 = bidx_stC1;
usFeat.bidx_endC1 = bidx_endC1;
usFeat.bidx_stC2 = bidx_stC2;
usFeat.bidx_endC2 = bidx_endC2;
end