function [BData] = GetBehavEventTimesOptoWire(fpath,GetManipulationTimes,IDs)
%%% Set GetManipulationTimes = 0 if you want manipulation times
if nargin < 2
    GetManipulationTimes = 1;
end
%% %%%%%%%%%%% Loading the File Properties %%%%%%%%%%%%%%
if nargin < 1
    [fname fpath] = uigetfile('*.csv');
end
%%
Fs = 100; % Sampling rate video
SigFs = 30; % Sampling rate Calcium acquisition
vidtime = 0:1/Fs:15; vidtime(end) = []; % Time signal
sigTime = 0:1/SigFs:15; sigTime(end) = [];
pcutoffC1 = 0.9; %%% Camera 1 trajectory prob cutoff
pcutoffC2 = 0.9; %%% Camera 2 trajectory prob cutoff
pMani = 0.8; %%% probability cutoff to classify manipulation behavior
MinManiDur = 0.1; %%% Minimum duration of Manipulatin to consider In SECONDS
MinInterManiDur = 0.1 ; %%% Minimum inter manipulation duration below which It is combined in SECONDS
[fnFeat, usFeat ] = getFileNamePropertiesOpto(fpath);%%% get all fileNames variables
%%
firstIdx = str2num(fnFeat.sname_all{1,1}(end-4));
if nargin < 3
    if firstIdx>1
        IDs = [firstIdx:length(fnFeat.fname_allC1)+firstIdx-1];
    else
        IDs = [1:length(fnFeat.fname_allC1)];
    end
end
%% %%%%%%%%%%% Extracting All Body Trajectories %%%%%%%%%%%%%%%%%%%%%
for fi = 1:length(IDs);
    %%
    [TrajDataC1 BodyPartsC1 TrajDataC2 BodyPartsC2] =  getBodyTrajectories(IDs(fi),pcutoffC1,pcutoffC2,fnFeat,usFeat,fpath);
    
    %% %%%%%%%%%%%%%%% Extracting Lick Event Times %%%%%%%%%%%%%%%%%
    LthreshC1 = 0.05; %%% def 0.05
    MinInterLickStartDur = 0.5; %%% in seconds def 0.5
    trajTong = TrajDataC1.tongue(:,1:2);
    trajTong_in = trajTong(:,2);
    [LickSig,LickT, LickStartTime, LickEndTime] = LickStartEnd(trajTong_in,LthreshC1,Fs,MinInterLickStartDur);
    LickDurations = LickEndTime - LickStartTime;
    FirstSigLickStartTime = LickStartTime(find(LickStartTime> 2,1)); %%% find lick start after 2 seconds of trial start
    isLick = ~isempty(FirstSigLickStartTime);
    
    %% %%%%%%%%%%%%%%%%%%%%%% Extracting Pellet in Mouth Onset Time %%%%%%%%%%%%%%
    [PIMStartIdx PIMStartTime] = PelletInMouthOnset(TrajDataC1,Fs); %% Get pellet in mouth time onset
    isPIM = ~isempty(PIMStartIdx);
    %%  %%%%%%%%%%%%%%%%%%%%%%%% Extracting First HandLift Onset Time %%%%%%%%%%%%
    HthreshC2 = 0.2;% def 0.25
    HTraj = TrajDataC2.lhand(:,2);
    HTraj(TrajDataC2.lhand(:,2) < 150) = nan; %%% remving trajectory jumps in lhand traj
    HTrajin = HTraj ;
    HTrajin(1:PIMStartIdx) = nan;
    [HandSig,HLiftStarttime,HLiftStartIdx,HandSig_Diff] = HandLiftStartSideView_Diff(HTrajin,PIMStartIdx,HthreshC2);
    
    %% %%%%%%%%%%%%%%%%%% checking if HandLift for manipulation execution %%%%%
    HandNoseThresh = 4.5;
    HandNoseCountThresh = 300;
    lhandTraj = TrajDataC2.lhand(:,2); lhandTraj(TrajDataC2.lhand(:,2)<150) = nan;
    HandNoseDist = lhandTraj - TrajDataC2.nose(:,2);
    NoseUpperLipDist = TrajDataC2.upperlip(:,2) - TrajDataC2.nose(:,2);
    HandNoseRelDist = HandNoseDist./NoseUpperLipDist;
    HandNoseCount = length(find(HandNoseRelDist(PIMStartIdx:end) < HandNoseThresh));
    isHandLift = HandNoseCount > HandNoseCountThresh;
    
    %% %%%%%%%%%%%%% Extracting manipulation times %%%%%%%%%%%%
    if GetManipulationTimes == 1
        MNet = load('F:\Hemanth_CSHL\WideField\BehaviorData\ManipulationClassification\ManipulationNet.mat');
        MStartEndCorrected_Index = [];
        ManiSig = [];
        FnameinC1 = [fnFeat.fname_exC1(1:usFeat.bidx_stC1) num2str(IDs(fi)) fnFeat.fname_exC1(usFeat.bidx_endC1:end)]; %%% generate appropriate file name
        FilepathC1 = fullfile(fpath,FnameinC1); %%% generate appropriate full file path
        [ManiSig, TrajDataC1] = getManipulationTrace(MNet.ManipulationNet,FilepathC1,pcutoffC1,pMani); %%% Predict manipulation classification signal
        if sum(ManiSig) > 0
   
            MStartEndCorrected_Index = getCorrectedManipulationIndex(ManiSig,MinInterManiDur,MinManiDur,Fs);
            MStartEndCor_Time = vidtime(MStartEndCorrected_Index);
        else
            MStartEndCorrected_Index = [];
            MStartEndCor_Time = [];
            disp(['No Manipulation Found in file Id ' num2str(IDs(fi))]);
        end
    else
        MStartEndCor_Time = [nan];
    end
    
    %% %%%%%%%%%%%%%%%% Generate Behavior Data Matrix %%%%%%%%%%%%%%%%%
    BData.Data(fi,:) = {IDs(fi) isLick isPIM isHandLift [2] [3] LickStartTime LickDurations FirstSigLickStartTime ...
        PIMStartTime HLiftStarttime MStartEndCor_Time };
    
end
BData.Headers = {'FileId' 'isLick' 'isPIM' 'isHandLift' 'PelletDropStart' 'CBeltStart' 'AllLickOnsetTimes' 'AllLickDuration' ...
    'FirstSigLickOnsetTime'  'PIMOnsetTime' 'HandLiftOnsetTime' ...
    'ManipulationStartEndTime'};

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Functions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [TrajDataC1 BodyPartsC1 TrajDataC2 BodyPartsC2] =  getBodyTrajectories(ii,pcutoffC1,pcutoffC2,fnFeat,usFeat,fpath)
fnameinC1 = [fnFeat.fname_exC1(1:usFeat.bidx_stC1) num2str(ii) fnFeat.fname_exC1(usFeat.bidx_endC1:end)]; %%% generate appropriate file name
filepathC1 = fullfile(fpath,fnameinC1); %%% generate appropriate full file path
[TrajDataC1 BodyPartsC1] =  ExtractBodyTraj(filepathC1,pcutoffC1);

fnameinC2 = [fnFeat.fname_exC2(1:usFeat.bidx_stC2) num2str(ii) fnFeat.fname_exC2(usFeat.bidx_endC2:end)]; %%% generate appropriate file name
filepathC2 = fullfile(fpath,fnameinC2); %%% generate appropriate full file path
[TrajDataC2 BodyPartsC2] =  ExtractBodyTraj(filepathC2,pcutoffC2);
end

function [fnFeat, usFeat ] = getFileNamePropertiesOpto(fpath)
%%%%%%%%%%%%% getting signal file name %%%%%%%%%%%%%%
listing_csv = dir([fpath '\*.csv']);
[~, sflname] = fileparts(fileparts(fpath));
spath = fullfile(fileparts(fileparts(fileparts(fpath))), 'OptoWiredData', sflname);
listing_sig = dir([spath '\*.mat']);
sname_all = natsortfiles({listing_sig.name}');
sname_ex = sname_all{1};
us_idx = find(sname_ex == '_',1,'last');

%%%%%%%% getting body trajectory file name %%%%%%%%%%%%
fname_all = natsortfiles({listing_csv.name}');
fname_allC1 = fname_all( contains(fname_all,'c1_T'));
fname_allC2 = fname_all( contains(fname_all,'c2_T'));

fname_exC1 = fname_allC1{1};
fname_us_idxC1 = find(fname_exC1 == '_');
fname_deep_idxC1 = strfind(fname_exC1, 'Deep');
bidx_stC1 = fname_us_idxC1(end-3);
bidx_endC1 = fname_deep_idxC1;

fname_exC2 = fname_allC2{1};
fname_us_idxC2 = find(fname_exC2 == '_');
fname_deep_idxC2 = strfind(fname_exC2, 'Deep');
bidx_stC2 = fname_us_idxC2(end-3);
bidx_endC2 = fname_deep_idxC2;


%%% updating all properties
fnFeat.sname_all = sname_all;
fnFeat.fname_allC1 = fname_allC1;
fnFeat.fname_allC2 = fname_allC2;
fnFeat.sname_ex = sname_ex;
fnFeat.fname_exC1 = fname_exC1;
fnFeat.fname_exC2 = fname_exC2;
fnFeat.spath = spath;

usFeat.us_idx = us_idx;
usFeat.bidx_stC1 = bidx_stC1;
usFeat.bidx_endC1 = bidx_endC1;
usFeat.bidx_stC2 = bidx_stC2;
usFeat.bidx_endC2 = bidx_endC2;
end

function [ManiSig, TrajDataC1] = getManipulationTrace(ManipulationNet,filepathC1,pcutoffC1,pMani)
[TrajDataC1 BodyPartsC1] =  ExtractBodyTraj(filepathC1,pcutoffC1);
allTrajData = [];
for bp = 1:length(BodyPartsC1)
    allTrajData = [allTrajData TrajDataC1.(BodyPartsC1{bp})(:,1:2)];
end
allTrajDataN = normalize(allTrajData,1);
allTrajDataN(isnan(allTrajDataN)) = 0;
%%%
Xin = tonndata(allTrajDataN,false,false)';
[ypred yscores] = classify(ManipulationNet,Xin);
ManiSig = zeros(1500,1);
ManiSig(find(yscores(:,1)>pMani)) = 1;
end

function MStartEndCorrected_Index = getCorrectedManipulationIndex(ManiSig,MinInterManiDur,MinManiDur,Fs)
MinInterManiCount = MinInterManiDur * Fs;
MinManiDurCount = MinManiDur * Fs;
ManiSigDiff = diff(ManiSig);
MStart = find(ManiSigDiff == 1) + 1;
MEnd = find(ManiSigDiff == -1) ;

%%% delete the Mstart event which happens at the end when there is no Mend
if length(MStart) == length(MEnd) + 1
    MStart(end) = [];
elseif length(MEnd) == length(MStart) +1
    MEnd(1) = [];
end
try
InterManiCount = MStart(2:end) - MEnd(1:end-1);
MStart_temp = MStart(2:end);
MEnd_temp = MEnd(1:end-1);
MStart_temp(find(InterManiCount < MinInterManiCount)) = [];
MEnd_temp(find(InterManiCount < MinInterManiCount)) = [];

MStartCor = [MStart(1); MStart_temp];
MEndCor = [MEnd_temp;MEnd(end)];
MStartEndCorrected_Index = [MStartCor MEndCor];
MStartEndDiff = MEndCor - MStartCor;
MStartEndCorrected_Index(find(MStartEndDiff < MinManiDurCount),:) = [];
catch
    MStartEndCorrected_Index = [];
end
end

