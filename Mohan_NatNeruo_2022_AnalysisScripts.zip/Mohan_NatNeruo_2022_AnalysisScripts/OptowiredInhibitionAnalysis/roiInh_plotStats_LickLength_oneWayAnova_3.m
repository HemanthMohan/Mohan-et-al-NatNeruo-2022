clear all; close all;clear mem; clc
%% load data
fez.frontal = load(['G:\Hemanth_CSHL\OptoWiredInhibition\Data_Analysis\LickTrajectory\' ...
    'LickTongueLength_Frontal_FezF2Gtacr1.mat']);
fez.frontal = fez.frontal.data;

fez.fla = load(['G:\Hemanth_CSHL\OptoWiredInhibition\Data_Analysis\LickTrajectory\' ...
    'LickTongueLength_Fla_FezF2Gtacr1.mat']);
fez.fla = fez.fla.data;

plex.frontal = load(['G:\Hemanth_CSHL\OptoWiredInhibition\Data_Analysis\LickTrajectory\' ...
    'LickTongueLength_Frontal_PlexinD1Gtacr1.mat']);
plex.frontal = plex.frontal.data;

plex.fla = load(['G:\Hemanth_CSHL\OptoWiredInhibition\Data_Analysis\LickTrajectory\' ...
'LickTongueLength_Fla_PlexinD1Gtacr1.mat']);
plex.fla = plex.fla.data;
%% get all ids
ids_frontal_fez = {};
for ii = 1:length(fez.frontal.allInhParams)
    ids_temp = {};
    for jj = 1:length(fez.frontal.allInhParams{ii,1}.inhOn_lickOn_Idx)
    ids_temp = [ids_temp; [fez.frontal.FoldersAnalyzed{ii} '-' num2str(fez.frontal.allInhParams{ii,1}.inhOn_lickOn_Idx(jj))]];
    end
    ids_frontal_fez = [ids_frontal_fez; ids_temp];
end

ids_fla_fez = {};
for ii = 1:length(fez.fla.allInhParams)
    ids_temp = {};
    for jj = 1:length(fez.fla.allInhParams{ii,1}.inhOn_lickOn_Idx)
    ids_temp = [ids_temp; [fez.fla.FoldersAnalyzed{ii} '-' num2str(fez.fla.allInhParams{ii,1}.inhOff_lickOn_Idx(jj))]];
    end
    ids_fla_fez = [ids_fla_fez; ids_temp];
end

ids_frontal_plex = {};
for ii = 1:length(plex.frontal.allInhParams)
    ids_temp = {};
    for jj = 1:length(plex.frontal.allInhParams{ii,1}.inhOn_lickOn_Idx)
    ids_temp = [ids_temp; [plex.frontal.FoldersAnalyzed{ii} '-' num2str(plex.frontal.allInhParams{ii,1}.inhOn_lickOn_Idx(jj))]];
    end
    ids_frontal_plex = [ids_frontal_plex; ids_temp];
end

ids_fla_plex = {};
for ii = 1:length(plex.fla.allInhParams)
    ids_temp = {};
    for jj = 1:length(plex.fla.allInhParams{ii,1}.inhOn_lickOn_Idx)
    ids_temp = [ids_temp; [plex.fla.FoldersAnalyzed{ii} '-' num2str(plex.fla.allInhParams{ii,1}.inhOn_lickOn_Idx(jj))]];
    end
    ids_fla_plex = [ids_fla_plex; ids_temp];
end
%% get parameters and data
sgTm = fez.frontal.trajTime;
durBefStim = fez.frontal.durBefStim;
durAftStim = fez.frontal.durAftStim;

inhOff_fez_front = fez.frontal.inhOff_TngTraj;
inhOn_fez_front = fez.frontal.inhOn_TngTraj;

inhOff_plex_front = plex.frontal.inhOff_TngTraj;
inhOn_plex_front = plex.frontal.inhOn_TngTraj;

inhOff_fez_fla = fez.fla.inhOff_TngTraj;
inhOn_fez_fla = fez.fla.inhOn_TngTraj;

inhOff_plex_fla = plex.fla.inhOff_TngTraj;
inhOn_plex_fla = plex.fla.inhOn_TngTraj;
%% clean up jumps in data
inhOff_fez_front(inhOff_fez_front<0) = nan;
inhOn_fez_front(inhOn_fez_front<0) = nan;

inhOff_plex_front(inhOff_plex_front<0) = nan;
inhOn_plex_front(inhOn_plex_front<0) = nan;

inhOff_fez_fla(inhOff_fez_fla<0) = nan;
inhOn_fez_fla (inhOn_fez_fla <0) = nan;

inhOff_plex_fla(inhOff_plex_fla<0) = nan;
inhOn_plex_fla(inhOn_plex_fla<0) = nan;

%% extract minimum value
minVal = nanmin([ inhOff_fez_front(:);inhOn_fez_front(:);inhOff_plex_front(:);inhOn_plex_front(:); ...
    inhOff_fez_fla(:);inhOn_fez_fla(:);inhOff_plex_fla(:);inhOn_plex_fla(:)]);
% % replace nan with minimum value
inhOff_fez_front(isnan(inhOff_fez_front)) = minVal;
inhOn_fez_front(isnan(inhOn_fez_front)) = minVal;

inhOff_plex_front(isnan(inhOff_plex_front)) = minVal;
inhOn_plex_front(isnan(inhOn_plex_front)) = minVal;

inhOff_fez_fla(isnan(inhOff_fez_fla)) = minVal;
inhOn_fez_fla(isnan(inhOn_fez_fla)) = minVal;

inhOff_plex_fla(isnan(inhOff_plex_fla)) = minVal;
inhOn_plex_fla(isnan(inhOn_plex_fla)) = minVal;
%% perform stats
sigdur = 1.5; %% how much time before and after to onside for analysis in secodds

befIdx = find(sgTm<=0 & sgTm>-sigdur);
aftIdx = find(sgTm>0 & sgTm<sigdur);


inhOffAvg_aftStim_fez_front = nanmean(inhOff_fez_front(aftIdx,:));
inhOnAvg_aftStim_fez_front = nanmean(inhOn_fez_front(aftIdx,:));

inhOffAvg_aftStim_plex_front = nanmean(inhOff_plex_front(aftIdx,:));
inhOnAvg_aftStim_plex_front = nanmean(inhOn_plex_front(aftIdx,:));

inhOffAvg_aftStim_fez_fla = nanmean(inhOff_fez_fla(aftIdx,:));
inhOnAvg_aftStim_fez_fla = nanmean(inhOn_fez_fla(aftIdx,:));

inhOffAvg_aftStim_plex_fla = nanmean(inhOff_plex_fla(aftIdx,:));
inhOnAvg_aftStim_plex_fla = nanmean(inhOn_plex_fla(aftIdx,:));

%% 3 way analysis of variance
cnt.fez.front = length(inhOffAvg_aftStim_fez_front);
cnt.plex.front = length(inhOffAvg_aftStim_plex_front);
cnt.fez.fla = length(inhOffAvg_aftStim_fez_fla);
cnt.plex.fla = length(inhOffAvg_aftStim_plex_fla);

g2 = [repmat("fez",cnt.fez.front,1); repmat("fez",cnt.fez.front,1); ...
    repmat("plex",cnt.plex.front,1); repmat("plex",cnt.plex.front,1); ...
    repmat("fez",cnt.fez.fla,1); repmat("fez",cnt.fez.fla,1); ...
    repmat("plex",cnt.plex.fla,1); repmat("plex",cnt.plex.fla,1)];
g3 = [repmat("frontal",cnt.fez.front,1); repmat("frontal",cnt.fez.front,1); ...
    repmat("frontal",cnt.plex.front,1); repmat("frontal",cnt.plex.front,1); ...
    repmat("fla",cnt.fez.fla,1); repmat("fla",cnt.fez.fla,1); ...
    repmat("fla",cnt.plex.fla,1); repmat("fla",cnt.plex.fla,1)];
g1 = [repmat("inhOff",cnt.fez.front,1); repmat("inhOn",cnt.fez.front,1); ...
    repmat("inhOff",cnt.plex.front,1); repmat("inhOn",cnt.plex.front,1); ...
    repmat("inhOff",cnt.fez.fla,1); repmat("inhOn",cnt.fez.fla,1); ...
    repmat("inhOff",cnt.plex.fla,1); repmat("inhOn",cnt.plex.fla,1)];

dataIn = [inhOffAvg_aftStim_fez_front inhOnAvg_aftStim_fez_front ...
    inhOffAvg_aftStim_plex_front inhOnAvg_aftStim_plex_front ...
    inhOffAvg_aftStim_fez_fla inhOnAvg_aftStim_fez_fla ...
    inhOffAvg_aftStim_plex_fla inhOnAvg_aftStim_plex_fla];

grpId = join([g1 g2 g3],"-");

% [p,tbl,stats] = anovan(dataIn,{g1 g2 g3},"Model","full", ...
%     "Varnames",["cellType","Area","inhibition"] );
[p,tbl,stats] = anova1(dataIn,grpId);
[results,~,~,gnames] = multcompare(stats);

% [results,~,~,gnames] = multcompare(stats,"Dimension",[1 2 3]);

fez_front_inhOffVsOn = results(find(results(:,1) == 1 & results(:,2)==2),6);
plex_front_inhOffVsOn = results(find(results(:,1) == 3 & results(:,2) == 4),6);
fez_fla_inhOffVsOn = results(find(results(:,1) == 5 & results(:,2) == 6),6);
plex_fla_inhOffVsOn = results(find(results(:,1) == 7 & results(:,2) == 8),6);
%% plotting means and sems
inhOff_fez_frontMn = nanmean(inhOff_fez_front,2);
inhOff_fez_frontSem = nanstd(inhOff_fez_front,[],2)./sqrt(cnt.fez.front);

inhOn_fez_frontMn = nanmean(inhOn_fez_front,2);
inhOn_fez_frontSem = nanstd(inhOn_fez_front,[],2)./sqrt(cnt.fez.front);

inhOff_plex_frontMn = nanmean(inhOff_plex_front,2);
inhOff_plex_frontSem = nanstd(inhOff_plex_front,[],2)./sqrt(cnt.plex.front);

inhOn_plex_frontMn = nanmean(inhOn_plex_front,2);
inhOn_plex_frontSem = nanstd(inhOn_plex_front,[],2)./sqrt(cnt.plex.front);

inhOff_fez_flaMn = nanmean(inhOff_fez_fla,2);
inhOff_fez_flaSem = nanstd(inhOff_fez_fla,[],2)./sqrt(cnt.fez.fla);

inhOn_fez_flaMn = nanmean(inhOn_fez_fla,2);
inhOn_fez_flaSem = nanstd(inhOn_fez_fla,[],2)./sqrt(cnt.fez.fla);

inhOff_plex_flaMn = nanmean(inhOff_plex_fla,2);
inhOff_plex_flaSem = nanstd(inhOff_plex_fla,[],2)./sqrt(cnt.plex.fla);

inhOn_plex_flaMn = nanmean(inhOn_plex_fla,2);
inhOn_plex_flaSem = nanstd(inhOn_plex_fla,[],2)./sqrt(cnt.plex.fla);


%% plot traces

close all
nTraces = 1;
h(1) = figure;h(1).Position = [-1671        -278         726         922];
traceIdx = randi(cnt.fez.front,nTraces,1);

ax(1) = subplot(4,2,1);
plot(sgTm,inhOff_fez_front(:,traceIdx ),'color',[0.5 0.5 0.5])
set(gca,'YDir','reverse')
hold on
plot([0,1.5],[-0.05 -0.05],'c-','LineWidth',4)
ylabel('norm Tng Length')
xlabel('time (sec)')
title('FezF2-Frontal-InhOff')


ax(2) = subplot(4,2,2);
plot(sgTm,inhOn_fez_front(:,traceIdx ),'color','g')
set(gca,'YDir','reverse')
hold on
plot([0,1.5],[-0.05 -0.05],'c-','LineWidth',4)
ylabel('norm Tng Length')
xlabel('time (sec)')
title('FezF2-Frontal-InhOn')
text(-1.4,0.5,ids_frontal_fez{traceIdx},'Interpreter','none')

traceIdx = randi(cnt.plex.front,nTraces,1);

ax(3) = subplot(4,2,3);
plot(sgTm,inhOff_plex_front(:,traceIdx ),'color',[0.5 0.5 0.5])
set(gca,'YDir','reverse')
hold on
plot([0,1.5],[-0.05 -0.05],'c-','LineWidth',4)
ylabel('norm Tng Length')
xlabel('time (sec)')
title('PlexinD1-Frontal-InhOff')

ax(4) = subplot(4,2,4);
plot(sgTm,inhOn_plex_front(:,traceIdx ),'color','b')
set(gca,'YDir','reverse')
hold on
plot([0,1.5],[-0.05 -0.05],'c-','LineWidth',4)
ylabel('norm Tng Length')
xlabel('time (sec)')
title('PlexinD1-Frontal-InhOn')
text(-1.4,0.5,ids_frontal_plex{traceIdx},'Interpreter','none')

traceIdx = randi(cnt.fez.fla,nTraces,1);

ax(5) = subplot(4,2,5);
plot(sgTm,inhOff_fez_fla(:,traceIdx ),'color',[0.5 0.5 0.5])
set(gca,'YDir','reverse')
hold on
plot([0,1.5],[-0.05 -0.05],'c-','LineWidth',4)
ylabel('norm Tng Length')
xlabel('time (sec)')
title('FezF2-Fla-InhOff')

ax(6) = subplot(4,2,6);
plot(sgTm,inhOn_fez_fla(:,traceIdx ),'color','g')
set(gca,'YDir','reverse')
hold on
plot([0,1.5],[-0.05 -0.05],'c-','LineWidth',4)
ylabel('norm Tng Length')
xlabel('time (sec)')
title('FezF2-Fla-InhOn')
text(-1.4,0.5,ids_fla_fez{traceIdx},'Interpreter','none')


traceIdx = randi(cnt.plex.fla,nTraces,1);

ax(7) = subplot(4,2,7);
plot(sgTm,inhOff_plex_fla(:,traceIdx ),'color',[0.5 0.5 0.5])
set(gca,'YDir','reverse')
hold on
plot([0,1.5],[-0.05 -0.05],'c-','LineWidth',4)
ylabel('norm Tng Length')
xlabel('time (sec)')
title('PlexinD1-Fla-InhOff')

ax(8) = subplot(4,2,8);
plot(sgTm,inhOn_plex_fla(:,traceIdx ),'color','b')
set(gca,'YDir','reverse')
hold on
plot([0,1.5],[-0.05 -0.05],'c-','LineWidth',4)
ylabel('norm Tng Length')
xlabel('time (sec)')
title('PlexinD1-Fla-InhOn')
text(-1.4,0.5,ids_fla_plex{traceIdx},'Interpreter','none')

linkaxes(ax)
%% plot average trace
h(2) = figure;h(2).Position = [120 67 1117 687];
ax1(1) = subplot(2,2,1);
patch([sgTm fliplr(sgTm)],[inhOff_fez_frontMn - 2*inhOff_fez_frontSem; ...
    flipud(inhOff_fez_frontMn + 2*inhOff_fez_frontSem)],'k','FaceAlpha',0.3,'EdgeColor','none')
hold on
plot(sgTm,inhOff_fez_frontMn,'k-','LineWidth',1)

patch([sgTm fliplr(sgTm)],[inhOn_fez_frontMn - 2*inhOn_fez_frontSem; ...
    flipud(inhOn_fez_frontMn + 2*inhOn_fez_frontSem)],'g','FaceAlpha',0.3,'EdgeColor','none')
plot(sgTm,inhOn_fez_frontMn,'g-','LineWidth',1)

plot([0,1.5],[0 0],'c-','LineWidth',4)
set(gca,'YDir','reverse')
ylabel('norm Tng Length')
xlabel('time (sec)')
title('FezF2-Frontal')

ax1(2) = subplot(2,2,2);
patch([sgTm fliplr(sgTm)],[inhOff_plex_frontMn - 2*inhOff_plex_frontSem; ...
    flipud(inhOff_plex_frontMn + 2*inhOff_plex_frontSem)],'k','FaceAlpha',0.3,'EdgeColor','none')
hold on
plot(sgTm,inhOff_plex_frontMn,'k-','LineWidth',1)

patch([sgTm fliplr(sgTm)],[inhOn_plex_frontMn - 2*inhOn_plex_frontSem; ...
    flipud(inhOn_plex_frontMn + 2*inhOn_plex_frontSem)],'b','FaceAlpha',0.3,'EdgeColor','none')
plot(sgTm,inhOn_plex_frontMn,'b-','LineWidth',1)

plot([0,1.5],[0 0],'c-','LineWidth',4)

set(gca,'YDir','reverse')
ylabel('norm Tng Length')
xlabel('time (sec)')
title('PlexinD1-Frontal')

ax1(3) = subplot(2,2,3);
patch([sgTm fliplr(sgTm)],[inhOff_fez_flaMn - 2*inhOff_fez_flaSem; ...
    flipud(inhOff_fez_flaMn + 2*inhOff_fez_flaSem)],'k','FaceAlpha',0.3,'EdgeColor','none')
hold on
plot(sgTm,inhOff_fez_flaMn,'k-','LineWidth',1)

patch([sgTm fliplr(sgTm)],[inhOn_fez_flaMn - 2*inhOn_fez_flaSem; ...
    flipud(inhOn_fez_flaMn + 2*inhOn_fez_flaSem)],'g','FaceAlpha',0.3,'EdgeColor','none')
plot(sgTm,inhOn_fez_flaMn,'g-','LineWidth',1)

plot([0,1.5],[0 0],'c-','LineWidth',4)
set(gca,'YDir','reverse')
ylabel('norm Tng Length')
xlabel('time (sec)')
title('FezF2-FLA')

ax1(4) = subplot(2,2,4);
patch([sgTm fliplr(sgTm)],[inhOff_plex_flaMn - 2*inhOff_plex_flaSem; ...
    flipud(inhOff_plex_flaMn + 2*inhOff_plex_flaSem)],'k','FaceAlpha',0.3,'EdgeColor','none')
hold on
plot(sgTm,inhOff_plex_flaMn,'k-','LineWidth',1)

patch([sgTm fliplr(sgTm)],[inhOn_plex_flaMn - 2*inhOn_plex_flaSem; ...
    flipud(inhOn_plex_flaMn + 2*inhOn_plex_flaSem)],'b','FaceAlpha',0.3,'EdgeColor','none')
plot(sgTm,inhOn_plex_flaMn,'b-','LineWidth',1)

plot([0,1.5],[0 0],'c-','LineWidth',4)
set(gca,'YDir','reverse')
ylabel('norm Tng Length')
xlabel('time (sec)')
title('PlexinD1-FLA')
linkaxes(ax1)
% % box plot
h(3) = figure;h(3).Position = [130 158 1242 695];
grpId = [repmat("fez-frontal-inhOff",cnt.fez.front,1); repmat("fez-frontal-inhOn",cnt.fez.front,1); ...
    repmat("plex-frontal-inhOff",cnt.plex.front,1); repmat("plex-frontal-inhOn",cnt.plex.front,1); ...
    repmat("fez-fla-inhOff",cnt.fez.fla,1); repmat("fez-fla-inhOn",cnt.fez.fla,1); ...
    repmat("plex-fla-inhOff",cnt.plex.fla,1); repmat("plex-fla-inhOn",cnt.plex.fla,1)];



boxplot([inhOffAvg_aftStim_fez_front inhOnAvg_aftStim_fez_front ...
    inhOffAvg_aftStim_plex_front inhOnAvg_aftStim_plex_front ...
    inhOffAvg_aftStim_fez_fla inhOnAvg_aftStim_fez_fla ...
    inhOffAvg_aftStim_plex_fla inhOnAvg_aftStim_plex_fla],grpId);
ylabel('tongue length')
text(1.2,0.2,['pVal = ' num2str(fez_front_inhOffVsOn)])
text(3.2,0.2,['pVal = ' num2str(plex_front_inhOffVsOn)])
text(5.2,0.2,['pVal = ' num2str(fez_fla_inhOffVsOn)])
text(7.2,0.2,['pVal = ' num2str(plex_fla_inhOffVsOn)])
text(4.5,0.25 , '1 Way anova')

%% %%%%%%%%%%%%% saving the figures %%%%%%%%%%

saveFig = input('Do you want to save the current figures : ');
if saveFig == 1
    %%% saving figures
    savepath = fullfile(['G:\Hemanth_CSHL\OptoWiredInhibition\Data_Figures\LickLengthPlots\'], ...
        ['lickLength_FezPlex.fig']);
    savefig(h,savepath)
end
