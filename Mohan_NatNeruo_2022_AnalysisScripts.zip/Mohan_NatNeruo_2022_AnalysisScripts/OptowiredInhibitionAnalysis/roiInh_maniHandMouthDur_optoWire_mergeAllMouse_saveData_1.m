clear all; close all; clc
[fname fpath] = uigetfile('*.csv');
%% %%%%%%%%%%%%%%% enter details to group sessions %%%%%%%%%%%%%
roiName = {'Fla'}; %% Frontal; Fla;
%%% fez properties %%%
% mouseIds = {'c16m1';'c17m1';'c17m2';};
% handedness= {'right';'left';'right'}; %% fez
% mouseType = ['FezF2Gtacr1']; %% fe
% sessionType = ['optowire'];
% % dateIn = {'20220610'};
% % dateIn = {'20220601';'20220602';'20220603';'20220606';'20220607';'20220608';'20220609';'20220610'; ...
% %      '20220611';'20220614';'20220615';'20220616';'20220617'};
%   dateIn = {'20220601';'20220602';'20220603';'20220606';'20220607';'20220608';'20220609';'20220610'; ...
%       '20220611';'20220614';'20220615';'20220616';'20220617';'20220708';'20220711';'20220712'; ...
%       '20220713';'20220714';'20220715';'20220718';'20220719';'20220720';'20220721';'20220722';'20220723'; ...
%       '20220725';'20220727';'20220728';'20220729'};

%%% plex properties %%%
mouseIds = {'c15m2';'c15m3';'c17m1';'c17m2'};
handedness= {'left';'right';'left';'left'}; %% fez
mouseType = ['PlexinD1Gtacr1']; %% fe
sessionType = ['optowire'];
% dateIn = {'20220610'};
% dateIn = {'20220601';'20220602';'20220603';'20220606';'20220607';'20220608';'20220609';'20220610'; ...
%      '20220611';'20220614';'20220615';'20220616';'20220617'};
  dateIn = {'20220601';'20220602';'20220603';'20220606';'20220607';'20220608';'20220609';'20220610'; ...
      '20220611';'20220614';'20220615';'20220616';'20220617';'20220708';'20220711';'20220712'; ...
      '20220713';'20220714';'20220715';'20220718';'20220719';'20220720';'20220721';'20220722';'20220723'; ...
      '20220725';'20220727';'20220728';'20220729'};
%% %%%%%%%%%%%%%%%%%%% get file  name structure %%%%%%%%%%%%
parentFold = fileparts(fileparts(fpath));
foldNames = [];
for jj = 1:length(mouseIds)
    for ii = 1:length(dateIn)
        FoldCont = dir(fullfile(fileparts(fileparts(fpath)),[dateIn{ii} '*', mouseType '*', mouseIds{jj} '*',sessionType '*']));
        foldNames = [foldNames;{FoldCont.name}'];
    end
end
%% %%%%%%%%%%%%%%% get Trial IDs and trajectories of control and inbhibition handlift trials
for kk = 1:length(foldNames)
    fpath1 = [fullfile(parentFold,foldNames{kk}) '\']
    [inhOn_PimOn{kk,1},inhOff_PimOn{kk,1}] = getTrajData(fpath1,roiName,mouseIds,handedness);
end
%% extract inhibition on and off first finger trajectorires
inhOnTj.lfing1x = [];
inhOnTj.lfing1y = [];
inhOnTj.rfing1x = [];
inhOnTj.rfing1y = [];
inhOnFingTrajy = [];
inhOnTj.fileTrialRefIdx = {};

inhOffTj.lfing1x = [];
inhOffTj.lfing1y = [];
inhOffTj.rfing1x = [];
inhOffTj.rfing1y = [];
inhOffFingTrajy = [];
stimStartEnd = [];
inhOffTj.fileTrialRefIdx = {};
k = 1;
for ii = 1:length(inhOn_PimOn)
    tempInhOnIdx = inhOn_PimOn{ii}.pimOnIdx(~isnan(inhOn_PimOn{ii}.pimOnIdx));
    tempInhOffIdx = inhOff_PimOn{ii}.pimOnIdx;
    handUsed = inhOn_PimOn{ii}.handUsed;
    for jj = 1:length(tempInhOffIdx)    
        inhOnTj.lfing1x = [inhOnTj.lfing1x inhOn_PimOn{ii}.ulNormTraj.C1(jj).lfing1(:,1)];
        inhOnTj.lfing1y = [inhOnTj.lfing1y inhOn_PimOn{ii}.ulNormTraj.C1(jj).lfing1(:,2)];
        inhOnTj.rfing1x = [inhOnTj.rfing1x inhOn_PimOn{ii}.ulNormTraj.C1(jj).rfing1(:,1)];
        inhOnTj.rfing1y = [inhOnTj.rfing1y inhOn_PimOn{ii}.ulNormTraj.C1(jj).rfing1(:,2)];
        inhOnTj.fileTrialRefIdx = [inhOnTj.fileTrialRefIdx; [k,foldNames(ii),tempInhOnIdx(jj)]];
        if strcmp('right',handUsed)
            inhOnFingTrajy = [inhOnFingTrajy inhOn_PimOn{ii}.ulNormTraj.C1(jj).rfing1(:,2)];
        elseif strcmp('left',handUsed)
            inhOnFingTrajy = [inhOnFingTrajy inhOn_PimOn{ii}.ulNormTraj.C1(jj).lfing1(:,2)];
        end
            
            
        inhOffTj.lfing1x = [inhOffTj.lfing1x inhOff_PimOn{ii}.ulNormTraj.C1(jj).lfing1(:,1)];
        inhOffTj.lfing1y = [inhOffTj.lfing1y inhOff_PimOn{ii}.ulNormTraj.C1(jj).lfing1(:,2)];
        inhOffTj.rfing1x = [inhOffTj.rfing1x inhOff_PimOn{ii}.ulNormTraj.C1(jj).rfing1(:,1)];
        inhOffTj.rfing1y = [inhOffTj.rfing1y inhOff_PimOn{ii}.ulNormTraj.C1(jj).rfing1(:,2)];
        inhOffTj.fileTrialRefIdx = [inhOffTj.fileTrialRefIdx; [k,foldNames(ii),tempInhOffIdx(jj)]];
        if strcmp('right',handUsed)
            inhOffFingTrajy = [inhOffFingTrajy inhOff_PimOn{ii}.ulNormTraj.C1(jj).rfing1(:,2)];
        elseif strcmp('left',handUsed)
            inhOffFingTrajy = [inhOffFingTrajy inhOff_PimOn{ii}.ulNormTraj.C1(jj).lfing1(:,2)];
        end
        
        k = k+1;
        
    end
    stimStartEnd = [stimStartEnd;inhOn_PimOn{ii}.stimStartEnd];
end

% % limit the trials
% inhOnFingTrajy = inhOnFingTrajy(:,1:300);
% inhOffFingTrajy = inhOffFingTrajy(:,1:300);
%% %%%% indentify if either of the hands is brought close to mouth and check total distance moved
fs = 100;
tm = linspace(0,15,1500); 
% rfing1_yTh = 0.4;
rfing1_xTh = -0.2;
% lfing1_yTh = 0.4;
lfing1_xTh = 0.2;
durTh = 0.3; %% duration threhsold for the hand to be close to mouth to be considerd as a successfull lift
trCnt = size(inhOnTj.rfing1y,2);
durBefStim = 2; %% how much time to collect data before stim onset
durAftStim = 4; %% how much time to collect data after stim onset


inhOn_hlIdx = [];
inhOn_noHlIdx = [];
inhOn_maniPos = [];
inhOn_maniAvgPos = [];
inhOn_maniVel = [];
inhOn_maniAvgVel = [];
inhOn_hlRef = [];
inhOn_noHlRef = [];


inhOff_hlIdx = [];
inhOff_noHlIdx = [];
inhOff_maniPos= [];
inhOff_maniAvgPos = [];
inhOff_maniVel = [];
inhOff_maniAvgVel = [];
inhOff_hlRef = [];
inhOff_noHlRef = [];

sigTm = -durBefStim:1/fs:durAftStim;sigTm(end) = [];

% check if either the left hand or right hand is near the mouth after
% picking pellet in mouth

for j = 1:trCnt
    inhOnTjX_r = inhOnTj.rfing1x(:,j);
    inhOnTjX_l = inhOnTj.lfing1x(:,j);
    handNearMouthTm_r = find(inhOnTjX_r > rfing1_xTh)/fs; %% find the time points when the right finger was close to mouth based on the thrsholds
    handNearMouthDur_r = length(find(handNearMouthTm_r > stimStartEnd(j,1) & handNearMouthTm_r < stimStartEnd(j,2)))/fs; %durion of hand being close ot mouth
    handNearMouthTm_l = find(inhOnTjX_l < lfing1_xTh )/fs; %% find the time points when the left finger was close to mouth based on the thrsholds
    handNearMouthDur_l = length(find(handNearMouthTm_l > stimStartEnd(j,1) & handNearMouthTm_l < stimStartEnd(j,2)))/fs;
    
    maniPos = inhOnFingTrajy(find(tm > stimStartEnd(j,1)-durBefStim & tm < stimStartEnd(j,1)+durAftStim),j);
    maniVel = abs(diff(maniPos));
    maniAvgPos = nanmean(maniPos(sigTm>0));
    maniAvgVel = nanmean(maniVel(sigTm(1:end-1)>0));
    % check if either the left or right finger was close to mouth and
    % collect data
    if handNearMouthDur_r>=durTh | handNearMouthDur_l>=durTh 
        inhOn_hlIdx  = [inhOn_hlIdx;j];
        inhOn_hlRef= [inhOn_hlRef; inhOnTj.fileTrialRefIdx(j,:)];
        inhOn_maniPos = [inhOn_maniPos maniPos];
        inhOn_maniVel = [inhOn_maniVel maniVel];
        inhOn_maniAvgPos = [inhOn_maniAvgPos;maniAvgPos];
        inhOn_maniAvgVel = [inhOn_maniAvgVel;maniAvgVel];
        inhOn_noHlIdx = [inhOn_noHlIdx;nan];
        inhOn_noHlRef = [inhOn_noHlRef; [{nan},{nan},{nan}]];
    else
        inhOn_noHlIdx = [inhOn_noHlIdx;j];
        inhOn_noHlRef = [inhOn_noHlRef; inhOnTj.fileTrialRefIdx(j,:)];
        inhOn_hlIdx  = [inhOn_hlIdx;nan];
        inhOn_hlRef= [inhOn_hlRef; [{nan},{nan},{nan}]];
        inhOn_maniPos = [inhOn_maniPos nan(length(maniPos),1)];
        inhOn_maniVel = [inhOn_maniVel nan(length(maniVel),1)];
        inhOn_maniAvgPos = [inhOn_maniAvgPos;nan];
        inhOn_maniAvgVel = [inhOn_maniAvgVel;nan];
        
    end
       
    %%%%%%%%%  inhibition off condition %%%%%%%%%%%%%%
    inhOffTjX_r = inhOffTj.rfing1x(:,j);
    inhOffTjX_l = inhOffTj.lfing1x(:,j);
    handNearMouthTm_r = find(inhOffTjX_r > rfing1_xTh)/fs; %% find the time points when the right finger was close to mouth based on the thrsholds
    handNearMouthDur_r = length(find(handNearMouthTm_r > stimStartEnd(j,1) & handNearMouthTm_r < stimStartEnd(j,2)))/fs; %durion of hand being close ot mouth
    handNearMouthTm_l = find(inhOffTjX_l < lfing1_xTh )/fs; %% find the time points when the left finger was close to mouth based on the thrsholds
    handNearMouthDur_l = length(find(handNearMouthTm_l > stimStartEnd(j,1) & handNearMouthTm_l < stimStartEnd(j,2)))/fs;
    
    maniPos = inhOffFingTrajy(find(tm > stimStartEnd(j,1)-durBefStim & tm < stimStartEnd(j,1)+durAftStim),j);
    maniVel = abs(diff(maniPos));
    maniAvgPos = nanmean(maniPos(sigTm>0));
    maniAvgVel = nanmean(maniVel(sigTm(1:end-1)>0));
    % check if either the left or right finger was close to mouth and
    % collect data
    if handNearMouthDur_r>=durTh | handNearMouthDur_l>=durTh 
        inhOff_hlIdx  = [inhOff_hlIdx;j];
        inhOff_hlRef = [inhOff_hlRef; inhOffTj.fileTrialRefIdx(j,:)];
        inhOff_maniPos = [inhOff_maniPos maniPos];
        inhOff_maniVel = [inhOff_maniVel maniVel];
        inhOff_maniAvgPos = [inhOff_maniAvgPos;maniAvgPos];
        inhOff_maniAvgVel = [inhOff_maniAvgVel;maniAvgVel];
        inhOff_noHlIdx = [inhOff_noHlIdx,nan];
        inhOff_noHlRef = [inhOff_noHlRef; [{nan},{nan},{nan}]];
    else        
        inhOff_noHlIdx = [inhOff_noHlIdx,j];
        inhOff_noHlRef = [inhOff_noHlRef; inhOffTj.fileTrialRefIdx(j,:)];
        inhOff_hlIdx  = [inhOff_hlIdx;nan];
        inhOff_hlRef = [inhOff_hlRef; [{nan},{nan},{nan}]];
        inhOff_maniPos = [inhOff_maniPos nan(length(maniPos),1)];
        inhOff_maniVel = [inhOff_maniVel nan(length(maniVel),1)];
        inhOff_maniAvgPos = [inhOff_maniAvgPos;nan];
        inhOff_maniAvgVel = [inhOff_maniAvgVel;nan];
        
    end
end
%% extract duration of the hand close to mouth
hmThresh = 0.1; %%% threshold below which hand is considered close to mouth
inhOn_handMouthDur = [];
inhOff_handMouthDur = [];
inhIdx = find(sigTm>0 & sigTm<durAftStim);
for ii = 1:size(inhOn_maniPos,2)
    if ~isnan(inhOn_hlIdx(ii))
        inhOn_handMouthDur(ii,1) = length(find(inhOn_maniPos(inhIdx,ii)<hmThresh))/fs;
    else
        inhOn_handMouthDur(ii,1) = nan;
    end
    
    if ~isnan(inhOff_hlIdx(ii))
        inhOff_handMouthDur(ii,1) = length(find(inhOff_maniPos(inhIdx,ii)<hmThresh))/fs;
    else
        inhOff_handMouthDur(ii,1) = nan;
    end
end
    
% %
[p] = ranksum(inhOff_handMouthDur,inhOn_handMouthDur)
figure
boxplot([inhOff_handMouthDur inhOn_handMouthDur])

%% saving data
data.durBefStim = durBefStim;
data.durAftStim = durAftStim;
data.handNearMouthThresh = hmThresh;
data.sigTm = sigTm;
data.inhOn_handliftIdx = inhOn_hlIdx;
data.inhOn_handlifTrialRef = inhOn_hlRef;
data.inhOn_manipulationPosition = inhOn_maniPos;
data.inhOn_manipulationVelocity = inhOn_maniVel;
data.inhOn_avgManipPosition = inhOn_maniAvgPos;
data.inhOn_avgManipVelocity = inhOn_maniAvgVel;
data.inhOn_noHandliftIdx = inhOn_noHlIdx;
data.inhOn_noHandliftTrialRef = inhOn_noHlRef;
data.inhOn_handNearMouthDur = inhOn_handMouthDur;

data.inhOff_handliftIdx = inhOff_hlIdx;
data.inhOff_handlifTrialRef = inhOff_hlRef;
data.inhOff_manipulationPosition = inhOff_maniPos;
data.inhOff_manipulationVelocity = inhOff_maniVel;
data.inhOff_avgManipPosition = inhOff_maniAvgPos;
data.inhOff_avgManipVelocity = inhOff_maniAvgVel;
data.inhOff_noHandliftIdx = inhOff_noHlIdx;
data.inhOff_noHandliftTrialRef = inhOff_noHlRef;
data.inhOff_handNearMouthDur = inhOff_handMouthDur;



data.roiName = roiName;
data.mouseIds = mouseIds;
data.mouseType = mouseType;
data.handedness = handedness;
data.datesAnalyzed = dateIn;
data.FoldersAnalyzed = foldNames;
%% plotting data
% % close all
% id =[1:464];
% inhOffDat = inhOff_maniPos(:,id);
% inhOnDat = inhOn_maniPos(:,id);
% Time = sigTm; %%% tm, sigTm
% h1 = figure;h1.Position = [146   187  560   771];
% subplot(2,1,1)
% plot(Time,inhOnDat,'g')
% hold on
% p2 = plot(Time,inhOffDat,'k');
% % plot([stimStartEnd(id,1) stimStartEnd(id,2)], [-0.15 -0.15],'g-','LineWidth',5)
% plot([0 5], [-0.15 -0.15],'g-','LineWidth',5)
% 
% set(gca,'YDir','reverse')
% for p = 1:length(p2)
%     p2(p).Color = [0,0,0,0.3];
% end
% title(['Inh Off: ' inhOff_hlRef{id(1),2} '-' num2str(inhOff_hlRef{id(1),3})  newline ...
%     'Inh On: ' inhOn_hlRef{id(1),2} '-' num2str(inhOn_hlRef{id(1),3})],'Interpreter','none') 
% 
% subplot(2,1,2)
% plot(Time,nanmean(inhOnDat,2),'g')
% hold on
% p2 = plot(Time,nanmean(inhOffDat,2),'k');
% % plot([stimStartEnd(id,1) stimStartEnd(id,2)], [-0.15 -0.15],'g-','LineWidth',5)
% plot([0 5], [-0.15 -0.15],'g-','LineWidth',5)
% 
% set(gca,'YDir','reverse')
%% plotting data
% getting stats
inhOn_maniPosMn = nanmean(inhOn_maniPos,2);
inhOn_maniPosSem = nanstd(inhOn_maniPos,[],2)./sqrt(size(inhOn_maniPos,2)) ;
inhOn_maniVelMn = nanmean(inhOn_maniVel,2);
inhOn_maniVelSem = nanstd(inhOn_maniVel,[],2)./sqrt(size(inhOn_maniVel,2)) ;

inhOff_maniPosMn = nanmean(inhOff_maniPos,2);
inhOff_maniPosSem = nanstd(inhOff_maniPos,[],2)./sqrt(size(inhOff_maniPos,2)) ;
inhOff_maniVelMn = nanmean(inhOff_maniVel,2);
inhOff_maniVelSem = nanstd(inhOff_maniVel,[],2)./sqrt(size(inhOff_maniVel,2)) ;
% close all
h1 = figure; h1.Position = [84         364        1147         491];
subplot(1,2,1)
patch([sigTm fliplr(sigTm)],[inhOff_maniPosMn-2*inhOff_maniPosSem ;  flipud(inhOff_maniPosMn+2*inhOff_maniPosSem)],'k','FaceAlpha',0.3,'EdgeColor','none' )
hold on
plot(sigTm, inhOff_maniPosMn,'k','LineWidth',1)
patch([sigTm fliplr(sigTm)],[inhOn_maniPosMn-2*inhOn_maniPosSem ;  flipud(inhOn_maniPosMn+2*inhOn_maniPosSem)],'g','FaceAlpha',0.3,'EdgeColor','none' )
plot(sigTm, inhOn_maniPosMn,'g','LineWidth',1)
plot([0,5],[0.07,0.07],'g-','LineWidth',5)
xlim([sigTm(1) sigTm(end)])
hold off
xlabel('time (sec)')
ylabel('normalized hand posiiton')
set(gca,'YDir','reverse')
% 
subplot(1,2,2)
[pPos] = ranksum(inhOff_handMouthDur,inhOn_handMouthDur)
boxId = [repmat("inhOff",length(inhOff_handMouthDur),1); repmat("inhOn",length(inhOn_handMouthDur),1)];
boxplot([inhOff_handMouthDur;inhOn_handMouthDur],boxId)
text(1.2,2.5,['ranksum pVal = ' num2str(pPos)])
ylabel('hand near mouth duration (sec)')

%% %%%%%%%%% saving the data %%%%%%%%%%
% 
filename = ['HandNearMouthDur_' roiName{1} '_' mouseType '.mat'];
saveData = input('Do you want to save the current data : ');
if saveData == 1
    %%% saving data
    savePath = fullfile('G:\Hemanth_CSHL\OptoWiredInhibition\Data_Analysis\HandNearMouthDuration\' ,filename);
    save(savePath,'data')
end


%% %%%%%%%% main function
function [inhOn_pimOn,inhOff_pimOn] = getTrajData(fpath,roiName,mouseIds,handedness)
%% %%%%%%%%%%%%%%%% get file  name structure %%%%%%%%%%%%

[fnFeat, usFeat ] = getOptoFileNameProperties(fpath);%%% get all fileNames variables
%% check handedness id
for h = 1:length(mouseIds)
    if contains(lower(fpath),mouseIds{h})
        handUsed = handedness{h};
    end
end

%% %%%%%%%%%%%%%%% Get Lick, Pim, Handlift Behavior Trial IDs %%%%%%%%%%%%%%%
disp('Extracting Behavior Temporal features .... ')
ExtractManipulaion = 0;%%%%% Enter zero to not extract manipulation times and 1 to extract
[BData] = GetBehavEventTimesOptoWire(fpath,ExtractManipulaion);
allTrialIdx = cell2mat(BData.Data(:,1));
lickOnsetAll = BData.Data(:,9);
pimOnsetAll = BData.Data(:,10);
hlOnsetAll = BData.Data(:,11);
lickOnIdx = find(cell2mat(BData.Data(:,2)) == 1);
pimOnIdx = find(cell2mat(BData.Data(:,2)) == 1 & cell2mat(BData.Data(:,3)) == 1);
% hlOnIdx = find(cell2mat(BData.Data(:,2)) == 1 & cell2mat(BData.Data(:,3)) == 1 & cell2mat(BData.Data(:,4)) == 1);
hlOnIdx = find(~cellfun(@isempty,hlOnsetAll));

bTime = linspace(0,15,1500);
%% %%% get roi stimulation index and parameters
roiParms = getRoiStimTrialIdx(fnFeat);
inhOn_Idx = roiParms.LzOnIdx;
%% Get trials with Hand lift event during frontal inhibition.
inhOn_pimOn_idx = nan(length(roiParms.(['LzOn' roiName{1} 'Idx'])),1);
inhOn_pimOff_idx = nan(length(roiParms.(['LzOn' roiName{1} 'Idx'])),1);
inhOn_ulNormTrajC2 = [];
inhOn_ulNormTrajC1 = [];
stimStartEnd = [];

for ii = 1:length(roiParms.(['LzOn' roiName{1} 'Idx']))
    inIdx = roiParms.(['LzOn' roiName{1} 'Idx'])(ii); %%% which index is being analyzed
    stimOnset = roiParms.(['LzOn' roiName{1} 'Parm']){ii,3}; %% stim onset time in seconds
    stimDur = roiParms.(['LzOn' roiName{1} 'Parm']){ii,4}; %% stim duration time in seconds
    stimEndTime = stimOnset + stimDur; %%% stim end time in seconds
    stimStartEnd = [stimStartEnd; [stimOnset stimEndTime]];
    %%
    [trajDataC1,trajDataC2,bodyPartsC1,bodyPartsC2 ] = getBehaviorTrajectory(fpath,fnFeat,usFeat,inIdx);
    %% collect upperlip normalized trajectories
    for jj = 1:length(fieldnames(trajDataC1))
        inhOn_ulNormTrajC1(ii).(bodyPartsC1{jj}) = (trajDataC1.(bodyPartsC1{jj})(:,1:2) - nanmean(trajDataC1.upperlip(:,1:2)))./nanmean(trajDataC1.upperlip(:,1:2));
    end
    
    for jj = 1:length(fieldnames(trajDataC2))
        inhOn_ulNormTrajC2(ii).(bodyPartsC2{jj}) = (trajDataC2.(bodyPartsC2{jj})(:,1:2) - nanmean(trajDataC2.upperlip(:,1:2)))./nanmean(trajDataC2.upperlip(:,1:2));
    end
    
    %%
    if sum(inIdx == pimOnIdx) == 1 %% check if the animal picks the pellet in mouth
        pimOnTime = pimOnsetAll{inIdx};
        if pimOnTime < stimEndTime % check if pim happend before end of stimulation and not after
            inhOn_pimOn_idx(ii) = inIdx; %%% trials with pim where inhibition starts within 0.5 seconds of pim
        else
            inhOn_pimOff_idx(ii) = inIdx;
        end
    else
        inhOn_pimOff_idx(ii) = inIdx;
    end
    
end

inhOn_pimOn.ulNormTraj.C1 = inhOn_ulNormTrajC1(~isnan(inhOn_pimOn_idx));
inhOn_pimOn.ulNormTraj.C2 = inhOn_ulNormTrajC2(~isnan(inhOn_pimOn_idx));
inhOn_pimOn.stimStartEnd = stimStartEnd(~isnan(inhOn_pimOn_idx),:);
inhOn_pimOn.pimOnIdx = inhOn_pimOn_idx;
inhOn_pimOn.pimOffIdx = inhOn_pimOff_idx;
inhOn_pimOn.handUsed = handUsed;
%% Get Trials with hand lift during control trials
inhOff_pimOnIdxAll = intersect(roiParms.LzOffIdx,pimOnIdx); %% get trials with pim duirng no inhibition
%% remove inhintion on trials if it is more than inhibtiobn off trials
if length(inhOff_pimOnIdxAll)< sum(~isnan(inhOn_pimOn_idx))
    inhOn_pimOn_idx(1:end-length(inhOff_pimOnIdxAll)) = nan;
end


%% remove late pim trials
pimOnTh = max(stimStartEnd(:));
for p = 1:length(inhOff_pimOnIdxAll)
    inIdx = inhOff_pimOnIdxAll(p);
    if pimOnsetAll{inIdx} > pimOnTh 
        inhOff_pimOnIdxAll(p) = nan;
    end
end
inhOff_pimOnIdxAll(isnan(inhOff_pimOnIdxAll)) = [];
%% get Pim On Indices of trials just before the inhibition on trials
inhOff_pimOn_idx = []; 
for kk = 1:length(inhOn_pimOn_idx)
    inhOff_pimOn_idx = [inhOff_pimOn_idx; inhOff_pimOnIdxAll(find(inhOff_pimOnIdxAll<inhOn_pimOn_idx(kk),1,'last'))]; %% get index id of pim on trial just before the inhibition trial
end

% find repeat trials and replace it with an older trial idx
[unqVal unqLoc] = unique(inhOff_pimOn_idx,'first');
repeatLoc = find(not(ismember(1:numel(inhOff_pimOn_idx),unqLoc)));
for kk = 1:length(repeatLoc)
    temp1 =  setdiff(inhOff_pimOnIdxAll(find(inhOff_pimOnIdxAll<inhOff_pimOn_idx(repeatLoc(kk)))), inhOff_pimOn_idx);
    if ~isempty(temp1)
    inhOff_pimOn_idx(repeatLoc(kk)) = temp1(end); %% unique indices of lazer off indices
    else
     inhOff_pimOn_idx(repeatLoc(kk)) =  inhOff_pimOnIdxAll(randi(length(inhOff_pimOnIdxAll)));
    end
end
%% get inh off trajectories
for pp = 1:length(inhOff_pimOn_idx)
    [trajDataC1,trajDataC2,bodyPartsC1,bodyPartsC2 ] = getBehaviorTrajectory(fpath,fnFeat,usFeat,inhOff_pimOn_idx(pp));
    
    for jj = 1:length(fieldnames(trajDataC1))
        inhOff_pimOn.ulNormTraj.C1(pp).(bodyPartsC1{jj}) = (trajDataC1.(bodyPartsC1{jj})(:,1:2) - nanmean(trajDataC1.upperlip(:,1:2)))./nanmean(trajDataC1.upperlip(:,1:2));
    end
    
    for jj = 1:length(fieldnames(trajDataC2))
        inhOff_pimOn.ulNormTraj.C2(pp).(bodyPartsC2{jj}) = (trajDataC2.(bodyPartsC2{jj})(:,1:2) - nanmean(trajDataC2.upperlip(:,1:2)))./nanmean(trajDataC2.upperlip(:,1:2));
    end
end
inhOff_pimOn.pimOnIdx = inhOff_pimOn_idx;
inhOff_pimOn.handUsed = handUsed;
%%

end

%% extract inhition off trajectory
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Functions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [TrajDataC1,TrajDataC2,BodyPartsC1,BodyPartsC2 ] = getBehaviorTrajectory(fpath,fnFeat,usFeat,FileId)
pcutoffC1 = 0.9;
pcutoffC2 = 0.8;
fnameinC1 = [fnFeat.fname_exC1(1:usFeat.bidx_stC1) num2str(FileId) fnFeat.fname_exC1(usFeat.bidx_endC1:end)];
filepathC1 = fullfile(fpath,fnameinC1);
[TrajDataC1 BodyPartsC1] =  ExtractBodyTraj(filepathC1,pcutoffC1);

fnameinC2 = [fnFeat.fname_exC2(1:usFeat.bidx_stC2) num2str(FileId) fnFeat.fname_exC2(usFeat.bidx_endC2:end)];
filepathC2 = fullfile(fpath,fnameinC2);
[TrajDataC2 BodyPartsC2] =  ExtractBodyTraj(filepathC2,pcutoffC2);
end

function [parms] = getRoiStimTrialIdx(fnFeat)
%% %%%%%%%%%% get laser stimulation parameters and trials
[stimParm,stimHead] = getLaserStimParam(fnFeat);
parms.LzOnIdx = find(cell2mat(stimParm(:,1)) == 1);
parms.LzOffIdx = find(cell2mat(stimParm(:,1)) == 0);
parms.stimHeading = stimHead;
parms.stimParmAll = stimParm;
%% %%%%% Roi Laser On Idx
if strcmp(lower(stimParm(1,2)), 'frontal')
    parms.LzOnFrontalIdx = find(cell2mat(stimParm(:,1)) == 1);
    parms.LzOnFlaIdx = [];
elseif strcmp(lower(stimParm(1,2)), 'fla')
    parms.LzOnFlaIdx = find(cell2mat(stimParm(:,1)) == 1);
    parms.LzOnFrontalIdx = [];
end
%% Roi Laser Parameters
parms.LzOnParm = stimParm(parms.LzOnIdx,:);
parms.LzOnFrontalParm = stimParm(parms.LzOnFrontalIdx,:);
parms.LzOnFlaParm = stimParm(parms.LzOnFlaIdx,:);
end

function [stimParm,stimHead] = getLaserStimParam(fnFeat)
for ii = 1:length(fnFeat.sname_all)
    data = load(fullfile(fnFeat.spath,fnFeat.sname_all{ii})); data = data.data;
    stimParm(ii,:) = data(2,:);
end
stimHead = data(1,:);
end

function [fnFeat, usFeat ] = getOptoFileNameProperties(fpath)
%%%%%%%%%%%%% getting signal file name %%%%%%%%%%%%%%
listing_csv = dir([fpath '\*.csv']);
[~, sflname] = fileparts(fileparts(fpath));
spath = fullfile(fileparts(fileparts(fileparts(fpath))), 'OptoWiredData', sflname);
listing_sig = dir([spath '\*.mat']);
sname_all = natsortfiles({listing_sig.name}');
sname_ex = sname_all{1};
us_idx = find(sname_ex == '_',1,'last');

%%%%%%%% getting body trajectory file name %%%%%%%%%%%%
fname_all = natsortfiles({listing_csv.name}');
fname_allC1 = fname_all( contains(fname_all,'c1_T'));
fname_allC2 = fname_all( contains(fname_all,'c2_T'));

fname_exC1 = fname_allC1{1};
fname_us_idxC1 = find(fname_exC1 == '_');
fname_deep_idxC1 = strfind(fname_exC1, 'Deep');
bidx_stC1 = fname_us_idxC1(end-3);
bidx_endC1 = fname_deep_idxC1;

fname_exC2 = fname_allC2{1};
fname_us_idxC2 = find(fname_exC2 == '_');
fname_deep_idxC2 = strfind(fname_exC2, 'Deep');
bidx_stC2 = fname_us_idxC2(end-3);
bidx_endC2 = fname_deep_idxC2;


%%% updating all properties
fnFeat.sname_all = sname_all;
fnFeat.fname_allC1 = fname_allC1;
fnFeat.fname_allC2 = fname_allC2;
fnFeat.sname_ex = sname_ex;
fnFeat.fname_exC1 = fname_exC1;
fnFeat.fname_exC2 = fname_exC2;
fnFeat.spath = spath;

usFeat.us_idx = us_idx;
usFeat.bidx_stC1 = bidx_stC1;
usFeat.bidx_endC1 = bidx_endC1;
usFeat.bidx_stC2 = bidx_stC2;
usFeat.bidx_endC2 = bidx_endC2;
end