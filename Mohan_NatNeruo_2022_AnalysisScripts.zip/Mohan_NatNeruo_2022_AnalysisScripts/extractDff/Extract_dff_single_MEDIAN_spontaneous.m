clear; close; clc
if isempty(gcp('nocreate')) == 1
parpool('local',8);
end
[fname fpath] = uigetfile('*.mj2');
listing_mj2 = dir([fpath '\*.mj2']);
listing_bin = dir([fpath '\*.bin']);
fname_mj2_all = natsortfiles({listing_mj2.name}');
fname_bin_all = natsortfiles({listing_bin.name}');

%%
fidx = 1; %%% Enter the id of the video for analysis
cur_fname = fname_mj2_all{fidx};
vfile = fullfile(fpath,cur_fname);
filenum = str2num(cur_fname(find(cur_fname == '_',1,'last')+1 : find(cur_fname == '.',1,'last')-1));
[Fr_Sig, ~] = fread(fopen(fullfile(fpath,fname_bin_all{fidx})),[3,inf],'double');
%%%%THis part finds the starting time to condister for trigger of frames
trigStartTime = 0.016; %%% trigger start time in seconds
startInd = find(Fr_Sig(1,:)>trigStartTime,1);
figure
plot(Fr_Sig(1,:),Fr_Sig(2,:)); hold on; plot(Fr_Sig(1,:),Fr_Sig(3,:),'m')
title('Frame Trigger Signal')
Fr_b_first = find(Fr_Sig(2,startInd:end)>3,1);
Fr_v_first = find(Fr_Sig(3,startInd:end)>3,1);
if (Fr_b_first - Fr_v_first)<0
    BlueFirst = 1;
elseif (Fr_b_first - Fr_v_first)>0
    BlueFirst = 0;
end

coorfile = [cur_fname(1:find(cur_fname == '_',1,'last')) 'coor.mat'];

if exist(fullfile(fpath,coorfile))
    load(fullfile(fpath,coorfile));
    disp('Loading PreExisting Coordinate Location for cropping!!')
else
[cpos, refimg] = MakeCoorFile(fpath,vfile,coorfile,BlueFirst);
end

%%
disp(' extracting videos...')
tic
[videoB videoV Bfi Vfi] = SplitVideo(vfile,BlueFirst,cpos); %% Bfi and Vfi are frame indices of blue and violet frames
toc
figure(1)
plot(Bfi,'b'); hold on; plot(Vfi,'m--')
title('Frames number blue violet')
VidSz = size(videoB);
vB = single(reshape(videoB,(size(videoB,1))*size(videoB,2),size(videoB,3)));
vV = single(reshape(videoV,size(videoV,1)*size(videoV,2),size(videoV,3)));
clearvars -except vB vV VidSz fpath cur_fname
%% %%%%%%%%%% polynomial detrending of signals %%%%%%%%%%%%%%%
disp(' detrending singal...')
vBdt = single([]);
vVdt = single([]);
polOrder = 7; %%% order of the polynomial. Default = 7
x = [1:size(vB,2)]';

parfor ii = 1:size(vB,1)
[pCoeffB,s,polMuB] = polyfit(x,vB(ii,:)',polOrder);
yFitB = polyval(pCoeffB,x,[],polMuB);
vBdt(ii,:) = single(vB(ii,:) - yFitB')+ mean(yFitB); %%%%%%%% detrended vB

[pCoeffV,~,polMuV] = polyfit(x,vV(ii,:)',polOrder);
yFitV = polyval(pCoeffV,x,[],polMuV);
vVdt(ii,:) = single(vV(ii,:) - yFitV') + mean(yFitV); %%%%%%%% detrended vV
end
clearvars -except vBdt vVdt VidSz fpath cur_fname %%%%% activate if matlab crashes

%%
disp(' performing df/f...')
tic
[dffV] = MakeDff(vBdt,vVdt,VidSz);
% [dffV] = MakeDffGpu_mean(vB,vV,VidSz);
toc

%% Saving DffV
disp(' saving signal ...')
% schoice = input('Do you want to save the video file (1 = yes; 0 = No) : ');
schoice = 1;
if schoice == 1
SaveDff(dffV,fpath,cur_fname);
end

%%
PlayDff(dffV,0.03,'cmap2')
%%%%%%%%%%%%%%%%%%%%% Function %%%%%%%%%%%%%%%%%
% function [videoBc_norm] = MakeDffSpont(vB,vV,VidSz)
% vsize1 = [round(size(vB,1)/2) size(vB,2)]; 
% vsize2 = [(vsize1(1)+1) size(vB,2)]; 
% TrB_nm= (vB - median(vB,2))./median(vB,2);
% TrV_nm= (vV - median(vV,2))./median(vV,2);
% 
% parfor ii=1:size(vB,1)
%     TrRcoef = [ones(size(TrV_nm(ii,:),2),1) movmean(TrV_nm(ii,:),10)'] \ TrB_nm(ii,:)'; %% Signal B is regressed with moving averaged for 10 frames(340ms) signal V
%     Tr_corrected = TrB_nm(ii,:)-([ones(size(TrV_nm(ii,:),2),1) (TrV_nm(ii,:))']*TrRcoef)';
%     videoBc_norm(ii,:) = Tr_corrected;
% end
% videoBc_norm = reshape(videoBc_norm, VidSz(1),  VidSz(2),  VidSz(3));
% clearvars -except videoBc_norm
% end

