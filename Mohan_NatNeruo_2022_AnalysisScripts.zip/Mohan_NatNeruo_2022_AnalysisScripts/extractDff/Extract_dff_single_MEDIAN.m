%% %%%%%%%%%%%%%%%%%%%%%%%
% Built: 2018
% Creator: Hemanth Mohan, Cold Spring Harbor Laboratory
% Contact: hemanth87@gmail.com
%% %%%%%%%%%%%%%
clear; close; clc
if isempty(gcp('nocreate')) == 1
parpool('local',8);
end
[fname fpath] = uigetfile('*.mj2');
listing_mj2 = dir([fpath '\*.mj2']);
listing_bin = dir([fpath '\*.bin']);
fname_mj2_all = natsortfiles({listing_mj2.name}');
fname_bin_all = natsortfiles({listing_bin.name}');

%%
fidx = 1; %%% Enter the id of the video for analysis
cur_fname = fname_mj2_all{fidx};
vfile = fullfile(fpath,cur_fname);
filenum = str2num(cur_fname(find(cur_fname == '_',1,'last')+1 : find(cur_fname == '.',1,'last')-1));
[Fr_Sig, ~] = fread(fopen(fullfile(fpath,fname_bin_all{fidx})),[3,inf],'double');
Fr_b_first = find(Fr_Sig(2,:)>3,1);
Fr_v_first = find(Fr_Sig(3,:)>3,1);
if (Fr_b_first - Fr_v_first)<0
    BlueFirst = 1;
elseif (Fr_b_first - Fr_v_first)>0
    BlueFirst = 0;
end

coorfile = [cur_fname(1:find(cur_fname == '_',1,'last')) 'coor.mat'];

if exist(fullfile(fpath,coorfile))
    load(fullfile(fpath,coorfile));
    disp('Loading PreExisting Coordinate Location for cropping!!')
else
[cpos, refimg] = MakeCoorFile(fpath,vfile,coorfile,BlueFirst);
end

%%
tic
[videoB videoV Bfi Vfi] = SplitVideo(vfile,BlueFirst,cpos); %% Bfi and Vfi are frame indices of blue and violet frames
toc
figure(1)
plot(Bfi,'b'); hold on; plot(Vfi,'m--')
title('Frames number blue violet')
VidSz = size(videoB);
vB = single(reshape(videoB,(size(videoB,1))*size(videoB,2),size(videoB,3)));
vV = single(reshape(videoV,size(videoV,1)*size(videoV,2),size(videoV,3)));
% clearvars -except vB vV VidSz

tic
[dffV] = MakeDffGpu(vB,vV,VidSz);
% [dffV] = MakeDffGpu_mean(vB,vV,VidSz);
toc

%% Saving DffV
% schoice = input('Do you want to save the video file (1 = yes; 0 = No) : ');
schoice = 1;
if schoice == 1
    SaveDff(dffV,fpath,cur_fname);
end

%%
PlayDff(dffV,0.03,'cmap2')


