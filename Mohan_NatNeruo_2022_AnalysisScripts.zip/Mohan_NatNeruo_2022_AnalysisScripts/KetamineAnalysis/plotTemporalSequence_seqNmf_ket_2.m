clear all; close all; clc
%%
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
cmapUse = cmap2; %% which cmap to use to plot
inPath = ['G:\Hemanth_CSHL\WideField\Data_Analysis\KetamineData\AllenFOVRegistered\seqNMFdata\' ...
'PlexinD1Ai148_16-Jan-2022_seqNMFData.mat'];
load(inPath);
AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.
[~,fname] = fileparts(inPath);
%% %%%%%%%%% get sample dorsal map
load('G:\Hemanth_CSHL\WideField\Data\AllenDorsalMap\allen_map\allenDorsalMap.mat');
%% load Data %%%%%%%%%
W = NMFdata.W;
redRat = NMFdata.imReduceRatio;
loadings = NMFdata.loadings;
dffVsz = NMFdata.dffVRedSize;
Wmap = reshape(W,dffVsz(1),dffVsz(2),NMFdata.numDims,NMFdata.dimLength);

%% Plot Frame Sequence %%%%%11%%%%%%%
close all
Fs = 30;
numFrames = 10; %%% how many frames to plot
WmapSz = size(Wmap);
frameIdxStart = 10;%1;
frameIdxEnd = 19;%WmapSz(4);
frameIdx = round(linspace(frameIdxStart,frameIdxEnd,numFrames));
frameTm = (frameIdx-1)* 1/Fs;
imScl = [0,1];

sigDim = 1:sum(loadings>0);
for jj = 1:length(sigDim)
inDim = jj;
Win = squeeze(Wmap(:,:,inDim,:));
WinSz = size(Win);
WinNorm = reshape(normalize(Win(:),'range',[0,1]),WinSz);
hIm(inDim) = figure;
hIm(inDim).Position = [26 705 - inDim*30 1820 148];
for ii = 1:length(frameIdx)
    %%%%%%%% plot activity image %%%%%%%%
    ax(ii) = subplot(1,length(frameIdx),ii);
    imagesc(WinNorm(:,:,frameIdx(ii)));
    hold on
    for p = 1:length(dorsalMaps.edgeOutlineSplit)
            plot( dorsalMaps.edgeOutlineSplit{p}(:, 2)*redRat,dorsalMaps.edgeOutlineSplit{p}(:, 1)*redRat,'color','w','LineWidth',0.5);
    end
    hold off
    caxis(imScl)
    axis image;
    set(gca,'XLim',[26 562]*redRat);
    set(gca,'YLim',[92 537]*redRat);
        colormap(hot);
    title([num2str(frameIdx(ii)) ' - ' num2str((frameTm(ii)))])
    set(gca,'XTick',[], 'YTick', [])
end
sgtitle([fname ' - Dim: ' num2str(inDim) '. Power:' num2str(NMFdata.power(1))],'interpreter','none')
end


%% %%%%%%%% saving the figures %%%%%%%%%%%
figFolder = ['G:\Hemanth_CSHL\WideField\Data_Figures\KetaminePlots\seqNmfMaps'];
if AskSaving == 1
    filename = [fname];
    savedim = input('Do you want to save the temporal Seq : ');
    if savedim == 1
        figpath = fullfile(figFolder,filename);
        savefig(hIm,[figpath '.fig']); % saving the figure as fig
        print(hIm,'-painters','-dsvg',[figpath '.svg'])
        disp('figures and data saved! ');
    end
end