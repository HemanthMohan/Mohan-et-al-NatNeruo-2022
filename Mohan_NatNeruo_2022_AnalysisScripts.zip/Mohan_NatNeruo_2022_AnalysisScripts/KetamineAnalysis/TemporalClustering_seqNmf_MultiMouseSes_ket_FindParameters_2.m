clear all; close all; clc
%%
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
cmapUse = cmap2; %% which cmap to use to plot
[fname fpath] = uigetfile('*.mat');
AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.
%% Sample dorsal map and mask path
dmName = [fname(1:end-10) 'dorsalMap.mat'];
load(fullfile(fpath,dmName));
%% %%%%%%%%%%%%%%% enter details to group sessions %%%%%%%%%%%%%
mouseIds = ['c']; %%%% enter the mouse ID to concatenate activity or even a part of it to concatedate across differenct mice
mouseType = ['FezF2'];
sessionType = ['ketAnaes'];
dateIn = {'20201210'};
% dateIn = {'20201209';'20201210';'20201211'};
%%%%%%%%%%%%%%%%%%% get file  name structure %%%%%%%%%%%%
parentFold = fileparts(fileparts(fpath));
foldNames = [];
if length(dateIn)>=1
    for ii = 1:length(dateIn)
        FoldCont = dir(fullfile(fileparts(fileparts(fpath)),[dateIn{ii} '*', mouseType '*', mouseIds '*',sessionType '*']));
        foldNames = [foldNames;{FoldCont.name}'];
    end
else
    FoldCont = dir(fullfile(fileparts(fileparts(fpath)),[dateIn '*', mouseType '*', mouseIds '*',sessionType '*']));
    foldNames = [foldNames;{FoldCont.name}];
end
%% extract Dff and concatenate
redRatio = 0.2; %%%% how much to shrink the file
durPerSes = 20; %% Duration of each session to consider for concatenation
bpFreq = [0.01 5]; %%%%%%% bandpass frequence range
dffVall = [];
tic
parfor kk = 1:length(foldNames)
    close all
    disp(['Processing Data from ' foldNames{kk}]);
    fpath1 = [fullfile(parentFold,foldNames{kk}) '\'];
    fname1 = [foldNames{kk} '_dffV_1.mat'];
    dffVout = getDff(fpath1,fname1,redRatio,durPerSes,bpFreq);
    
%     dffVall(:,:,:,kk) = dffVout;
    dffVall(:,:,:,kk) = reshape(zscore(dffVout(:)),dffVoutSz); %% zscoring the signal
    
%     dffVall = cat(3,dffVall,dffVout);
end
tmpSz = size(dffVall);
dffVall = single(reshape(dffVall,tmpSz(1), tmpSz(2),tmpSz(3)*tmpSz(4)));
toc/60
%% %%%%%%%%% making Matrix %%%%%%%%%%
dffVsz = size(dffVall);
dffVmat = single(reshape(dffVall,dffVsz(1)*dffVsz(2),dffVsz(3)));
dffVmat(find(dffVmat<0)) = 0;
%% %%%%%%%%%%% choosing K
tic
L = 30;
Ws = {};
Hs = {};
Diss = [];
maxIter1 = 50;
numfits = 4; %number of fits to compare
kIters = 15; %% number of dimension to explore
for k = 1:kIters
    display(sprintf('running seqNMF with K = %i',k))
    parfor ii = 1:numfits
        [Ws{ii,k},Hs{ii,k}] = seqNMF(dffVmat,'K',k, 'L', L,'lambda', 0,'maxiter',maxIter1,'showplot',0); 
        % note that max iter set low (30iter) for speed in demo (not recommended in practice)
    end
    inds = nchoosek(1:numfits,2);
    parfor i = 1:size(inds,1) % consider using parfor for larger numfits
            Diss(i,k) = helper.DISSX(Hs{inds(i,1),k},Ws{inds(i,1),k},Hs{inds(i,2),k},Ws{inds(i,2),k});
    end
end
chooseKDur = toc/60
%% Plot Diss and choose K with the minimum average diss.
figure,
plot([1:kIters],Diss,'ko'), hold on
Diss_median = median(Diss,1);
DissIdx = find(Diss_median == min(Diss_median));
h1 = plot([1:kIters],median(Diss,1),'k-','linewidth',2);
h2 = plot([DissIdx,DissIdx],[0,0.5],'r--');
legend([h1 h2], {'median Diss','true K'})
xlabel('K')
ylabel('Diss')
Kidentified = DissIdx;
%% Procedure for choosing lambda
nLambdas = 20; % increase if you're patient
if Kidentified > 1
    K = Kidentified; 
else
    K = 2;
end
lambdas = sort([logspace(-1,-5,nLambdas)], 'ascend'); 
loadings = [];
regularization = []; 
cost = []; 
parfor li = 1:length(lambdas)
    display(['Testing lambda ' num2str(li) '/' num2str(length(lambdas))])
    [N,T] = size(dffVmat);
    [W, H, ~,loadings(li,:),power]= seqNMF(dffVmat,'K',K,'L',L,...
         'lambda', lambdas(li), 'maxiter', 50, 'showPlot', 0); 
    [cost(li),regularization(li),~] = helper.get_seqNMF_cost(dffVmat,W,H);
end
%% plot costs as a function of lambda
windowSize = 3; 
b = (1/windowSize)*ones(1,windowSize);
a = 1;
Rs = filtfilt(b,a,regularization); 
minRs = prctile(regularization,10); maxRs= prctile(regularization,90);
Rs = (Rs-minRs)/(maxRs-minRs); 
R = (regularization-minRs)/(maxRs-minRs); 
Cs = filtfilt(b,a,cost); 
minCs =  prctile(cost,10); maxCs =  prctile(cost,90); 
Cs = (Cs -minCs)/(maxCs-minCs); 
C = (cost -minCs)/(maxCs-minCs); 
figure;
clf; hold on
plot(lambdas,Rs, 'b')
plot(lambdas,Cs,'r')
scatter(lambdas, R, 'b', 'markerfacecolor', 'flat');
scatter(lambdas, C, 'r', 'markerfacecolor', 'flat');
xlabel('Lambda'); ylabel('Cost (au)')
set(legend('Correlation cost', 'Reconstruction cost'), 'Box', 'on')
set(gca, 'xscale', 'log', 'ytick', [], 'color', 'none')
set(gca,'color','none','tickdir','out','ticklength', [0.025, 0.025])
%% storing Data
data.sessions = foldNames;
data.mouseType = mouseType;
data.durPerSes = durPerSes;
data.redRatio = redRatio;
data.L = L;
data.lambdaK = K;
data.numfits = numfits;
data.kIters = kIters;
data.Diss = Diss;
data.DissIdx = DissIdx ;
data.lambdas = lambdas;
data.Rs = Rs;
data.R = R;
data.Cs = Cs;
data.C = C;
%%  %%%%%%%%%%%%%%%%%%%%%%%%%%%%% Saving seqNMF parameteres data %%%%%%%%%%%%%%%%%%%%
if contains(lower(mouseType),'fezf')
    CellType = 'FezF2Ai148'; %%%%% options 'FezF2Ai148'; 'PlexinD1Ai148'; 'Tle4Ai148'; 'CBAAi93h'
elseif contains(lower(mouseType),'plexin')
    CellType = 'PlexinD1Ai148';
end

if AskSaving == 1
    filename = [CellType '_' date '_seqNMFParameterData.mat']
    savepath = fullfile('G:\Hemanth_CSHL\WideField\Data_Analysis\KetamineData\AllenFOVRegistered\seqNMFdata',filename);
    saveData = input('Do you want to save the NMF data : ');
    if saveData == 1
        save(savepath,'data')
        disp('NMF Data Saved !!')
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% %%%%%%%%%%%%%%%%%%% funcitons %%%%%%%%%%%%%%%%%%%%%
function [dffVout] = getDff(fpath,fname,redRatio,durPerSes,bpFreq)
Fs = 30;
%% %%%%%%%%%%%%%%% load allen dorasal map coordinates %%%%%
dmName = [fname(1:end-10) 'dorsalMap.mat'];
load(fullfile(fpath,dmName));
tform = dorsalMaps.tform;
%% %%%%%%%% loading FOV mask file %%%%%%%%%
[~,maskFold] = fileparts(fileparts(fpath));
maskPath = fullfile(fileparts(fileparts(fileparts(fpath))),['Data'],maskFold);
fovMask = load(fullfile(maskPath,[fname(1:end-10) 'refMask.mat']));
%% %%%%%%%%%%% extract dffV Signal %%%%%%%%%%%%%%%%%
disp(['Collecting raw signal and building Matrix'])
vfile = fullfile(fpath,fname);
load(vfile);
frameLen = durPerSes*Fs;
dffV = dffV(:,:,1:frameLen);
dffV= imwarp(dffV.*fovMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*dorsalMaps.maskScaled;
dffV = imresize(dffV,redRatio);
dffV = regressMeanOut(dffV); %%%%%%%%%%% regressing Mean out
dffVfilt = single(filter_dffV(dffV,bpFreq));
dffVout = zscore(dffVfilt,[],3);
end