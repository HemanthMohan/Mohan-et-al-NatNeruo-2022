clear all; close all; clc
%%
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
cmapUse = cmap2; %% which cmap to use to plot
[fname fpath] = uigetfile('*.mat');
AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.
%% %%%%%%%%% get sample dorsal map
load('G:\Hemanth_CSHL\WideField\Data\AllenDorsalMap\allen_map\allenDorsalMap.mat');
%% extract Dff and concatenate
redRatio = 0.25; %%%% how much to shrink the file
durPerSes = 60; %% Duration of each session to consider for concatenation in seconds
bpFreq = [0.01 5]; %%%%%%% bandpass frequence range
dffVall = [];
tic
close all
disp(['Processing Data from ' fname]);
dffVout = getDff(fpath,fname,redRatio,durPerSes,bpFreq);
dffVall = dffVout;
toc/60
%% %%%%%%%%% making Matrix %%%%%%%%%%
dffVsz = size(dffVall);
dffVmat = single(reshape(dffVall,dffVsz(1)*dffVsz(2),dffVsz(3)));
dffVmat(find(dffVmat<0)) = 0;
%% %%%%%%%%%%% choosing K
tic
L = 30;
Ws = {};
Hs = {};
Diss = [];
maxIter1 = 50;
numfits = 4; %number of fits to compare
kIters = 10; %% number of dimension to explore
for k = 1:kIters
    display(sprintf('running seqNMF with K = %i',k))
    parfor ii = 1:numfits
        [Ws{ii,k},Hs{ii,k}] = seqNMF(dffVmat,'K',k, 'L', L,'lambda', 0,'maxiter',maxIter1,'showplot',0); 
        % note that max iter set low (30iter) for speed in demo (not recommended in practice)
    end
    inds = nchoosek(1:numfits,2);
    parfor i = 1:size(inds,1) % consider using parfor for larger numfits
            Diss(i,k) = helper.DISSX(Hs{inds(i,1),k},Ws{inds(i,1),k},Hs{inds(i,2),k},Ws{inds(i,2),k});
    end
end
chooseKDur = toc/60
%% Plot Diss and choose K with the minimum average diss.
figure,
plot([1:kIters],Diss,'ko'), hold on
Diss_median = median(Diss,1);
DissIdx = find(Diss_median == min(Diss_median));
h1 = plot([1:kIters],median(Diss,1),'k-','linewidth',2);
h2 = plot([DissIdx,DissIdx],[0,0.5],'r--');
legend([h1 h2], {'median Diss','true K'})
xlabel('K')
ylabel('Diss')
%%
% K = 20;
% L = 30;
% maxIter2 = 50;
% lam = 0.001;
% [W, H, cost,loadings,power] = seqNMF(dffVmat,'K',K,'L',L,'lambda',lam,'maxiter',maxIter2,'lambdaL1H', .1);
%%
% %% %%%%%%%% Perform seq NNMF and extract componenets with custom ALS %%%%%%%%%
% % nmfIter = 50; %%%% default = 50 as temporary. You have to check properly
% A = dffVmat;
% A(find(A<0)) = 0;
% K = 8;
% L = 30;
% maxIter = 20;
% lam = 0.001;
% % [H,W,HUnit,WUnit,HVar,HUnitVar,SqErr] = MyNmfAls(A,inRank,nmfIter,U,S);
% [W, H, cost,loadings,power] = seqNMF(A,'K',K,'L',L,'lambda',lam,'maxiter',maxIter);
% %% %%%%%%%%%%%%% storing NMF data %%%%%%%%%%%
% NMFdata.H = H;
% NMFdata.W = W;
% NMFdata.numDims = K;
% NMFdata.dimLength = L;
% NMFdata.loadings = loadings;
% NMFdata.power = power;
% NMFdata.lambda = lam;
% NMFdata.MaxNumIter = maxIter;
% NMFdata.imReduceRatio = redRatio;
% NMFdata.dffVRedSize = dffVsz;
% NMFdata.sessions = foldNames;
% NMFdata.date = date;
% NMFdata.dorsalMap = dorsalMaps.edgeOutlineSplit;
% %%  %%%%%%%%%%%%%%%%%%%%%%%%%%%%% Saving NMF data %%%%%%%%%%%%%%%%%%%%
% if contains(lower(mouseType),'fezf')
%     CellType = 'FezF2Ai148'; %%%%% options 'FezF2Ai148'; 'PlexinD1Ai148'; 'Tle4Ai148'; 'CBAAi93h'
% elseif contains(lower(mouseType),'plexin')
%     CellType = 'PlexinD1Ai148';
% end
% 
% if AskSaving == 1
%     filename = [CellType '_' date '_seqNMFData.mat']
%     savepath = fullfile('G:\Hemanth_CSHL\WideField\Data_Analysis\KetamineData\AllenFOVRegistered\seqNMFdata',filename);
%     saveData = input('Do you want to save the NMF data : ');
%     if saveData == 1
%         save(savepath,'NMFdata')
%         disp('NMF Data Saved !!')
%     end
% end
%% %%%%% plotting nmf Maps %%%%%%%%%%%%
% indim = 3;    %%%% Enter the dimension to plot
% ImScale = [4];
% close(gcf)
% dmMap = dorsalMaps.edgeOutlineSplit;
% 
% seqDim = reshape(W(:,indim,:),dffVsz(1),dffVsz(2),L);
% PlayDff(seqDim,ImScale,'cmap2')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% %%%%%%%%%%%%%%%%%%% funcitons %%%%%%%%%%%%%%%%%%%%%
function [dffVout] = getDff(fpath,fname,redRatio,durPerSes,bpFreq)
Fs = 30;
%% %%%%%%%%%%%%%%% load allen dorasal map coordinates %%%%%
dmName = [fname(1:end-10) 'dorsalMap.mat'];
load(fullfile(fpath,dmName));
tform = dorsalMaps.tform;
%% %%%%%%%% loading FOV mask file %%%%%%%%%
[~,maskFold] = fileparts(fileparts(fpath));
maskPath = fullfile(fileparts(fileparts(fileparts(fpath))),['Data'],maskFold);
fovMask = load(fullfile(maskPath,[fname(1:end-10) 'refMask.mat']));
%% %%%%%%%%%%% extract dffV Signal %%%%%%%%%%%%%%%%%
disp(['Collecting raw signal and building Matrix'])
vfile = fullfile(fpath,fname);
load(vfile);
frameLen = durPerSes*Fs;
dffV = dffV(:,:,1:frameLen);
dffV= imwarp(dffV.*fovMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*dorsalMaps.maskScaled;
dffV = imresize(dffV,redRatio);
dffV = regressMeanOut(dffV); %%%%%%%%%%% regressing Mean out
dffVfilt = single(filter_dffV(dffV,bpFreq));
dffVout = zscore(dffVfilt,[],3);
end