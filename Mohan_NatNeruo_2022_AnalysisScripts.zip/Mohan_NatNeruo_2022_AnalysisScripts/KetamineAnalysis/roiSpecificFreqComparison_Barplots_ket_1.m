clear all; close all; clc
%%
plexData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\KetamineData\AllenFOVRegistered\roiSpecificFreqData\PlexinD1Ai148_freqData.mat');
plexData = plexData.data; 
fezData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\KetamineData\AllenFOVRegistered\roiSpecificFreqData\FezF2Ai148_freqData.mat');
fezData = fezData.data;
AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.
%% %%%%%% Extract Power within freq range
freqRange = [1,1.4]; %%%% enter the frequency range in Hz you want to compare across cell types [0.6 0.9] and [1 1.4];
f = plexData.pf;
freqRangeIdx = find(f >= freqRange(1) & f <= freqRange(2)); 
roiNames = fieldnames(plexData.pxxRel);
for ii = 1:length(roiNames)
    for jj = 1:size(plexData.pxxRel,2)
        plexData.meanPw.(roiNames{ii})(jj) = mean(plexData.pxxRel(jj).(roiNames{ii})(freqRangeIdx));
        fezData.meanPw.(roiNames{ii})(jj) = mean(fezData.pxxRel(jj).(roiNames{ii})(freqRangeIdx));
    end
end
%% %%%%%%% perform statistical significance test 
for ii = 1:length(roiNames)
    [p.(roiNames{ii}), ~, stats.(roiNames{ii})] = ranksum(plexData.meanPw.(roiNames{ii})',fezData.meanPw.(roiNames{ii})');
end

%% %%%%%%%% plot Values %%%%%%
h1 = figure(1);
h1.Position = [285   322   684   656];
for ii = 1:length(roiNames)
    ax(ii) = subplot(2,3,ii);
    grp = [ones(length(plexData.meanPw.(roiNames{ii})),1); 2*ones(length(fezData.meanPw.(roiNames{ii})),1)];
    boxplot([plexData.meanPw.(roiNames{ii})';fezData.meanPw.(roiNames{ii})'],grp,'Labels',{'plexinD1','FezF2'})
    ylabel('Mean Rel Pw')
    set(gca,'TickDir','out');
    text(1.3,6e-3,['p = ' num2str(p.(roiNames{ii}))])
    title(roiNames{ii})
end
linkaxes(ax,'y');
sgtitle([' FreqRange : ' num2str(freqRange(1)) ' - ' num2str(freqRange(2))])
%% %%%%%%%%%%%%% saving the figures %%%%%%%%%%
if AskSaving == 1
    saveFig = input('Do you want to save the current figure : ');
    if saveFig == 1
        %%% saving figures
        savepath = fullfile(['G:\Hemanth_CSHL\WideField\Data_Figures\KetaminePlots\RoiSpecificFrequency\'], ...
            ['RelPowComparison_BoxPlot_Freq_' num2str(freqRange(1)) ' - ' num2str(freqRange(2)) 'Hz.fig']);
        savefig(h1,savepath)
        saveas(h1,[savepath(1:end-4) '.svg']);
    end
end
