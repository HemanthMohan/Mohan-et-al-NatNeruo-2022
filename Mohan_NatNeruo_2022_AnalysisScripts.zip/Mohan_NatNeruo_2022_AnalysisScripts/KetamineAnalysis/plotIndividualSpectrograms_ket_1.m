clear all; close all; clc
%% load data
inFile = ['G:\Hemanth_CSHL\WideField\Data_Analysis\KetamineData\AllenFOVRegistered\roiSpecificFreqData\' ...
    'FezF2Ai148_freqData.mat'];
load(inFile);
AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.

%% %%%%%%%%%%%%%%% extract spectrogram
roiNames = fieldnames(data.specAllRel);
%% %%%%%%%%%% ploting spectrogram and PSD %%%%%%%%%%%%%%
%%%%%%%%%%%%%% plotting spectrograms %%%%%%%%%%%%%%%%%%
close all
st = data.st;
sf = data.sf;
f = data.f;
lClr = rand(6,3);
nSessions = size(data.specAllRel.(roiNames{1}),3);
for ii = 1:length(roiNames)
    h1(ii) = figure;
    h1(ii).Position = [90+10*ii 6+10*ii 1781 669];
    for jj = 1:nSessions
        ax1(ii,jj) = subplot(3,6,jj);
        imagesc(st,sf,data.specAllRel.(roiNames{ii})(:,:,jj)')
        caxis(ax1(ii,jj),[0,0.5])
        title(data.sessions{jj},'interpreter','none','FontSize',8)
    end
    set(ax1(ii,:),'YDir','Normal','YLim',[0,4])
    set(ax1(ii,:),'TickDir','out')
    colormap jet
    sgtitle(['Relative Power - ' (roiNames{ii})])
    linkaxes(ax1)
end
%%% plot power spectrum

for ii = 1:length(roiNames)
    h2(ii) = figure;
    h2(ii).Position = [10+10*ii 113+10*ii 1625 613];
    for jj = 1:nSessions
        ax2(ii,jj) = subplot(3,6,jj);
        plot(f,data.pxxRel(jj).(roiNames{ii}),'color',lClr(ii,:),'LineWidth',1)
        title(data.sessions{jj},'interpreter','none','FontSize',8)
    end
    set(ax2(ii,:),'TickDir','out')
    sgtitle(['Relative Power - ' (roiNames{ii})])
    linkaxes(ax2)
    xlim([0,5])
end


%% %%%%%%%%%%%%% saving the figures and data %%%%%%%%%%
if contains(lower(data.sessions{1}),'fezf')
    CellType = 'FezF2Ai148'; %%%%% options 'FezF2Ai148'; 'PlexinD1Ai148'; 'Tle4Ai148'; 'CBAAi93h'
elseif contains(lower(data.sessions{1}),'plexin')
    CellType = 'PlexinD1Ai148';
end

if AskSaving == 1
    filename = CellType;
    saveFig = input('Do you want to save the current figure : ');
    if saveFig == 1
        %%% saving figures
        savepath1 = fullfile(['G:\Hemanth_CSHL\WideField\Data_Figures\KetaminePlots\RoiSpecificFrequency\'],[filename '_relativeSpectorgramSingleSessions.fig']);
        savefig(h1,savepath1)
        
        savepath2 = fullfile(['G:\Hemanth_CSHL\WideField\Data_Figures\KetaminePlots\RoiSpecificFrequency\'],[filename '_relativePSDSingleSessions.fig']);
        savefig(h2,savepath2)
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% %%%%%%%%%%%%%%%%%%%%%%%%%%% Functions %%%%%%%%%%%%%%%%%%%

function [pxxAbs,pxxRel,f,spec] = getPSD_Spec(fpath,fname)
%% %%%%%%%%%%%%%%% load allen dorasal map coordinates %%%%%
dmName = [fname(1:end-10) 'dorsalMap.mat'];
load(fullfile(fpath,dmName));
tform = dorsalMaps.tform;
%% %%%%%%%% loading FOV mask file %%%%%%%%%
[~,maskFold] = fileparts(fileparts(fpath));
maskPath = fullfile(fileparts(fileparts(fileparts(fpath))),['Data'],maskFold);
fovMask = load(fullfile(maskPath,[fname(1:end-10) 'refMask.mat']));
%% %%%%%%%%%% load roi Masks %%%%%%%%%%
roiMasks = load('G:\Hemanth_CSHL\WideField\Data_Analysis\KetamineData\AllenFOVRegistered\ketamineRoiMasks.mat');
roiMasks = roiMasks.data.roiMasks;
bcMask = double(roiMasks.BarrelCortex); bcMask(bcMask==0) = nan; %%% barrel cortex Mask
mopMask = double(roiMasks.PrimaryMotorCortex); mopMask(mopMask==0) = nan; %%% primary motor cortex Mask
mosMask = double(roiMasks.SecondaryMotorCortex); mosMask(mosMask==0) = nan; %%% secondary motor cortex Mask
hlMask = double(roiMasks.HindlimbCortex); hlMask(hlMask==0) = nan; %%% hindlimb cortex Mask
rspMask = double(roiMasks.RetrosplenialCortex); rspMask(rspMask==0) = nan; %%% retrosplenial cortex Mask
vcMask = double(roiMasks.VisualCortex); vcMask(vcMask==0) = nan; %%% visual cortex Mask
%% %%%%%%%%%%% extract dffV Signal %%%%%%%%%%%%%%%%%
disp(['Collecting raw signal and building Matrix'])
vfile = fullfile(fpath,fname);
load(vfile);
dffV= imwarp(dffV.*fovMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*dorsalMaps.maskScaled;
dffVsize = size(dffV);
%% Extract Roi Traces and plot 
trace.bc = squeeze(nanmean(nanmean(dffV .* bcMask)));
trace.mop = squeeze(nanmean(nanmean(dffV .* mopMask))); 
trace.mos = squeeze(nanmean(nanmean(dffV .* mosMask)));
trace.hl = squeeze(nanmean(nanmean(dffV .* hlMask)));
trace.rsp = squeeze(nanmean(nanmean(dffV .* rspMask)));
trace.vc = squeeze(nanmean(nanmean(dffV .* vcMask)));
%% %%%%%%%%%%% Extracting Spectral Properties
Fs = 30;
roiNames = fieldnames(trace);
L = dffVsize(3);
% [pxx.bc,f] = periodogram(trace.bc,[],L,Fs);
for ii = 1:length(roiNames)
[pxxAbs.(roiNames{ii}),f] = pmtm(trace.(roiNames{ii}),[],L,Fs); %%%% multi taper estimate
pxxRel.(roiNames{ii}) = pxxAbs.(roiNames{ii})./(sum(pxxAbs.(roiNames{ii})));
end
%% %%%%%%%%%%%%%% Extract Spectrograms uisng multitaper estimate 
movingwin=[20 0.05]; %%%%%% size of the window to compute spectrogram and step size in Seconds. Use Fs to make sense
params = [];
spec = [];
params.tapers=[2 3];
params.Fs=30;
params.pad=1;
params.fpass=[0 10];
for ii = 1:length(roiNames)
sigIn = trace.(roiNames{ii});
[spec.(roiNames{ii}).AbsSpec,st,sf]=mtspecgramc(sigIn,movingwin,params);
spec.(roiNames{ii}).RelSpec = spec.(roiNames{ii}).AbsSpec./max(max(spec.(roiNames{ii}).AbsSpec));
end
spec.params = params;
spec.t = st;
spec.f = sf;
end
