clear all; close all; clc
%%
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
plexDataF1 = load('G:\Hemanth_CSHL\WideField\Data_Analysis\KetamineData\AllenFOVRegistered\FrequencySpecificAmplitudeData\PlexinD1Ai148_202012092020121020201211_FreqBand-0.6-0.9Hz_freqAmpData.mat');
plexDataF1 = plexDataF1.data; 
fezDataF1 = load('G:\Hemanth_CSHL\WideField\Data_Analysis\KetamineData\AllenFOVRegistered\FrequencySpecificAmplitudeData\FezF2Ai148_202012092020121020201211_FreqBand-0.6-0.9Hz_freqAmpData.mat');
fezDataF1 = fezDataF1.data;
plexDataF2 = load('G:\Hemanth_CSHL\WideField\Data_Analysis\KetamineData\AllenFOVRegistered\FrequencySpecificAmplitudeData\PlexinD1Ai148_202012092020121020201211_FreqBand-1-1.4Hz_freqAmpData.mat');
plexDataF2 = plexDataF2.data; 
fezDataF2 = load('G:\Hemanth_CSHL\WideField\Data_Analysis\KetamineData\AllenFOVRegistered\FrequencySpecificAmplitudeData\FezF2Ai148_202012092020121020201211_FreqBand-1-1.4Hz_freqAmpData.mat');
fezDataF2 = fezDataF2.data;

AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.
%% Sample dorsal map and mask path
dmName = ['20210126_PlexinD1Ai148_c8m2_spont_dorsalMap.mat'];
fpath = 'G:\Hemanth_CSHL\WideField\Data_Corrected\20210126_PlexinD1Ai148_c8m2_spont';
load(fullfile(fpath,dmName));
dmMap = dorsalMaps.edgeOutlineSplit;
redRat = 0.3
%% perform PCA
allMaps = [zscore(plexDataF1.freqBandPowAmp)' ; zscore(plexDataF2.freqBandPowAmp)';zscore(fezDataF1.freqBandPowAmp)' ; zscore(fezDataF2.freqBandPowAmp)' ];
numSes = length(plexDataF1.sessions);
grpIdx = [repmat({'plex:0.6-0.9Hz '},numSes,1); repmat({'plex:1-1.4Hz '},numSes,1);repmat({'fez:0.6-0.9Hz '},numSes,1); repmat({'fez:1-1.4Hz '},numSes,1)];
[pca_coef,pca_score] = pca(allMaps);
%% %%%%
imShape = size(plexDataF1.freqBandPowAmpNormMap);
%% %%%%%%%%%%%% plotting variance maps %%%%%%%%%%%%%%
close all
h1 = figure;h1.Position = [20 478 1533 429];
ax(1) = subplot(1,3,1);
gscatter(pca_score(:,1),pca_score(:,2),grpIdx); axis square
xlabel('PC 1');ylabel('PC 2');

ax(2) = subplot(1,3,2);
imagesc(reshape(pca_coef(:,1),imShape));axis image;colormap(cmap2)
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','w');
end
hold off
title('PC Dim 1')

ax(3) = subplot(1,3,3);
imagesc(reshape(pca_coef(:,2),imShape));axis image;colormap(cmap2)
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','w');
end
hold off
title('PC Dim 2')


%% %%%%%%%%%%%%% saving the figures %%%%%%%%%%
if AskSaving == 1
    saveFig = input('Do you want to save the current figures : ');
    if saveFig == 1
        %%% saving figures
        savepath = fullfile(['G:\Hemanth_CSHL\WideField\Data_Figures\KetaminePlots\FrequencySpecificAmplitudeMaps\'], ...
            ['freqPowerMap_PCA.fig']);
        savefig(h1,savepath)
    end
end
