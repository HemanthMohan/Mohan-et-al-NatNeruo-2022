clear all; close all; clc
%%
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
cmapUse = cmap2; %% which cmap to use to plot
[fname fpath] = uigetfile('*.mat');
AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.

%% %%%%%%%%%%%%%%% enter details to group sessions %%%%%%%%%%%%%
mouseIds = ['c']; %%%% enter the mouse ID to concatenate activity or even a part of it to concatedate across differenct mice
mouseType = ['PlexinD1'];
sessionType = ['ketAnaes'];
% dateIn = {'20201209'};
dateIn = {'20201209';'20201210';'20201211'};

% % %%%%%%%%%%%%%%%%%%% get file  name structure %%%%%%%%%%%%
parentFold = fileparts(fileparts(fpath));
foldNames = [];
if length(dateIn)>=1
    for ii = 1:length(dateIn)
        FoldCont = dir(fullfile(fileparts(fileparts(fpath)),[dateIn{ii} '*', mouseType '*', mouseIds '*',sessionType '*']));
        foldNames = [foldNames;{FoldCont.name}'];
    end
else
    FoldCont = dir(fullfile(fileparts(fileparts(fpath)),[dateIn '*', mouseType '*', mouseIds '*',sessionType '*']));
    foldNames = [foldNames;{FoldCont.name}];
end
%% %%%%%%%%%%%%%%% Extract PSD and spectrogram signals for all sessions  %%%%%
tic
nw = 4;%%% time-halfBandwidth for psd. Def = 4
for kk = 1:length(foldNames)
    disp(['Processing Data from ' foldNames{kk}]);
    %%%%%%%%%%%%%%%%% load allen dorasal map coordinates %%%%%
    fpath1 = [fullfile(parentFold,foldNames{kk}) '\'];
    fname1 = [foldNames{kk} '_dffV_1.mat'];
    [pxxAbs(kk),pxxRel(kk),f,spec(kk)] = getPSD_Spec(fpath1,fname1,nw);
end
toc/60
%% %%%%%%%%%%%%%% calculate mean PSD and spectrograms %%
roiNames = fieldnames(pxxAbs);
pxxAbsMean = [];pxxRelMean = [];pxxAbsSe = []; pxxRelSe = [];
specMean = [];
for ii = 1:length(roiNames)
    %%%%%%%%%%% calculate mean and SEM of PSD
    pxxAbsMean.(roiNames{ii}) = mean([pxxAbs(:).(roiNames{ii})],2);
    pxxRelMean.(roiNames{ii}) = mean([pxxRel(:).(roiNames{ii})],2);
    
    pxxAbsSe.(roiNames{ii}) = std([pxxAbs(:).(roiNames{ii})],[],2)./sqrt(length(foldNames));
    pxxRelSe.(roiNames{ii}) = std([pxxRel(:).(roiNames{ii})],[],2)./sqrt(length(foldNames));
    %%%%%%%%%%% calculate mean spectrograms %%%%%%%%
    for jj = 1:length(foldNames)
        specAllRel.(roiNames{ii})(:,:,jj) = single([spec(jj).(roiNames{ii}).RelSpec]);
        specAllAbs.(roiNames{ii})(:,:,jj) = single([spec(jj).(roiNames{ii}).AbsSpec]);
    end
    specRelMean.(roiNames{ii}) = mean(specAllRel.(roiNames{ii}),3);
    specAbsMean.(roiNames{ii}) = mean(specAllAbs.(roiNames{ii}),3);
end
%% %%%%%%%%%% storing data 
data = [];
data.pxxAbs = pxxAbs;
data.pxxRel = pxxRel;
data.pf = f;
data.timeHalfbandwidth = nw;
data.st = spec.t;
data.sf = spec.f;
data.specAllRel = specAllRel;
data.specAllAbs = specAllAbs;
data.pxxAbsMean = pxxAbsMean;
data.pxxRelMean = pxxRelMean;
data.pxxAbsSe = pxxAbsSe;
data.pxxRelSe = pxxRelSe;
data.sessions = foldNames;

%% %%%%%%%%%% ploting mean PSD %%%%%%%%%%%%%%
close all
h3 = figure;
lClr = rand(6,3);
for ii = 1:length(roiNames)
    ax1(ii) = subplot(2,3,ii);
    hold on
    fill([f' fliplr(f')],[[pxxRelMean.(roiNames{ii}) + 2*pxxRelSe.(roiNames{ii})]' ...
        fliplr([pxxRelMean.(roiNames{ii}) - 2*pxxRelSe.(roiNames{ii})]')],lClr(ii,:),'FaceAlpha',0.3,'EdgeColor','none')
    plot(f,pxxRelMean.(roiNames{ii}),'color',lClr(ii,:),'LineWidth',1.5)
    title((roiNames{ii}))
end
hold off
sgtitle('Relative Power')
linkaxes(ax1)
xlim([0,5])
set(ax1,'TickDir','out')
annotation(h3,'textbox', [0, 0.9, 0, 0], 'string', foldNames,'FontSize',7, 'Interpreter', 'none')
h3.Position = [9 349 1128 647];

h4 = figure;
for ii = 1:length(roiNames)
    ax2(ii) = subplot(2,3,ii);
    hold on
    fill([f' fliplr(f')],[[pxxAbsMean.(roiNames{ii}) + 2*pxxAbsSe.(roiNames{ii})]' ...
        fliplr([pxxAbsMean.(roiNames{ii}) - 2*pxxAbsSe.(roiNames{ii})]')],lClr(ii,:),'FaceAlpha',0.3,'EdgeColor','none')
    plot(f,pxxAbsMean.(roiNames{ii}),'color',lClr(ii,:),'LineWidth',1.5)
    title((roiNames{ii}))
end
hold off
sgtitle('Absolute Power')
linkaxes(ax2)
xlim([0,5])
set(ax2,'TickDir','out')
annotation(h4,'textbox', [0, 0.9, 0, 0], 'string', foldNames,'FontSize',7, 'Interpreter', 'none')
h4.Position = [386 237 1128 647];

%%%%%%%%%%%%%% plotting spectrograms %%%%%%%%%%%%%%%%%%
st = spec.t;
sf = spec.f;
h5 = figure;
for ii = 1:length(roiNames)
    ax3(ii) = subplot(2,3,ii);
    imagesc(st,sf,specRelMean.(roiNames{ii})')
    title((roiNames{ii}))
    caxis(ax3(ii),[0,0.3])
end
set(ax3,'YDir','Normal','YLim',[0,5])
colormap jet
hold off
sgtitle('Relative Power')
linkaxes(ax3)
set(ax3,'TickDir','out')
annotation(h5,'textbox', [0, 0.9, 0, 0], 'string', foldNames,'FontSize',7, 'Interpreter', 'none')
h5.Position = [386 237 1128 647];

h6 = figure;
for ii = 1:length(roiNames)
    ax4(ii) = subplot(2,3,ii);
    imagesc(st,sf,specAbsMean.(roiNames{ii})')
    title((roiNames{ii}))
    caxis(ax4(ii),[0,3e-4])
end
set(ax4,'YDir','Normal','YLim',[0,5])
colormap jet
hold off
sgtitle('Absolute Power')
linkaxes(ax4)
set(ax4,'TickDir','out')
annotation(h6,'textbox', [0, 0.9, 0, 0], 'string', foldNames,'FontSize',7, 'Interpreter', 'none')
h6.Position = [386 237 1128 647];
%% %%%%%%%%%%%%% saving the figures and data %%%%%%%%%%
if contains(lower(mouseType),'fezf')
    CellType = 'FezF2Ai148'; %%%%% options 'FezF2Ai148'; 'PlexinD1Ai148'; 'Tle4Ai148'; 'CBAAi93h'
elseif contains(lower(mouseType),'plexin')
    CellType = 'PlexinD1Ai148';
end

if AskSaving == 1
    filename = CellType;
    saveFig = input('Do you want to save the current figure : ');
    if saveFig == 1
        %%% saving figures
        savepath1 = fullfile(['G:\Hemanth_CSHL\WideField\Data_Figures\KetaminePlots\RoiSpecificFrequency\'],[filename '_relativePSD.fig']);
        savefig(h3,savepath1)
        saveas(h3,[savepath1(1:end-4) '.svg']);
        
        savepath2 = fullfile(['G:\Hemanth_CSHL\WideField\Data_Figures\KetaminePlots\RoiSpecificFrequency\'],[filename '_absolutePSD.fig']);
        savefig(h4,savepath2)
        saveas(h4,[savepath2(1:end-4) '.svg']);
        
        savepath3 = fullfile(['G:\Hemanth_CSHL\WideField\Data_Figures\KetaminePlots\RoiSpecificFrequency\'],[filename '_relativeSpectrogram.fig']);
        savefig(h5,savepath3)
        saveas(h5,[savepath3(1:end-4) '.svg']);
        
        savepath4 = fullfile(['G:\Hemanth_CSHL\WideField\Data_Figures\KetaminePlots\RoiSpecificFrequency\'],[filename '_absoluteSpectrogram.fig']);
        savefig(h6,savepath4)
        saveas(h6,[savepath4(1:end-4) '.svg']);
        disp('Figures are Saved !')
        %%%%% saving data
        datapath = fullfile(['G:\Hemanth_CSHL\WideField\Data_Analysis\KetamineData\AllenFOVRegistered\roiSpecificFreqData'],[filename '_freqData.mat']);
        save(datapath,'data', '-v7.3')
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% %%%%%%%%%%%%%%%%%%%%%%%%%%% Functions %%%%%%%%%%%%%%%%%%%

function [pxxAbs,pxxRel,f,spec] = getPSD_Spec(fpath,fname,nw)
%% %%%%%%%%%%%%%%% load allen dorasal map coordinates %%%%%
dmName = [fname(1:end-10) 'dorsalMap.mat'];
load(fullfile(fpath,dmName));
tform = dorsalMaps.tform;
%% %%%%%%%% loading FOV mask file %%%%%%%%%
[~,maskFold] = fileparts(fileparts(fpath));
maskPath = fullfile(fileparts(fileparts(fileparts(fpath))),['Data'],maskFold);
fovMask = load(fullfile(maskPath,[fname(1:end-10) 'refMask.mat']));
%% %%%%%%%%%% load roi Masks %%%%%%%%%%
roiMasks = load('G:\Hemanth_CSHL\WideField\Data_Analysis\KetamineData\AllenFOVRegistered\ketamineRoiMasks.mat');
roiMasks = roiMasks.data.roiMasks;
bcMask = double(roiMasks.BarrelCortex); bcMask(bcMask==0) = nan; %%% barrel cortex Mask
mopMask = double(roiMasks.PrimaryMotorCortex); mopMask(mopMask==0) = nan; %%% primary motor cortex Mask
mosMask = double(roiMasks.SecondaryMotorCortex); mosMask(mosMask==0) = nan; %%% secondary motor cortex Mask
hlMask = double(roiMasks.HindlimbCortex); hlMask(hlMask==0) = nan; %%% hindlimb cortex Mask
rspMask = double(roiMasks.RetrosplenialCortex); rspMask(rspMask==0) = nan; %%% retrosplenial cortex Mask
vcMask = double(roiMasks.VisualCortex); vcMask(vcMask==0) = nan; %%% visual cortex Mask
%% %%%%%%%%%%% extract dffV Signal %%%%%%%%%%%%%%%%%
disp(['Collecting raw signal and building Matrix'])
vfile = fullfile(fpath,fname);
load(vfile);
dffV= imwarp(dffV.*fovMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*dorsalMaps.maskScaled;
dffVsize = size(dffV);
%% Extract Roi Traces and plot 
trace.bc = squeeze(nanmean(nanmean(dffV .* bcMask)));
trace.mop = squeeze(nanmean(nanmean(dffV .* mopMask))); 
trace.mos = squeeze(nanmean(nanmean(dffV .* mosMask)));
trace.hl = squeeze(nanmean(nanmean(dffV .* hlMask)));
trace.rsp = squeeze(nanmean(nanmean(dffV .* rspMask)));
trace.vc = squeeze(nanmean(nanmean(dffV .* vcMask)));
%% mean correction
roiNames = fieldnames(trace);
for ii = 1:length(roiNames)
trace.(roiNames{ii}) = trace.(roiNames{ii}) - mean(trace.(roiNames{ii}));
end
%% %%%%%%%%%%% Extracting Spectral Properties
Fs = 30;
L = dffVsize(3);
NW = nw;
% [pxx.bc,f] = periodogram(trace.bc,[],L,Fs);
for ii = 1:length(roiNames)
[pxxAbs.(roiNames{ii}),f] = pmtm(trace.(roiNames{ii}),NW,L,Fs); %%%% multi taper estimate
pxxRel.(roiNames{ii}) = pxxAbs.(roiNames{ii})./(sum(pxxAbs.(roiNames{ii})));
end
%% %%%%%%%%%%%%%% Extract Spectrograms uisng multitaper estimate 
movingwin=[20 0.05]; %%%%%% size of the window to compute spectrogram and step size in Seconds. Use Fs to make sense
params = [];
spec = [];
params.tapers=[2 3];
params.Fs=30;
params.pad=1;
params.fpass=[0 10];
for ii = 1:length(roiNames)
sigIn = trace.(roiNames{ii});
[spec.(roiNames{ii}).AbsSpec,st,sf]=mtspecgramc(sigIn,movingwin,params);
spec.(roiNames{ii}).RelSpec = spec.(roiNames{ii}).AbsSpec./max(max(spec.(roiNames{ii}).AbsSpec));
end
spec.params = params;
spec.t = st;
spec.f = sf;
end
