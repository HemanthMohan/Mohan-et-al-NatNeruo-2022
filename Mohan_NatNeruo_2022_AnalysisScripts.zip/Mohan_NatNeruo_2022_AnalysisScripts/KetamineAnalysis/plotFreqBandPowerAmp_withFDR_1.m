clear all; close all; clc
%%
load('F:\Hemanth_CSHL\WideField\Data\cmapPlexFez.mat');
plexData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\KetamineData\AllenFOVRegistered\FrequencySpecificAmplitudeData\PlexinD1Ai148_202012092020121020201211_FreqBand-1-1.4Hz_freqAmpData.mat');
plexData = plexData.data; 
fezData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\KetamineData\AllenFOVRegistered\FrequencySpecificAmplitudeData\FezF2Ai148_202012092020121020201211_FreqBand-1-1.4Hz_freqAmpData.mat');
fezData = fezData.data;
AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.
%% Sample dorsal map and mask path
dmName = ['20210126_PlexinD1Ai148_c8m2_spont_dorsalMap.mat'];
fpath = 'G:\Hemanth_CSHL\WideField\Data_Corrected\20210126_PlexinD1Ai148_c8m2_spont';
load(fullfile(fpath,dmName));
dmMap = dorsalMaps.edgeOutlineSplit;
redRat = plexData.redRat;
%% %%%%%%% reshape maps
cnt = length(plexData.sessions);
imSize = size(plexData.freqBandPowAmpNormMap);
fezMaps = reshape(fezData.freqBandPowAmp,[size(fezData.freqBandPowAmpNormMap),size(fezData.freqBandPowAmp,2)]);
plexMaps = reshape(plexData.freqBandPowAmp,[size(plexData.freqBandPowAmpNormMap),size(plexData.freqBandPowAmp,2)]);
%% %%%%%%%%%% Generate average maps Maps %%%%%%%%%
plexMapAvg = nanmean(plexMaps,3);
fezMapAvg = nanmean(fezMaps,3);

plexMapMat = plexData.freqBandPowAmp';
% pledMapMat(plexMapMat==0) = nan;

fezMapMat = fezData.freqBandPowAmp';
% fezMapMat(fezMapMat==0) = nan;

pVal = [];
parfor ii = 1:size(fezMapMat,2);
    sigPlex = plexMapMat(:,ii);
    sigFez = fezMapMat(:,ii);
%     [~,pVal(1,ii)] =ttest2(sigPlex,sigFez);
    [pVal(1,ii)] =ranksum(sigPlex,sigFez); 
end
pValMap = reshape(pVal,imSize(1),imSize(2));
%% %%% calculate the false discovery reate
q_fdr = 0.05; %% set the acceptable false discovery rate
% [fdr_pval] = myFalseDiscoveryThreshold(pVal,q_fdr); %% alternate fdr_bh function
[~,fdr_pval] = fdr_bh(pVal,q_fdr); %% alternate fdr_bh function
disp(['fdr p val : ' num2str(fdr_pval)])
%% %%% extract significant pixels and mean values associated with sig p vals
pValMask = pValMap<fdr_pval;
fezPlexMap = plexMapAvg- fezMapAvg;
fezPlexMapTh = fezPlexMap.*pValMask;
fezPlexMapTh(isnan(fezPlexMap)) = 0;

%% %%%%%%%%%%%% plotting mean power maps maps %%%%%%%%%%%%%%
close all
h(1) = figure; h(1).Position = [419         331        1400         500];
imScl1 = [0 6e-4];

ax(1) = subplot(1,3,1);
imagesc(plexMapAvg, imScl1); colorbar;
axis image
colormap(hot);
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','w');
end
hold off
axis(gca,[24 560 88 536]*redRat)
title(['Average plexin Power map Freq: ' num2str(plexData.freqBand)])

ax(2) = subplot(1,3,2);
imagesc(fezMapAvg, imScl1); colorbar;
axis image
colormap(hot);
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','w');
end
hold off
axis(gca,[24 560 88 536]*redRat)
title(['Average plexin Power map Freq: ' num2str(plexData.freqBand)])


imScl2 = [-4e-4 4e-4];
ax(3) = subplot(1,3,3);
imagesc(fezPlexMapTh,imScl2); colorbar;
axis image
colormap(cmap);
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','k');
end
hold off
axis(gca,[24 560 88 536]*redRat)
title(['Average plexin - fez Power map Freq: ' num2str(plexData.freqBand) '. FDR Correction = 0.05'])

colormap(ax(1),'hot');colormap(ax(2),'hot')

%% %%%%%%%%%%%%% saving the figures %%%%%%%%%%
if AskSaving == 1
    saveFig = input('Do you want to save the current figures : ');
    if saveFig == 1
        %%% saving figures
        savepath = fullfile(['G:\Hemanth_CSHL\WideField\Data_Figures\KetaminePlots\FrequencySpecificAmplitudeMaps\'], ...
            ['freqPowerMaps_meanWithFDRCorr_FezPlex_' num2str(fezData.freqBand(1)) ' - ' num2str(fezData.freqBand(2)) ' Hz.fig']);
        savefig(h,savepath)
        print(h,[savepath(1:end-4) '.svg'],'-dsvg','-painters');
    end
end
