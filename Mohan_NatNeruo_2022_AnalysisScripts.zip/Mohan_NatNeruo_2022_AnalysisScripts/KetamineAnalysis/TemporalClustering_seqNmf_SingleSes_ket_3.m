clear all; close all; clc
%%
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
cmapUse = cmap2; %% which cmap to use to plot
[fname fpath] = uigetfile('*.mat');
AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.
%% %%%%%%%%% get sample dorsal map
load('G:\Hemanth_CSHL\WideField\Data\AllenDorsalMap\allen_map\allenDorsalMap.mat');
%% extract Dff and concatenate
redRatio = 0.50; %%%% how much to shrink the file
rMask = imresize(dorsalMaps.maskScaled,redRatio);
durPerSes = 60; %% Duration of each session to consider for concatenation in seconds
bpFreq = [0.01 5]; %%%%%%% bandpass frequence range
dffVall = [];
tic
close all
disp(['Processing Data from ' fname]);
[dffVout,dffVoutz] = getDff(fpath,fname,redRatio,durPerSes,bpFreq);
dffVsz = size(dffVout);
% dffVall = reshape(normalize(dffVout(:),'range',[0,1]),dffVsz).*rMask;%%% normalizing signal between 0 and 1
dffVall = dffVout;
toc/60
%% %%%%%%%%% making Matrix %%%%%%%%%%
dffVmat = single(reshape(dffVall,dffVsz(1)*dffVsz(2),dffVsz(3)));
dffVmat(find(dffVmat<0)) = 0;
%%
K = 10; %%%%%%%% number of dimensions 
L = 30; %%%%%% number fo frames per dimension
maxIter2 = 100;
lam = 0.01;%%% good values = 0.001
lamH = 0;
lamW = 0;
[W, H, cost,loadings,power] = seqNMF(dffVmat,'K',K,'L',L,'lambda',lam,'maxiter',maxIter2,'lambdaOrthoH', lamH,'lambdaOrthoW',lamW);
% [W, H, cost,loadings,power] = seqNMF_HMedit(dffVmat,'K',K,'L',L,'lambda',lam,'maxiter',maxIter2,'lambdaOrthoH', lamH,'lambdaOrthoW',lamW);
ccH = corr(H');
figure; imagesc(ccH); colormap jet; colorbar
%% %%%%%%%%%%%%% storing NMF data %%%%%%%%%%%
NMFdata.H = H;
NMFdata.W = W;
NMFdata.numDims = K;
NMFdata.dimLength = L;
NMFdata.cost = cost;
NMFdata.loadings = loadings;
NMFdata.power = power;
NMFdata.lambda = lam;
NMFdata.lambdaH = lamH;
NMFdata.lambdaW = lamW;
NMFdata.MaxNumIter = maxIter2;
NMFdata.imReduceRatio = redRatio;
NMFdata.dffVRedSize = dffVsz;
NMFdata.sessions = fname;
NMFdata.date = date;
NMFdata.dorsalMap = dorsalMaps.edgeOutlineSplit;
%%  %%%%%%%%%%%%%%%%%%%%%%%%%%%%% Saving NMF data %%%%%%%%%%%%%%%%%%%%

if AskSaving == 1
    filename = [fname(1:end-4) '_' date '_seqNMFData.mat']
    savepath = fullfile('G:\Hemanth_CSHL\WideField\Data_Analysis\KetamineData\AllenFOVRegistered\seqNMFdata',filename);
    saveData = input('Do you want to save the NMF data : ');
    if saveData == 1
        save(savepath,'NMFdata')
        disp('NMF Data Saved !!')
    end
end
%% %%%%% plotting nmf Maps %%%%%%%%%%%%
indim = 1;    %%%% Enter the dimension to plot
ImScale = [0.2];
close(gcf)
dmMap = dorsalMaps.edgeOutlineSplit;
seqDim = reshape(W(:,indim,:),dffVsz(1),dffVsz(2),L);
PlayDff(seqDim,ImScale,'cmap2')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% %%%%%%%%%%%%%%%%%%% funcitons %%%%%%%%%%%%%%%%%%%%%
function [dffVout,dffVoutZ] = getDff(fpath,fname,redRatio,durPerSes,bpFreq)
Fs = 30;
%% %%%%%%%%%%%%%%% load allen dorasal map coordinates %%%%%
dmName = [fname(1:end-10) 'dorsalMap.mat'];
load(fullfile(fpath,dmName));
tform = dorsalMaps.tform;
%% %%%%%%%% loading FOV mask file %%%%%%%%%
[~,maskFold] = fileparts(fileparts(fpath));
maskPath = fullfile(fileparts(fileparts(fileparts(fpath))),['Data'],maskFold);
fovMask = load(fullfile(maskPath,[fname(1:end-10) 'refMask.mat']));
%% %%%%%%%%%%% extract dffV Signal %%%%%%%%%%%%%%%%%
disp(['Collecting raw signal and building Matrix'])
vfile = fullfile(fpath,fname);
load(vfile);
frameLen = durPerSes*Fs;
dffV = dffV(:,:,1:frameLen);
dffV= imwarp(dffV.*fovMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*dorsalMaps.maskScaled;
dffV = imresize(dffV,redRatio);dffVfilt = single(filter_dffV(dffV,bpFreq));
dffVout = dffVfilt;
dffVoutZ = zscore(dffVfilt,[],3); %%%%%%%%% with z scoreing of signal
end