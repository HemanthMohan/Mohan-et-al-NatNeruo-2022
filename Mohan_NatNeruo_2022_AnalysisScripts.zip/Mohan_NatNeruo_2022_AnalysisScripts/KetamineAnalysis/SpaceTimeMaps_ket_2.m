clear all; close all; clc
%%
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
cmapUse = cmap2; %% which cmap to use to plot
[fname fpath] = uigetfile('*.mat');
AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.

%% %%%%%%%%%%%%%%% load allen dorasal map coordinates %%%%%
dmName = [fname(1:end-10) 'dorsalMap.mat'];
load(fullfile(fpath,dmName));
tform = dorsalMaps.tform;
%% %%%%%%%% loading FOV mask file %%%%%%%%%
[~,maskFold] = fileparts(fileparts(fpath));
maskPath = fullfile(fileparts(fileparts(fileparts(fpath))),['Data'],maskFold);
fovMask = load(fullfile(maskPath,[fname(1:end-10) 'refMask.mat']));
%% %%%%%%%%%%% extract dffV Signal %%%%%%%%%%%%%%%%%
disp(['Collecting raw signal and building Matrix'])
vfile = fullfile(fpath,fname);
load(vfile);
dffV= imwarp(dffV.*fovMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*dorsalMaps.maskScaled;
dffVsize = size(dffV);
%% %%%%%%%%% get the line roi %%%%%%%%
close all
h1 = figure;
h1.Position = [261 86 990 773];
imagesc(imgaussfilt(dffV(:,:,1),2),[-0.06,0.06]); colormap(cmap2);axis image;colorbar
hold on
for p = 1:length(dorsalMaps.edgeOutlineSplit)
    plot( dorsalMaps.edgeOutlineSplit{p}(:, 2),dorsalMaps.edgeOutlineSplit{p}(:, 1),'color','w','LineWidth',0.5);
end
hold off
title('Green: ROI-1  Cyan: ROI-2')
pos1 =[122,164;279,465];
pos2 =[287,147;138,482];
hRoi1 = drawline('Position',[140,146; 279,465],'color','green');
hRoi2 = drawline('Position',[271,101; 140,482],'color','cyan');
lmask1 = createMask(hRoi1);
lmask2 = createMask(hRoi2);
% close(h1)
[lr1,lc1] = find(lmask1==1);
[lr2,lc2] = find(lmask2==1);
if lr1(1)>lr1(end)
    lr1 = flipud(lr1);
    lc1 = flipud(lc1);
end
if lr2(1)>lr2(end)
    lr2 = flipud(lr2);
    lc2 = flipud(lc2);
end

stMap1 = [];
for ii = 1:length(lr1)
    stMap1 = [stMap1;squeeze(dffV(lr1(ii),lc1(ii),:))'];
end

stMap2 = [];
for ii = 1:length(lr2)
    stMap2 = [stMap2;squeeze(dffV(lr2(ii),lc2(ii),:))'];
end

%% %%%%%%%%%%% plot space time plots %%%%%
close
Fs = 30;
tm = linspace(0,dffVsize(3)/Fs,dffVsize(3));
h2 = figure;
h2.Position = [114 289 1524 634];
stScl = 0.06;
ax(1) = subplot(2,1,1);
imagesc(tm,[1:length(lr1)],stMap1,[-stScl,stScl]); colormap(cmap2); colorbar
title('ROI 1 (Green)')

ax(2) = subplot(2,1,2);
imagesc(tm,[1:length(lr2)],stMap2,[-stScl,stScl]); colormap(cmap2); colorbar
title('ROI 2 (Cyan)')
linkaxes(ax,'x')

figure(h2);
axRef = axes('Position',[-0.06 0.4 0.25 0.25]);
imagesc(imgaussfilt(dffV(:,:,1),2),[-0.05,0.05]); colormap(cmap2);axis image;
hold on
for p = 1:length(dorsalMaps.edgeOutlineSplit)
    plot( dorsalMaps.edgeOutlineSplit{p}(:, 2),dorsalMaps.edgeOutlineSplit{p}(:, 1),'color','w','LineWidth',0.5);
end
plot(lc1,lr1,'g','linewidth',1.5)
plot(lc2,lr2,'c','linewidth',1.5)
hold off
%% Saving Figures
if AskSaving == 1
    filename = fname;
    saveFig = input('Do you want to save the current figure : ');
    if saveFig == 1
        savepath1 = fullfile(['G:\Hemanth_CSHL\WideField\Data_Figures\KetaminePlots\SpaceTimeMaps\'],[filename(1:end-4) '_maxFreqMap.fig']);
        savefig(h2,savepath1)
        saveas(h2,[savepath1(1:end-4) '.svg']);
        %%% saving data
        disp('Figures and data are Saved !')
    end
end
%%   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     %%%%%%%%%%%%%%%%%%%%%%%%Functions%%%%%%%%%%%%%%%%%%%%%%%%%%

function[roiData] = getROI(src,evt)
roiData = evt;
end