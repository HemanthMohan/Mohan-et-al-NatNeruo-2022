clear all; close all; clc
%%
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
cmapUse = cmap2; %% which cmap to use to plot
[fname fpath] = uigetfile('*.mat');
AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.
%% %%%%%%%%% get sample dorsal map
load('G:\Hemanth_CSHL\WideField\Data\AllenDorsalMap\allen_map\allenDorsalMap.mat');
dmMap = dorsalMaps.edgeOutlineSplit;
%% %%%%%%%%%%%%%%% enter details to group sessions %%%%%%%%%%%%%
mouseIds = ['c']; %%%% enter the mouse ID to concatenate activity or even a part of it to concatedate across differenct mice
mouseType = ['FezF2'];
sessionType = ['ketAnaes'];
% dateIn = {'20201209'};
dateIn = {'20201209';'20201210';'20201211'};
%%%%%%%%%%%%%%%%%%% get file  name structure %%%%%%%%%%%%
parentFold = fileparts(fileparts(fpath));
foldNames = [];
if length(dateIn)>=1
    for ii = 1:length(dateIn)
        FoldCont = dir(fullfile(fileparts(fileparts(fpath)),[dateIn{ii} '*', mouseType '*', mouseIds '*',sessionType '*']));
        foldNames = [foldNames;{FoldCont.name}'];
    end
else
    FoldCont = dir(fullfile(fileparts(fileparts(fpath)),[dateIn '*', mouseType '*', mouseIds '*',sessionType '*']));
    foldNames = [foldNames;{FoldCont.name}];
end
%% extract Dff and concatenate
redRatio = 0.5; %%%% how much to shrink the file
freqBand = [0.6 0.9];
tic
for kk = 1:length(foldNames)
    close all
    disp(['Processing Data from ' foldNames{kk}]);
    fpath1 = [fullfile(parentFold,foldNames{kk}) '\'];
    fname1 = [foldNames{kk} '_dffV_1.mat'];
    [freqBandPowAmp(:,kk),dffVRedSz] = getPowAmp(fpath1,fname1,redRatio,freqBand);
end
toc/60
%%
freqBandPowAmpMean = mean(freqBandPowAmp,2);
freqBandPowAmpNormMap = reshape(normalize(freqBandPowAmpMean,'range',[0,1]),dffVRedSz(1),dffVRedSz(2));
h1 = figure;
imagesc(freqBandPowAmpNormMap,[0,1]); axis image; colormap jet;colorbar
    hold on
    for p = 1:length(dmMap)
        plot( dmMap{p}(:, 2)*redRatio,dmMap{p}(:, 1)*redRatio,'color','w','LineWidth',0.5);
    end
title(['Frequency Band Amplitude : ' num2str(freqBand(1)) '-' num2str(freqBand(2))]) 
%% %%%%%%%%%% load data %%%%%%%%%
data.freqBandPowAmp = freqBandPowAmp;
data.freqBandPowAmpNormMap = freqBandPowAmpNormMap;
data.freqBand = freqBand;
data.sessions = foldNames;
data.redRat = redRatio;
data.date = date;
data.mouseType = mouseType;
%%  %%%%%%%%%%%%%%%%%%%%%%%%%%%%% Saving data and figure images %%%%%%%%%%%%%%%%%%%%

if contains(lower(mouseType),'fezf')
    CellType = 'FezF2Ai148'; %%%%% options 'FezF2Ai148'; 'PlexinD1Ai148'; 'Tle4Ai148'; 'CBAAi93h'
elseif contains(lower(mouseType),'plexin')
    CellType = 'PlexinD1Ai148';
end

if AskSaving == 1
    filename = CellType;
    saveFig = input('Do you want to save the current figure : ');
    if saveFig == 1
        savepath1 = fullfile(['G:\Hemanth_CSHL\WideField\Data_Figures\KetaminePlots\FrequencySpecificAmplitudeMaps\'],[filename '_' cell2mat(dateIn') '_FreqBand-' num2str(freqBand(1)) '-' num2str(freqBand(2)) 'Hz.fig']);
        savefig(h1,savepath1)
        saveas(h1,[savepath1(1:end-4) '.svg']);
        
         %%%%% saving data
        datapath = fullfile(['G:\Hemanth_CSHL\WideField\Data_Analysis\KetamineData\AllenFOVRegistered\FrequencySpecificAmplitudeData'],[filename '_' cell2mat(dateIn') '_FreqBand-' num2str(freqBand(1)) '-' num2str(freqBand(2)) 'Hz_freqAmpData.mat']);
        save(datapath,'data', '-v7.3')
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% %%%%%%%%%%%%%%%%%%% funcitons %%%%%%%%%%%%%%%%%%%%%
function [freqBandPowAmp,dffVRedSz] = getPowAmp(fpath,fname,redRatio,freqBand)
%% %%%%%%%%%%%%%%% load allen dorasal map coordinates %%%%%
dmName = [fname(1:end-10) 'dorsalMap.mat'];
load(fullfile(fpath,dmName));
tform = dorsalMaps.tform;
%% %%%%%%%% loading FOV mask file %%%%%%%%%
[~,maskFold] = fileparts(fileparts(fpath));
maskPath = fullfile(fileparts(fileparts(fileparts(fpath))),['Data'],maskFold);
fovMask = load(fullfile(maskPath,[fname(1:end-10) 'refMask.mat']));
%% %%%%%%%%%%% extract dffV Signal %%%%%%%%%%%%%%%%%
disp(['Collecting raw signal and building Matrix'])
vfile = fullfile(fpath,fname);
load(vfile);
dffV= imwarp(dffV.*fovMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*dorsalMaps.maskScaled;
dffVsize = size(dffV);
%% %%%%%%%%%%%%%% Reducing the size of the images if Required %%%%%%%%%%%%%%
reduceRatio = redRatio; %%%%% insert 1 for no reduction. Def 0.5
dffVReduced = imresize(dffV,reduceRatio);
dffVRedSz = size(dffVReduced);
dffVRedMat = reshape(dffVReduced,dffVRedSz(1)*dffVRedSz(2),dffVRedSz(3));
%% %%%%%%%%%%% power spectrum decomposition
L = dffVsize(3);
Fs = 30;
[pwS,f] = pmtm(dffVRedMat',[],L,Fs); %%%% multi taper estimate
% pwSNorm = normalize(pwS,1,'range',[0,1]);
% pwSNorm = pwS./sum(pwS); %% relative power
%% %% Freq Band specific power amplitude
freqBand = freqBand;
freqBandPowAmp = mean(pwS(find(f>freqBand(1) & f<freqBand(2)),:))';
end