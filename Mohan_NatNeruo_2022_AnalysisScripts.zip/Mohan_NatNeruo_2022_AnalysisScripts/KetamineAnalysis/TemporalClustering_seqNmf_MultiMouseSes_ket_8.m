clear all; close all; clc
%%
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
cmapUse = cmap2; %% which cmap to use to plot
[fname fpath] = uigetfile('*.mat');
AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.
%% %%%%%%%%% get sample dorsal map
load('G:\Hemanth_CSHL\WideField\Data\AllenDorsalMap\allen_map\allenDorsalMap.mat');
%% %%%%%%%%%%%%%%% enter details to group sessions %%%%%%%%%%%%%
mouseIds = ['c']; %%%% enter the mouse ID to concatenate activity or even a part of it to concatedate across differenct mice
mouseType = ['FezF2'];
sessionType = ['ketAnaes'];
% dateIn = {'20201210'};
dateIn = {'20201209';'20201210';'20201211'};
%%%%%%%%%%%%%%%%%%% get file  name structure %%%%%%%%%%%%
parentFold = fileparts(fileparts(fpath));
foldNames = [];
if length(dateIn)>=1
    for ii = 1:length(dateIn)
        FoldCont = dir(fullfile(fileparts(fileparts(fpath)),[dateIn{ii} '*', mouseType '*', mouseIds '*',sessionType '*']));
        foldNames = [foldNames;{FoldCont.name}'];
    end
else
    FoldCont = dir(fullfile(fileparts(fileparts(fpath)),[dateIn '*', mouseType '*', mouseIds '*',sessionType '*']));
    foldNames = [foldNames;{FoldCont.name}];
end
%% extract Dff and concatenate
redRatio = 0.25; %%%% how much to shrink the file
rMask = imresize(dorsalMaps.maskScaled,redRatio);
durPerSes = 20; %% Duration of each session to consider for concatenation in seconds
bpFreq = [0.01 5]; %%%%%%% bandpass frequence range
dffVall = [];
tic
parfor kk = 1:length(foldNames)
    close all
    disp(['Processing Data from ' foldNames{kk}]);
    fpath1 = [fullfile(parentFold,foldNames{kk}) '\'];
    fname1 = [foldNames{kk} '_dffV_1.mat'];
    dffVout = getDff(fpath1,fname1,redRatio,durPerSes,bpFreq);
    dffVoutSz = size(dffVout);
    dffVall(:,:,:,kk) = dffVout;% Without zscoring the signal
%     dffVall(:,:,:,kk) = reshape(zscore(dffVout(:)),dffVoutSz); %% zscoring the signal
%     dffVall(:,:,:,kk) = reshape(normalize(dffVout(:),'range',[0,1]),dffVoutSz); %% normalizing the signal between 0 and 1
%     dffVall = cat(3,dffVall,dffVout);
end
dffVall = dffVall.*rMask ;
toc/60
%% %%%%%%%%% making Matrix %%%%%%%%%%
dffVsz = size(dffVall);
dffVmat = single(reshape(dffVall,dffVsz(1)*dffVsz(2),dffVsz(3)*dffVsz(4)));
dffVmat(find(dffVmat<0)) = 0;
%%
K = 10; %%%%%%%% number of dimensions 
L = 30; %%%%%% number fo frames per dimension
maxIter2 = 100;
lam = 0.01;%%% good values = 0.0005
lamOrthoH = 0;
lamOrthoW = 0;
lamH = 0;
lamW = 0;
[W, H, cost,loadings,power] = seqNMF(dffVmat,'K',K,'L',L,'lambda',lam,'maxiter',maxIter2, ...
    'lambdaOrthoH', lamOrthoH,'lambdaOrthoW',lamOrthoW,'lambdaL1W',lamW,'lambdaL1H',lamH,'useWupdate',0);
% [W, H, cost,loadings,power] = seqNMF_HMedit(dffVmat,'K',K,'L',L,'lambda',lam,'maxiter',maxIter2,'lambdaOrthoH', lamH,'lambdaOrthoW',lamW);
% ccH = corr(H');
%%
ccH = corr(H');
figure; subplot(2,1,1); imagesc(ccH,[0,1]); colormap jet; colorbar; axis image
subplot(2,1,2); plot(H')
%% %%%%%%%%%%%%% storing NMF data %%%%%%%%%%%
NMFdata.H = H;
NMFdata.W = W;
NMFdata.numDims = K;
NMFdata.dimLength = L;
NMFdata.cost = cost;
NMFdata.loadings = loadings;
NMFdata.power = power;
NMFdata.lambda = lam;
NMFdata.lambdaH = lamOrthoH;
NMFdata.lambdaW = lamW;
NMFdata.MaxNumIter = maxIter2;
NMFdata.imReduceRatio = redRatio;
NMFdata.dffVRedSize = dffVsz;
NMFdata.sessions = foldNames;
NMFdata.date = date;
NMFdata.dorsalMap = dorsalMaps.edgeOutlineSplit;
%%  %%%%%%%%%%%%%%%%%%%%%%%%%%%%% Saving NMF data %%%%%%%%%%%%%%%%%%%%
if contains(lower(mouseType),'fezf')
    CellType = 'FezF2Ai148'; %%%%% options 'FezF2Ai148'; 'PlexinD1Ai148'; 'Tle4Ai148'; 'CBAAi93h'
elseif contains(lower(mouseType),'plexin')
    CellType = 'PlexinD1Ai148';
end

if AskSaving == 1
    filename = [CellType '_' date '_seqNMFData.mat']
    savepath = fullfile('G:\Hemanth_CSHL\WideField\Data_Analysis\KetamineData\AllenFOVRegistered\seqNMFdata',filename);
    saveData = input('Do you want to save the NMF data : ');
    if saveData == 1
        save(savepath,'NMFdata')
        disp('NMF Data Saved !!')
    end
end
%% %%%%% plotting nmf Maps %%%%%%%%%%%%
indim = 1;    %%%% Enter the dimension to plot
ImScale = [0.2];
close(gcf)
dmMap = dorsalMaps.edgeOutlineSplit;
seqDim = reshape(W(:,indim,:),dffVsz(1),dffVsz(2),L);
PlayDff(seqDim,ImScale,'cmap2')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% %%%%%%%%%%%%%%%%%%% funcitons %%%%%%%%%%%%%%%%%%%%%
function [dffVout] = getDff(fpath,fname,redRatio,durPerSes,bpFreq)
Fs = 30;
%% %%%%%%%%%%%%%%% load allen dorasal map coordinates %%%%%
dmName = [fname(1:end-10) 'dorsalMap.mat'];
load(fullfile(fpath,dmName));
tform = dorsalMaps.tform;
%% %%%%%%%% loading FOV mask file %%%%%%%%%
[~,maskFold] = fileparts(fileparts(fpath));
maskPath = fullfile(fileparts(fileparts(fileparts(fpath))),['Data'],maskFold);
fovMask = load(fullfile(maskPath,[fname(1:end-10) 'refMask.mat']));
%% %%%%%%%%%%% extract dffV Signal %%%%%%%%%%%%%%%%%
disp(['Collecting raw signal and building Matrix'])
vfile = fullfile(fpath,fname);
load(vfile);
frameLen = durPerSes*Fs;
dffV = dffV(:,:,1:frameLen);
dffV= imwarp(dffV.*fovMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*dorsalMaps.maskScaled;
dffV = imresize(dffV,redRatio);
dffVfilt = single(filter_dffV(dffV,bpFreq));
dffVout = dffVfilt;
end