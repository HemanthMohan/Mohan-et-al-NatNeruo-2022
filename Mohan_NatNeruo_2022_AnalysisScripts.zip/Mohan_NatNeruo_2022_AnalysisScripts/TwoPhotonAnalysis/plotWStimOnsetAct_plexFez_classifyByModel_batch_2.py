# %clear -f
import sys
sys.path.append(r'G:\Hemanth_CSHL\MyScripts\PythonScripts\CalciumImaging\WhiskerStimulation\supportLibrary')
import os as os
from os.path import split
import numpy as np
import tkinter as tk
from tkinter import filedialog
import matplotlib.pyplot as plt
plt.rcParams['svg.fonttype'] = 'none'
from scipy.signal import convolve
from scipy.stats import zscore
import time
from getStimActivityTr import getStimActivityTrace,movmean
import statsmodels.api as sm
#%% load data
def getWhiskerAct(dataPath):
    # dataPath = filedialog.askopenfilename(initialdir = os.getcwd(),filetypes=[("choose any", '*.npy')])
    [Fcorr,dff,dffSm,stat,dffPerTrialPerCell,
            dffAvgPerCell,avgDffActPerTrial,sTm]= getStimActivityTrace(dataPath)
    #% % generate zscore based on baseline activity from averate dff act per cell
    ## zscore is computed based on baseline 2 seconds before stimulus onset
    dffAvgPerCellZscr = [(i - np.mean(i[30:90]))/np.std(i[30:90]) for i in dffAvgPerCell]
    
    #% % use linear modelling to identify responsive neuron and seperate between active, inhibited and non responsive class
    Fs = 30.9
    stimStart = 3
    stimEnd = 4
    stimIdx = (np.arange(stimStart,stimEnd,1/Fs)*Fs).astype(int)
    x = np.zeros_like(dffPerTrialPerCell[0])
    x[:,stimIdx] = 1
    X = x.reshape(-1,1)
    X = sm.add_constant(X)
    betaVal = []
    pVal = []
    for i in range(0,len(dffPerTrialPerCell)):
        y = dffPerTrialPerCell[i].reshape(-1,1)
        model = sm.OLS(y,X)
        results = model.fit()
        betaVal.append(results.params)
        pVal.append(results.pvalues)

    betaVal = np.array(betaVal)
    pVal = np.array(pVal)

    pValTh = 0.05 ## threshold to identify responsive cell.
    cellCnt = dff.shape[0]
    actCells = []
    inhCells = []
    nonResCells = []
    for i in range(0,cellCnt):
        if (pVal[i,1]<pValTh and betaVal[i,1]>0):
            actCells.append(i)
        elif (pVal[i,1]<pValTh and betaVal[i,1]<0):
            inhCells.append(i)
        else:
            nonResCells.append(i)

    actCells = np.array(actCells)
    inhCells = np.array(inhCells)
    nonResCells = np.array(nonResCells)
    #% % seperate activity data into active, inhibited and non active cells
    ## active cells activity
    dffAvgPerCell_actCells = list(np.array(dffAvgPerCell)[actCells])
    dffAvgPerCellMean_actCells = np.array(dffAvgPerCell_actCells).mean(axis=0)
    
    dffAvgPerCellZscr_actCells = list(np.array(dffAvgPerCellZscr)[actCells])
    dffAvgPerCellZscrMean_actCells = np.array(dffAvgPerCellZscr_actCells).mean(axis=0)
    
    dffAvgPerTrial_actCells = np.mean(np.array(dffPerTrialPerCell)[actCells],axis=0)
    dffAvgPerTrialMean_actCells = np.mean(dffAvgPerTrial_actCells,axis=0)
    
    tempActZ=[] ## extract zscored activity per cell across trials
    for j in range(0,len(actCells)):
        tempAct = np.array(dffPerTrialPerCell)[actCells[j]]
        tempActZ.append((tempAct - tempAct[:,30:90].mean())/tempAct[:,30:90].std())
    dffAvgPerTrialZscr_actCells = np.mean(np.array(tempActZ),axis=0)
    dffAvgPerTrialZscrMean_actCells = np.mean(dffAvgPerTrialZscr_actCells,axis=0)
    
    
    ## inhibited cells activity
    dffAvgPerCell_inhCells = list(np.array(dffAvgPerCell)[inhCells])
    dffAvgPerCellMean_inhCells = np.array(dffAvgPerCell_inhCells).mean(axis=0)
    
    dffAvgPerCellZscr_inhCells = list(np.array(dffAvgPerCellZscr)[inhCells])
    dffAvgPerCellZscrMean_inhCells = np.array(dffAvgPerCellZscr_inhCells).mean(axis=0)
    
    dffAvgPerTrial_inhCells = np.mean(np.array(dffPerTrialPerCell)[inhCells],axis=0)
    dffAvgPerTrialMean_inhCells = np.mean(dffAvgPerTrial_inhCells,axis=0)
    
    tempActZ=[]
    for j in range(0,len(inhCells)):
        tempAct = np.array(dffPerTrialPerCell)[inhCells[j]]
        tempActZ.append((tempAct - tempAct[:,30:90].mean())/tempAct[:,30:90].std())
    dffAvgPerTrialZscr_inhCells = np.mean(np.array(tempActZ),axis=0)
    dffAvgPerTrialZscrMean_inhCells = np.mean(dffAvgPerTrialZscr_inhCells,axis=0)
    
    ## non responsive cells activity
    dffAvgPerCell_nonResCells = list(np.array(dffAvgPerCell)[nonResCells])
    dffAvgPerCellMean_nonResCells = np.array(dffAvgPerCell_nonResCells).mean(axis=0)
    
    dffAvgPerCellZscr_nonResCells = list(np.array(dffAvgPerCellZscr)[nonResCells])
    dffAvgPerCellZscrMean_nonResCells = np.array(dffAvgPerCellZscr_nonResCells).mean(axis=0)
    
    dffAvgPerTrial_nonResCells = np.mean(np.array(dffPerTrialPerCell)[nonResCells],axis=0)
    dffAvgPerTrialMean_nonResCells = np.mean(dffAvgPerTrial_nonResCells,axis=0)
    
    tempActZ=[]
    for j in range(0,len(nonResCells)):
        tempAct = np.array(dffPerTrialPerCell)[nonResCells[j]]
        tempActZ.append((tempAct - tempAct[:,30:90].mean())/tempAct[:,30:90].std())
    dffAvgPerTrialZscr_nonResCells = np.mean(np.array(tempActZ),axis=0)
    dffAvgPerTrialZscrMean_nonResCells = np.mean(dffAvgPerTrialZscr_nonResCells,axis=0)
    
    cellCount = {"active": len(actCells), "inhibited": len(inhCells), "nonResponsive": len(nonResCells)}
    return (dffAvgPerCell_actCells,dffAvgPerCell_inhCells,dffAvgPerCell_nonResCells,
            dffAvgPerCellZscr_actCells, dffAvgPerCellZscr_inhCells, dffAvgPerCellZscr_nonResCells,cellCount )

#%% get paths and extract data to plot
f = {}
f["fez"] = open(r"G:\Hemanth_CSHL\Calcium Imaging\Data\Fezf2\pathsToPlot.txt", "r")
f["plex"] = open(r"G:\Hemanth_CSHL\Calcium Imaging\Data\PlexinD1\pathsToPlot.txt", "r")
allPaths = {}
allPaths["fez"] = f["fez"].readlines()
allPaths["plex"] = f["plex"].readlines()

dffPerCell_act = {"fez":[], "plex":[]}
dffPerCell_inh = {"fez":[], "plex":[]}
dffPerCell_nonRes = {"fez":[], "plex":[]}
dffPerCellZ_act = {"fez":[], "plex":[]}
dffPerCellZ_inh = {"fez":[], "plex":[]}
dffPerCellZ_nonRes = {"fez":[], "plex":[]}
cellCount = {"fez":[], "plex": []}

for i in range(0,len(allPaths["fez"])):
    print(i)
    dataPath = os.path.join(allPaths["fez"][i][:-1],'suite2p\plane0\F.npy')
    [dffAvgPerCell_actCells,dffAvgPerCell_inhCells,dffAvgPerTrial_nonResCells,
     dffAvgPerCellZscr_actCells, dffAvgPerCellZscr_inhCells, dffAvgPerTrialZscr_nonResCells, cellNumbers] = getWhiskerAct(dataPath)
    dffPerCell_act["fez"].append(np.array(dffAvgPerCell_actCells))
    dffPerCell_inh["fez"].append(np.array(dffAvgPerCell_inhCells))
    dffPerCell_nonRes["fez"].append(np.array(dffAvgPerTrial_nonResCells))
    dffPerCellZ_act["fez"].append(np.array(dffAvgPerCellZscr_actCells))
    dffPerCellZ_inh["fez"].append(np.array(dffAvgPerCellZscr_inhCells))
    dffPerCellZ_nonRes["fez"].append(np.array(dffAvgPerTrialZscr_nonResCells))
    cellCount["fez"].append(cellNumbers)
    


for i in range(0,len(allPaths["plex"])):
    print(i)
    dataPath = os.path.join(allPaths["plex"][i][:-1],'suite2p\plane0\F.npy')
    [dffAvgPerCell_actCells,dffAvgPerCell_inhCells,dffAvgPerTrial_nonResCells,
     dffAvgPerCellZscr_actCells, dffAvgPerCellZscr_inhCells, dffAvgPerTrialZscr_nonResCells,cellNumbers] = getWhiskerAct(dataPath)
    dffPerCell_act["plex"].append(np.array(dffAvgPerCell_actCells))
    dffPerCell_inh["plex"].append(np.array(dffAvgPerCell_inhCells))
    dffPerCell_nonRes["plex"].append(np.array(dffAvgPerTrial_nonResCells))
    dffPerCellZ_act["plex"].append(np.array(dffAvgPerCellZscr_actCells))
    dffPerCellZ_inh["plex"].append(np.array(dffAvgPerCellZscr_inhCells))
    dffPerCellZ_nonRes["plex"].append(np.array(dffAvgPerTrialZscr_nonResCells))
    cellCount["plex"].append(cellNumbers)
#%% make activit matrix for plotting each subset
wstim_act = {"fez": np.concatenate(dffPerCell_act["fez"],axis=0)}
wstim_inh = {"fez": np.concatenate(dffPerCell_inh["fez"],axis=0)}
wstim_nonRes = {"fez": np.concatenate(dffPerCell_nonRes["fez"],axis=0)}

wstimZ_act = {"fez": np.concatenate(dffPerCellZ_act["fez"],axis=0)}
wstimZ_inh = {"fez": np.concatenate(dffPerCellZ_inh["fez"],axis=0)}
wstimZ_nonRes = {"fez": np.concatenate(dffPerCellZ_nonRes["fez"],axis=0)}

wstimMean_act = {"fez": np.mean(wstim_act["fez"],axis=0)}
wstimSem_act = {"fez": np.std(wstim_act["fez"],axis=0)/np.sqrt(wstim_act["fez"].shape[0])}

wstimZMean_act = {"fez": np.mean(wstimZ_act["fez"],axis=0)}
wstimZSem_act = {"fez": np.std(wstimZ_act["fez"],axis=0)/np.sqrt(wstimZ_act["fez"].shape[0])}

wstimMean_inh = {"fez": np.mean(wstim_inh["fez"], axis=0)}
wstimSem_inh = {"fez": np.std(wstim_inh["fez"],axis=0)/np.sqrt(wstim_inh["fez"].shape[0])}

wstimZMean_inh = {"fez": np.mean(wstimZ_inh["fez"], axis=0)}
wstimZSem_inh = {"fez": np.std(wstimZ_inh["fez"],axis=0)/np.sqrt(wstimZ_inh["fez"].shape[0])}

wstimMean_nonRes = {"fez": np.mean(wstim_nonRes["fez"], axis=0)}
wstimSem_nonRes = {"fez": np.std(wstim_nonRes["fez"],axis=0)/np.sqrt(wstim_nonRes["fez"].shape[0])}

wstimZMean_nonRes = {"fez": np.mean(wstimZ_nonRes["fez"], axis=0)}
wstimZSem_nonRes = {"fez": np.std(wstimZ_nonRes["fez"],axis=0)/np.sqrt(wstimZ_nonRes["fez"].shape[0])}

wstim_act["plex"] =  np.concatenate(dffPerCell_act["plex"],axis=0)
wstim_inh["plex"] =  np.concatenate(dffPerCell_inh["plex"],axis=0)
wstim_nonRes["plex"] =  np.concatenate(dffPerCell_nonRes["plex"],axis=0)

wstimZ_act["plex"] = np.concatenate(dffPerCellZ_act["plex"],axis=0)
wstimZ_inh["plex"] =  np.concatenate(dffPerCellZ_inh["plex"],axis=0)
wstimZ_nonRes["plex"] = np.concatenate(dffPerCellZ_nonRes["plex"],axis=0)

wstimMean_act["plex"] =  np.mean(wstim_act["plex"],axis=0)
wstimSem_act["plex"] =  np.std(wstim_act["plex"],axis=0)/np.sqrt(wstim_act["plex"].shape[0])

wstimZMean_act["plex"] =  np.mean(wstimZ_act["plex"],axis=0)
wstimZSem_act["plex"] =  np.std(wstimZ_act["plex"],axis=0)/np.sqrt(wstimZ_act["plex"].shape[0])

wstimMean_inh["plex"] =  np.mean(wstim_inh["plex"], axis=0)
wstimSem_inh["plex"] =  np.std(wstim_inh["plex"],axis=0)/np.sqrt(wstim_inh["plex"].shape[0])
    
wstimZMean_inh["plex"] =  np.mean(wstimZ_inh["plex"], axis=0)
wstimZSem_inh["plex"] =  np.std(wstimZ_inh["plex"],axis=0)/np.sqrt(wstimZ_inh["plex"].shape[0])

wstimMean_nonRes["plex"] =  np.mean(wstim_nonRes["plex"], axis=0)
wstimSem_nonRes["plex"] =  np.std(wstim_nonRes["plex"],axis=0)/np.sqrt(wstim_nonRes["plex"].shape[0])
    
wstimZMean_nonRes["plex"] = np.mean(wstimZ_nonRes["plex"], axis=0)
wstimZSem_nonRes["plex"] =  np.std(wstimZ_inh["plex"],axis=0)/np.sqrt(wstimZ_inh["plex"].shape[0])
#%% make grand mean across all condition
fezActFull = np.vstack((wstim_act["fez"],wstim_inh["fez"],wstim_nonRes["fez"]))
plexActFull = np.vstack((wstim_act["plex"],wstim_inh["plex"],wstim_nonRes["plex"]))

fezActZFull = np.vstack((wstimZ_act["fez"],wstimZ_inh["fez"],wstimZ_nonRes["fez"]))
plexActZFull = np.vstack((wstimZ_act["plex"],wstimZ_inh["plex"],wstimZ_nonRes["plex"]))

grandAvg = {"dff": {"fez": fezActFull.mean(axis=0)}}
grandSem = {"dff": {"fez": fezActFull.std(axis=0)/np.sqrt(fezActFull.shape[0])}}

grandAvg["dff"]["plex"] = np.vstack((wstim_act["plex"],wstim_inh["plex"],wstim_nonRes["plex"])).mean(axis=0)
grandSem["dff"]["plex"] = fezActFull.std(axis=0)/np.sqrt(plexActFull.shape[0])


grandAvg["zscr"] = {"fez": fezActZFull.mean(axis=0)}
grandSem["zscr"] = {"fez": fezActZFull.std(axis=0)/np.sqrt(fezActFull.shape[0])}

grandAvg["zscr"]["plex"] = plexActZFull.mean(axis=0)
grandSem["zscr"]["plex"] = plexActZFull.std(axis=0)/np.sqrt(plexActFull.shape[0])
#%% %%% cell count distributions
plexProp = np.zeros( [len(cellCount["plex"]),3]   )
for i in range(0,len(cellCount["plex"])):
    plexProp[i,0] = cellCount["plex"][i]["active"]/np.sum([cellCount["plex"][i]["active"],cellCount["plex"][i]["inhibited"],
                                                 cellCount["plex"][i]["nonResponsive"]])
    plexProp[i,1] = cellCount["plex"][i]["inhibited"]/np.sum([cellCount["plex"][i]["active"],cellCount["plex"][i]["inhibited"],
                                                 cellCount["plex"][i]["nonResponsive"]])
    plexProp[i,2] = cellCount["plex"][i]["nonResponsive"]/np.sum([cellCount["plex"][i]["active"],cellCount["plex"][i]["inhibited"],
                                                 cellCount["plex"][i]["nonResponsive"]])
    
fezProp = np.zeros( [len(cellCount["fez"]),3]   )
for i in range(0,len(cellCount["fez"])):
    fezProp[i,0] = cellCount["fez"][i]["active"]/np.sum([cellCount["fez"][i]["active"],cellCount["fez"][i]["inhibited"],
                                                 cellCount["fez"][i]["nonResponsive"]])
    fezProp[i,1] = cellCount["fez"][i]["inhibited"]/np.sum([cellCount["fez"][i]["active"],cellCount["fez"][i]["inhibited"],
                                                 cellCount["fez"][i]["nonResponsive"]])
    fezProp[i,2] = cellCount["fez"][i]["nonResponsive"]/np.sum([cellCount["fez"][i]["active"],cellCount["fez"][i]["inhibited"],
                                                 cellCount["fez"][i]["nonResponsive"]])

plexPropGrand = np.zeros([1,3])
plexPropGrand[0,0] = wstim_act["plex"].shape[0]/(wstim_act["plex"].shape[0] + wstim_inh["plex"].shape[0] + wstim_nonRes["plex"].shape[0])
plexPropGrand[0,1] = wstim_inh["plex"].shape[0]/(wstim_act["plex"].shape[0] + wstim_inh["plex"].shape[0] + wstim_nonRes["plex"].shape[0])
plexPropGrand[0,2] = wstim_nonRes["plex"].shape[0]/(wstim_act["plex"].shape[0] + wstim_inh["plex"].shape[0] + wstim_nonRes["plex"].shape[0])

fezPropGrand = np.zeros([1,3])
fezPropGrand[0,0] = wstim_act["fez"].shape[0]/(wstim_act["fez"].shape[0] + wstim_inh["fez"].shape[0] + wstim_nonRes["fez"].shape[0])
fezPropGrand[0,1] = wstim_inh["fez"].shape[0]/(wstim_act["fez"].shape[0] + wstim_inh["fez"].shape[0] + wstim_nonRes["fez"].shape[0])
fezPropGrand[0,2] = wstim_nonRes["fez"].shape[0]/(wstim_act["fez"].shape[0] + wstim_inh["fez"].shape[0] + wstim_nonRes["fez"].shape[0])

#%% plot graphs
Fs = 30.9
sTm = np.arange(0,216/Fs,1/Fs)
plt.close('all')
stimSt = 2.8 ## approximage stimulation staart time
## fezf plot

fig_fez, ax = plt.subplots(4,3,figsize=(11,8), constrained_layout=True)
im = ax[0,0].imshow(wstim_act["fez"],vmin=-0.2,vmax=0.3,aspect='auto',extent=[sTm[0],sTm[-1],0-0.5,wstim_act["fez"].shape[0]-0.5],origin='lower')
ax[0,0].set_xlim(1,6)
ax[0,0].plot([3,3],[0-0.5, wstim_act["fez"].shape[0]-0.5],'--',c='w')
fig_fez.colorbar(im,ax=ax[0,0],shrink=0.6)

ax[1,0].plot(sTm,wstimMean_act["fez"])
ax[1,0].set_xlim(1,6)
ax[1,0].set_ylim(-0.1,0.15)
ax[1,0].plot([stimSt,stimSt],[-0.1,0.15],'--',c='k')


im = ax[2,0].imshow(wstimZ_act["fez"],vmin=-1,vmax=3,aspect='auto',extent=[sTm[0],sTm[-1],0-0.5,wstim_act["fez"].shape[0]-0.5],origin='lower')
ax[2,0].set_xlim(1,6)
ax[2,0].plot([stimSt,stimSt],[0-0.5, wstim_act["fez"].shape[0]-0.5],'--',c='w')
fig_fez.colorbar(im,ax=ax[2,0],shrink=0.6)

ax[3,0].plot(sTm,wstimZMean_act["fez"])
ax[3,0].set_xlim(1,6)
ax[3,0].set_ylim(-1,4)
ax[3,0].plot([stimSt,stimSt],[-1,4],'--',c='k')


im = ax[0,1].imshow(wstim_inh["fez"],vmin=-0.2,vmax=0.3,aspect='auto',extent=[sTm[0],sTm[-1],0-0.5,wstim_inh["fez"].shape[0]-0.5],origin='lower')
ax[0,1].set_xlim(1,6)
ax[0,1].plot([stimSt,stimSt],[0-0.5, wstim_inh["fez"].shape[0]-0.5],'--',c='w')
fig_fez.colorbar(im,ax=ax[0,1],shrink=0.6)

ax[1,1].plot(sTm,wstimMean_inh["fez"])
ax[1,1].set_xlim(1,6)
ax[1,1].set_ylim(-0.1,0.05)
ax[1,1].plot([stimSt,stimSt],[-0.1,0.05],'--',c='k')


im = ax[2,1].imshow(wstimZ_inh["fez"],vmin=-1,vmax=3,aspect='auto',extent=[sTm[0],sTm[-1],0-0.5,wstim_inh["fez"].shape[0]-0.5],origin='lower')
ax[2,1].set_xlim(1,6)
ax[2,1].plot([stimSt,stimSt],[0-0.5, wstim_inh["fez"].shape[0]-0.5],'--',c='w')
fig_fez.colorbar(im,ax=ax[2,1],shrink=0.6)


ax[3,1].plot(sTm,wstimZMean_inh["fez"])
ax[3,1].set_xlim(1,6)
ax[3,1].set_ylim(-3,2)
ax[3,1].plot([stimSt,stimSt],[-3,2],'--',c='k')

im = ax[0,2].imshow(wstim_nonRes["fez"],vmin=-0.2,vmax=0.3,aspect='auto',extent=[sTm[0],sTm[-1],0-0.5,wstim_nonRes["fez"].shape[0]-0.5],origin='lower')
ax[0,2].set_xlim(1,6)
ax[0,2].plot([stimSt,stimSt],[0-0.5, wstim_nonRes["fez"].shape[0]-0.5],'--',c='w')
fig_fez.colorbar(im,ax=ax[0,2],shrink=0.6)

ax[1,2].plot(sTm,wstimMean_nonRes["fez"])
ax[1,2].set_xlim(1,6)
ax[1,2].set_ylim(-0.05,0.05)
ax[1,2].plot([stimSt,stimSt],[-0.05,0.05],'--',c='k')


im = ax[2,2].imshow(wstimZ_nonRes["fez"],vmin=-1,vmax=3,aspect='auto',extent=[sTm[0],sTm[-1],0-0.5,wstim_nonRes["fez"].shape[0]-0.5],origin='lower')
ax[2,2].set_xlim(1,6)
ax[2,2].plot([stimSt,stimSt],[0-0.5, wstim_nonRes["fez"].shape[0]-0.5],'--',c='w')
fig_fez.colorbar(im,ax=ax[2,2],shrink=0.6)


ax[3,2].plot(sTm,wstimZMean_nonRes["fez"])
ax[3,2].set_xlim(1,6)
ax[3,2].set_ylim(-1,1)
ax[3,2].plot([stimSt,stimSt],[-1,1],'--',c='k')

plt.suptitle('FezF2')
ax[0,0].set_title('active'); ax[0,1].set_title('inhibited'); ax[0,2].set_title('non responsive')




## plexin plot
fig_plex, ax = plt.subplots(4,3,figsize=(11,8), constrained_layout=True)
im = ax[0,0].imshow(wstim_act["plex"],vmin=-0.2,vmax=0.3,aspect='auto',extent=[sTm[0],sTm[-1],0-0.5,wstim_act["plex"].shape[0]-0.5],origin='lower')
ax[0,0].set_xlim(1,6)
ax[0,0].plot([stimSt,stimSt],[0-0.5, wstim_act["plex"].shape[0]-0.5],'--',c='w')
fig_plex.colorbar(im,ax=ax[0,0],shrink=0.6)

ax[1,0].plot(sTm,wstimMean_act["plex"])
ax[1,0].set_xlim(1,6)
ax[1,0].set_ylim(-0.05,0.1)
ax[1,0].plot([stimSt,stimSt],[-0.05,0.1],'--',c='k')


im = ax[2,0].imshow(wstimZ_act["plex"],vmin=-1,vmax=3,aspect='auto',extent=[sTm[0],sTm[-1],0-0.5,wstim_act["plex"].shape[0]-0.5],origin='lower')
ax[2,0].set_xlim(1,6)
ax[2,0].plot([stimSt,stimSt],[0-0.5, wstim_act["plex"].shape[0]-0.5],'--',c='w')
fig_plex.colorbar(im,ax=ax[2,0],shrink=0.6)

ax[3,0].plot(sTm,wstimZMean_act["plex"])
ax[3,0].set_xlim(1,6)
ax[3,0].set_ylim(-1,4)
ax[3,0].plot([stimSt,stimSt],[-1,4],'--',c='k')


im = ax[0,1].imshow(wstim_inh["plex"],vmin=-0.2,vmax=0.3,aspect='auto',extent=[sTm[0],sTm[-1],0-0.5,wstim_inh["plex"].shape[0]-0.5],origin='lower')
ax[0,1].set_xlim(1,6)
ax[0,1].plot([stimSt,stimSt],[0-0.5, wstim_inh["plex"].shape[0]-0.5],'--',c='w')
fig_plex.colorbar(im,ax=ax[0,1],shrink=0.6)

ax[1,1].plot(sTm,wstimMean_inh["plex"])
ax[1,1].set_xlim(1,6)
ax[1,1].set_ylim(-0.1,0.05)
ax[1,1].plot([stimSt,stimSt],[-0.1,0.05],'--',c='k')


im = ax[2,1].imshow(wstimZ_inh["plex"],vmin=-1,vmax=3,aspect='auto',extent=[sTm[0],sTm[-1],0-0.5,wstim_inh["plex"].shape[0]-0.5],origin='lower')
ax[2,1].set_xlim(1,6)
ax[2,1].plot([stimSt,stimSt],[0-0.5, wstim_inh["plex"].shape[0]-0.5],'--',c='w')
fig_plex.colorbar(im,ax=ax[2,1],shrink=0.6)


ax[3,1].plot(sTm,wstimZMean_inh["plex"])
ax[3,1].set_xlim(1,6)
ax[3,1].set_ylim(-3,2)
ax[3,1].plot([stimSt,stimSt],[-3,2],'--',c='k')

im = ax[0,2].imshow(wstim_nonRes["plex"],vmin=-0.2,vmax=0.3,aspect='auto',extent=[sTm[0],sTm[-1],0-0.5,wstim_nonRes["plex"].shape[0]-0.5],origin='lower')
ax[0,2].set_xlim(1,6)
ax[0,2].plot([stimSt,stimSt],[0-0.5, wstim_nonRes["plex"].shape[0]-0.5],'--',c='w')
fig_plex.colorbar(im,ax=ax[0,2],shrink=0.6)

ax[1,2].plot(sTm,wstimMean_nonRes["plex"])
ax[1,2].set_xlim(1,6)
ax[1,2].set_ylim(-0.05,0.05)
ax[1,2].plot([stimSt,stimSt],[-0.05,0.05],'--',c='k')


im = ax[2,2].imshow(wstimZ_nonRes["plex"],vmin=-1,vmax=3,aspect='auto',extent=[sTm[0],sTm[-1],0-0.5,wstim_nonRes["plex"].shape[0]-0.5],origin='lower')
ax[2,2].set_xlim(1,6)
ax[2,2].plot([stimSt,stimSt],[0-0.5, wstim_nonRes["plex"].shape[0]-0.5],'--',c='w')
fig_plex.colorbar(im,ax=ax[2,2],shrink=0.6)


ax[3,2].plot(sTm,wstimZMean_nonRes["plex"])
ax[3,2].set_xlim(1,6)
ax[3,2].set_ylim(-1,1)
ax[3,2].plot([stimSt,stimSt],[-1,1],'--',c='k')

plt.suptitle('PlexinD1')
ax[0,0].set_title('active'); ax[0,1].set_title('inhibited'); ax[0,2].set_title('non responsive')



#% % plexin & fez overlaid plot

fig_fezPlex, ax = plt.subplots(2,4,figsize=(14,5), constrained_layout=True)

ax[0,0].fill_between(sTm,wstimMean_act["fez"]-2*wstimSem_act["fez"],wstimMean_act["fez"]+2*wstimSem_act["fez"],color='g',alpha=0.3)
ax[0,0].plot(sTm,wstimMean_act["fez"],c='g',label='Fezf2')
ax[0,0].fill_between(sTm,wstimMean_act["plex"]-2*wstimSem_act["plex"],wstimMean_act["plex"]+2*wstimSem_act["plex"],color='b',alpha=0.3)
ax[0,0].plot(sTm,wstimMean_act["plex"],c='b',label='PlexinD1')
ax[0,0].set_xlim(1,6)
ax[0,0].set_ylim(-0.1,0.15)
ax[0,0].plot([stimSt,stimSt],[-0.1,0.15],'--',c='k')
ax[0,0].set(xlabel='time (sec)', ylabel='dff')
ax[0,0].set_title('Active Neurons - Mean')


ax[0,1].fill_between(sTm,wstimMean_inh["fez"]-2*wstimSem_inh["fez"],wstimMean_inh["fez"]+2*wstimSem_inh["fez"],color='g',alpha=0.3)
ax[0,1].plot(sTm,wstimMean_inh["fez"],c='g',label='Fezf2')
ax[0,1].fill_between(sTm,wstimMean_inh["plex"]-2*wstimSem_inh["plex"],wstimMean_inh["plex"]+2*wstimSem_inh["plex"],color='b',alpha=0.3)
ax[0,1].plot(sTm,wstimMean_inh["plex"],c='b',label='PlexinD1')
ax[0,1].set_xlim(1,6)
ax[0,1].set_ylim(-0.1,0.15)
ax[0,1].plot([stimSt,stimSt],[-0.1,0.15],'--',c='k')
ax[0,1].set(xlabel='time (sec)', ylabel='dff')
ax[0,1].set_title('Inhibited Neurons - Mean')

ax[0,2].fill_between(sTm,wstimMean_nonRes["fez"]-2*wstimSem_nonRes["fez"],wstimMean_nonRes["fez"]+2*wstimSem_nonRes["fez"],color='g',alpha=0.3)
ax[0,2].plot(sTm,wstimMean_nonRes["fez"],c='g',label='Fezf2')
ax[0,2].fill_between(sTm,wstimMean_nonRes["plex"]-2*wstimSem_nonRes["plex"],wstimMean_nonRes["plex"]+2*wstimSem_nonRes["plex"],color='b',alpha=0.3)
ax[0,2].plot(sTm,wstimMean_nonRes["plex"],c='b',label='PlexinD1')
ax[0,2].set_xlim(1,6)
ax[0,2].set_ylim(-0.1,0.15)
ax[0,2].plot([stimSt,stimSt],[-0.1,0.15],'--',c='k')
ax[0,2].set(xlabel='time (sec)', ylabel='dff')
ax[0,2].set_title('NonResponsive Neurons - Mean')

ax[0,3].fill_between(sTm,grandAvg["dff"]["fez"]-2*grandSem["dff"]["fez"],grandAvg["dff"]["fez"]+2*grandSem["dff"]["fez"],color='g',alpha=0.3)
ax[0,3].plot(sTm,grandAvg["dff"]["fez"],c='g',label='Fezf2')
ax[0,3].fill_between(sTm,grandAvg["dff"]["plex"]-2*grandSem["dff"]["plex"],grandAvg["dff"]["plex"]+2*grandSem["dff"]["plex"],color='b',alpha=0.3)
ax[0,3].plot(sTm,grandAvg["dff"]["plex"],c='b',label='PlexinD1')
ax[0,3].set_xlim(1,6)
ax[0,3].set_ylim(-0.02,0.02)
ax[0,3].plot([stimSt,stimSt],[-0.02,0.02],'--',c='k')
ax[0,3].set(xlabel='time (sec)', ylabel='dff')
ax[0,3].set_title('Grand Average')
ax[0,3].legend(loc='upper left')

ax[1,0].fill_between(sTm,wstimZMean_act["fez"]-2*wstimZSem_act["fez"], wstimZMean_act["fez"] + 2*wstimZSem_act["fez"],color='g',alpha=0.3)
ax[1,0].plot(sTm,wstimZMean_act["fez"],c='g',label='Fezf2')
ax[1,0].fill_between(sTm,wstimZMean_act["plex"]-2*wstimZSem_act["plex"],wstimZMean_act["plex"]+2*wstimZSem_act["plex"],color='b',alpha=0.3)
ax[1,0].plot(sTm,wstimZMean_act["plex"],c='b',label='PlexinD1')
ax[1,0].set_xlim(1,6)
ax[1,0].set_ylim(-2,4)
ax[1,0].plot([stimSt,stimSt],[-2,4],'--',c='k')
ax[1,0].set(xlabel='time (sec)', ylabel='z-score')
ax[1,0].set_title('Active Neurons - Mean')

ax[1,1].fill_between(sTm,wstimZMean_inh["fez"]-2*wstimZSem_inh["fez"],wstimZMean_inh["fez"]+2*wstimZSem_inh["fez"],color='g',alpha=0.3)
ax[1,1].plot(sTm,wstimZMean_inh["fez"],c='g',label='Fezf2')
ax[1,1].fill_between(sTm,wstimZMean_inh["plex"]-2*wstimZSem_inh["plex"],wstimZMean_inh["plex"]+2*wstimZSem_inh["plex"],color='b',alpha=0.3)
ax[1,1].plot(sTm,wstimZMean_inh["plex"],c='b',label='PlexinD1')
ax[1,1].set_xlim(1,6)
ax[1,1].set_ylim(-2,4)
ax[1,1].plot([stimSt,stimSt],[-2,4],'--',c='k')
ax[1,1].set(xlabel='time (sec)', ylabel='z-score')
ax[1,1].set_title('Inhibited Neurons - Mean')

ax[1,2].fill_between(sTm,wstimZMean_nonRes["fez"]-2*wstimZSem_nonRes["fez"],wstimZMean_nonRes["fez"]+2*wstimZSem_nonRes["fez"],color='g',alpha=0.3)
ax[1,2].plot(sTm,wstimZMean_nonRes["fez"],c='g',label='Fezf2')
ax[1,2].fill_between(sTm,wstimZMean_nonRes["plex"]-2*wstimZSem_nonRes["plex"],wstimZMean_nonRes["plex"]+2*wstimZSem_nonRes["plex"],color='b',alpha=0.3)
ax[1,2].plot(sTm,wstimZMean_nonRes["plex"],c='b',label='PlexinD1')
ax[1,2].set_xlim(1,6)
ax[1,2].set_ylim(-2,4)
ax[1,2].plot([stimSt,stimSt],[-2,4],'--',c='k')
ax[1,2].set(xlabel='time (sec)', ylabel='z-score')
ax[1,2].set_title('NonResponsive Neurons - Mean')

ax[1,3].fill_between(sTm,grandAvg["zscr"]["fez"]-2*grandSem["zscr"]["fez"],grandAvg["zscr"]["fez"]+2*grandSem["zscr"]["fez"],color='g',alpha=0.3)
ax[1,3].plot(sTm,grandAvg["zscr"]["fez"],c='g',label='Fezf2')
ax[1,3].fill_between(sTm,grandAvg["zscr"]["plex"]-2*grandSem["zscr"]["plex"],grandAvg["zscr"]["plex"]+2*grandSem["zscr"]["plex"],color='b',alpha=0.3)
ax[1,3].plot(sTm,grandAvg["zscr"]["plex"],c='b',label='PlexinD1')
ax[1,3].set_xlim(1,6) 
ax[1,3].set_ylim(-0.5,1.5)
ax[1,3].plot([stimSt,stimSt],[-0.5,1.5],'--',c='k')
ax[1,3].set(xlabel='time (sec)', ylabel='z-score')
ax[1,3].set_title('Grand Average')
ax[1,3].legend(loc='upper left')

#% % make the cell distribution plots
figBox, ax = plt.subplots(2,2,constrained_layout=True,figsize=(7,7))
ax[0,0].boxplot(plexProp,labels=('active','inhibited','nonresponsive'))
ax[0,0].set_ylim(0,0.7)
ax[0,0].set(ylabel='Proportion')
ax[0,0].set_title('PlexinD1')

ax[0,1].boxplot(fezProp,labels=('active','inhibited','nonresponsive'))
ax[0,1].set_ylim(0,0.7)
ax[0,1].set(ylabel='Proportion')
ax[0,1].set_title('FezF2')

ax[1,0].pie(plexPropGrand.reshape(-1),labels = ('active','inhibited','nonresponsive'))
ax[1,0].set_title('Grand Proportion-PlexinD1')

ax[1,1].pie(fezPropGrand.reshape(-1),labels = ('active','inhibited','nonresponsive'))
ax[1,1].set_title('Grand Proportion-FezF2')

#%% saving all the figures
saveFold = r'G:\Hemanth_CSHL\Calcium Imaging\Figures\whiskStimClassifiedActivityPlots'
fName_plex ='whiskStimClusterdAct_plex.svg'  
fName_fez ='whiskStimClusterdAct_fez.svg'
fName_plexFez ='whiskStimClusterdAct_plexFez.svg'  
fName_plexFezCount ='whiskStimClusterdCellProportions_plexFez.svg' 
sPath_plex = os.path.join(saveFold, fName_plex)
sPath_fez = os.path.join(saveFold, fName_fez)
sPath_plexFez = os.path.join(saveFold, fName_plexFez)
sPath_plexFezCount = os.path.join(saveFold, fName_plexFezCount)

saveFig =int(input('Do you want to save the figures ? : '))
if saveFig == 1:
    fig_plex.savefig(sPath_plex)
    fig_plex.savefig(sPath_plex[0:-4] + '.png')
    fig_fez.savefig(sPath_fez)
    fig_fez.savefig(sPath_fez[0:-4] + '.png')
    fig_fezPlex.savefig(sPath_plexFez)
    fig_fezPlex.savefig(sPath_plexFez[0:-4] + '.png')
    figBox.savefig(sPath_plexFezCount)
    figBox.savefig(sPath_plexFezCount[0:-4] + '.png')
