# -*- coding: utf-8 -*-
"""
Created on Thu Jul 14 13:03:01 2022

@author: Hemanth
"""

import os as os
from os.path import split
import numpy as np
import tkinter as tk
from tkinter import filedialog
import matplotlib.pyplot as plt
from scipy.signal import convolve
from scipy.stats import zscore
import time

#%% functions
def movmean(Sig,leng=5):
    cSig = np.ones(leng)/leng
    return convolve(Sig,cSig,mode='same')

def getStimActivityTrace(dataPath):
    iscell = np.load(split(dataPath)[0] + '/iscell.npy', allow_pickle=True)[:,0].astype(bool)
    F = np.load(split(dataPath)[0] + '/F.npy', allow_pickle=True)[iscell,:]
    Fneu = np.load(split(dataPath)[0] + '/Fneu.npy', allow_pickle=True)[iscell,:]
    ops = np.load(split(dataPath)[0] + '/ops.npy', allow_pickle=True).item()
    stat = np.load(split(dataPath)[0] + '/stat.npy', allow_pickle=True)[iscell]
    ## df/f calculaton
    Fcorr = F - 0.7*Fneu
    F0 = np.mean(Fcorr,axis=1).reshape(-1,1)
    dff = (Fcorr - F0)/F0
    dffSm = [movmean(dff[i,:],leng=10) for i in range(0,np.shape(Fcorr)[0])]
    dffSm = np.asarray(dffSm)
    cellCnt = np.size(Fcorr,0)
    ## sort signals based on strength
    sortIdx = np.flipud(np.argsort(np.max(dffSm,axis=1)))
    Fcorr_sort = Fcorr[sortIdx]
    dff_sort = dff[sortIdx]
    dffSm_sort = dffSm[sortIdx]
    stat_sort = stat[sortIdx]
    ## convert traces to trial matrix
    frPerTrial = ops['frames_per_file']
    frPerTrialCol = 216 # how many frames per trial to collect for analysis 

    dffPerTrialPerCell = []
    dffAvgPerCell = []
    for cellId in range(0,cellCnt):
        k = 0
        wActFull = []
        wAct = []
        for i in range(0,len(frPerTrial)):
            wActFull.append(dffSm_sort[cellId,k:k+frPerTrial[i]])
            wAct.append( wActFull[i][0:frPerTrialCol])
            k = k+frPerTrial[i]    
        dffPerTrialPerCell.append(np.asarray(wAct))
        dffAvgPerCell.append(np.mean(np.asarray(wAct),0))
    ## extract average activity of all cells per trial
    avgDffActPerTrial = []
    for i in range(0,len(frPerTrial)):
        temp = []
        for k in range(0,cellCnt):
            temp.append( dffPerTrialPerCell[k][i,:])
        avgDffActPerTrial.append(np.mean(np.asarray(temp),0))
    avgDffActPerTrialMn = np.mean(np.asarray(avgDffActPerTrial),axis=0)
    Fs = 30.9
    sTm = np.linspace(0,frPerTrialCol/Fs,frPerTrialCol)
    
    return (Fcorr_sort,dff_sort,dffSm_sort,stat_sort,dffPerTrialPerCell,
            dffAvgPerCell,avgDffActPerTrial,sTm)