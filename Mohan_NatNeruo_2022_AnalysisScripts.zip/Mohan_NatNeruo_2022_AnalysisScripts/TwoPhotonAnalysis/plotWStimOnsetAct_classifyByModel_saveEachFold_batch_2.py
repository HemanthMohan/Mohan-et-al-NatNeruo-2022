# %clear -f
import sys
sys.path.append(r'G:\Hemanth_CSHL\MyScripts\PythonScripts\CalciumImaging\WhiskerStimulation\supportLibrary')
import os as os
from os.path import split
import numpy as np
import tkinter as tk
from tkinter import filedialog
import matplotlib.pyplot as plt
plt.rcParams['svg.fonttype'] = 'none'
from scipy.signal import convolve
from scipy.stats import zscore
import time
from getStimActivityTr import getStimActivityTrace,movmean
import statsmodels.api as sm
#%% load data
def plotAct(dataPath):
# root = tk.Tk()
# root.withdraw()
# dataPath = filedialog.askopenfilename(initialdir = os.getcwd(),filetypes=[("choose any", '*.npy')])
    [Fcorr,dff,dffSm,stat,dffPerTrialPerCell,
            dffAvgPerCell,avgDffActPerTrial,sTm]= getStimActivityTrace(dataPath)
    #% % generate zscore based on baseline activity from averate dff act per cell
    ## zscore is computed based on baseline 2 seconds before stimulus onset
    dffAvgPerCellZscr = [(i - np.mean(i[30:90]))/np.std(i[30:90]) for i in dffAvgPerCell]
        
        #%% use linear modelling to identify responsive neuron and seperate between active, inhibited and non responsive class
    Fs = 30.9
    stimStart = 3
    stimEnd = 4
    stimIdx = (np.arange(stimStart,stimEnd,1/Fs)*Fs).astype(int)
    x = np.zeros_like(dffPerTrialPerCell[0])
    x[:,stimIdx] = 1
    X = x.reshape(-1,1)
    X = sm.add_constant(X)
    betaVal = []
    pVal = []
    for i in range(0,len(dffPerTrialPerCell)):
        y = dffPerTrialPerCell[i].reshape(-1,1)
        model = sm.OLS(y,X)
        results = model.fit()
        betaVal.append(results.params)
        pVal.append(results.pvalues)
    
    betaVal = np.array(betaVal)
    pVal = np.array(pVal)
    
    pValTh = 0.05 ## threshold to identify responsive cell.
    cellCnt = dff.shape[0]
    k = 0
    actCells = []
    inhCells = []
    nonResCells = []
    for i in range(0,cellCnt):
        if (pVal[i,1]<pValTh and betaVal[i,1]>0):
            actCells.append(i)
        elif (pVal[i,1]<pValTh and betaVal[i,1]<0):
            inhCells.append(i)
        else:
            nonResCells.append(i)
    
    actCells = np.array(actCells)
    inhCells = np.array(inhCells)
    nonResCells = np.array(nonResCells)
    #% % seperate activity data into active, inhibited and non active cells
    ## active cells activity
    dffAvgPerCell_actCells = list(np.array(dffAvgPerCell)[actCells])
    dffAvgPerCellMean_actCells = np.array(dffAvgPerCell_actCells).mean(axis=0)
    dffAVtPerCellSem_actCells = np.array(dffAvgPerCell_actCells).std(axis=0)/np.sqrt(len(actCells))
    
    dffAvgPerCellZscr_actCells = list(np.array(dffAvgPerCellZscr)[actCells])
    dffAvgPerCellZscrMean_actCells = np.array(dffAvgPerCellZscr_actCells).mean(axis=0)
    dffAvgPerCellZscrSem_actCells = np.array(dffAvgPerCellZscr_actCells).std(axis=0)/np.sqrt(len(actCells))
    
    dffAvgPerTrial_actCells = np.mean(np.array(dffPerTrialPerCell)[actCells],axis=0)
    dffAvgPerTrialMean_actCells = np.mean(dffAvgPerTrial_actCells,axis=0)
    
    tempActZ=[] ## extract zscored activity per cell across trials
    for j in range(0,len(actCells)):
        tempAct = np.array(dffPerTrialPerCell)[actCells[j]]
        tempActZ.append((tempAct - tempAct[:,30:90].mean())/tempAct[:,30:90].std())
    dffAvgPerTrialZscr_actCells = np.mean(np.array(tempActZ),axis=0)
    dffAvgPerTrialZscrMean_actCells = np.mean(dffAvgPerTrialZscr_actCells,axis=0)
    
    
    ## inhibited cells activity
    dffAvgPerCell_inhCells = list(np.array(dffAvgPerCell)[inhCells])
    dffAvgPerCellMean_inhCells = np.array(dffAvgPerCell_inhCells).mean(axis=0)
    dffAvgPerCellSem_inhCells = np.array(dffAvgPerCell_inhCells).std(axis=0)/np.sqrt(len(inhCells))
    
    dffAvgPerCellZscr_inhCells = list(np.array(dffAvgPerCellZscr)[inhCells])
    dffAvgPerCellZscrMean_inhCells = np.array(dffAvgPerCellZscr_inhCells).mean(axis=0)
    dffAvgPerCellZscrSem_inhCells = np.array(dffAvgPerCellZscr_inhCells).std(axis=0)/np.sqrt(len(inhCells))
    
    dffAvgPerTrial_inhCells = np.mean(np.array(dffPerTrialPerCell)[inhCells],axis=0)
    dffAvgPerTrialMean_inhCells = np.mean(dffAvgPerTrial_inhCells,axis=0)
    
    tempActZ=[]
    for j in range(0,len(inhCells)):
        tempAct = np.array(dffPerTrialPerCell)[inhCells[j]]
        tempActZ.append((tempAct - tempAct[:,30:90].mean())/tempAct[:,30:90].std())
    dffAvgPerTrialZscr_inhCells = np.mean(np.array(tempActZ),axis=0)
    dffAvgPerTrialZscrMean_inhCells = np.mean(dffAvgPerTrialZscr_inhCells,axis=0)
    
    ## non responsive cells activity
    dffAvgPerCell_nonResCells = list(np.array(dffAvgPerCell)[nonResCells])
    dffAvgPerCellMean_nonResCells = np.array(dffAvgPerCell_nonResCells).mean(axis=0)
    dffAvgPerCellSem_nonResCells = np.array(dffAvgPerCell_nonResCells).std(axis=0)/np.sqrt(len(nonResCells))
    
    dffAvgPerCellZscr_nonResCells = list(np.array(dffAvgPerCellZscr)[nonResCells])
    dffAvgPerCellZscrMean_nonResCells = np.array(dffAvgPerCellZscr_nonResCells).mean(axis=0)
    dffAvgPerCellZscrSem_nonResCells = np.array(dffAvgPerCellZscr_nonResCells).std(axis=0)/np.sqrt(len(nonResCells))
    
    dffAvgPerTrial_nonResCells = np.mean(np.array(dffPerTrialPerCell)[nonResCells],axis=0)
    dffAvgPerTrialMean_nonResCells = np.mean(dffAvgPerTrial_nonResCells,axis=0)
    
    tempActZ=[]
    for j in range(0,len(nonResCells)):
        tempAct = np.array(dffPerTrialPerCell)[nonResCells[j]]
        tempActZ.append((tempAct - tempAct[:,30:90].mean())/tempAct[:,30:90].std())
    dffAvgPerTrialZscr_nonResCells = np.mean(np.array(tempActZ),axis=0)
    dffAvgPerTrialZscrMean_nonResCells = np.mean(dffAvgPerTrialZscr_nonResCells,axis=0)
    #%b% grand average
    dffGAvgMean =  np.array(dffAvgPerCell).mean(axis=0)
    dffGAvgSem =  np.array(dffAvgPerCell).std(axis=0)/np.sqrt(cellCnt)
    
    dffGAvgZscrMean =  np.array(dffAvgPerCellZscr).mean(axis=0)
    dffGAvgZscrSem =  np.array(dffAvgPerCellZscr).std(axis=0)/np.sqrt(cellCnt)
    
    #%b% plotting scripts
    plt.close('all')
    
    cellCnt_act = len(actCells)
    cellCnt_inh = len(inhCells)
    cellCnt_nonRes = len(nonResCells)
    
    plt.close('all')
    fig,ax = plt.subplots(3,7,figsize=(18,7))
    # plt.tight_layout()
    plt.rcParams.update({'font.size':6})
    
    ## active cell plots
    im = ax[0,0].imshow(np.asarray(dffAvgPerCell_actCells),vmin=-0.1,vmax=0.2,aspect='auto',
                        extent=[sTm[0],sTm[-1],0-0.5,cellCnt_act-0.5],interpolation='None',origin='lower')
    fig.colorbar(im,ax=ax[0,0],shrink=0.6)
    ax[0,0].set_title('Avg dff act Per Cell-Active Cells')
    ax[0,0].set(xlabel='time (sec)', ylabel='cell #')
    ax[0,0].set_xlim(1,6)
    ax[0,0].plot([2.9,2.9],[0-0.5,cellCnt_act-0.5],'--',c='w')
    
    plt.draw()
    
    ax[0,1].fill_between(sTm,dffAvgPerCellMean_actCells-2*dffAVtPerCellSem_actCells,
                         dffAvgPerCellMean_actCells+2*dffAVtPerCellSem_actCells,color='b',alpha=0.3)
    ax[0,1].plot(sTm, dffAvgPerCellMean_actCells)
    ax[0,1].set_title('Avg of avg dff Act per cell-Active cells')
    ax[0,1].set(xlabel='time (sec)', ylabel='dff')
    ax[0,1].set_xlim(1,6)
    ax[0,1].set_ylim([-0.1,0.15])
    ax[0,1].plot([2.9,2.9],[-0.1,0.15],'--',c='k')
    plt.draw()
    
    im = ax[0,2].imshow(np.asarray(dffAvgPerCellZscr_actCells),vmin=-1,vmax=3,aspect='auto',
                        extent=[sTm[0],sTm[-1],0-0.5,cellCnt_act-0.5],interpolation='None',origin='lower')
    fig.colorbar(im,ax=ax[0,2],shrink=0.6)
    ax[0,2].set_title('Avg zscored dff act Per Cell-Active Cells')
    ax[0,2].set(xlabel='time (sec)', ylabel='cell #')
    ax[0,2].set_xlim(1,6)
    ax[0,2].plot([2.9,2.9],[0-0.5,cellCnt_act-0.5],'--',c='w')
    
    ax[0,3].fill_between(sTm,dffAvgPerCellZscrMean_actCells-2*dffAvgPerCellZscrSem_actCells,
                         dffAvgPerCellZscrMean_actCells+2*dffAvgPerCellZscrSem_actCells,color='b',alpha=0.3)
    ax[0,3].plot(sTm, dffAvgPerCellZscrMean_actCells)
    ax[0,3].set_title('Avg of avg zscore dff Act per cell-Active cells')
    ax[0,3].set(xlabel='time (sec)', ylabel='zscore')
    ax[0,3].set_xlim(1,6)
    ax[0,3].plot([2.9,2.9],[-2,6],'--',c='k')
    ax[0,3].set_ylim([-2,6])
    plt.draw()
    
    im = ax[0,4].imshow(np.asarray(dffAvgPerTrial_actCells),vmin=-0.1,vmax=0.15,aspect='auto',
                        extent=[sTm[0],sTm[-1],0-0.5,20-0.5],interpolation='None',origin='lower')
    fig.colorbar(im,ax=ax[0,4],shrink=0.6)
    ax[0,4].set_title('Avg dff act Per Trial-Active Cells')
    ax[0,4].set(xlabel='time (sec)', ylabel='trial #')
    ax[0,4].set_xlim(1,6)
    ax[0,4].plot([2.9,2.9],[0-0.5,20-0.5],'--',c='w')
    
    
    
    im = ax[0,5].imshow(np.asarray(dffAvgPerTrialZscr_actCells),vmin=-0.2,vmax=1,aspect='auto',
                        extent=[sTm[0],sTm[-1],0-0.5,20-0.5],interpolation='None',origin='lower')
    fig.colorbar(im,ax=ax[0,5],shrink=0.6)
    ax[0,5].set_title('Avg zscore dff act Per Trial-Active Cells')
    ax[0,5].set(xlabel='time (sec)', ylabel='trial #')
    ax[0,5].set_xlim(1,6)
    ax[0,5].plot([2.9,2.9],[0-0.5,20-0.5],'--',c='w')
    
    
    
    
    ## inhibition cell plots
    im = ax[1,0].imshow(np.asarray(dffAvgPerCell_inhCells),vmin=-0.1,vmax=0.2,aspect='auto',
                        extent=[sTm[0],sTm[-1],0-0.5,cellCnt_inh-0.5],interpolation='None',origin='lower')
    fig.colorbar(im,ax=ax[1,0],shrink=0.6)
    ax[1,0].set_title('Avg dff act Per Cell-inh Cells')
    ax[1,0].set(xlabel='time (sec)', ylabel='cell #')
    ax[1,0].set_xlim(1,6)
    ax[1,0].plot([2.9,2.9],[0-0.5,cellCnt_inh-0.5],'--',c='w')
    
    plt.draw()
    
    ax[1,1].fill_between(sTm,dffAvgPerCellMean_inhCells-2*dffAvgPerCellSem_inhCells,
                         dffAvgPerCellMean_inhCells+2*dffAvgPerCellSem_inhCells,color='b',alpha=0.3)
    ax[1,1].plot(sTm, dffAvgPerCellMean_inhCells)
    ax[1,1].set_title('Avg of avg dff Act per cell-inh cells')
    ax[1,1].set(xlabel='time (sec)', ylabel='dff')
    ax[1,1].set_xlim(1,6)
    ax[1,1].set_ylim([-0.1,0.15])
    ax[1,1].plot([2.9,2.9],[-0.1,0.15],'--',c='k')
    plt.draw()
    
    im = ax[1,2].imshow(np.asarray(dffAvgPerCellZscr_inhCells),vmin=-1,vmax=3,aspect='auto',
                        extent=[sTm[0],sTm[-1],0-0.5,cellCnt_inh-0.5],interpolation='None',origin='lower')
    fig.colorbar(im,ax=ax[1,2],shrink=0.6)
    ax[1,2].set_title('Avg zscored dff act Per Cell-inh Cells')
    ax[1,2].set(xlabel='time (sec)', ylabel='cell #')
    ax[1,2].set_xlim(1,6)
    ax[1,2].plot([2.9,2.9],[0-0.5,cellCnt_inh-0.5],'--',c='w')
    
    ax[1,3].fill_between(sTm,dffAvgPerCellZscrMean_inhCells-2*dffAvgPerCellZscrSem_inhCells,
                         dffAvgPerCellZscrMean_inhCells+2*dffAvgPerCellZscrSem_inhCells,color='b',alpha=0.3)
    ax[1,3].plot(sTm, dffAvgPerCellZscrMean_inhCells)
    ax[1,3].set_title('Avg of avg zscore dff Act per cell-inh cells')
    ax[1,3].set(xlabel='time (sec)', ylabel='zscore')
    ax[1,3].set_xlim(1,6)
    ax[1,3].plot([2.9,2.9],[-2,6],'--',c='k')
    ax[1,3].set_ylim([-2,6])
    plt.draw()
    
    im = ax[1,4].imshow(np.asarray(dffAvgPerTrial_inhCells),vmin=-0.03,vmax=0.05,aspect='auto',
                        extent=[sTm[0],sTm[-1],0-0.5,20-0.5],interpolation='None',origin='lower')
    fig.colorbar(im,ax=ax[1,4],shrink=0.6)
    ax[1,4].set_title('Avg dff act Per Trial-inh Cells')
    ax[1,4].set(xlabel='time (sec)', ylabel='trial #')
    ax[1,4].set_xlim(1,6)
    ax[1,4].plot([2.9,2.9],[0-0.5,20-0.5],'--',c='w')
    
    
    im = ax[1,5].imshow(np.asarray(dffAvgPerTrialZscr_inhCells),vmin=-0.2,vmax=0.5,aspect='auto',
                        extent=[sTm[0],sTm[-1],0-0.5,20-0.5],interpolation='None',origin='lower')
    fig.colorbar(im,ax=ax[1,5],shrink=0.6)
    ax[1,5].set_title('Avg zscore dff act Per Trial-inh Cells')
    ax[1,5].set(xlabel='time (sec)', ylabel='trial #')
    ax[1,5].set_xlim(1,6)
    ax[1,5].plot([2.9,2.9],[0-0.5,20-0.5],'--',c='w')
        
    
    
    ## non responsive cell plots
    im = ax[2,0].imshow(np.asarray(dffAvgPerCell_nonResCells),vmin=-0.1,vmax=0.2,aspect='auto',
                        extent=[sTm[0],sTm[-1],0-0.5,cellCnt_nonRes-0.5],interpolation='None',origin='lower')
    fig.colorbar(im,ax=ax[2,0],shrink=0.6)
    ax[2,0].set_title('Avg dff act Per Cell-nonRes Cells')
    ax[2,0].set(xlabel='time (sec)', ylabel='cell #')
    ax[2,0].set_xlim(1,6)
    ax[2,0].plot([2.9,2.9],[0-0.5,cellCnt_nonRes-0.5],'--',c='w')
    
    plt.draw()
    
    ax[2,1].fill_between(sTm,dffAvgPerCellMean_nonResCells-2*dffAvgPerCellSem_nonResCells,
                         dffAvgPerCellMean_nonResCells+2*dffAvgPerCellSem_nonResCells,color='b',alpha=0.3)
    ax[2,1].plot(sTm, dffAvgPerCellMean_nonResCells)
    ax[2,1].set_title('Avg of avg dff Act per cell-nonRes cells')
    ax[2,1].set(xlabel='time (sec)', ylabel='dff')
    ax[2,1].set_xlim(1,6)
    ax[2,1].set_ylim([-0.1,0.15])
    ax[2,1].plot([2.9,2.9],[-0.1,0.15],'--',c='k')
    plt.draw()
    
    im = ax[2,2].imshow(np.asarray(dffAvgPerCellZscr_nonResCells),vmin=-1,vmax=3,aspect='auto',
                        extent=[sTm[0],sTm[-1],0-0.5,cellCnt_nonRes-0.5],interpolation='None',origin='lower')
    fig.colorbar(im,ax=ax[2,2],shrink=0.6)
    ax[2,2].set_title('Avg zscored dff act Per Cell-nonRes Cells')
    ax[2,2].set(xlabel='time (sec)', ylabel='cell #')
    ax[2,2].set_xlim(1,6)
    ax[2,2].plot([2.9,2.9],[0-0.5,cellCnt_nonRes-0.5],'--',c='w')
    
    ax[2,3].fill_between(sTm,dffAvgPerCellZscrMean_nonResCells-2*dffAvgPerCellZscrSem_nonResCells,
                         dffAvgPerCellZscrMean_nonResCells+2*dffAvgPerCellZscrSem_nonResCells,color='b',alpha=0.3)
    ax[2,3].plot(sTm, dffAvgPerCellZscrMean_nonResCells)
    ax[2,3].set_title('Avg of avg zscore dff Act per cell-nonRes cells')
    ax[2,3].set(xlabel='time (sec)', ylabel='zscore')
    ax[2,3].set_xlim(1,6)
    ax[2,3].plot([2.9,2.9],[-2,6],'--',c='k')
    ax[2,3].set_ylim([-2,6])
    plt.draw()
    
    im = ax[2,4].imshow(np.asarray(dffAvgPerTrial_nonResCells),vmin=-0.03,vmax=0.05,aspect='auto',
                        extent=[sTm[0],sTm[-1],0-0.5,20-0.5],interpolation='None',origin='lower')
    fig.colorbar(im,ax=ax[2,4],shrink=0.6)
    ax[2,4].set_title('Avg dff act Per Trial-nonRes Cells')
    ax[2,4].set(xlabel='time (sec)', ylabel='trial #')
    ax[2,4].set_xlim(1,6)
    ax[2,4].plot([2.9,2.9],[0-0.5,20-0.5],'--',c='w')
    
    
    im = ax[2,5].imshow(np.asarray(dffAvgPerTrialZscr_nonResCells),vmin=-0.2,vmax=0.5,aspect='auto',
                        extent=[sTm[0],sTm[-1],0-0.5,20-0.5],interpolation='None',origin='lower')
    fig.colorbar(im,ax=ax[2,5],shrink=0.6)
    ax[2,5].set_title('Avg zscore dff act Per Trial-nonRes Cells')
    ax[2,5].set(xlabel='time (sec)', ylabel='trial #')
    ax[2,5].set_xlim(1,6)
    ax[2,5].plot([2.9,2.9],[0-0.5,20-0.5],'--',c='w')
    
    ########## plotting grand Averages
    ax[0,6].fill_between(sTm,dffGAvgMean-2*dffGAvgSem,
                         dffGAvgMean+2*dffGAvgSem,color='b',alpha=0.3)
    ax[0,6].plot(sTm, dffGAvgMean)
    ax[0,6].set_title('Grand Average of Dff')
    ax[0,6].set(xlabel='time (sec)', ylabel='dff')
    ax[0,6].set_xlim(1,6)
    ax[0,6].plot([2.9,2.9],[-0.05,0.1],'--',c='k')
    ax[0,6].set_ylim([-0.05,0.1])
    
    ax[1,6].fill_between(sTm,dffGAvgZscrMean-2*dffGAvgZscrSem,
                         dffGAvgZscrMean+2*dffGAvgZscrSem,color='b',alpha=0.3)
    ax[1,6].plot(sTm, dffGAvgZscrMean)
    ax[1,6].set_title('Grand Average of Dff Zscore')
    ax[1,6].set(xlabel='time (sec)', ylabel='zscore')
    ax[1,6].set_xlim(1,6)
    ax[1,6].plot([2.9,2.9],[-1,4],'--',c='k')
    ax[1,6].set_ylim([-1,4])
    
    #% % save figure
    saveFold = r'G:\Hemanth_CSHL\Calcium Imaging\Figures\whiskStimActClassifiedRefTraces'
    path = os.path.normpath(dataPath)
    pathParts = path.split(os.sep)
    filePath = os.path.join(saveFold,pathParts[4]);
    fileName =''
    for i in range(4,9):
        if i==4:
            fileName = pathParts[i]
        else:
            fileName = fileName + '_' + pathParts[i]
    
        
    savePath1 = os.path.join(filePath, fileName + '.svg')
    savePath2 = os.path.join(filePath, fileName + '.png')
    if not os.path.exists(filePath):
        os.makedirs(filePath)
        
    fig.savefig(savePath1)
    fig.savefig(savePath2)
    plt.close('all')


#%% get paths to plot
f=open(r"G:\Hemanth_CSHL\Calcium Imaging\Data\Fezf2\pathsToPlot.txt", "r")
allPaths = f.readlines()
for i in range(0,len(allPaths)):
    print(i)
    dataPath = os.path.join(allPaths[i][:-1],'suite2p\plane0\F.npy')
    plotAct(dataPath)