clear all; close all; clc;
%% Load Data
plexData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\MeanActivityAroundPIM\PlexinD1Ai148_MeanActivityAroudPIM_Full.mat');
plexData = plexData.data;
fezData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\MeanActivityAroundPIM\FezF2Ai148_MeanActivityAroudPIM_Full.mat');
fezData = fezData.data;
dmMap = plexData.dorsalMap.edgeOutlineSplit;
%% extract mean maps
meanMaps_plex = squeeze(mean(plexData.meanFlowAll,3));
meanMaps_fez = squeeze(mean(fezData.meanFlowAll,3));
%%
size_plex = size(meanMaps_plex);
size_fez = size(meanMaps_fez);
maps_plex = reshape(meanMaps_plex,size_plex(1)*size_plex(2),size_plex(3));
maps_fez = reshape(meanMaps_fez,size_fez(1)*size_fez(2),size_fez(3));

maps_plexFez = [maps_plex';maps_fez'];
maps_plexFez = maps_plexFez - mean(maps_plexFez);
%% pca
[coeff,score] = pca(maps_plexFez);
pc1 = reshape(coeff(:,1),size_plex(1),size_plex(2));
pc2 = reshape(coeff(:,2),size_plex(1),size_plex(2));
%% plot pca cluster and maps
h1 = figure; h1.Position = [36 558 1260 420];
subplot(1,3,1)
plot(score(1:size_plex(3),1),score(1:size_plex(3),2),'b.','MarkerSize',15)
hold on
plot(score((size_plex(3)+1) :end,1),score((size_plex(3)+1) :end,2),'g.','MarkerSize',15)
legend('Plex','Fez')
xlabel('PC1');ylabel('PC2')
axis square
hold off

subplot(1,3,2)
imagesc(pc1);colormap hot; axis image; colorbar
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2),dmMap{p}(:, 1),'color','w');
end
hold off
title('PC1')

subplot(1,3,3)
imagesc(pc2);colormap hot; axis image; colorbar
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2),dmMap{p}(:, 1),'color','w');
end
hold off
title('PC2')

%% %%%%%%%%%%%%% saving the figures %%%%%%%%%%

saveFolder = 'G:\Hemanth_CSHL\WideField\Data_Figures\ActivityPlots\AllenMaskROIAnalysis\FeedingActMapsPCAclusters\';
fileName1 = ['FeedingActivityMapPcaClusters.fig'];
savePath1 = fullfile(saveFolder,fileName1);
saveFig = input('Do you want to save the current figure : ');
if saveFig == 1
    savefig(h1,savePath1)
    saveas(h1,[savePath1(1:end-4) '.svg']);
end