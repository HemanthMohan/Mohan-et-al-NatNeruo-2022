clear all; close all; clc;
%% Load Data
plexData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\MeanActivityAroundPIM\PlexinD1Ai148_MeanActivityAroudPIM_Full.mat');
plexData = plexData.data;
fezData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\MeanActivityAroundPIM\FezF2Ai148_MeanActivityAroudPIM_Full.mat');
fezData = fezData.data;
load('F:\Hemanth_CSHL\WideField\Data\cmapPlexFez.mat');
dmMap = plexData.dorsalMap.edgeOutlineSplit;
%% extract variance maps
meanMaps_plex = squeeze(mean(plexData.meanFlowAll,3));
meanMaps_fez = squeeze(mean(fezData.meanFlowAll,3));
% 
% meanMaps_plex(find(meanMaps_plex==0)) = NaN;
% meanMaps_fez(find(meanMaps_fez==0)) = NaN;

numSes_plex = length(plexData.foldersAnalyzed);
numSes_fez = length(fezData.foldersAnalyzed);

%% perform pixel wise ttests
plexMap = reshape(meanMaps_plex,size(meanMaps_plex,1)*size(meanMaps_plex,2),size(meanMaps_plex,3))';
fezMap = reshape(meanMaps_fez,size(meanMaps_fez,1)*size(meanMaps_fez,2),size(meanMaps_fez,3))';
pVal = [];
parfor ii = 1:size(fezMap,2);
    sigPlex = plexMap(:,ii);
    sigFez = fezMap(:,ii);
%     [~,pVal(1,ii)] =ttest2(sigPlex,sigFez);
    [pVal(1,ii)] =ranksum(sigPlex,sigFez); 
end
pValMap = reshape(pVal,size(meanMaps_fez,1),size(meanMaps_fez,2));
%% %%% calculate the false discovery reate
q_fdr = 0.05; %% set the acceptable false discovery rate
% [fdr_pval] = myFalseDiscoveryThreshold(pVal,q_fdr); %% alternate fdr_bh function
[~,fdr_pval] = fdr_bh(pVal,q_fdr); %% alternate fdr_bh function
disp(['fdr p val : ' num2str(fdr_pval)])
%% %%% extract significant pixels and mean values associated with sig p vals
pValMask = pValMap<fdr_pval;
fezPlexMap = nanmean(meanMaps_plex,3)- nanmean(meanMaps_fez,3);
fezPlexMapTh = fezPlexMap.*pValMask;
fezPlexMapTh(isnan(fezPlexMap)) = 0;
%% plot the map of pixels significantly different from each other
h1 = figure; h1.Position = [100   174   886   701];
imagesc(fezPlexMapTh,[-0.01,0.01]); axis image; colormap(cmap);hc = colorbar;
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2),dmMap{p}(:, 1),'color','k','LineWidth',0.1);
end
hold off
axis(gca,2*[12 280 44 268])

title( ["Pixels significantly different from each other with FDR = 0.05" + newline + ... 
"PlexinD1 mean map - FezF2 mean map" ],'Interpreter','none'   )
hc.Label.String='df/f';
annotation(h1,'textbox', [0, 0.99, 0, 0], 'string', [plexData.foldersAnalyzed; fezData.foldersAnalyzed],'FontSize',7, 'Interpreter', 'none')
% %% %%%%%%%%%%%%% saving the figures %%%%%%%%%%
% 
saveFolder = 'G:\Hemanth_CSHL\WideField\Data_Figures\ActivityPlots\AllenMaskROIAnalysis\FeedingActMapsCorrelation\';
fileName1 = ['FeedingActivityStatisticalParametricTest.fig'];
savePath1 = fullfile(saveFolder,fileName1);
saveFig = input('Do you want to save the current figure : ');
if saveFig == 1
    savefig(h1,savePath1)
    saveas(h1,[savePath1(1:end-4) '.svg']);
end