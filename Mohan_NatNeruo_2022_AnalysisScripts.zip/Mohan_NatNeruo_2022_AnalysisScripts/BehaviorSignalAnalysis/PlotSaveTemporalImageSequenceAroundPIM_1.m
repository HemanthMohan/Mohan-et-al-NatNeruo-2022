clear all; close all; clc
load('F:\Hemanth_CSHL\WideField\Data\cmap3.mat');
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');

AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.
%% %%%%%%%%%%%%%%%% load sequence data %%%%%%%%%%%%
plexData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\MeanActivityAroundPIM\PlexinD1Ai148_MeanActivityAroudPIM.mat');
fezData = load ('G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\MeanActivityAroundPIM\FezF2Ai148_MeanActivityAroudPIM');
plexSeq = plexData.data.meanFlow;
fezSeq = fezData.data.meanFlow;
dorsalMap = plexData.data.dorsalMap.edgeOutlineSplit;
seqTm = linspace(-plexData.data.durBeforeOnset, plexData.data.durAfterOnset, size(plexSeq,3));
%% Sampling and plotting mean activity frames %%%%%%%
close all
numFrames = 10; %%% how many frames to plot
timeFrame = [-1,1]; %% time frame to plot the sequence. Should be between the time collected around pim
frameIdx = round(linspace(find(seqTm>=timeFrame(1),1),find(seqTm>=timeFrame(2),1),numFrames));
frameTm = seqTm(frameIdx);
imSclPlex = [-0.02,0.02];
imSclFez = [-0.032,0.032];
hPlex = figure;
hFez = figure;
hPlex.Position = [25 756 1881 179];
hFez.Position = [33 475 1881 179];
for ii = 1:length(frameIdx)
    figure(hPlex)
    subplot(1,length(frameIdx),ii)
    imagesc(imgaussfilt(plexSeq(:,:,frameIdx(ii)),2))
    hold on
    for p = 1:length(dorsalMap)
        plot( dorsalMap{p}(:, 2),dorsalMap{p}(:, 1),'color','w','LineWidth',0.5);
    end
    hold off
    caxis(imSclPlex)
    axis image
    set(gca,'XLim',[26 562]);
    set(gca,'YLim',[92 537]);
    colormap(cmap2);
    title(num2str(frameTm(ii)))
    set(gca,'XTick',[], 'YTick', [])
    
    figure(hFez)
    subplot(1,length(frameIdx),ii)
    imagesc(imgaussfilt(fezSeq(:,:,frameIdx(ii)),2))
    hold on
    for p = 1:length(dorsalMap)
        plot( dorsalMap{p}(:, 2),dorsalMap{p}(:, 1),'color','w','LineWidth',0.5);
    end
    hold off
    caxis(imSclFez)
    axis image
    set(gca,'XLim',[26 562]);
    set(gca,'YLim',[92 537]);
    colormap(cmap2);
    title(num2str(frameTm(ii)))
    set(gca,'XTick',[], 'YTick', [])
end
sgtitle(hPlex, 'PlexinD1 Temporal Sequence')
sgtitle(hFez, 'FezF2 Temporal Sequence')
%% %%%%%%%%%% saving the data %%%%%%%%%%%%%%
figFolder = ['G:\Hemanth_CSHL\WideField\Data_Figures\Spatial Dimensions\TemporalSequence'];
if AskSaving == 1
    filename_plex = ['PlexinD1Ai148_temporalSeqAroundPIM'];
    filename_fez = ['FezF2Ai148_temporalSeqAroundPIM'];
    savedim = input('Do you want to save the temporal Seq : ');
    if savedim == 1
        figpath_plex = fullfile(figFolder,filename_plex);
        figpath_fez = fullfile(figFolder,filename_fez);
        savefig(hPlex,[figpath_plex '.fig']); % saving the figure as fig
        saveas(hPlex,[figpath_plex '.svg']); % saving the figure as svg
        savefig(hFez,[figpath_fez '.fig']); % saving the figure as fig
        saveas(hFez,[figpath_fez '.svg']); % saving the figure as svg
        disp('figures and data saved! '); 
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Functions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function [fnFeat, usFeat ] = getFileNameProperties(fpath)
%%%%%%%%%%%%% getting signal file name %%%%%%%%%%%%%%
listing_csv = dir([fpath '\*.csv']);
[~, sflname] = fileparts(fileparts(fpath));
spath = fullfile(fileparts(fileparts(fileparts(fpath))), 'Data_Corrected', sflname);
listing_sig = dir([spath '\*.mat']);
sname_all = natsortfiles({listing_sig.name}');
sname_ex = sname_all{1};
us_idx = find(sname_ex == '_',1,'last');

%%%%%%%% getting body trajectory file name %%%%%%%%%%%%
fname_all = natsortfiles({listing_csv.name}');
fname_allC1 = fname_all( contains(fname_all,'c1_T'));
fname_allC2 = fname_all( contains(fname_all,'c2_T'));

fname_exC1 = fname_allC1{1};
fname_us_idxC1 = find(fname_exC1 == '_');
fname_deep_idxC1 = strfind(fname_exC1, 'Deep');
bidx_stC1 = fname_us_idxC1(end-4);
bidx_endC1 = fname_deep_idxC1;

fname_exC2 = fname_allC2{1};
fname_us_idxC2 = find(fname_exC2 == '_');
fname_deep_idxC2 = strfind(fname_exC2, 'Deep');
bidx_stC2 = fname_us_idxC2(end-4);
bidx_endC2 = fname_deep_idxC2;


%%% updating all properties
fnFeat.sname_all = sname_all;
fnFeat.fname_allC1 = fname_allC1;
fnFeat.fname_allC2 = fname_allC2;
fnFeat.sname_ex = sname_ex;
fnFeat.fname_exC1 = fname_exC1;
fnFeat.fname_exC2 = fname_exC2;
fnFeat.spath = spath;

usFeat.us_idx = us_idx;
usFeat.bidx_stC1 = bidx_stC1;
usFeat.bidx_endC1 = bidx_endC1;
usFeat.bidx_stC2 = bidx_stC2;
usFeat.bidx_endC2 = bidx_endC2;
end




