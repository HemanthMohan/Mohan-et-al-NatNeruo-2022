clear all; close all; clc
%% %%%%%%%%%%%%%% Enter the path fro analysis %%%%%%%%%%%%%%%%%%
%%%%%%%% REMOVE FORWARD SLASH IN THE LAST %%%%%%%%%%%%%
liftFolder = 'G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\MaskRoiSelectionAnalysis\NoCorrection\HandLiftTrials\PelletInMouthOnset\FezF2Ai148'; %% no slash in the last
noLiftFolder = 'G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\MaskRoiSelectionAnalysis\NoCorrection\HandBlockedTrials\PelletInMouthOnset_HandBlocked\FezF2Ai148'; %% no slash in the last
FoldContLift = dir(fullfile(liftFolder,['*.mat']));
sampDataLift = load(fullfile(liftFolder,FoldContLift(1).name));

FoldContNolift = dir(fullfile(noLiftFolder,['*.mat']));
sampDataNolift = load(fullfile(noLiftFolder,FoldContNolift(1).name));
AskSaving = 1; %%%%%%%%% 1 To ask the saving plot question. 0 to avoid saving

%% %%%%%%%%%% Extracting the Data from each file  %%%%%%%%
[caDataLift,caDataFiltLift] = GetCaData(liftFolder,FoldContLift,sampDataLift);
[caDataNolift,caDataFiltNolift] = GetCaData(noLiftFolder,FoldContNolift,sampDataNolift);
%% %%%%%%%%%%% calculating Area Under The Curve %%%%%%%%%%%%%%%%%%%
%%%%%% applygint the S golay filter design %%%%%
close all
parms.plotGraphs = 0 ;
parms.actTm = sampDataLift.data.actTime' ;
parms.durBef = 0; %% duration in sec before trigger to consider for extracting AUC
parms.durAft = 1 ; %% duration in sec after trigger to consider for extracting peak value

[aucFrontalLift] = extractAUC(caDataLift.leftFrontal, parms);
[aucParietalLift] = extractAUC(caDataLift.leftParietal, parms);
[aucFlaLift] = extractAUC(caDataLift.leftFLA, parms);
[aucFlpLift] = extractAUC(caDataLift.leftFLP, parms);

[aucFrontalNolift] = extractAUC(caDataNolift.leftFrontal, parms);
[aucParietalNolift] = extractAUC(caDataNolift.leftParietal, parms);
[aucFlaNolift] = extractAUC(caDataNolift.leftFLA, parms);
[aucFlpNolift] = extractAUC(caDataNolift.leftFLP, parms);
%% %%%%% pefroming two way ANOVA stats
g1 = [cellstr(repmat("Frontal",length(aucFrontalLift),1)); cellstr(repmat("Frontal",length(aucFrontalNolift),1)); ...
    cellstr(repmat("Parietal",length(aucParietalLift),1)); cellstr(repmat("Parietal",length(aucParietalNolift),1)); ...
    ];

g2 = [cellstr(repmat("Lift",length(aucFrontalLift),1)); cellstr(repmat("NoLift",length(aucFrontalNolift),1)); ...
    cellstr(repmat("Lift",length(aucParietalLift),1)); cellstr(repmat("NoLift",length(aucParietalNolift),1)); ...
    ];


aucData = [aucFrontalLift;aucFrontalNolift;aucParietalLift;aucParietalNolift];

[anova_p,tbl,stats] = anovan(aucData,{g1,g2},'model','interaction',"Varnames",["Region","lift"] );
[mCompTable,~,~,gnames] = multcompare(stats,"Dimension",[1 2]);
frontal_LiftVsNolift_p = mCompTable(2,6);
parietal_LiftVsNolift_p = mCompTable(5,6);
statsText = "Two Way Anova with multCompare" + newline + ...
    "frontal Lift Vs Nolift :" + num2str(frontal_LiftVsNolift_p) + newline + ...
    "parietal Lift Vs Nolift :" + num2str(parietal_LiftVsNolift_p);

%%
% yRange = [min([aucFrontalLift;aucParietalLift;aucFlaLift;aucFlpLift]) max([aucFrontalLift;aucParietalLift;aucFlaLift;aucFlpLift])] ;
yRange = [-0.02 0.06];
h2 = figure;
h2.Position = [320 44 1167 869];

ax(1) = subplot(2,2,1);
boxplot([aucFrontalLift;aucFrontalNolift],[ones(length(aucFrontalLift),1); 2*ones(length(aucFrontalNolift),1)], ...
    'Labels',{'lift Frontal','nolift Frontal'})


ax(2) = subplot(2,2,2);
boxplot([aucParietalLift;aucParietalNolift],[ones(length(aucParietalLift),1); 2*ones(length(aucParietalNolift),1)], ...
    'Labels',{'lift Parietal','nolift Parietal'})

set(ax,'YLim', yRange)
text(1,0.05,statsText)

sessionName = sampDataLift.data.MouseID(10:end-5);
[~,trialType] = fileparts(fileparts(liftFolder));
sgtitle([sessionName '_' trialType ' - Duration = ' '-' num2str(parms.durBef) ' to ' num2str(parms.durAft) ' sec'],'interpreter','none')
set(ax,'TickDir','out')
linkaxes(ax)

%% %%%%%%%%%% Annotating the plots %%%%%%
for ii = 1:length(FoldContLift)
    FolderNames{ii,1} = FoldContLift(ii).name(1:end-9);
end
annotation(h2,'textbox', [0, 0.95, 0, 0], 'string', FolderNames,'FontSize',7, 'Interpreter', 'none')

%% Saving the figures %%
clc
saveFig = input('Do you want to save the figure (Y = 1, N = 0) ? : ');
if saveFig == 1
    disp('!!!!!!!!! MAKE SURE THE PATH TO SAVE AND FILENAME IS CORRECT !!!!!!!!!!')
    %%%%%%%% Enter the correct path to save the data %%%%%%%%%%%%%
    actSpath = 'G:\Hemanth_CSHL\WideField\Data_Figures\ActivityPlots\AllenMaskROIAnalysis\LiftNoLiftAUCplots';
    actFname = [sessionName '_' trialType '_AreaUnderCurve_anovaStats']; %%%% enter file name to save everytime !!!
    disp(['The File name being Saved is : ' actFname]);
    saveas(h2,fullfile(actSpath,actFname),'fig');
    saveas(h2,fullfile(actSpath,actFname),'svg');
    disp(' Figure SAVED! ')
end


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% FUNCTIONS %%%%%%%%%%%%%%%%%%%%%%%%%%
function [auc] = extractAUC(dataIn,parms)
durIdx = find(parms.actTm>= -parms.durBef & parms.actTm <= parms.durAft);
for jj = 1:size(dataIn,2)
    idx = jj;
    %%%%% collecting signal %%%%%%
    sigIn = double(dataIn(:,idx));
    %%%%%% Plotting graphs if selected
    if parms.plotGraphs == 1
        close all
        h1  = figure;
        h1.Position = [419 380 500 400];
        hold on
        plot(parms.actTm,sigIn,'color','k','LineWidth',2);
        plot([0 0],[-0.02 0.05],'r-')
        area(parms.actTm(durIdx),sigIn(durIdx))
        pause(0.5)
    end
    
    %%%% extract AUC value%%%%%%
    auc(idx,1) = trapz(parms.actTm(durIdx),sigIn(durIdx));
end
end

function [caData,caDataFilt,caDataMean,caDataStdErr] = GetCaData(InFolder,FoldCont,sampData)
Locations = fieldnames(sampData.data.Actdata);
caData.(Locations{1}) = [];
caData.(Locations{2}) = [];
caData.(Locations{3}) = [];
caData.(Locations{4}) = [];
caData.(Locations{5})= [];
caData.(Locations{6}) =[];
caData.(Locations{7}) =[];
caData.(Locations{8}) = [];

for ii = 1:length(FoldCont)
    FullPathIn = fullfile(InFolder,FoldCont(ii).name);
    load(FullPathIn)
    caData.(Locations{1}) =  [caData.(Locations{1}),data.Actdata.(Locations{1})];
    caData.(Locations{2}) =  [caData.(Locations{2}),data.Actdata.(Locations{2})];
    caData.(Locations{3}) =  [caData.(Locations{3}),data.Actdata.(Locations{3})];
    caData.(Locations{4}) =  [caData.(Locations{4}),data.Actdata.(Locations{4})];
    caData.(Locations{5}) =  [caData.(Locations{5}),data.Actdata.(Locations{5})];
    caData.(Locations{6}) =  [caData.(Locations{6}),data.Actdata.(Locations{6})];
    caData.(Locations{7}) =  [caData.(Locations{7}),data.Actdata.(Locations{7})];
    caData.(Locations{8}) =  [caData.(Locations{8}),data.Actdata.(Locations{8})];
    
end

%% %%%%%%%%% filtering jumps in the signal %%%%%%%%%
thresh = 0.1;
for kk = 1:length(Locations)
    MergedSig = caData.(Locations{kk})';
    MergedSigFilt = MergedSig;
    [mrow, mcol] = find(MergedSig > thresh | MergedSig < -thresh) ;
    for jj = 1:length(mrow)
        try
            MergedSigFilt(mrow(jj),mcol(jj)) = MergedSigFilt(mrow(jj),mcol(jj)-1);
        catch
        end
    end
    caDataFilt.(Locations{kk}) = MergedSigFilt;
    caDataMean.(Locations{kk}) = mean(MergedSigFilt);
    caDataStdErr.(Locations{kk}) = std(MergedSigFilt)/sqrt(size(MergedSigFilt,1));
end
end