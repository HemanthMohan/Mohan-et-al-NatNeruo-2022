clear all; close all; clc
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
load('F:\Hemanth_CSHL\WideField\Data\cmap1.mat');
%% Inser path
liftPath_fez = 'G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\MeanActivityAroundPIM\FezF2Ai148_MeanActivityAroudPIM_Full.mat';
liftPath_plex = 'G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\MeanActivityAroundPIM\PlexinD1Ai148_MeanActivityAroudPIM_Full.mat';
noliftPath_fez = 'G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\MeanActivityAroundPIM_HandBlocked\FezF2Ai148_MeanActivityAroudPIM.mat';
noliftPath_plex = 'G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\MeanActivityAroundPIM_HandBlocked\PlexinD1Ai148_MeanActivityAroudPIM.mat';
%% %%%%%%%%% load data
lift_fez = load(liftPath_fez);lift_fez = lift_fez.data;
lift_plex = load(liftPath_plex);lift_plex = lift_plex.data;
nolift_fez = load(noliftPath_fez);nolift_fez = nolift_fez.data;
nolift_plex = load(noliftPath_plex);nolift_plex = nolift_plex.data;
%% Load allen Data
dmap = lift_fez.dorsalMap;
%% parameters for plotting
timeBeforePim = 0;%%%% duration to consider before pim onset. Should be less that the duration used for meanSequence
timeAfterPim = 1;%%%% duraiong to consider after pim onset. Should be less that the duration used for meanSequence
%% calculatin mean image
seqTm = linspace(-lift_fez.durBeforeOnset,lift_fez.durAfterOnset,size(lift_fez.meanFlow,3));
useIdx = find(seqTm>= -1*timeBeforePim &  seqTm<=timeAfterPim);%% indexs used to make mean image;
lift_fezAct = squeeze(nanmean(lift_fez.meanFlowAll(:,:,useIdx,:),3));
nolift_fezAct =squeeze( nanmean(nolift_fez.meanFlowAll(:,:,useIdx,:),3));
lift_plexAct = squeeze(nanmean(lift_plex.meanFlowAll(:,:,useIdx,:),3));
nolift_plexAct = squeeze(nanmean(nolift_plex.meanFlowAll(:,:,useIdx,:),3));
liftNolift_fezMn = nanmean(lift_fezAct,3) - nanmean(nolift_fezAct,3);
liftNolift_plexMn = nanmean(lift_plexAct,3) - nanmean(nolift_plexAct,3);
%% pefrom FDR correnction for statitical maps
mapSz_liftFez = size(lift_fezAct);
mapSz_noliftFez = size(nolift_fezAct);

mapSz_liftPlex = size(lift_plexAct);
mapSz_noliftPlex = size(nolift_plexAct);


liftFezMap = reshape(lift_fezAct,mapSz_liftFez(1)*mapSz_liftFez(2),mapSz_liftFez(3))';
noliftFezMap = reshape(nolift_fezAct,mapSz_noliftFez(1)*mapSz_noliftFez(2),mapSz_noliftFez(3))';
liftPlexMap = reshape(lift_plexAct,mapSz_liftPlex(1)*mapSz_liftPlex(2),mapSz_liftPlex(3))';
noliftPlexMap = reshape(nolift_plexAct,mapSz_noliftPlex(1)*mapSz_noliftPlex(2),mapSz_noliftPlex(3))';



parfor ii = 1:size(liftFezMap,2)
    [pVal_Fez(1,ii)] = ranksum(liftFezMap(:,ii),noliftFezMap(:,ii));
    [pVal_Plex(1,ii)] = ranksum(liftPlexMap(:,ii),noliftPlexMap(:,ii));
%     [~,pVal_Fez(1,ii)] = ttest2(liftFezMap(:,ii),noliftFezMap(:,ii));
%     [~,pVal_Plex(1,ii)] = ttest2(liftPlexMap(:,ii),noliftPlexMap(:,ii));
    
end
pVal_FezMap = reshape(pVal_Fez,mapSz_liftFez(1),mapSz_liftFez(2));
pVal_PlexMap = reshape(pVal_Plex,mapSz_liftPlex(1),mapSz_liftPlex(2));
%% %%% calculate the false discovery reate
q_fdr = 0.05; %% set the acceptable false discovery rate
[~,pCrt_fez] = fdr_bh(pVal_Fez,q_fdr); %% alternate fdr_bh function
[~,pCrt_plex] = fdr_bh(pVal_Plex,q_fdr); %% alternate fdr_bh function
%% generate pval Mazk
pMask_fez = pVal_FezMap<pCrt_fez;
pMask_plex = pVal_PlexMap<pCrt_plex;
%% difference map after threhsolding
liftNolift_fezMn_th = liftNolift_fezMn.*pMask_fez;
liftNolift_plexMn_th = liftNolift_plexMn.*pMask_plex;
%% Plot actual maps
close all
h1 = figure; h1.Position = [101   203   866   784];
imScl1 = [-0.025 0.025];
subplot(2,2,1)
imagesc(nanmean(lift_fezAct,3),imScl1); axis image; colormap(cmap); colorbar
hold on
for p = 1:length(dmap.edgeOutlineSplit)
    plot( dmap.edgeOutlineSplit{p}(:, 2),dmap.edgeOutlineSplit{p}(:, 1),'color','w','LineWidth',0.5);
end
title('Mean FezF2 Lift')

subplot(2,2,2)
imagesc(nanmean(nolift_fezAct,3),imScl1); axis image; colormap(cmap); colorbar
hold on
for p = 1:length(dmap.edgeOutlineSplit)
    plot( dmap.edgeOutlineSplit{p}(:, 2),dmap.edgeOutlineSplit{p}(:, 1),'color','w','LineWidth',0.5);
end
title('Mean FezF2 No Lift')

subplot(2,2,3)
imagesc(nanmean(lift_plexAct,3),imScl1); axis image; colormap(cmap); colorbar
hold on
for p = 1:length(dmap.edgeOutlineSplit)
    plot( dmap.edgeOutlineSplit{p}(:, 2),dmap.edgeOutlineSplit{p}(:, 1),'color','w','LineWidth',0.5);
end
title('Mean PlexinD1 Lift')

subplot(2,2,4)
imagesc(nanmean(nolift_plexAct,3),imScl1); axis image; colormap(cmap); colorbar
hold on
for p = 1:length(dmap.edgeOutlineSplit)
    plot( dmap.edgeOutlineSplit{p}(:, 2),dmap.edgeOutlineSplit{p}(:, 1),'color','w','LineWidth',0.5);
end
title('Mean PlexinD1 No Lift')
sgtitle(['pellet in mouth Dur: ' num2str(timeBeforePim) ' sec before to ' num2str(timeAfterPim ) ' sec after' ])
%% %%%%%%%%%% plot difference maps
imScl2 = [-0.012 0.012];
h2 = figure; h2.Position = [101 390 1353 679];
subplot(1,2,1)
imagesc(liftNolift_fezMn_th,imScl2); axis image; colormap(cmap); colorbar
hold on
for p = 1:length(dmap.edgeOutlineSplit)
    plot( dmap.edgeOutlineSplit{p}(:, 2),dmap.edgeOutlineSplit{p}(:, 1),'color','w','LineWidth',0.5);
end
title('Mean FezF2 Lift - No Lift')
axis(gca,2*[12 280 44 268])

subplot(1,2,2)
imagesc(liftNolift_plexMn_th,imScl2); axis image; colormap(cmap); colorbar
hold on
for p = 1:length(dmap.edgeOutlineSplit)
    plot( dmap.edgeOutlineSplit{p}(:, 2),dmap.edgeOutlineSplit{p}(:, 1),'color','w','LineWidth',0.5);
end
title('Mean PlexinD1 Lift - No Lift')
axis(gca,2*[12 280 44 268])

sgtitle(['pixels above pCritical identifyied by FDR = 0.05'])
annotation(h2,'textbox', [0, 0.99, 0, 0], 'string', [lift_fez.foldersAnalyzed; lift_plex.foldersAnalyzed],'FontSize',7, 'Interpreter', 'none')
annotation(h2,'textbox', [0.88, 0.99, 0, 0], 'string', [nolift_fez.foldersAnalyzed; nolift_plex.foldersAnalyzed],'FontSize',7, 'Interpreter', 'none')

%% Saving the mean image %%%%%%
saveFolder = 'G:\Hemanth_CSHL\WideField\Data_Figures\Spatial Dimensions\LiftNoLiftAfterPimDifference\';
fileName1 = ['LiftNoLiftAfterPIM_meanImage.fig'];
fileName2 = ['LiftMinusNoLiftAfterPIM_meanImageFDRCorrection.fig'];
savePath1 = fullfile(saveFolder,fileName1);
savePath2 = fullfile(saveFolder,fileName2);

saveFig = input('Do you want to save the current figure : ');
if saveFig == 1
    savefig(h1,savePath1)
    saveas(h1,[savePath1(1:end-4) '.svg']);
    savefig(h2,savePath2)
    saveas(h2,[savePath2(1:end-4) '.svg']);
end
