clear all; close all; clc
load('F:\Hemanth_CSHL\WideField\Data\cmap3.mat');
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
%% %%%%%%%%%%%%%% Enter the path foranalysis %%%%%%%%%%%%%%%%%%
%%%%%%%% REMOVE FORWARD SLASH IN THE LAST %%%%%%%%%%%%%
InFolder = 'G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\BehaviorEventsRegressionMapData\FezF2Ai148'; %% no slash in the last
FoldCont = dir(fullfile(InFolder,['*_regressionData.mat']));
for ii = 1:length(FoldCont)
    FolderNames{ii,1} = FoldCont(ii).name(1:end-19);
end
sampData = load(fullfile(InFolder,FoldCont(1).name));sampData = sampData.data;
AskSaving = 1; %%%%%%%%% 1 To ask the saving plot question. 0 to avoid saving
%% Sample dorsal map and mask path
dmName = ['20190118_PlexinD1Ai148_c1m2_dorsalMap.mat'];
fpath = 'G:\Hemanth_CSHL\WideField\Data_Corrected\20190118_PlexinD1Ai148_c1m2';
load(fullfile(fpath,dmName));
dmMap = dorsalMaps.edgeOutlineSplit;
redRat = sampData.redRat;
%% extract predictor names
for ii = 1:length(sampData.PredictorVar)
    varNames{ii} = sampData.PredictorVar{ii}(find(~isspace(sampData.PredictorVar{ii})));
end
%% %%%%%%%%%%%%%% Extract relevant data

betaMaps = [];
data = [];
for ii = 1:length(FoldCont)
    data = load(fullfile(InFolder,FoldCont(ii).name));data = data.data;
    for jj = 1:length(varNames)
    betaMaps.(varNames{jj})(:,:,ii) = data.betaMaps(:,:,jj);
    end
end
betaMapsMean = [];

for jj = 1:length(varNames)
    betaMapsMean.(varNames{jj}) = mean(betaMaps.(varNames{jj}),3);
end

%% plotting data
close all
redRat = data.redRat;
h1 = figure; h1.Position = [81 558 1770 420];
for jj = 1:length(varNames)
    ax(jj) = subplot(1,5,jj);
    imScl = [-max(betaMapsMean.(varNames{jj})(:)) max(betaMapsMean.(varNames{jj})(:)) ];
    imagesc(betaMapsMean.(varNames{jj}),imScl); axis image; colormap(cmap2); colorbar
    hold on
for p = 1:length(dorsalMaps.edgeOutlineSplit)
    plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','w');
end
hold off
title(varNames{jj})
end

sgtitle(sampData.MouseID(10:end),'interpreter','none')
annotation(h1,'textbox', [0, 0.8, 0, 0], 'string', FolderNames,'FontSize',7, 'Interpreter', 'none')

colormap(ax(1),cmap2)

%% Saving the figures
[~,MouseType] = fileparts(InFolder);
if AskSaving == 1
    %%%%%%%%% Generate the path to save the plots %%%%%%%%%%
    SavePath = 'G:\Hemanth_CSHL\WideField\Data_Figures\Spatial Dimensions\BehaviorEventRegressionMaps';
    saveFname = [MouseType '_BehavEvent_regWeightMaps'];
    wantSave = input('Do you want to save Figures Enter (Yes = 1, No = 0) : ');
    if wantSave == 1
        saveas(h1,fullfile(SavePath,saveFname),'fig');
        saveas(h1,fullfile(SavePath,saveFname),'svg');
    end
end
