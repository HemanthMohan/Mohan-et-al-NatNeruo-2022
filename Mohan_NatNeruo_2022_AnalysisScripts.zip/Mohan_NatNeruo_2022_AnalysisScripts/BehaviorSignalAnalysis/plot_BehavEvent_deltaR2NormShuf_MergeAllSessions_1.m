clear all; close all; clc
load('F:\Hemanth_CSHL\WideField\Data\cmap3.mat');
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
%% %%%%%%%%%%%%%% Enter the path foranalysis %%%%%%%%%%%%%%%%%%
%%%%%%%% REMOVE FORWARD SLASH IN THE LAST %%%%%%%%%%%%%
InFolder = 'G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\BehaviorEventsRegressionMapData\PlexinD1Ai148'; %% no slash in the last
FoldCont = dir(fullfile(InFolder,['*_regressionData.mat']));
for ii = 1:length(FoldCont)
    FolderNames{ii,1} = FoldCont(ii).name(1:end-19);
end
sampData = load(fullfile(InFolder,FoldCont(1).name));sampData = sampData.data;
AskSaving = 1; %%%%%%%%% 1 To ask the saving plot question. 0 to avoid saving
%% extract predictor names
for ii = 1:length(sampData.PredictorVar)
    varNames{ii} = sampData.PredictorVar{ii}(find(~isspace(sampData.PredictorVar{ii})));
end
%% %%%%%%%%%%%%%% Extract relevant data

deltaR2 = [];
data = [];
for ii = 1:length(FoldCont)
    data = load(fullfile(InFolder,FoldCont(ii).name));data = data.data;
    deltaR2 = [deltaR2; data.deltaR2];
end
%% get p value
for ii = 1:size(deltaR2,2)
    pVal(1,ii) = length(find(deltaR2(:,ii)<0)) / size(deltaR2,1);
    pVal_signtest(1,ii) = signrank(deltaR2(:,ii));
end
%% plotting data
[~,MouseType] = fileparts(InFolder);
close all
h1 = figure;
boxplot(deltaR2,'Labels',varNames)
ylabel('deltaR2')
sgtitle(['control - shuffled R2 ' MouseType],'interpreter','none')
annotation(h1,'textbox', [0, 0.8, 0, 0], 'string', FolderNames,'FontSize',7, 'Interpreter', 'none')
text(2,20,varNames')
text(4,20,num2str(pVal'))
text(3,26,'pValue')
set(gca,'YLim',[-1,40])

%% Saving the figures
[~,MouseType] = fileparts(InFolder);
if AskSaving == 1
    %%%%%%%%% Generate the path to save the plots %%%%%%%%%%
    SavePath = 'G:\Hemanth_CSHL\WideField\Data_Figures\Spatial Dimensions\BehaviorEventRegressionMaps';
    saveFname = [MouseType '_BehavEvent_deltaR2'];
    wantSave = input('Do you want to save Figures Enter (Yes = 1, No = 0) : ');
    if wantSave == 1
        saveas(h1,fullfile(SavePath,saveFname),'fig');
        saveas(h1,fullfile(SavePath,saveFname),'svg');
    end
end
