clear all; close all; clc
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
load('F:\Hemanth_CSHL\WideField\Data\cmap3.mat');
AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.
%% Load all folders for analysis 
textFilePath = 'G:\Hemanth_CSHL\WideField\Data_Analysis\readFolderPaths_withHandFeeding_Fez.txt'; %%% update the paths to the folder you are cuurently analysing
pathsIn = convertPathsToMatReadable(textFilePath);

disp('Make Sure that the Initial folder to save is Correct. ie HandLift or HandLiftBlocked or Lido..')
ErrorFoldsIdx = zeros(length(pathsIn),1);
tbeftrig = 1; %%% time before trigger in seconds
tafttrig = 2; %% time after trigger in seconds
fpathAnalyzed = [];
meanImAll = [];
meanFlowAll = [];
idsAnalyzed = {};
foldersAnalyzed = [];
tic
for jj = 1:size(pathsIn,1)
    fpath =[pathsIn{jj,1} '\'];
    try
        disp([ num2str(jj) '. ' fpath]);
        fpathAnalyzed = [fpathAnalyzed;fpath];
        [~,foldersAnalyzed{jj,1}] = fileparts(fileparts(fpath));
       [meanImAll(:,:,jj),meanFlowAll(:,:,:,jj),idsAnalyzed{jj,1}] = getMeanActivity(fpath,tbeftrig,tafttrig);
    catch
        ErrorFoldsIdx(jj) = 1;
        continue
    end
end
toc
meanIm = mean(meanImAll,3);
meanFlow = mean(meanFlowAll,4);
%% Plotting Maps %%%%%
fpathSamp = [pathsIn{1,1} '\'];
[fnFeat, usFeat ] = getFileNameProperties(fpathSamp);%%% get all fileNames variables
dmName = [fnFeat.sname_ex(1:usFeat.us_idx-5) 'dorsalMap.mat'];
load(fullfile(fnFeat.spath,dmName));
tform = dorsalMaps.tform;
h1 = figure;
imScl = [-0.02 0.02];
imagesc(meanIm(:,:,1),imScl); axis image; 
colormap(cmap2)
colorbar
hold on
for p = 1:length(dorsalMaps.edgeOutlineSplit)
    plot( dorsalMaps.edgeOutlineSplit{p}(:, 2),dorsalMaps.edgeOutlineSplit{p}(:, 1),'color','w','LineWidth',0.5);
end
%% playing the mean flow activity
PlayDff(meanFlow,0.02,'cmap2')
%%
data.meanIm = meanIm;
data.meanFlow = meanFlow;
data.meanFlowAll = meanFlowAll;
data.foldersAnalyzed = foldersAnalyzed;
data.pathsAnalyzed = fpathAnalyzed;
data.idsAnalyzed = idsAnalyzed;
data.durBeforeOnset = tbeftrig;
data.durAfterOnset = tafttrig;
data.dorsalMap = dorsalMaps;
%% %%%%%%%%%%%%%%%%% Saving the Data %%%%%%%%%%%%%%%
if contains(lower(fnFeat.sname_ex),'fezf')
    MouseType = 'FezF2Ai148';
elseif contains(lower(fnFeat.sname_ex),'plex')
    MouseType = 'PlexinD1Ai148';
elseif contains(lower(fnFeat.sname_ex),'tle4')
    MouseType = 'Tle4Ai148';
elseif contains(lower(fnFeat.sname_ex),'cba')
    MouseType = 'CBAAi93h';
else
    MouseType = input('What Mouse is this: ','s');
end
if AskSaving == 1
    filename = [MouseType '_MeanActivityAroudPIM.mat'];
    savepath = fullfile(['G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\MeanActivityAroundPIM'],filename);
    saveData = input('Do you want to save the Data ? : ');
    if saveData == 1
        save(savepath,'data','-v7.3');
    end
end
%% %%%%%%%%% Getting the mean image Activity %%%%%%%%%%%%%%%%
function [meanKernalFlat, meanKernalStack,IDsThatMadeIt] = getMeanActivity(fpath,tbeftrig,tafttrig)
%% %%%%%%%%%%%%%%%% get file  name structure %%%%%%%%%%%%
[fnFeat, usFeat ] = getFileNameProperties(fpath);%%% get all fileNames variables
%% %%%%%%%%%%%%%%% load allen dorasal map coordinates %%%%%
dmName = [fnFeat.sname_ex(1:usFeat.us_idx-5) 'dorsalMap.mat'];
load(fullfile(fnFeat.spath,dmName));
tform = dorsalMaps.tform;
%% %%%%%%%% loading mask file %%%%%%%%%
[~,maskFold] = fileparts(fnFeat.spath);
maskPath = fullfile(fileparts(fileparts(fnFeat.spath)),['Data'],maskFold);
roiMask = load(fullfile(maskPath,[fnFeat.sname_ex(1:find(fnFeat.sname_ex == '_',2,'last')) 'refMask.mat']));
%% %%%%%%%%%%%%%%% Get Handlift Behavior Trials %%%%%%%%%%%%%%%
disp('Extracting Behavior Temporal features .... ')
ExtractManipulaion = 0;%%%%% Enter zero to not extract manipulation times and 1 to extract
[BData] = GetBehavEventTimes(fpath,ExtractManipulaion); %%%%% Enter second input as zero to not extract manipulation times. The third variable is are the file ids to consider
HandLiftTrials = find(cell2mat(BData.Data(:,2)) == 1 & cell2mat(BData.Data(:,3)) == 1 & cell2mat(BData.Data(:,4)) == 1);
HandLiftFileIds = cell2mat(BData.Data(HandLiftTrials,1));
%% %%%%%%%%%%%%%%% Extract Task relevant Calcium frames %%%%%%
%%%%%% File ID and plottting variables %%%%%%%
SigFs = 30;
BehFs = 100;
ID = HandLiftFileIds;
sigTime = 0:1/SigFs:15; sigTime(end) = [];
behTime = 0:1/BehFs:15; behTime(end) = [];
trig_frms = tbeftrig*SigFs + tafttrig*SigFs;
trigCasig = [];
trigon_allFrms = [];
IDsThatMadeIt= []; %%%% ID's that made it to being plotted
firstIdx = str2num(fnFeat.sname_all{1,1}(end-4));
%% %%%%%%%%%%%%%% Signal Analysis %%%%%%%%%%%%%%%%%%%%%%%%%
for ii = 1:length(ID);
    %%%%%%%%% Extract Calcium Signal
    sname_in = [fnFeat.sname_ex(1:usFeat.us_idx) num2str(ID(ii)) '.mat'];
    CaSig_in = load(fullfile(fnFeat.spath,sname_in));
    %%%%% Extract Calcium Activity %%%%%%%
    CaSig = CaSig_in.dffV;
    %%%%%%%%% GET PIM ONSET TIME Onset  %%%%%%%%%%
    starttime_pim = cell2mat(BData.Data((ID(ii)- (firstIdx-1)),10)); %%% find lick start after 2 seconds of trial start
    startidx_pim = find(sigTime >= starttime_pim,1);
    %%%%%%%%%%%%%%% Plot Body Signal if required
    if length(starttime_pim) < 1
        disp(' COULD NOT FIND PROPER PIM TIME ' )
        continue
    end
    %%%%%%%%%%%% Exract calcium activity %%%%%%%%%%%%%%%%
    caActIdx = [];
    caActIdxTemp = find(sigTime>starttime_pim-tbeftrig & sigTime<starttime_pim+tafttrig);
    if length(caActIdxTemp) < trig_frms
        continue
    else
        caActIdx = caActIdxTemp;
        IDsThatMadeIt = [IDsThatMadeIt;ID(ii)];
    end

    trigCasig_temp = CaSig(:,:,caActIdx(:));
    trigCasig = cat(4,trigCasig,trigCasig_temp);
end

%% %%%%%%%% Making Mean Activity Maps %%%%%%%%%%
meanKernalStack = imwarp(mean(trigCasig,4).* roiMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*dorsalMaps.maskScaled;
meanKernalFlat = mean(meanKernalStack,3);

end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Functions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




function [BEvent] = getBehaviorEvents(BData,Trials)
BEvent.PelletDrop = cell2mat(BData.Data(1,5));
BEvent.BeltStart = cell2mat(BData.Data(1,6));

%% %%%%%%% Generate Behavior Distribtuions for HandLift Trials %%%%%%%%%%%%
LickOnsetTime = cell2mat(BData.Data(Trials,9));
PIMOnsetTime = cell2mat(BData.Data(Trials,10));
HandLiftOnsetTime = cell2mat(BData.Data(Trials,11));
%% %%%%%%%%%% Generating behavior probabilites %%%%%%%%
bEdges = 0:0.2:15;
[lickCount lickEdges] = histcounts(LickOnsetTime,bEdges);
BEvent.lickProb = lickCount/ sum(lickCount);
BEvent.lickMedian = nanmedian(LickOnsetTime);

[pimCount pimEdges] = histcounts(PIMOnsetTime,bEdges);
BEvent.pimProb = pimCount/ sum(pimCount);
BEvent.pimMedian = nanmedian(PIMOnsetTime);

[handliftCount handliftEdges] = histcounts(HandLiftOnsetTime,bEdges);
BEvent.handliftProb = handliftCount/ sum(handliftCount);
BEvent.handliftMedian = nanmedian(HandLiftOnsetTime);

BEvent.pTime = bEdges;
end

function [fnFeat, usFeat ] = getFileNameProperties(fpath)
%%%%%%%%%%%%% getting signal file name %%%%%%%%%%%%%%
listing_csv = dir([fpath '\*.csv']);
[~, sflname] = fileparts(fileparts(fpath));
spath = fullfile(fileparts(fileparts(fileparts(fpath))), 'Data_Corrected', sflname);
listing_sig = dir([spath '\*.mat']);
sname_all = natsortfiles({listing_sig.name}');
sname_ex = sname_all{1};
us_idx = find(sname_ex == '_',1,'last');

%%%%%%%% getting body trajectory file name %%%%%%%%%%%%
fname_all = natsortfiles({listing_csv.name}');
fname_allC1 = fname_all( contains(fname_all,'c1_T'));
fname_allC2 = fname_all( contains(fname_all,'c2_T'));

fname_exC1 = fname_allC1{1};
fname_us_idxC1 = find(fname_exC1 == '_');
fname_deep_idxC1 = strfind(fname_exC1, 'Deep');
bidx_stC1 = fname_us_idxC1(end-4);
bidx_endC1 = fname_deep_idxC1;

fname_exC2 = fname_allC2{1};
fname_us_idxC2 = find(fname_exC2 == '_');
fname_deep_idxC2 = strfind(fname_exC2, 'Deep');
bidx_stC2 = fname_us_idxC2(end-4);
bidx_endC2 = fname_deep_idxC2;


%%% updating all properties
fnFeat.sname_all = sname_all;
fnFeat.fname_allC1 = fname_allC1;
fnFeat.fname_allC2 = fname_allC2;
fnFeat.sname_ex = sname_ex;
fnFeat.fname_exC1 = fname_exC1;
fnFeat.fname_exC2 = fname_exC2;
fnFeat.spath = spath;

usFeat.us_idx = us_idx;
usFeat.bidx_stC1 = bidx_stC1;
usFeat.bidx_endC1 = bidx_endC1;
usFeat.bidx_stC2 = bidx_stC2;
usFeat.bidx_endC2 = bidx_endC2;
end




