clear all; close all; clc
[fname,fpath]= uigetfile('G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\MeanActivityAroundPIM\*.mat');
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
load('F:\Hemanth_CSHL\WideField\Data\cmap3.mat');
load(fullfile(fpath,fname));
askSaving = 1;
%% parameters for plotting
timeBeforePim = 1;%%%% duration to consider before pim onset. Should be less that the duration used for meanSequence
timeAfterPim = 2;%%%% duraiong to consider after pim onset. Should be less that the duration used for meanSequence
%% Load reuired Data
dorsalMaps = data.dorsalMap;
meanSeq = data.meanFlow;
foldersAnalyzed = data.foldersAnalyzed;
%% calculatin mean image
seqTm = linspace(-1*data.durBeforeOnset,data.durAfterOnset,size(meanSeq,3));
useIdx = find(seqTm>= -1*timeBeforePim &  seqTm<=timeAfterPim);%% indexs used to make mean image;
meanImg = mean(meanSeq(:,:,useIdx),3);
meanImgNm = meanImg./max(meanImg(:));
% %
imScl = [-0.01 0.011];
nmScl = [-1 1];
h1 = figure;
h1.Position = [10 10 1070 420];
ax(1) = subplot(1,2,1);
imagesc(meanImg,imScl)
axis image
colormap(cmap2); colorbar
hold on
for p = 1:length(dorsalMaps.edgeOutlineSplit)
    plot( dorsalMaps.edgeOutlineSplit{p}(:, 2),dorsalMaps.edgeOutlineSplit{p}(:, 1),'color','w','LineWidth',0.5);
end
title('df/f')

ax(2) = subplot(1,2,2);
imagesc(meanImgNm,nmScl)
axis image
colormap(cmap2); colorbar
hold on
for p = 1:length(dorsalMaps.edgeOutlineSplit)
    plot( dorsalMaps.edgeOutlineSplit{p}(:, 2),dorsalMaps.edgeOutlineSplit{p}(:, 1),'color','w','LineWidth',0.5);
end
annotation(h1,'textbox', [0, 1, 0, 0], 'string', foldersAnalyzed,'FontSize',7, 'Interpreter', 'none');
title('Max normalized')
ax(1).XLim = [26 562]; ax(1).YLim = [92 537]; ax(2).XLim = [26 562]; ax(2).YLim = [92 537];
%% Saving the mean image %%%%%%
saveFolder = 'G:\Hemanth_CSHL\WideField\Data_Figures\Spatial Dimensions\MeanMaps\FeedingSequence\AllenFovRegistered\';
fileName = [fname(1:end-4) '_meanImage.fig'];
savePath = fullfile(saveFolder,fileName);
if askSaving == 1
    saveFig = input('Do you want to save the current figure : ');
    if saveFig == 1
        savefig(h1,savePath)
        saveas(h1,[savePath(1:end-4) '.svg']);
    end
end