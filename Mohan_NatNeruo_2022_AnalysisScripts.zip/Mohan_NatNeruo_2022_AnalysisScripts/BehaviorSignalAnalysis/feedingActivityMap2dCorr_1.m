clear all; close all; clc;
%% Load Data
plexData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\MeanActivityAroundPIM\PlexinD1Ai148_MeanActivityAroudPIM_Full.mat');
plexData = plexData.data;
fezData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\MeanActivityAroundPIM\FezF2Ai148_MeanActivityAroudPIM_Full.mat');
fezData = fezData.data;
%% extract variance maps
meanMaps_plex = squeeze(mean(plexData.meanFlowAll,3));
meanMaps_fez = squeeze(mean(fezData.meanFlowAll,3));

meanMaps_plex(find(meanMaps_plex==0)) = NaN;
meanMaps_fez(find(meanMaps_fez==0)) = NaN;

numSes_plex = length(plexData.foldersAnalyzed);
numSes_fez = length(fezData.foldersAnalyzed);
%% perform 2D Correlaions within and between types
ccIdx_plex = nchoosek([1:numSes_plex],2);
ccIdx_fez = nchoosek([1:numSes_fez],2);
for ii = 1:length(ccIdx_plex)
    cc_plex(ii,1) = corr(reshape(meanMaps_plex(:,:,ccIdx_plex(ii,1)),[],1), reshape(meanMaps_plex(:,:,ccIdx_plex(ii,2)),[],1),'Rows','complete');
end

for ii = 1:length(ccIdx_fez)
    cc_fez(ii,1) = corr(reshape(meanMaps_fez(:,:,ccIdx_fez(ii,1)),[],1), reshape(meanMaps_fez(:,:,ccIdx_fez(ii,2)),[],1),'Rows','complete');
end

for ii =1:numSes_plex
    for jj = 1:numSes_fez
        cc_plexfezMat(ii,jj) = corr(reshape(meanMaps_plex(:,:,ii),[],1), reshape(meanMaps_fez(:,:,jj),[],1),'Rows','complete');
    end
end
cc_plexfez = cc_plexfezMat(:);

%% Perform Stats
pCnt = length(cc_plex);
fCnt = length(cc_fez);
pfCnt = length(cc_plexfez);
grpId = [repmat({'plexVsPlex'},pCnt,1);repmat({'fezVsfez'},fCnt,1);repmat({'plexVsfez'},pfCnt,1) ];

[kw_p,~,stats] = kruskalwallis([cc_plex;cc_fez;cc_plexfez],grpId);
[mComp,~,~,gnames] = multcompare(stats);


statsText = "KruskalWallisTest" + newline + ...
    gnames{mComp(1,1)} + " VS " + gnames{mComp(1,2)} + " = " + num2str(mComp(1,6)) + ...
    newline + gnames{mComp(2,1)} + " VS " + gnames{mComp(2,2)} + " = " + num2str(mComp(2,6)) + ...
    newline + gnames{mComp(3,1)} + " VS " + gnames{mComp(3,2)} + " = " + num2str(mComp(3,6));

%% %%%%%%%%%%% plotting the distribution
h1 = figure; h1.Position = [228   498   568   480];
boxplot([cc_plex;cc_fez;cc_plexfez],grpId)
ylabel('corr coef')
title (' Feeing onset activity map 2D Correlation')

annotation(h1,'textbox', [0, 0.95, 0, 0], 'string', statsText,'FontSize',8)
% annotation(h2,'textbox', [0, 0.99, 0, 0], 'string', [lift_fez.foldersAnalyzed; lift_plex.foldersAnalyzed],'FontSize',7, 'Interpreter', 'none')
%% %%%%%%%%%%%%% saving the figures %%%%%%%%%%

saveFolder = 'G:\Hemanth_CSHL\WideField\Data_Figures\ActivityPlots\AllenMaskROIAnalysis\FeedingActMapsCorrelation\';
fileName1 = ['FeedingActivitySimilarity2DCorrelations.fig'];
savePath1 = fullfile(saveFolder,fileName1);
saveFig = input('Do you want to save the current figure : ');
if saveFig == 1
    savefig(h1,savePath1)
    saveas(h1,[savePath1(1:end-4) '.svg']);
end