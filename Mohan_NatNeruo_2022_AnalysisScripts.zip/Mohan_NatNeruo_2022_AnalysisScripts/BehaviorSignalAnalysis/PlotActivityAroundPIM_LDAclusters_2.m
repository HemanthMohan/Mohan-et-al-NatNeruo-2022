clear all; close all; clc
%% %%%%%%%%%%%%%% Enter the path fro analysis %%%%%%%%%%%%%%%%%%
%%%%%%%% PUT FORWARD SLASH IN THE LAST %%%%%%%%%%%%%
InFolderPlex = 'G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\MaskRoiSelectionAnalysis\NoCorrection\HandLiftTrials\PelletInMOuthOnset\PlexinD1Ai148\'; %% put slash in the last
InFolderFez = 'G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\MaskRoiSelectionAnalysis\NoCorrection\HandLiftTrials\PelletInMOuthOnset\FezF2Ai148\'; %% put slash in the last
FoldContPlex = dir(fullfile(InFolderPlex,['*.mat']));
FoldContFez = dir(fullfile(InFolderFez,['*.mat']));
sampDataPlex = load(fullfile(InFolderPlex,FoldContPlex(1).name));
sampDataFez = load(fullfile(InFolderFez,FoldContFez(1).name));
AskSaving = 1; %%%%%%%%% 1 To ask the saving plot question. 0 to avoid saving
[~,TrialType] = fileparts(fileparts(fileparts(InFolderPlex)));; %%%%%%% Trial Type for titles

%% %%%%%%%%%% Extracting the Data from each file  %%%%%%%%
[caDataPlex,caDataFiltPlex] = GetCaData(InFolderPlex,FoldContPlex,sampDataPlex);
[caDataFez,caDataFiltFez] = GetCaData(InFolderFez,FoldContFez,sampDataFez);
%% %%%%%%%%%%%%%%%%%%%% Create ROI specific signal matrix %%%%%%%%%%%%%%%%
roiNames = fieldnames(sampDataPlex.data.Actdata);
actTime = sampDataPlex.data.actTime;
plexSz = size(caDataFiltPlex.leftParietal);
fezSz = size(caDataFiltFez.leftParietal);
caDataPlexFez = [];
for ii = 1:length(roiNames)
caDataPlexFez.(roiNames{ii}) = [caDataFiltPlex.(roiNames{ii});caDataFiltFez.(roiNames{ii})];
end
plexFezId = [zeros(plexSz(1),1);ones(fezSz(1),1)];
plexFezIdShuf = plexFezId(randperm(length(plexFezId))');
%% %%%%%%%%%%% make LDA clusters
for ii = 1:length(roiNames)
% coeff.(roiNames{ii}) = LDA(caDataPlexFez.(roiNames{ii}),plexFezId);
coeff.(roiNames{ii}) = LDA(caDataPlexFez.(roiNames{ii}),plexFezId);
score.(roiNames{ii}) = [ones(length(plexFezId),1) caDataPlexFez.(roiNames{ii})]*coeff.(roiNames{ii})';
end
%% %%%%%%%%%% Plot Clusters %%%%%%
close all
clustIds = [repmat({'Plex'},plexSz(1),1);repmat({'Fez'},fezSz(1),1)];
h1 = figure; h1.Position = [27  272  1463 623];
for ii = 1:length(roiNames)
    ax(ii) = subplot(2,4,ii);
    gscatter(score.(roiNames{ii})(:,1) , score.(roiNames{ii})(:,2),clustIds)
    axis square
    title(roiNames{ii})
    xlabel('LDA Dim 1')
    ylabel('LDA Dim 2')
end

annotation(h1,'textbox', [0, 0.95, 0, 0], 'string', [{FoldContFez.name}';{FoldContPlex.name}'] ,'FontSize',7, 'Interpreter', 'none')
%% %%%%%%%%%%%%%%%%%%%%% Saving the plots %%%%%%%%%%%%%%%%%%%%%%%%
if AskSaving == 1
%%%%%%%%% Generate the path to save the plots %%%%%%%%%%
PlotPath = 'G:\Hemanth_CSHL\WideField\Data_Figures\ActivityPlots\AllenMaskROIAnalysis\BehaviorEventActLDAclusters';
fileName = 'PIMOnsetLDAclusters'
fullPlotPath = fullfile(PlotPath,fileName);
%%%%%%%%%%%%%%%%% save the plots in the path %%%%%%%%%%%%
    wantSave = input('Do you want to save Figures Enter (Yes = 1, No = 0) : ');
    
    if wantSave == 1
        saveas(h1,fullPlotPath,'fig');
        saveas(h1,fullPlotPath,'svg');
    end
end
%%
% set(gcf,'Renderer','Painter')
% hgexport(gcf,'2D.eps');
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% FUNCTIONS %%%%%%%%%%%%%%%%%%%%%%%%%%

function [caData,caDataFilt,caDataMean,caDataStdErr] = GetCaData(InFolder,FoldCont,sampData)
Locations = fieldnames(sampData.data.Actdata);
caData.(Locations{1}) = [];
caData.(Locations{2}) = [];
caData.(Locations{3}) = [];
caData.(Locations{4}) = [];
caData.(Locations{5})= [];
caData.(Locations{6}) =[];
caData.(Locations{7}) =[];
caData.(Locations{8}) = [];

for ii = 1:length(FoldCont)
    FullPathIn = fullfile(InFolder,FoldCont(ii).name);
    load(FullPathIn)
    caData.(Locations{1}) =  [caData.(Locations{1}),data.Actdata.(Locations{1})];
    caData.(Locations{2}) =  [caData.(Locations{2}),data.Actdata.(Locations{2})];
    caData.(Locations{3}) =  [caData.(Locations{3}),data.Actdata.(Locations{3})];
    caData.(Locations{4}) =  [caData.(Locations{4}),data.Actdata.(Locations{4})];
    caData.(Locations{5}) =  [caData.(Locations{5}),data.Actdata.(Locations{5})];
    caData.(Locations{6}) =  [caData.(Locations{6}),data.Actdata.(Locations{6})];
    caData.(Locations{7}) =  [caData.(Locations{7}),data.Actdata.(Locations{7})];
    caData.(Locations{8}) =  [caData.(Locations{8}),data.Actdata.(Locations{8})];

end

%% %%%%%%%%% filtering jumps in the signal %%%%%%%%%
thresh = 0.1;
for kk = 1:length(Locations)
    MergedSig = caData.(Locations{kk})';
    MergedSigFilt = MergedSig;
    [mrow, mcol] = find(MergedSig > thresh | MergedSig < -thresh) ;
    for jj = 1:length(mrow)
        try
            MergedSigFilt(mrow(jj),mcol(jj)) = MergedSigFilt(mrow(jj),mcol(jj)-1);
        catch
        end
    end
    caDataFilt.(Locations{kk}) = MergedSigFilt;
    caDataMean.(Locations{kk}) = mean(MergedSigFilt);
    caDataStdErr.(Locations{kk}) = std(MergedSigFilt)/sqrt(size(MergedSigFilt,1));
end
end