clear all; close all; clc
[fname fpath] = uigetfile('*.csv');
%% get behavior time stamps 
[BData] = GetBehavEventTimes(fpath,1); 
%% %%%%%%%%%%%%%%%% get file  name structure %%%%%%%%%%%%
[fnFeat, usFeat ] = getFileNameProperties(fpath);%%% get all fileNames variables
%%
fileID = 40 ; %%%% which file do you want to plot
%% %%%%%%%%%%%% get behavior file paths
fnameinC1 = [fnFeat.fname_exC1(1:usFeat.bidx_stC1) num2str(fileID) fnFeat.fname_exC1(usFeat.bidx_endC1:end)];
fnameVidC1 = [fnFeat.fname_exC1(1:usFeat.bidx_stC1) num2str(fileID) '.mp4'];
filepathC1 = fullfile(fpath,fnameinC1);
vFilepathC1 = fullfile(fpath,fnameVidC1);

fnameinC2 = [fnFeat.fname_exC2(1:usFeat.bidx_stC2) num2str(fileID) fnFeat.fname_exC2(usFeat.bidx_endC2:end)];
fnameVidC2 = [fnFeat.fname_exC2(1:usFeat.bidx_stC2) num2str(fileID) '.mp4'];
filepathC2 = fullfile(fpath,fnameinC2);
vFilepathC2 = fullfile(fpath,fnameVidC2);
%% extract behavior event and manipulatin time stamps
rIdx = find(cell2mat(BData.Data(:,1))==fileID);
lickOnset = BData.Data{rIdx,9};
pimOnset = BData.Data{rIdx,10};
hlOnset = BData.Data{rIdx,11};
maniOnOff = BData.Data{rIdx,12};
%% load body tracjectories
BehFs = 100;
pcutoffC1 = 0.9; %%%% threshold for plotting behavior signal
pcutoffC2 = 0.8; %%%% threshold for plotting behavior signal
behTime = 0:1/BehFs:15; behTime(end) = [];
[TrajDataC1 BodyPartsC1] =  ExtractBodyTraj(filepathC1,pcutoffC1);
[TrajDataC2 BodyPartsC2] =  ExtractBodyTraj(filepathC2,pcutoffC2);
%% generate manipulation times signal
manDur = 0; %%%%%%%%% minimun duraion of manipulation in seconds to consider
manDelay = 0.5; %%%%%%%% min duration between handlift onset and maniulation onset signals to consider in seconds

manDiff = maniOnOff(:,2) - maniOnOff(:,1);
manTime = maniOnOff(find(manDiff>= manDur),:); %% only select long duration manipulations
manTime(find(manTime(:,1) <= hlOnset + manDelay),:) = []; %%% delete manipulaitons close to hand lift events
manSig = zeros(length(behTime),1);
for mm = 1:size(manTime,1)
    manSig(behTime>manTime(mm,1) & behTime<manTime(mm,2)) = 1; %%% manipulatino indices
end
%% get and generate chew signal
chewPrm.stdThresh = 0.1; %% def 0.1 for chew time signal
chewPrm.freqRange = [4,7]; %% def [4,7] for chew time signal
chewPrm.Fs = BehFs; %%% minimun duration of chew in seconds
minChewDur = 0.5; %%% minimun duration of chew in seconds def 0.5
lowerlipY = TrajDataC1.lowerlip(:,2);
[chewTime] =  getChewTimes2(lowerlipY,chewPrm)';
chewTime(find((chewTime(:,2) - chewTime(:,1))<minChewDur),:) = []; %% delete short duration chews
chewTime = chewTime(find(chewTime(:,1)>hlOnset),:); %% find chews after hand lift
chewSig = zeros(length(behTime),1);
for cc = 1:size(chewTime,1)
    chewSig(behTime>chewTime(cc,1) & behTime<chewTime(cc,2)) = 1; %%% manipulatino indices
end

%%
close all
h1 = figure;
hold on
area(behTime,manSig*500,'FaceColor','cyan','FaceAlpha',0.5,'EdgeColor','none') %%% plot manipualtion area

area(behTime,chewSig*500,'FaceColor','g','FaceAlpha',0.5,'EdgeColor','none')%%% plot chew area

idx2pltC2 = [3]
for ii = 1:length(idx2pltC2)
plot(behTime, TrajDataC2.(BodyPartsC2{idx2pltC2(ii)})(:,2))
end


idx2pltC1 = [1,3,4,5]
for ii = 1:length(idx2pltC1)
plot(behTime, TrajDataC1.(BodyPartsC1{idx2pltC1(ii)})(:,2))
end

plot([1.7 1.7],[0,500],'-')
plot([2.7 2.7],[0,500],'-')
plot([lickOnset lickOnset],[0,500],'-')
plot([pimOnset pimOnset],[0,500],'-')
plot([hlOnset hlOnset],[0,500],'-')

set(gca,'YDir','reverse')
legend(['Manipulation';'Chewing';BodyPartsC2(idx2pltC2);BodyPartsC1(idx2pltC1);'Pellet Drop';'Belt Start';'Lick Onset';'pim Onset';'handlift Onset'])

%% %%%%%%%%%%%%%%%%%%%%% Saving the plots %%%%%%%%%%%%%%%%%%%%%%%%

    %%%%%%%%% Generate the path to save the plots %%%%%%%%%%
    saveFolder = 'G:\Hemanth_CSHL\WideField\Data_Figures\ActivityPlots\AllenMaskROIAnalysis\SingleTrialBehaivorTraj';
    saveFname = [fnFeat.fname_exC1(1:usFeat.bidx_stC1) num2str(fileID) '_behavTraj'];
    wantSave = input('Do you want to save Figures Enter (Yes = 1, No = 0) : ');
    if wantSave == 1
        saveas(h1,fullfile(saveFolder,saveFname),'fig');
        saveas(h1,fullfile(saveFolder,saveFname),'svg');
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Functions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [fnFeat, usFeat ] = getFileNameProperties(fpath)
%%%%%%%%%%%%% getting signal file name %%%%%%%%%%%%%%
listing_csv = dir([fpath '\*.csv']);
[~, sflname] = fileparts(fileparts(fpath));
spath = fullfile(fileparts(fileparts(fileparts(fpath))), 'Data_Corrected', sflname);
listing_sig = dir([spath '\*.mat']);
sname_all = natsortfiles({listing_sig.name}');
sname_ex = sname_all{1};
us_idx = find(sname_ex == '_',1,'last');

%%%%%%%% getting body trajectory file name %%%%%%%%%%%%
fname_all = natsortfiles({listing_csv.name}');
fname_allC1 = fname_all( contains(fname_all,'c1_T'));
fname_allC2 = fname_all( contains(fname_all,'c2_T'));

fname_exC1 = fname_allC1{1};
fname_us_idxC1 = find(fname_exC1 == '_');
fname_deep_idxC1 = strfind(fname_exC1, 'Deep');
bidx_stC1 = fname_us_idxC1(end-4);
bidx_endC1 = fname_deep_idxC1;

fname_exC2 = fname_allC2{1};
fname_us_idxC2 = find(fname_exC2 == '_');
fname_deep_idxC2 = strfind(fname_exC2, 'Deep');
bidx_stC2 = fname_us_idxC2(end-4);
bidx_endC2 = fname_deep_idxC2;


%%% updating all properties
fnFeat.sname_all = sname_all;
fnFeat.fname_allC1 = fname_allC1;
fnFeat.fname_allC2 = fname_allC2;
fnFeat.sname_ex = sname_ex;
fnFeat.fname_exC1 = fname_exC1;
fnFeat.fname_exC2 = fname_exC2;
fnFeat.spath = spath;

usFeat.us_idx = us_idx;
usFeat.bidx_stC1 = bidx_stC1;
usFeat.bidx_endC1 = bidx_endC1;
usFeat.bidx_stC2 = bidx_stC2;
usFeat.bidx_endC2 = bidx_endC2;
end