clear all; close all;clear  mem; clc
textFilePath = 'G:\Hemanth_CSHL\WideField\Data_Analysis\readFolderPaths_withHandFeeding_PlexFez.txt';
pathsIn = convertPathsToMatReadable(textFilePath);
%% Extract and save activity for each path
disp('Make Sure that the Initial folder to save is Correct. ie HandLift or HandLiftBlocked or Lido..')
ErrorFoldsIdx = zeros(length(pathsIn),1);
tic
for jj = 1:size(pathsIn,1)
    fpath =[pathsIn{jj,1} '\'];
    try
        ExtractAndSaveRegressionMaps(fpath)
    catch
        ErrorFoldsIdx(jj) = 1;
        continue
    end
end
toc
%% %%%%%%%%%%%%%%%%%%%%%% function %%%%%%%%
function ExtractAndSaveRegressionMaps(fpath)
%% %%%%%%%%%%%%%%%% get file  name structure %%%%%%%%%%%%
[fnFeat, usFeat ] = getFileNameProperties(fpath);%%% get all fileNames variables
%% %%%%%%%%%%%%%%% load ROI MASKS for analysis %%%%%%%%%%%%%%%%
maskData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\behaviorActivityRoiMasks.mat');
roiMasks = maskData.data.roiMasks;
%% %%%%%%%%%%%%%%% load allen dorasal map coordinates %%%%%
dmName = [fnFeat.sname_ex(1:usFeat.us_idx-5) 'dorsalMap.mat'];
load(fullfile(fnFeat.spath,dmName));
tform = dorsalMaps.tform;
%% %%%%%%%% loading mask file %%%%%%%%%
[~,fovMaskFold] = fileparts(fnFeat.spath);
fovMaskPath = fullfile(fileparts(fileparts(fnFeat.spath)),['Data'],fovMaskFold);
fovMask = load(fullfile(fovMaskPath,[fnFeat.sname_ex(1:find(fnFeat.sname_ex == '_',2,'last')) 'refMask.mat']));
%% %%%%%%%%%%%%%%% Get Handlift Behavior Trials %%%%%%%%%%%%%%%
disp('Extracting Behavior Temporal features .... ')
ExtractManipulaion = 1;%%%%% Enter zero to not extract manipulation times and 1 to extract
[BData] = GetBehavEventTimes(fpath,ExtractManipulaion); %%%%% Enter second input as zero to not extract manipulation times. The third variable is are the file ids to consider
HandLiftTrials = find(cell2mat(BData.Data(:,2)) == 1 & cell2mat(BData.Data(:,3)) == 1 & cell2mat(BData.Data(:,4)) == 1);
HandLiftFileIds = cell2mat(BData.Data(HandLiftTrials,1));

%% %%%%%%%%%%%%%%% Extract Task relevant Calcium frames %%%%%%
redRat = 0.5;
%%%%%% File ID and plottting variables %%%%%%%
SigFs = 30;
BehFs = 100;
ID = HandLiftFileIds;
plotBody = 1; %% Do you want to plot the body signal??
sigTime = 0:1/SigFs:15; sigTime(end) = [];
behTime = 0:1/BehFs:15; behTime(end) = [];
%%%%%%%%% manipulation filters
manDur = 0; %%%%%%%%% minimun duraion of manipulation in seconds to consider
manDelay = 0.5; %%%%%%%% min duration between handlift onset and maniulation onset signals to consider in seconds
%%%%%%%%%
pcutoffC1 = 0.9;
pcutoffC2 = 0.8;
IDsThatMadeIt = []; %%%% ID's that made it to being plotted
chewPrm.stdThresh = 0.05; %% def 0.1 for chew time signal
chewPrm.freqRange = [3,8]; %% def [4,7] for chew time signal
chewPrm.Fs = BehFs; %%% minimun duration of chew in seconds
minChewDur = 0.5; %%% minimun duration of chew in seconds
firstIdx = str2num(fnFeat.sname_all{1,1}(end-4));
%% %%%%%%%%%%%%%% extract Calcium Signal And relevant behvaior signals %%%%%%%%%%%%%%%%%%%%%%%%%
caSigAll = [];
idxCnt = 1;
for ii = 1:length(ID);
    %%%%%%%%% Extract Calcium Signal
    sname_in = [fnFeat.sname_ex(1:usFeat.us_idx) num2str(ID(ii)) '.mat']
    CaSig_in = load(fullfile(fnFeat.spath,sname_in));
    CaSig = CaSig_in.dffV;%%%
    %%%%%%%%% Find proper Lick Onset Time only when all three lick, pim and handlift are present %%%%%%%%%%
    starttime_firstLick = cell2mat(BData.Data((ID(ii) - (firstIdx-1)),9)); %%% find lick start after 2 seconds of trial start
    if length(starttime_firstLick) < 1
        disp(' COULD NOT FIND PROPER LICK START TIME ' )
        continue
    end
    
    starttime_pim = cell2mat(BData.Data((ID(ii)- (firstIdx-1)),10));; %%% find lick start after 2 seconds of trial start
    if length(starttime_pim) < 1
        disp(' COULD NOT FIND PROPER PIM START TIME ' )
        continue
    end
    
    starttime_handlift = cell2mat(BData.Data((ID(ii)- (firstIdx-1)),11));; %%% find lick start after 2 seconds of trial start
    if length(starttime_handlift) < 1
        disp(' COULD NOT FIND PROPER HANDLIFT START TIME ' )
        continue
    end
    %%%%%%%%%% get manipulation Times and index %%%%%%%%%%
    manTimeFull = cell2mat(BData.Data((ID(ii)- (firstIdx-1)),12));
    if length(manTimeFull)<1
        continue
    end
    manDiff = manTimeFull(:,2) - manTimeFull(:,1);
    manTime = manTimeFull(find(manDiff>= manDur),:); %% only select long duration manipulations
    manTime(find(manTime(:,1) <= starttime_handlift+manDelay),:) = []; %%% delete manipulaitons close to hand lift events
    if length(manTime) < 1
        disp(' COULD NOT FIND PROPER MANIPULATION START TIME ' )
        continue
    end
    %% %%%%%%% final trials that are used for analysis
    IDsThatMadeIt = [IDsThatMadeIt;ID(ii)];
    %% %%%%%%% extract body trajectory files
    fnameinC2 = [fnFeat.fname_exC2(1:usFeat.bidx_stC2) num2str(ID(ii)) fnFeat.fname_exC2(usFeat.bidx_endC2:end)];
    filepathC2 = fullfile(fpath,fnameinC2);
    [TrajDataC2 BodyPartsC2] =  ExtractBodyTraj(filepathC2,pcutoffC2);
    
    fnameinC1 = [fnFeat.fname_exC1(1:usFeat.bidx_stC1) num2str(ID(ii)) fnFeat.fname_exC1(usFeat.bidx_endC1:end)];
    filepathC1 = fullfile(fpath,fnameinC1);
    [TrajDataC1 BodyPartsC1] =  ExtractBodyTraj(filepathC1,pcutoffC1);
    
    %% %%%%%%%%%%%%%%%% extract relevant behavior features %%%%%%%%
    %%%% manipulation signal All
    manSig = zeros(length(behTime),1);
    for mm = 1:size(manTime,1)
        manSig(behTime>manTime(mm,1) & behTime<manTime(mm,2)) = 1; %%% manipulatino indices
    end
    manSigAll(:,idxCnt) = manSig;
    manTimesAll{1,idxCnt} = manTime;
    %%%% chew signal
    lowerlipY = TrajDataC2.lowerlip(:,2);
    [chewTime] =  getChewTimes3(lowerlipY,chewPrm)';
    chewTime(find((chewTime(:,2) - chewTime(:,1))<minChewDur),:) = []; %% delete short duration chews
    chewTime = chewTime(find(chewTime(:,1)>starttime_handlift),:); %% find chews after hand lift
    chewSig = zeros(length(behTime),1);
    for cc = 1:size(chewTime,1)
        chewSig(behTime>chewTime(cc,1) & behTime<chewTime(cc,2)) = 1; %%% manipulatino indices
    end
    chewSigAll(:,idxCnt) = chewSig;
    %%%% Left hand signal
    leftHandC2All(:,idxCnt) = TrajDataC2.lhand2(:,2);
    %%%% tongue
    tongueC2All(:,idxCnt) = TrajDataC2.tongue(:,2);
    tongueC1All(:,idxCnt) = TrajDataC1.tongue(:,2);
    %%%% lower lip
    lowerLipC2All(:,idxCnt) = TrajDataC2.lowerlip(:,2);
    lowerLipC1All(:,idxCnt) = TrajDataC1.lowerlip(:,2);
    %%%% upper lip
    upperLipC1All(:,idxCnt) = TrajDataC1.upperlip(:,2);
    %%%% lick, pim, handlift onset
    lickOnsetAll(1,idxCnt) = starttime_firstLick;
    pimOnsetAll(1,idxCnt) = starttime_pim;
    handliftOnsetAll(1,idxCnt) = starttime_handlift;
    %% Append calcium signal
    caSigAll = single(cat(3,caSigAll,imresize(imwarp(CaSig.*fovMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*dorsalMaps.maskScaled,redRat)));
    idxCnt = idxCnt+1;
end
%% build predictor matrix %%
beh2sigIdx = round(linspace(1,1500,450));
%%%% manipulation signal
sManSig = manSigAll(beh2sigIdx,:);
%%%% chew Sighal
sChewSig = chewSigAll(beh2sigIdx,:);
%%%% lick onset signal
lickSigDur = 0.3; %%% length of signal duration before lick onset in seconds to consider in model
slickOnLinSig = [];
for ii = 1:length(lickOnsetAll)
    lickOnLin = zeros(length(sigTime),1);
    lickOnStart = find(sigTime>=lickOnsetAll(ii)-lickSigDur,1);
    pimOnStart = find(sigTime>=pimOnsetAll(ii),1);
    lickOnLin(lickOnStart:pimOnStart-1) = 1;
    slickOnLinSig = [slickOnLinSig;lickOnLin];
end

%%%% pim onset
spimOnLinSig = [];
pimOnStart = [];
for ii = 1:length(pimOnsetAll)
    pimOnLin = zeros(length(sigTime),1);
    pimOnStart = find(sigTime>=pimOnsetAll(ii),1);
    handliftOnStart = find(sigTime>=handliftOnsetAll(ii),1);
    pimOnLin(pimOnStart:handliftOnStart-1) = 1;
    spimOnLinSig = [spimOnLinSig;pimOnLin];
end
%%%% handlift onset
handliftSigDur = 0.5; %%% length of signal duration after handlift onset to consider in model
handliftOnStart = [];
shandliftOnLinSig = [];
for ii = 1:length(handliftOnsetAll)
    handliftOnLin = zeros(length(sigTime),1);
    handliftOnStart = find(sigTime >= handliftOnsetAll(ii),1);
    handliftOnLin(handliftOnStart:handliftOnStart+round(handliftSigDur*SigFs)) = 1;
    shandliftOnLinSig = [shandliftOnLinSig;handliftOnLin];
end
%%%% building the matrix
Xactual = [slickOnLinSig spimOnLinSig shandliftOnLinSig sManSig(:) sChewSig(:)];
Xvariables = {'LickOnset';'PIM Onset';'Handlift Onset';'Manipulation';'Chewing'};
X = [ones(size(Xactual,1),1) Xactual];
%% Build response Matrix
caSz = size(caSigAll);
caSigMat = reshape(caSigAll,caSz(1)*caSz(2),caSz(3));
nDims = 200;% Number of svd dimensions to use
[U,S,V] = svd(caSigMat,'econ');
Y = [S(1:nDims,1:nDims)*V(:,1:nDims)']';
%% perform logistic regression
betaAll = [];
bstats = [];
for ii = 1:size(Y,2)
    [betaAll(:,ii),~,~,~,bstats(ii,:)] = regress(Y(:,ii),X);
end
beta = betaAll(2:end,:);
%% Measure goodness of each variable
for j = 1:1000
    for vv = 2:size(X,2);
        xShufInd = randperm(size(X,1))';
        Xshuf = X; Xshuf(:,vv) = X(xShufInd,vv);
        betaAct = X\Y;
        Ypred = X*betaAct;
        rssPred = sum((Y(:)- Ypred(:)).^2);
        tssPred = sum((Y(:)- mean(Y(:))).^2);
        r2Pred = (1 - rssPred/tssPred)*100;
        
        betaShuf = Xshuf\Y;
        YpredShuf= Xshuf*betaShuf;
        rssPredShuf = sum((Y(:) - YpredShuf(:)).^2);
        r2PredShuf = (1 - rssPredShuf/tssPred)*100;
        deltaR2(j,vv-1) = r2Pred - r2PredShuf;
    end
end

%% generate regression map
close all
h1 = figure;h1.Position = [30 690 1851 280];

for ii = 1:size(beta,1)
    betaIn = beta(ii,:);
    betaMaps(:,:,ii) = reshape([U(:,1:nDims)*betaIn'],caSz(1),caSz(2),size(betaIn,1));
end


%% %%%%%%%%%%%%%%%% load Data %%%%%%%%%%%%%%%
data.MouseID = fnFeat.sname_ex(1:end-11);
data.IDsThatMadeIt = IDsThatMadeIt;
data.PredictorSig = Xactual;
data.PredictorVar = Xvariables;
data.deltaR2 = deltaR2;
data.minManipulationDuration = manDur;
data.manipulationDelayHandlift = manDelay;
data.chewingParameters = chewPrm;
data.minChewDuration = minChewDur;
data.IDsThatMadeIt = IDsThatMadeIt;
data.redRat = redRat;
data.numNeuralSVDdims = nDims;
data.betaAll = betaAll;
data.betaStats = bstats;
data.betaMaps = betaMaps;
data.date = date;
%% %%%%%%%%%%%%%%%% Saving Data %%%%%%%%%%%%%%%
clc
disp('!!!!!!!!! MAKE SURE THE PATH TO SAVE AND FILENAME IS CORRECT !!!!!!!!!!')
%%%%%%%% Enter the correct path to save the data %%%%%%%%%%%%%
actSpath = 'G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\BehaviorEventsRegressionMapData';
%%%%%%%%%%%% obtain correct Mouse folder to save the data %%%%%%%%%
if contains(lower(fnFeat.sname_ex),'fezf')
    MouseFold = 'FezF2Ai148';
elseif contains(lower(fnFeat.sname_ex),'plex')
    MouseFold = 'PlexinD1Ai148';
elseif contains(lower(fnFeat.sname_ex),'tle4')
    MouseFold = 'Tle4Ai148';
elseif contains(lower(fnFeat.sname_ex),'cba')
    MouseFold = 'CBAAi93h';
end
fullPath = fullfile(actSpath,MouseFold);
if isdir(fullPath) == 0
    mkdir(fullPath)
end
%% %%%%%%%%%%%%%% Saving the activity %%%%%%%%%%%%%%%%%%%%
sFilename = [fnFeat.sname_ex(1:end-11) '_regressionData.mat']; %%%% enter file name to save everytime !!!
disp(['The File name being Saved is : ' sFilename]);

save(fullfile(fullPath,sFilename),'data','-v7.3');


end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Functions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [trainIdx,testIdx] = kFoldSplit(allIdx,kF)
allIdx = allIdx;
sigL = length(allIdx);
trainPer = 1 - 1/kF;
trainL = round(trainPer*sigL);
testL = sigL-trainL;
trainIdx = zeros(sigL ,1);
trainIdx(1:round(trainPer*sigL)) = ones;
testIdx = trainIdx==0;
for ii = 2:kF
    trainIdx(:,ii) = circshift(trainIdx(:,ii-1),testL);
end
testIdx = trainIdx==0;
trainIdx = logical(trainIdx);
testIdx = logical(testIdx);
end

function [fnFeat, usFeat ] = getFileNameProperties(fpath)
%%%%%%%%%%%%% getting signal file name %%%%%%%%%%%%%%
listing_csv = dir([fpath '\*.csv']);
[~, sflname] = fileparts(fileparts(fpath));
spath = fullfile(fileparts(fileparts(fileparts(fpath))), 'Data_Corrected', sflname);
listing_sig = dir([spath '\*.mat']);
sname_all = natsortfiles({listing_sig.name}');
sname_ex = sname_all{1};
us_idx = find(sname_ex == '_',1,'last');

%%%%%%%% getting body trajectory file name %%%%%%%%%%%%
fname_all = natsortfiles({listing_csv.name}');
fname_allC1 = fname_all( contains(fname_all,'c1_T'));
fname_allC2 = fname_all( contains(fname_all,'c2_T'));

fname_exC1 = fname_allC1{1};
fname_us_idxC1 = find(fname_exC1 == '_');
fname_deep_idxC1 = strfind(fname_exC1, 'Deep');
bidx_stC1 = fname_us_idxC1(end-4);
bidx_endC1 = fname_deep_idxC1;

fname_exC2 = fname_allC2{1};
fname_us_idxC2 = find(fname_exC2 == '_');
fname_deep_idxC2 = strfind(fname_exC2, 'Deep');
bidx_stC2 = fname_us_idxC2(end-4);
bidx_endC2 = fname_deep_idxC2;


%%% updating all properties
fnFeat.sname_all = sname_all;
fnFeat.fname_allC1 = fname_allC1;
fnFeat.fname_allC2 = fname_allC2;
fnFeat.sname_ex = sname_ex;
fnFeat.fname_exC1 = fname_exC1;
fnFeat.fname_exC2 = fname_exC2;
fnFeat.spath = spath;

usFeat.us_idx = us_idx;
usFeat.bidx_stC1 = bidx_stC1;
usFeat.bidx_endC1 = bidx_endC1;
usFeat.bidx_stC2 = bidx_stC2;
usFeat.bidx_endC2 = bidx_endC2;
end