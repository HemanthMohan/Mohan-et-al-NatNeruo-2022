clear all; close all; clc;
%% Load Data
plexData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\MeanActivityAroundPIM\PlexinD1Ai148_MeanActivityAroudPIM_Full.mat');
plexData = plexData.data;
fezData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\MeanActivityAroundPIM\FezF2Ai148_MeanActivityAroudPIM_Full.mat');
fezData = fezData.data;
load('F:\Hemanth_CSHL\WideField\Data\cmapPlexFez.mat');
dmMap = plexData.dorsalMap.edgeOutlineSplit;

plexSeq = plexData.meanFlowAll;
fezSeq = fezData.meanFlowAll;

plexSeqMean = plexData.meanFlow;
fezSeqMean = fezData.meanFlow;

plexSz = size(plexData.meanFlowAll);
fezSz = size(fezData.meanFlowAll);
%% perform pixel wise ttests for each image
for jj = 1:plexSz(3)
    disp(jj)
    meanMaps_plex = squeeze(plexSeq(:,:,jj,:));
    meanMaps_fez = squeeze(fezSeq(:,:,jj,:));
    pValMapSeq(:,:,jj) = getPvalMap(meanMaps_plex,meanMaps_fez);
end
%% plot pvalue map
idx = 50
imagesc(log10(pValMapSeq(:,:,idx)), [log10(1e-8), log10(1e-2)]);
axis image; colormap jet; colorbar

%% %%% calculate the false discovery rate
q_fdr = 0.05; %% set the acceptable false discovery rate
[fdr_pval] = myFalseDiscoveryThreshold(pValMapSeq(:),q_fdr); %% alternate fdr_bh function
disp(['fdr p val : ' num2str(fdr_pval)])
%% %%% extract significant pixels and mean values associated with sig p vals
pValSeqMask = pValMapSeq<fdr_pval;
fezPlexSeqMap = plexSeqMean - fezSeqMean;
fezPlexSeqMapTh = fezPlexSeqMap.*pValSeqMask;
fezPlexSeqMapTh(isnan(fezPlexSeqMap)) = 0;
%% plot the image sequence map of pixels significantly different from each other
close all
seqTm = linspace(-plexData.durBeforeOnset, plexData.durAfterOnset, size(plexSeq,3));
numFrames = 10; %%% how many frames to plot
timeFrame = [-1,1]; %% time frame to plot the sequence. Should be between the time collected around pim
frameIdx = round(linspace(find(seqTm>=timeFrame(1),1),find(seqTm>=timeFrame(2),1),numFrames));
frameTm = seqTm(frameIdx);
imScl = [-0.012,0.012];
h1 = figure;
h1.Position = [25 692 1881 243];

for ii = 1:length(frameIdx)
    figure(h1)
    subplot(1,length(frameIdx),ii)
    imagesc(imgaussfilt(fezPlexSeqMapTh(:,:,frameIdx(ii)),2),imScl)
    
    hold on
    for p = 1:length(dmMap)
        plot( dmMap{p}(:, 2),dmMap{p}(:, 1),'color','k','LineWidth',0.3);
    end
    hold off
    caxis(imScl)
    axis image
    set(gca,'XLim',[26 562]);
    set(gca,'YLim',[92 537]);
    colormap(cmap)
    title(num2str(frameTm(ii)))
    set(gca,'XTick',[], 'YTick', [])
end

sgtitle( ["Pixels significantly different from each other with FDR = 0.05" + newline + ... 
"PlexinD1 mean map - FezF2 mean map" ]   )
%% %%%%%%%%%%%%% saving the figures %%%%%%%%%%
saveFolder = 'G:\Hemanth_CSHL\WideField\Data_Figures\ActivityPlots\AllenMaskROIAnalysis\FeedingActMapsCorrelation\';
fileName1 = ['FeedingActivitySequenceStatisticalParametricTest.fig'];
savePath1 = fullfile(saveFolder,fileName1);
saveFig = input('Do you want to save the current figure : ');
if saveFig == 1
    savefig(h1,savePath1)
    print(h1,[savePath1(1:end-4) '.svg'],'-dsvg','-painters');
end
%%  %%%%%%%%%%%%%%%%%%%%% function %%%%%%%%%%%%%%%%%%%
function [pValMap] = getPvalMap(meanMaps_plex,meanMaps_fez)
plexMap = reshape(meanMaps_plex,size(meanMaps_plex,1)*size(meanMaps_plex,2),size(meanMaps_plex,3))';
fezMap = reshape(meanMaps_fez,size(meanMaps_fez,1)*size(meanMaps_fez,2),size(meanMaps_fez,3))';
pVal = [];
parfor ii = 1:size(fezMap,2);
    sigPlex = plexMap(:,ii);
    sigFez = fezMap(:,ii);
%     [~,pVal(1,ii)] =ttest2(sigPlex,sigFez);
    [pVal(1,ii)] =ranksum(sigPlex,sigFez);
end
pValMap = reshape(pVal,size(meanMaps_fez,1),size(meanMaps_fez,2));
end