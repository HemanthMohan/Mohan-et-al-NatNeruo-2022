clear all; close all; clc
load('F:\Hemanth_CSHL\WideField\Data\cmap3.mat');
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
[fname fpath] = uigetfile('*.csv');
AskSaving = 1; %%%%%%%%% do you want to save data
%% %%%%%%%%%%%%%%%% get file  name structure %%%%%%%%%%%%
[fnFeat, usFeat ] = getFileNameProperties(fpath);%%% get all fileNames variables
%% %%%%%%%%%%%%%%% load ROI MASKS for analysis %%%%%%%%%%%%%%%%
maskData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\behaviorActivityRoiMasks.mat');
roiMasks = maskData.data.roiMasks;
%% %%%%%%%%%%%%%%% load allen dorasal map coordinates %%%%%
dmName = [fnFeat.sname_ex(1:usFeat.us_idx-5) 'dorsalMap.mat'];
load(fullfile(fnFeat.spath,dmName));
tform = dorsalMaps.tform;
%% %%%%%%%% loading mask file %%%%%%%%%
[~,fovMaskFold] = fileparts(fnFeat.spath);
fovMaskPath = fullfile(fileparts(fileparts(fnFeat.spath)),['Data'],fovMaskFold);
fovMask = load(fullfile(fovMaskPath,[fnFeat.sname_ex(1:find(fnFeat.sname_ex == '_',2,'last')) 'refMask.mat']));
%% %%%%%%%%%%%%%%% Get Handlift Behavior Trials %%%%%%%%%%%%%%%
disp('Extracting Behavior Temporal features .... ')
ExtractManipulaion = 1;%%%%% Enter zero to not extract manipulation times and 1 to extract
[BData] = GetBehavEventTimes(fpath,ExtractManipulaion); %%%%% Enter second input as zero to not extract manipulation times. The third variable is are the file ids to consider
HandLiftTrials = find(cell2mat(BData.Data(:,2)) == 1 & cell2mat(BData.Data(:,3)) == 1 & cell2mat(BData.Data(:,4)) == 1);
HandLiftFileIds = cell2mat(BData.Data(HandLiftTrials,1));
disp(['Handlift IDs: ' num2str(HandLiftFileIds')])
%% %%%%%%%%%%%%%%% Extract Task relevant Calcium frames %%%%%%
%%%%%% File ID and plottting variables %%%%%%%
%%%%%%%% BELOW ENTER WHICH TRIAL ID DO YOU WANT TO PLOT %%%%%%
idToPlot = 46; %%% Which Trial do you wnat to plot?
close all;
SigFs = 30;
BehFs = 100;
pcutoffC1 = 0.9; %%%% threshold for plotting behavior signal from camera 1
pcutoffC2 = 0.8; %%%% threshold for plotting behavior signal from camera 2
sigTime = 0:1/SigFs:15; sigTime(end) = [];
behTime = 0:1/BehFs:15; behTime(end) = [];
% % %%%%%%%%%%%%%% Extractin Behavior Traces %%%%%%%%%%%%%
fnameinC1 = [fnFeat.fname_exC1(1:usFeat.bidx_stC1) num2str(idToPlot) fnFeat.fname_exC1(usFeat.bidx_endC1:end)];
filepathC1 = fullfile(fpath,fnameinC1);
[TrajDataC1 BodyPartsC1] =  ExtractBodyTraj(filepathC1,pcutoffC1);

fnameinC2 = [fnFeat.fname_exC2(1:usFeat.bidx_stC2) num2str(idToPlot) fnFeat.fname_exC2(usFeat.bidx_endC2:end)];
filepathC2 = fullfile(fpath,fnameinC2);
[TrajDataC2 BodyPartsC2] =  ExtractBodyTraj(filepathC2,pcutoffC2);

tongueTraj = normalize(TrajDataC1.tongue(:,2),'range');
pelletTraj = normalize(TrajDataC1.pellet(:,2),'range');
lowerLipTraj = normalize(TrajDataC1.lowerlip(:,2),'range');
leftHandTraj = normalize(TrajDataC2.lhand2(:,2),'range');

%% %%%%%%%%%%%%%% Signal Analysis %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% Extract Calcium Signal
sname_in = [fnFeat.sname_ex(1:usFeat.us_idx) num2str(idToPlot) '.mat']
CaSig_in = load(fullfile(fnFeat.spath,sname_in));
CaSigTemp = CaSig_in.dffV;%%% NEW calcium signal with mask application
%%%%%%%%% Find Onset Times and indexs of behvaior events %%%%%%%%%%
firstIdx = str2num(fnFeat.sname_all{1,1}(end-4));
starttime_firstLick = cell2mat(BData.Data((idToPlot - (firstIdx-1)),9)); %%% find lick start after 2 seconds of trial start
starttime_pim = cell2mat(BData.Data((idToPlot - (firstIdx-1)),10)); %%% find lick start after 2 seconds of trial start
starttime_handlift = cell2mat(BData.Data((idToPlot - (firstIdx-1)),11)); %%% find lick start after 2 seconds of trial start

startidx_firstLick = find(sigTime >= starttime_firstLick,1); %%% proper lick onset Index
startidx_pim = find(sigTime >= starttime_pim,1); %%% proper lick onset Index
startidx_handlift = find(sigTime >= starttime_handlift,1); %%% proper lick onset Index
%% generate manipulation times signal
maniOnOff = BData.Data{(idToPlot - (firstIdx-1)),12};
manDur = 0; %%%%%%%%% minimun duraion of manipulation in seconds to consider
manDelay = 0.5; %%%%%%%% min duration between handlift onset and maniulation onset signals to consider in seconds
manDiff = maniOnOff(:,2) - maniOnOff(:,1);
manTime = maniOnOff(find(manDiff>= manDur),:); %% only select long duration manipulations
manTime(find(manTime(:,1) <= starttime_handlift + manDelay),:) = []; %%% delete manipulaitons close to hand lift events
manSig = zeros(length(behTime),1);
for mm = 1:size(manTime,1)
    manSig(behTime>manTime(mm,1) & behTime<manTime(mm,2)) = 1; %%% manipulatino indices
end
%% get and generate chew signal
chewPrm.stdThresh = 0.1; %% def 0.1 for chew time signal
chewPrm.freqRange = [4,7]; %% def [4,7] for chew time signal
chewPrm.Fs = BehFs; %%% minimun duration of chew in seconds
minChewDur = 0.5; %%% minimun duration of chew in seconds def 0.5
lowerlipY = TrajDataC2.lowerlip(:,2);
[chewTime] =  getChewTimes2(lowerlipY,chewPrm)';
chewTime(find((chewTime(:,2) - chewTime(:,1))<minChewDur),:) = []; %% delete short duration chews
chewTime = chewTime(find(chewTime(:,1) > starttime_handlift),:); %% find chews after hand lift
chewSig = zeros(length(behTime),1);
for cc = 1:size(chewTime,1)
    chewSig(behTime>chewTime(cc,1) & behTime<chewTime(cc,2)) = 1; %%% manipulatino indices
end
%% %%%%%%%% get calcium signal trace
CaSig = imwarp(CaSigTemp.*fovMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*dorsalMaps.maskScaled;

% %    %%%%%%%%%%%%%% Extracting ROI Activity%%%%%%%%%%%%%%%%
%%%%%%%% extrating Left Frontal Activity %%%%%
leftFrontalMask = single(roiMasks.leftFrontal); leftFrontalMask(roiMasks.leftFrontal==0)=nan;
Actdata.leftFrontal = squeeze(nanmean(nanmean(CaSig .* leftFrontalMask,1),2));

%%%%%%%% extrating Left Parietal Activity %%%%%
leftParietalMask = single(roiMasks.leftParietal); leftParietalMask(roiMasks.leftParietal==0)=nan;
Actdata.leftParietal = squeeze(nanmean(nanmean(CaSig .* leftParietalMask,1),2));

%%%%%%%% extrating Left FLA Activity %%%%%
leftFLAMask = single(roiMasks.leftFLA); leftFLAMask(roiMasks.leftFLA==0)=nan;
Actdata.leftFLA = squeeze(nanmean(nanmean(CaSig .* leftFLAMask,1),2));

%%%%%%%% extrating Left FLP Activity %%%%%
leftFLPMask = single(roiMasks.leftFLP); leftFLPMask(roiMasks.leftFLP==0)=nan;
Actdata.leftFLP = squeeze(nanmean(nanmean(CaSig .* leftFLPMask,1),2));

%%%%%%%% extrating right Frontal Activity %%%%%
rightFrontalMask = single(roiMasks.rightFrontal); rightFrontalMask(roiMasks.rightFrontal==0)=nan;
Actdata.rightFrontal = squeeze(nanmean(nanmean(CaSig .* rightFrontalMask,1),2));

%%%%%%%% extrating right Parietal Activity %%%%%
rightParietalMask = single(roiMasks.rightParietal); rightParietalMask(roiMasks.rightParietal==0)=nan;
Actdata.rightParietal = squeeze(nanmean(nanmean(CaSig .* rightParietalMask,1),2));

%%%%%%%% extrating right FLA Activity %%%%%
rightFLAMask = single(roiMasks.rightFLA); rightFLAMask(roiMasks.rightFLA==0)=nan;
Actdata.rightFLA = squeeze(nanmean(nanmean(CaSig .* rightFLAMask,1),2));

%%%%%%%% extrating right FLP Activity %%%%%
rightFLPMask = single(roiMasks.rightFLP); rightFLPMask(roiMasks.rightFLP==0)=nan;
Actdata.rightFLP = squeeze(nanmean(nanmean(CaSig .* rightFLPMask,1),2));
% % %%%%%%%%%%%%%% plotting the singal and behavior time stapmps
close all
smoothFac = 3; %%% how much do you want to smoothen the data
h1 = figure; hold on
h1.Position = [34    38   862   942];
%%%%%%%%%%% Plotting Behavior Traces %%%%%%%%%%%%
subplot(2,1,1)
hold on

plot([2,2],[-0.05 0.2],'k','LineWidth',1)
plot([3,3],[-0.05 0.2],'k','LineWidth',1)
plot([starttime_firstLick,starttime_firstLick],[-0.05 0.2],'k','LineWidth',1)
plot([starttime_pim,starttime_pim],[-0.05 0.2],'k','LineWidth',1)
plot([starttime_handlift,starttime_handlift],[-0.05 0.2],'k','LineWidth',1)
plot(behTime,tongueTraj+0,'color',[0,0,0.5],'LineWidth',1)
plot(behTime,pelletTraj+1,'color',[0,1,0.5],'LineWidth',1)
plot(behTime,lowerLipTraj+1,'color',[1,0,0.5],'LineWidth',1)
plot(behTime,leftHandTraj+2,'LineStyle','-','color',[0,0.5,0.5],'LineWidth',1)
set(gca,'YDir','Reverse')
title('Behavior Trace')
%%%%%%%%%%% Plotting Singal Traces %%%%%%%%%%%%%
subplot(2,1,2)
hold on
area(behTime,manSig*0.2,'FaceColor','cyan','FaceAlpha',0.5,'EdgeColor','none') %%% plot manipualtion area
area(behTime,chewSig*0.2,'FaceColor','g','FaceAlpha',0.5,'EdgeColor','none')%%% plot chew area
plot([1.7,1.7],[-0.05 0.2],'k','LineWidth',1)
plot([2.7,2.7],[-0.05 0.2],'k','LineWidth',1)
plot([starttime_firstLick,starttime_firstLick],[-0.05 0.2],'k','LineWidth',1)
plot([starttime_pim,starttime_pim],[-0.05 0.2],'k','LineWidth',1)
plot([starttime_handlift,starttime_handlift],[-0.05 0.2],'k','LineWidth',1)
plot(sigTime,smooth(Actdata.leftFrontal,smoothFac),'r','LineWidth',2); text(15,0,'leftFrontal')
plot(sigTime,smooth(Actdata.leftParietal,smoothFac)+0.05,'m','LineWidth',2); text(15,0.05,'leftParietal')
plot(sigTime,smooth(Actdata.leftFLP,smoothFac)+0.1,'c','LineWidth',2); text(15,0.1,'leftFLP')
plot(sigTime,smooth(Actdata.leftFLA,smoothFac)+0.15,'b','LineWidth',2); text(15,0.15,'leftFLA')
tH(1) = text(2,0.17,'Pellet Drop');
tH(2) = text(3,0.17,'Belt Start');
tH(3) = text(starttime_firstLick,0.17,'Lick Bout Onset');
tH(4) = text(starttime_pim,0.17,'PIM Onset');
tH(5) = text(starttime_handlift,0.17,'Handlift Onset');
set(tH,'Rotation',60);
title(sname_in(1:end-4),'Interpreter','none')
hold off
%% %%%%%%%%%%%%%%%%%%%%% Saving the plots %%%%%%%%%%%%%%%%%%%%%%%%
if AskSaving == 1
    %%%%%%%%% Generate the path to save the plots %%%%%%%%%%
    saveFolder = 'G:\Hemanth_CSHL\WideField\Data_Figures\ActivityPlots\AllenMaskROIAnalysis\SingleTrialActivity';
    saveFname = [sname_in(1:end-4) '_singleTrial'];
    wantSave = input('Do you want to save Figures Enter (Yes = 1, No = 0) : ');
    if wantSave == 1
        saveas(h1,fullfile(saveFolder,saveFname),'fig');
        saveas(h1,fullfile(saveFolder,saveFname),'svg');
    end
end