clear all; close all; clc
%% %%%%%%%%%%%%%% Enter the path fro analysis %%%%%%%%%%%%%%%%%%
%%%%%%%% REMOVE FORWARD SLASH IN THE LAST %%%%%%%%%%%%%
InFolder = 'G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\MaskRoiSelectionAnalysis\NoCorrection\HandBlockedTrials\PelletInMouthOnset_HandBlocked\FezF2Ai148'; %% no slash in the last
mouseId = 'c1m1'; %%%% enter the mouse ID to concatenate activity
FoldCont = dir(fullfile(InFolder,['*' mouseId '_3sec.mat']));
sampData = load(fullfile(InFolder,FoldCont(1).name));
AskSaving = 1; %%%%%%%%% 1 To ask the saving plot question. 0 to avoid saving
%% %%%%%%%%%%%%%% Enter Plotting Features %%%%%%%%%%%%%
load('F:\Hemanth_CSHL\WideField\Data\cmap3.mat');
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
MeanPltScl = [-0.01 0.04]; %%%%%%%% Y axis scale for the mean plots
HeatPltScl = [-0.05 0.05]; %%%%%%%% Bar scale for the heat maps
[~,TrialType] = fileparts(fileparts(InFolder));

%% %%%%%%%%%% Extracting the Data from each file  %%%%%%%%
[caData,caDataFilt,caDataMean,caDataStdErr] = GetCaData(InFolder,FoldCont,sampData);

%% %%%%%%%%%%%%%%%%%%%% plotting signals %%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%% Plotting Heat Map %%%%%%%%%%%%%%%%%%%%
roiNames = fieldnames(sampData.data.Actdata);
plotDim = [2,4];
actTime = sampData.data.actTime;
h1 = figure;
for ii = 1:length(fieldnames(sampData.data.Actdata))
subplot(plotDim(1),plotDim(2),ii)
imagesc(actTime, 1:size(caDataFilt.(roiNames{ii}),1),caDataFilt.(roiNames{ii}),HeatPltScl);
set(gca,'YDir','normal')
hold on
plot([0 0],[1 size(caDataFilt.(roiNames{ii}),1)+0.5],'w','LineWidth',1)
colormap(cmap2)
colorbar
set(gca,'TickDir','out')
title(roiNames{ii})
end
%%%%%%%%%%%%%%%%%%%%%%%%% Plotting mean Trace Activity %%%%%%%%%%%%%%%%%%%%%
h2 = figure;
for ii = 1:length(fieldnames(sampData.data.Actdata))
    subplot(plotDim(1),plotDim(2),ii)
    fill([actTime fliplr(actTime)],[caDataMean.(roiNames{ii})+ 2*caDataStdErr.(roiNames{ii}) ...
        fliplr(caDataMean.(roiNames{ii}) - 2*caDataStdErr.(roiNames{ii}))],'c','FaceAlpha',0.3,'EdgeColor','none')
    hold on
    plot(actTime,caDataMean.(roiNames{ii}),'k','LineWidth',2)
    plot([0 0],MeanPltScl,'r')
    ylim(MeanPltScl)
    set(gca,'TickDir','out')
    title(roiNames{ii})
    hold off
    xlim([min(actTime) max(actTime)])
end

h1.Position = [65 558 1285 416];
h2.Position = [66 51 1285 416];

sgtitle(h1,TrialType)
sgtitle(h2,TrialType)
%% %%%%%%%%%% Annotating the plots %%%%%%
for ii = 1:length(FoldCont)
    FolderNames{ii,1} = FoldCont(ii).name(1:end-9);
end
annotation(h1,'textbox', [0, 0.8, 0, 0], 'string', FolderNames,'FontSize',7, 'Interpreter', 'none')
annotation(h2,'textbox', [0, 0.8, 0, 0], 'string', FolderNames,'FontSize',7, 'Interpreter', 'none')
%% %%%%%%%%%%%%%%%%%%%%% Saving the plots %%%%%%%%%%%%%%%%%%%%%%%%
if AskSaving == 1
%%%%%%%%% Generate the path to save the plots %%%%%%%%%%
PlotPath = 'G:\Hemanth_CSHL\WideField\Data_Figures\ActivityPlots\AllenMaskROIAnalysis';
[path1,fold1] = fileparts(fileparts([InFolder '\']));
[path2,fold2] = fileparts(path1);
[path3,fold3] = fileparts(path2);
[path4,fold4] = fileparts(path3);
fullPlotPath = fullfile(PlotPath,fold4,fold3,fold2,fold1);
if ~exist(fullPlotPath,'dir')
    mkdir(fullPlotPath) %%%%%%% Make the folder if it does not exist
end
%%%%%%%%%%%%%%%%% save the plots in the path %%%%%%%%%%%%

    saveFname1 = [fold1 '_' TrialType '_Mouse_' mouseId '_HeatMap'];
    saveFname2 = [fold1 '_' TrialType '_Mouse_' mouseId '_MeanTrace'];
    wantSave = input('Do you want to save Figures Enter (Yes = 1, No = 0) : ');
    
    if wantSave == 1
        saveas(h1,fullfile(fullPlotPath,saveFname1),'fig');
        saveas(h1,fullfile(fullPlotPath,saveFname1),'svg');
        saveas(h2,fullfile(fullPlotPath,saveFname2),'fig');
        saveas(h2,fullfile(fullPlotPath,saveFname2),'svg');
    end
end
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% FUNCTIONS %%%%%%%%%%%%%%%%%%%%%%%%%%

function [caData,caDataFilt,caDataMean,caDataStdErr] = GetCaData(InFolder,FoldCont,sampData)
Locations = fieldnames(sampData.data.Actdata);
caData.(Locations{1}) = [];
caData.(Locations{2}) = [];
caData.(Locations{3}) = [];
caData.(Locations{4}) = [];
caData.(Locations{5})= [];
caData.(Locations{6}) =[];
caData.(Locations{7}) =[];
caData.(Locations{8}) = [];

for ii = 1:length(FoldCont)
    FullPathIn = fullfile(InFolder,FoldCont(ii).name);
    load(FullPathIn)
    caData.(Locations{1}) =  [caData.(Locations{1}),data.Actdata.(Locations{1})];
    caData.(Locations{2}) =  [caData.(Locations{2}),data.Actdata.(Locations{2})];
    caData.(Locations{3}) =  [caData.(Locations{3}),data.Actdata.(Locations{3})];
    caData.(Locations{4}) =  [caData.(Locations{4}),data.Actdata.(Locations{4})];
    caData.(Locations{5}) =  [caData.(Locations{5}),data.Actdata.(Locations{5})];
    caData.(Locations{6}) =  [caData.(Locations{6}),data.Actdata.(Locations{6})];
    caData.(Locations{7}) =  [caData.(Locations{7}),data.Actdata.(Locations{7})];
    caData.(Locations{8}) =  [caData.(Locations{8}),data.Actdata.(Locations{8})];
    
end

%% %%%%%%%%% filtering jumps in the signal %%%%%%%%%
thresh = 0.1;
for kk = 1:length(Locations)
    MergedSig = caData.(Locations{kk})';
    MergedSigFilt = MergedSig;
    [mrow, mcol] = find(MergedSig > thresh | MergedSig < -thresh) ;
    for jj = 1:length(mrow)
        try
            MergedSigFilt(mrow(jj),mcol(jj)) = MergedSigFilt(mrow(jj),mcol(jj)-1);
        catch
        end
    end
    caDataFilt.(Locations{kk}) = MergedSigFilt;
    caDataMean.(Locations{kk}) = mean(MergedSigFilt);
    caDataStdErr.(Locations{kk}) = std(MergedSigFilt)/sqrt(size(MergedSigFilt,1));
end
end