clear all; close all; clc
textFilePath = 'G:\Hemanth_CSHL\WideField\Data_Analysis\readFolderPaths_HandBlockedFeeding.txt';
pathsIn = convertPathsToMatReadable(textFilePath);

%% Extract and save activity for each path
disp('Make Sure that the Initial folder to save is Correct. ie HandLift or HandLiftBlocked or Lido..')
ErrorFoldsIdx = zeros(length(pathsIn),1);
tic
for ii = 1:size(pathsIn,1)
    fpath =[pathsIn{ii,1} '\'];
    try
        ExtractAndSaveActivity(fpath)
    catch
        ErrorFoldsIdx(ii) = 1;
        continue
    end
end
toc
%%
function ExtractAndSaveActivity(fpath)
close all
load('F:\Hemanth_CSHL\WideField\Data\cmap3.mat');
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
%% %%%%%%%%%%%%%%%% get file  name structure %%%%%%%%%%%%
[fnFeat, usFeat ] = getFileNameProperties(fpath);%%% get all fileNames variables
%% %%%%%%%%%%%%%%% load ROI MASKS for analysis %%%%%%%%%%%%%%%%
maskData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\behaviorActivityRoiMasks.mat');
roiMasks = maskData.data.roiMasks;
%% %%%%%%%%%%%%%%% load allen dorasal map coordinates %%%%%
dmName = [fnFeat.sname_ex(1:usFeat.us_idx-5) 'dorsalMap.mat'];
load(fullfile(fnFeat.spath,dmName));
tform = dorsalMaps.tform;
%% %%%%%%%% loading mask file %%%%%%%%%
[~,fovMaskFold] = fileparts(fnFeat.spath);
fovMaskPath = fullfile(fileparts(fileparts(fnFeat.spath)),['Data'],fovMaskFold);
fovMask = load(fullfile(fovMaskPath,[fnFeat.sname_ex(1:find(fnFeat.sname_ex == '_',2,'last')) 'refMask.mat']));
%% %%%%%%%%%%%%%%% Get Handlift Behavior Trials %%%%%%%%%%%%%%%
disp('Extracting Behavior Temporal features .... ')
ExtractManipulaion = 0;%%%%% Enter zero to not extract manipulation times and 1 to extract
[BData] = GetBehavEventTimes(fpath,ExtractManipulaion); %%%%% Enter second input as zero to not extract manipulation times. The third variable is are the file ids to consider
PIMTrials = find(cell2mat(BData.Data(:,2)) == 1 & cell2mat(BData.Data(:,3)) == 1);
PIMFileIds = cell2mat(BData.Data(PIMTrials,1));
%% %%%%%%%%%%%%%%% Extract Task relevant Calcium frames %%%%%%
%%%%%% File ID and plottting variables %%%%%%%
SigFs = 30;
BehFs = 100;
ID = PIMFileIds;
plotBody = 1; %% Do you want to plot the body signal??
sigTime = 0:1/SigFs:15; sigTime(end) = [];
behTime = 0:1/BehFs:15; behTime(end) = [];
pcutoffC1 = 0.9;
tbeftrig = 3; %%% time before trigger in seconds
tafttrig = 3; %% time after trigger in seconds
trig_frms = tbeftrig*SigFs + tbeftrig*SigFs;
trigCasigV = [];
trigon_allFrms = [];
IDsThatMadeIt = []; %%%% ID's that made it to being plotted
BehaviorTimes = [];
firstIdx = str2num(fnFeat.sname_all{1,1}(end-4));
%% %%%%%%%%%%%%%% Signal Analysis %%%%%%%%%%%%%%%%%%%%%%%%%
trigCasigV = [];
for ii = 1:length(ID);
    %%%%%%%%% Extract Calcium Signal
    sname_in = [fnFeat.sname_ex(1:usFeat.us_idx) num2str(ID(ii)) '.mat']
    CaSig_in = load(fullfile(fnFeat.spath,sname_in));
    CaSig = CaSig_in.dffV;%%% NEW calcium signal with mask application
    %%%%%%%%% Find proper Handlift Onset Time only when both lick and  pim are present %%%%%%%%%%
    starttime_firstLick = cell2mat(BData.Data((ID(ii) - (firstIdx-1)),9)); %%% find lick start after 2 seconds of trial start
    if starttime_firstLick < tbeftrig
        disp(' COULD NOT FIND PROPER LICK START TIME ' )
        continue
    end
    
    starttime_pim = cell2mat(BData.Data((ID(ii) - (firstIdx-1)),10));; %%% find lick start after 2 seconds of trial start
    if length(starttime_pim) < 1
        disp(' COULD NOT FIND PROPER PIM START TIME ' )
        continue
    end
    
    startidx_pim = find(sigTime >= starttime_pim,1);

    %%%%%%%%%%%%%%% Plot Body Signal if required
    if plotBody == 1
        close(gcf)
        %%%%%%%%%%%% Extract Body Trajectories %%%%%%%%%%%
        fnameinC1 = [fnFeat.fname_exC1(1:usFeat.bidx_stC1) num2str(ID(ii)) fnFeat.fname_exC1(usFeat.bidx_endC1:end)];
        filepathC1 = fullfile(fpath,fnameinC1);
        [TrajDataC1 BodyPartsC1] =  ExtractBodyTraj(filepathC1,pcutoffC1);
        h1 = figure;
        hold on
        plot(behTime,normalize(TrajDataC1.pellet(:,2),'range'),'b','LineWidth',1)
        plot(behTime,normalize(TrajDataC1.lowerlip(:,2),'range'),'m','LineWidth',1)
        plot(starttime_pim, 0.5,'g.','MarkerSize',20)
        xlim([0 15])
        ylim([-0.5 1.5])
        title([ 'idx= ' num2str(ii) '  ID= ' num2str(ID(ii))]);
        set(gca,'YDir','reverse')
        hold off
        pause(0.1)
    end
    
    %%%%%%%%%%%% Exract time centred calcium activity %%%%%%%%%%%%%%%%%
    lcs_trigon = []; 
    lcsidx = find(sigTime>starttime_pim-tbeftrig & sigTime<starttime_pim+tafttrig);
    %%%%%%%%%% This is just to include trials where by chance the length is one frame less than actual
    if length(lcsidx) < trig_frms
        lcsidx(length(lcsidx)+1) = lcsidx(end)+1;
    end
    
    %%%%%%%%%% This is just to include trials where by chance the length is one frame more than actual
    if length(lcsidx) > trig_frms
        lcsidx(length(lcsidx)) = [];
    end
    
    %%%%%%% Obtaining the final indices for analysis %%%%%%%%  
    if length(lcsidx) < trig_frms
        continue
    else
        lcs_trigon = [lcs_trigon lcsidx'];
        IDsThatMadeIt = [IDsThatMadeIt;ID(ii)];
    end
    %%%%%%% Extract the Frames %%%%%%
    BehaviorTimes = [BehaviorTimes;starttime_pim];
    trigon_allFrms =[trigon_allFrms lcs_trigon];
    trigCasigV_temp = CaSig(:,:,lcs_trigon(:));
    trigCasigV = cat(4,trigCasigV,trigCasigV_temp);
end
trigCaSig = imwarp(trigCasigV.*fovMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*dorsalMaps.maskScaled;
%% %%%%%%%% Making Mean Activity Maps %%%%%%%%%%
mnScl = [-0.015 0.015];
nmScl = [-1 1];
meanIm = mean(mean(trigCaSig,4),3);
meanImNorm = meanIm./max(max(meanIm));
h1 = figure();
h1.Position = [200 413 1105 420];
subplot(1,2,1)
imagesc(meanIm,mnScl); axis image; 
colormap(cmap2)
colorbar
hold on
for p = 1:length(dorsalMaps.edgeOutlineSplit)
    plot( dorsalMaps.edgeOutlineSplit{p}(:, 2),dorsalMaps.edgeOutlineSplit{p}(:, 1),'color','w','LineWidth',0.5);
end
hold off
title('df/f')

subplot(1,2,2)
imagesc(meanImNorm,nmScl); axis image; 
colormap(cmap2)
colorbar
hold on
for p = 1:length(dorsalMaps.edgeOutlineSplit)
    plot( dorsalMaps.edgeOutlineSplit{p}(:, 2),dorsalMaps.edgeOutlineSplit{p}(:, 1),'color','w','LineWidth',0.5);
end
hold off
title('Max Normalized')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%    %%%%%%%%%%%%%% Analyzing time centerd activity %%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% extrating Left Frontal Activity %%%%%
leftFrontalMask = single(roiMasks.leftFrontal); leftFrontalMask(roiMasks.leftFrontal==0)=nan;
Actdata.leftFrontal = squeeze(nanmean(nanmean(trigCaSig .* leftFrontalMask,1),2));

%%%%%%%% extrating Left Parietal Activity %%%%%
leftParietalMask = single(roiMasks.leftParietal); leftParietalMask(roiMasks.leftParietal==0)=nan;
Actdata.leftParietal = squeeze(nanmean(nanmean(trigCaSig .* leftParietalMask,1),2));

%%%%%%%% extrating Left FLA Activity %%%%%
leftFLAMask = single(roiMasks.leftFLA); leftFLAMask(roiMasks.leftFLA==0)=nan;
Actdata.leftFLA = squeeze(nanmean(nanmean(trigCaSig .* leftFLAMask,1),2));

%%%%%%%% extrating Left FLP Activity %%%%%
leftFLPMask = single(roiMasks.leftFLP); leftFLPMask(roiMasks.leftFLP==0)=nan;
Actdata.leftFLP = squeeze(nanmean(nanmean(trigCaSig .* leftFLPMask,1),2));

%%%%%%%% extrating right Frontal Activity %%%%%
rightFrontalMask = single(roiMasks.rightFrontal); rightFrontalMask(roiMasks.rightFrontal==0)=nan;
Actdata.rightFrontal = squeeze(nanmean(nanmean(trigCaSig .* rightFrontalMask,1),2));

%%%%%%%% extrating right Parietal Activity %%%%%
rightParietalMask = single(roiMasks.rightParietal); rightParietalMask(roiMasks.rightParietal==0)=nan;
Actdata.rightParietal = squeeze(nanmean(nanmean(trigCaSig .* rightParietalMask,1),2));

%%%%%%%% extrating right FLA Activity %%%%%
rightFLAMask = single(roiMasks.rightFLA); rightFLAMask(roiMasks.rightFLA==0)=nan;
Actdata.rightFLA = squeeze(nanmean(nanmean(trigCaSig .* rightFLAMask,1),2));

%%%%%%%% extrating right FLP Activity %%%%%
rightFLPMask = single(roiMasks.rightFLP); rightFLPMask(roiMasks.rightFLP==0)=nan;
Actdata.rightFLP = squeeze(nanmean(nanmean(trigCaSig .* rightFLPMask,1),2));


%%%%%%% Plotting the reference image with the masks %%%%%%%%
hRefIm = figure;
imagesc(meanImNorm,nmScl); axis image; 
colormap(cmap2)
colorbar
hold on
for p = 1:length(dorsalMaps.edgeOutlineSplit)
    plot( dorsalMaps.edgeOutlineSplit{p}(:, 2),dorsalMaps.edgeOutlineSplit{p}(:, 1),'color','w','LineWidth',0.5);
end
imagesc(double(leftFrontalMask)*-1,'AlphaData',double(leftFrontalMask)*0.7);
imagesc(double(leftParietalMask)*-1,'AlphaData',double(leftParietalMask)*0.7);
imagesc(double(leftFLAMask)*-1,'AlphaData',double(leftFLAMask)*0.7);
imagesc(double(leftFLPMask)*-1,'AlphaData',double(leftFLPMask)*0.7);
imagesc(double(rightFrontalMask)*-1,'AlphaData',double(rightFrontalMask)*0.7);
imagesc(double(rightParietalMask)*-1,'AlphaData',double(rightParietalMask)*0.7);
imagesc(double(rightFLAMask)*-1,'AlphaData',double(rightFLAMask)*0.7);
imagesc(double(rightFLPMask)*-1,'AlphaData',double(rightFLPMask)*0.7);
refImgWithMasks = getframe(hRefIm);
refImgWithMasks = refImgWithMasks.cdata;

%% %%%%%%%%% Plotting activity Data %%%%%%%%%
%%%%%%%%%% plot heat map activity %%%%%%%%%%%%%
segt = linspace(-tbeftrig,tafttrig,trig_frms);
roiNames = fieldnames(Actdata);
hpScl = [-0.04 0.04];
h2 = figure;
set(h2,'position',[10 400  1260   400])
for ii = 1:length(roiNames)
subplot(2,4,ii)
imagesc(segt,1:size(Actdata.( roiNames{ii} ),2),smoothdata(Actdata.( roiNames{ii} ),1,'movmean',3)',hpScl)
set(gca,'YDir','normal')
hold on
plot([0 0],[0 size(Actdata.( roiNames{ii} )',2)+0.5],'g','LineWidth',1)
colormap(cmap2)
colorbar
title(roiNames{ii})
hold off
end

%%%%%%%%%%%%% ploting mean activity %%%%%%%%%%%%%%%%%%
h3 = figure;
set(h3,'position',[1 1  1260   400])
mpYScl = [-0.02 0.05];
nTrials = size(trigCaSig,4);
for ii = 1:length(roiNames)
    subplot(2,4,ii)
    meanAct = mean((Actdata.( roiNames{ii} )),2)';
    sdAct = std((Actdata.( roiNames{ii} )),[],2)';
    seAct = sdAct/sqrt(nTrials);
    fill([segt fliplr(segt)],[meanAct + 2*seAct,fliplr(meanAct - 2*seAct)],'c','FaceAlpha',0.3,'EdgeColor','none');
    hold on
    plot(segt,meanAct,'k','LineWidth',2)
    plot([0 0],mpYScl,'r')
    ylim(mpYScl)
    xlim([-3 3])
    title(roiNames{ii})
    hold off
end

%% %%%%%%%%%%%%%%%% Saving Data %%%%%%%%%%%%%%%
clc
disp('!!!!!!!!! MAKE SURE THE PATH TO SAVE AND FILENAME IS CORRECT !!!!!!!!!!')
%%%%%%%% Enter the correct path to save the data %%%%%%%%%%%%% 
actSpath = 'G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\MaskRoiSelectionAnalysis\NoCorrection\HandBlockedTrials\PelletInMouthOnset_HandBlocked';

SignalDur = [num2str(tafttrig) 'sec']; %%%%%%%%%% Get Signal duration string

%%%%%%%%%%%% obtain correct Mouse folder to save the data %%%%%%%%%
if contains(lower(fnFeat.sname_ex),'fezf')
    MouseFold = 'FezF2Ai148';
elseif contains(lower(fnFeat.sname_ex),'plex')
    MouseFold = 'PlexinD1Ai148';
elseif contains(lower(fnFeat.sname_ex),'tle4')
    MouseFold = 'Tle4Ai148';
elseif contains(lower(fnFeat.sname_ex),'cba')
    MouseFold = 'CBAAi93h';
end


%% %%%%%%%%%%%%%% Saving the activity %%%%%%%%%%%%%%%%%%%%
actFname = [fnFeat.sname_ex(1:usFeat.us_idx-5) SignalDur '.mat']; %%%% enter file name to save everytime !!!
disp(['The File name being Saved is : ' actFname]);

playSound;
data.Actdata = Actdata;
data.Trials = IDsThatMadeIt;
data.Behavior = 'PIMOnset';
data.MouseID = fnFeat.sname_ex(1:usFeat.us_idx-6);
data.BehaviorOnset = BehaviorTimes;
data.meanImg = meanIm;
data.refImgWithMasks = refImgWithMasks;
data.actTime = segt;
save(fullfile(actSpath,MouseFold,actFname),'data');

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Functions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [fnFeat, usFeat ] = getFileNameProperties(fpath)
%%%%%%%%%%%%% getting signal file name %%%%%%%%%%%%%%
listing_csv = dir([fpath '\*.csv']);
[~, sflname] = fileparts(fileparts(fpath));
spath = fullfile(fileparts(fileparts(fileparts(fpath))), 'Data_Corrected', sflname);
listing_sig = dir([spath '\*.mat']);
sname_all = natsortfiles({listing_sig.name}');
sname_ex = sname_all{1};
us_idx = find(sname_ex == '_',1,'last');

%%%%%%%% getting body trajectory file name %%%%%%%%%%%%
fname_all = natsortfiles({listing_csv.name}');
fname_allC1 = fname_all( contains(fname_all,'c1_T'));
fname_allC2 = fname_all( contains(fname_all,'c2_T'));

fname_exC1 = fname_allC1{1};
fname_us_idxC1 = find(fname_exC1 == '_');
fname_deep_idxC1 = strfind(fname_exC1, 'Deep');
bidx_stC1 = fname_us_idxC1(end-4);
bidx_endC1 = fname_deep_idxC1;

fname_exC2 = fname_allC2{1};
fname_us_idxC2 = find(fname_exC2 == '_');
fname_deep_idxC2 = strfind(fname_exC2, 'Deep');
bidx_stC2 = fname_us_idxC2(end-4);
bidx_endC2 = fname_deep_idxC2;


%%% updating all properties
fnFeat.sname_all = sname_all;
fnFeat.fname_allC1 = fname_allC1;
fnFeat.fname_allC2 = fname_allC2;
fnFeat.sname_ex = sname_ex;
fnFeat.fname_exC1 = fname_exC1;
fnFeat.fname_exC2 = fname_exC2;
fnFeat.spath = spath;

usFeat.us_idx = us_idx;
usFeat.bidx_stC1 = bidx_stC1;
usFeat.bidx_endC1 = bidx_endC1;
usFeat.bidx_stC2 = bidx_stC2;
usFeat.bidx_endC2 = bidx_endC2;
end