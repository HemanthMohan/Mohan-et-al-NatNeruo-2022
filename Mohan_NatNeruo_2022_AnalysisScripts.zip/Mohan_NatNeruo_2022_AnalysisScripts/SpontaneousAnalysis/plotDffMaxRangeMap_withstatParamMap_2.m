clear all; close all; clc
%%
load('F:\Hemanth_CSHL\WideField\Data\cmapPlexFez.mat');
plexData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\SpontaneousData\AllenFOVRegistered\MaxRangeDffData\PlexinD1Ai148_202012142020121520210126_dffMaxRangeData.mat');
plexData = plexData.data; 
fezData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\SpontaneousData\AllenFOVRegistered\MaxRangeDffData\FezF2Ai148_202012142020121520210126_dffMaxRangeData.mat');
fezData = fezData.data;
AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.
%% Sample dorsal map and mask path
dmName = ['20210126_PlexinD1Ai148_c8m2_spont_dorsalMap.mat'];
fpath = 'G:\Hemanth_CSHL\WideField\Data_Corrected\20210126_PlexinD1Ai148_c8m2_spont';
load(fullfile(fpath,dmName));
dmMap = dorsalMaps.edgeOutlineSplit;
%% %%%%%%% load max data
fezMaps_maxdff = fezData.maxMapAll;
plexMaps_maxdff = plexData.maxMapAll;
fezMaps_maxdffMean = nanmean(fezMaps_maxdff,3);
plexMaps_maxdffMean = nanmean(plexMaps_maxdff,3);
diffMap_maxDff = plexMaps_maxdffMean - fezMaps_maxdffMean;
%% perfrom statistical parametric maps with FDR calculation
mapSz = size(fezMaps_maxdff);
fezMap = reshape(fezMaps_maxdff,mapSz(1)*mapSz(2),mapSz(3))';
plexMap = reshape(plexMaps_maxdff,mapSz(1)*mapSz(2),mapSz(3))';
parfor ii = 1:size(fezMap,2)
    [pVal(1,ii)] = ranksum(fezMap(:,ii),plexMap(:,ii));
%     [~,pVal(1,ii)] = ttest2(fezMap(:,ii),plexMap(:,ii));
end
pValMap = reshape(pVal,mapSz(1),mapSz(2));
%% %%% calculate the false discovery reate
q_fdr = 0.05; %% set the acceptable false discovery rate
[~,pCrt] = fdr_bh(pVal,q_fdr); %% alternate fdr_bh function
%% generate pval masks
pMask = pValMap<pCrt;
diffMap_maxDiffTh = diffMap_maxDff.*pMask;
%% %%%%%%%%%%%% plotting variance maps %%%%%%%%%%%%%%
close all
h1 = figure;
imScl = [-0.05 , 0.05];
imagesc(diffMap_maxDiffTh,imScl); axis image; colorbar;colormap(cmap)
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2),dmMap{p}(:, 1),'color','k');
end
hold off
title(['PlexinD1 - Fez max dff diff map cross thrieshold. FDR =  ' num2str(q_fdr)] )


axis(gca,[24 560 88 536]);
%% %%%%%%%%%%%%% saving the figures %%%%%%%%%%
if AskSaving == 1
    saveFig = input('Do you want to save the current figures : ');
    if saveFig == 1
        %%% saving figures
        savepath = fullfile(['G:\Hemanth_CSHL\WideField\Data_Figures\SpontaneousPlots\dffMaxRangeMaps\'], ...
            ['dffMaxdffMaps_statParamTest_FezPlex.fig']);
        savefig(h1,savepath)
    end
end
