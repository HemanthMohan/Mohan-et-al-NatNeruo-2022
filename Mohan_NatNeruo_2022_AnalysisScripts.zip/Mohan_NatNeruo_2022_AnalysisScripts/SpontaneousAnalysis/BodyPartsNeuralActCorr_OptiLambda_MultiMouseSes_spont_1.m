clear all; close all;clear mem; clc
%%
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
cmapUse = cmap2; %% which cmap to use to plot
[fname fpath] = uigetfile('*.mat');
AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.
%% %%%%%%%%%%%%%%% enter details to group sessions %%%%%%%%%%%%%
mouseIds = ['c']; %%%% enter the mouse ID to concatenate activity or even a part of it to concatedate across differenct mice
mouseType = ['FezF2'];
sessionType = ['spont'];
% dateIn = {'20201214';'20201215'};
dateIn = {'20201214';'20201215';'20210126'};

% % %%%%%%%%%%%%%%%%%%% get file  name structure %%%%%%%%%%%%
parentFold = fileparts(fileparts(fpath));
foldNames = [];
if length(dateIn)>=1
    for ii = 1:length(dateIn)
        FoldCont = dir(fullfile(fileparts(fileparts(fpath)),[dateIn{ii} '*', mouseType '*', mouseIds '*',sessionType '*']));
        foldNames = [foldNames;{FoldCont.name}'];
    end
else
    FoldCont = dir(fullfile(fileparts(fileparts(fpath)),[dateIn '*', mouseType '*', mouseIds '*',sessionType '*']));
    foldNames = [foldNames;{FoldCont.name}];
end

%% extract Nerural activity varaince explained by distinct body parts  %%%%%%%%%
redRat = 0.5; % how much to reduce the neural frame size
bRedRat = 0.4; % how much to reducte the behavior video frame size
ndDims = 200;  % number of neural activity dimentions to use as dependent variables
bpFreq = [0.01,5]; % frequency to filter both neural activity and behavior video
LambdaVals = 0:10:5000; % ridge regressino lambda
tic
for kk = 1:length(foldNames) %% change to 1:length(foldNames)
    close all
    disp(['Processing Data from ' foldNames{kk}]);
    fpath1 = [fullfile(parentFold,foldNames{kk}) '\'];
    fname1 = [foldNames{kk} '_dffV_1.mat'];
    [crossValTestR2FullModel(kk,1),crossValTestR2BodyParts(kk,:),bodyParts,metaParameters{kk}] = ...
        getNeuralBodyPartFit(fpath1,fname1,redRat,bRedRat,ndDims,bpFreq,LambdaVals);
end
%% loading data
data.crossValTestR2FullModel = crossValTestR2FullModel;
data.crossValTestR2BodyParts = crossValTestR2BodyParts;
data.bodyParts = bodyParts;
data.metaParameters = metaParameters;
data.LambdaVals = LambdaVals;
data.ndDims = ndDims;
data.bpFreq = bpFreq;
data.redRat = redRat;
data.bRedRat = bRedRat ;
data.mouseType = mouseType;
data.sessions = foldNames;
data.date = date;
%% saving data
if contains(lower(mouseType),'fezf')
    CellType = 'FezF2Ai148'; %%%%% options 'FezF2Ai148'; 'PlexinD1Ai148'; 'Tle4Ai148'; 'CBAAi93h'
elseif contains(lower(mouseType),'plexin')
    CellType = 'PlexinD1Ai148';
end

if AskSaving == 1
    filename = CellType;
    saveData = input('Do you want to save the current data : ');
    if saveData == 1
        %%%% saving data
        datapath = fullfile(['G:\Hemanth_CSHL\WideField\Data_Analysis\SpontaneousData\AllenFOVRegistered\BodyPartsNeuralActEncodingData'],[filename '_' cell2mat(dateIn') '_BodyPartsNeuralActivity_OptiLambda_VarianceData.mat']);
        save(datapath,'data')
    end
end
%% %%%%%%%%%%%%%%% functions %%%%%%%%%%%%%%%%%%%%%%
function [R2Full_test_OptiMean,R2Body_test_OptiMean ,bodyMasks,metaParameters] = ...
    getNeuralBodyPartFit(fpath,fname,redRat,bRedRat,ndDims,bpFreq,LambdaVals)
%% %%%%%%% get behavior file path %%%%%%%%%%
[~,bFoldname] = fileparts(fileparts(fpath));
bFpath = fullfile(fileparts(fileparts(fileparts(fpath))),'BehaviorData',bFoldname);
%% %%%%%%%%%%%%%%%% get file  name structure %%%%%%%%%%%%
[fnFeat, usFeat ] = getFileNameProperties([bFpath '\']);%%% get all fileNames variables
%%%% get signal file path
sname_in = [fnFeat.sname_ex(1:usFeat.us_idx) '1.mat'];
dFilepath= fullfile(fnFeat.spath,sname_in);
%%%% get behavior file path
[~,bFoldname] = fileparts(fileparts(fpath));
bFilename = [bFoldname '_c2_T_1.mp4']; %%%%% file name of c2 camera
bPath = fullfile(fileparts(fileparts(fileparts(fpath))),'BehaviorData',bFoldname);
bFilepath = fullfile(bPath,bFilename);
%%%% get trajectory file path
fnameinC2 = fnFeat.fname_exC2;
filepathC2 = fullfile(bPath,fnameinC2);
%% %%%%%%%%%%%%%%% load allen dorasal map coordinates %%%%%
dmName = [fnFeat.sname_ex(1:usFeat.us_idx-5) 'dorsalMap.mat'];
load(fullfile(fnFeat.spath,dmName));
tform = dorsalMaps.tform;
dmMap = dorsalMaps.edgeOutlineSplit;
%% %%%%%%%% loading full FOV mask file %%%%%%%%%
[~,fovMaskFold] = fileparts(fnFeat.spath);
fovMaskPath = fullfile(fileparts(fileparts(fnFeat.spath)),['Data'],fovMaskFold);
fovMask = load(fullfile(fovMaskPath,[fnFeat.sname_ex(1:find(fnFeat.sname_ex == '_',2,'last')) 'refMask.mat']));
%% %%%%%%%%%% Enter the ratio to scale down the images
redRat = redRat;
%% %%%%%%%%%%% extract dffV Signal %%%%%%%%%%%%%%%%%
tic
disp(['Loading raw signal and building Matrix...'])
sname_in = [fnFeat.sname_ex(1:usFeat.us_idx) '1.mat'];
CaSig_in = load(dFilepath);dffV = CaSig_in.dffV; clearvars CaSig_in
dffV= imwarp(dffV.*fovMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*dorsalMaps.maskScaled;
dffV = imresize(dffV,redRat);
dffVsz = size(dffV);
bpFreq = bpFreq;%%%%%%% bandpass frequence range
Fs = 30;
[dffVfilt] = single(filter_dffVFs(dffV,bpFreq,Fs));
toc
%% %%%%%%% load Behavior file %%%%%%%%% Behavior is recored at 20 FPS
disp(['Loading Behavior Video...'])
bRedRat = bRedRat; %%%%% how much to reduce the behavior video size
vR = VideoReader(bFilepath);
bVlen =ceil(vR.Duration*vR.FrameRate);
bVid = [];
tic
for ii=1:bVlen
    bVid(:,:,ii) = imresize(rgb2gray(read(vR,ii)),bRedRat);
end
toc
bVidSz = size(bVid);
bFs = 20; %%%% sampling frequenfy of behavior video
bVid = single(filter_dffVFs(bVid,bpFreq,bFs)); %%% filtered behavior %%% filtered behavior
bVidME = diff(bVid,1,3); bVidME = cat(3,bVidME(:,:,1),bVidME);%%%behavior  motion Energy of filterd signal
bVidMEmat = reshape(bVidME,bVidSz(1)*bVidSz(2),bVidSz(3));
bVidMEmat = resample(double(bVidMEmat'),dffVsz(3),bVidSz(3))'; %%% resampled sampling rate of behavior
%% %%%%%%%% generate body parts masks
[bMasks] = getBehMasks(filepathC2,bRedRat,bVidSz);
figure
imagesc(bVid(:,:,1)); axis image;hold on; colormap gray;
imagesc(bMasks.whiskerMask,'AlphaData',bMasks.whiskerMask);
imagesc(bMasks.noseMask,'AlphaData',bMasks.noseMask);
imagesc(bMasks.mouthMask,'AlphaData',bMasks.mouthMask);
imagesc(bMasks.handsMask,'AlphaData',bMasks.handsMask);
maskedFrame = getframe(gca);maskedFrame = rgb2gray( maskedFrame.cdata);
close(gcf)
%% %%%%%%  Extract masked motion variance
disp(['Obtaining behavior mask motion energy...'])
bodyMasks = fieldnames(bMasks);
behavME = [];
tic
for ii = 1:length(bodyMasks)
    maskedME = [bVidMEmat .* bMasks.(bodyMasks{ii})(:)]';
    maskedMEEnv = abs(hilbert(maskedME)); %%%% extract amplitude of motion energy
    behavME(:,ii) = nanmean(maskedMEEnv,2);
end
toc

%% %%%%%%% Neural actvity svd Components %%%%%%%%
tic
disp(['Perform SVD of dffV...'])
dffVMat = reshape(dffVfilt,dffVsz(1)*dffVsz(2),dffVsz(3));
[dU,dS,dV] = svd(dffVMat,'econ');
dffVar = var([dS*dV']');
dffCumVar = cumsum(dffVar/sum(dffVar))*100;
toc
%% %%%%%%%% Build predictors and predited variables
disp(['Perform Regression...'])
ndDims = ndDims; %%% number of neural activity dimentions to use as dependent variables
%%%% build dependent variables of neural activity
Yall = [dS(1:ndDims,1:ndDims) * dV(:,1:ndDims)']'; %%% with out mean correction
%%%% build independent variables of behavior components
Xall = zscore(behavME);
%% %%%%%%%%%% split X and Y into training and Test Set with cross validation
X = Xall;
Y = Yall;
allIdx = [1:size(X,1)]';
kF = 5; %%%%% k fold value
[trainIdx,testIdx] = kFoldSplit(allIdx,kF);
%% perform  ridge regression on Full Model with all Lambdas
LambdaVals = LambdaVals; %%% def 0:10:5000
RSS_test_allLam = [];
R2Full_test_allLam = [];
RSS_train_allLam = [];
R2Full_train_allLam = [];
tic
for  ti = 1:kF;
    %% split
    X_train = X(trainIdx(:,ti),:);
    X_test = X(testIdx(:,ti),:);
    Y_train = Y(trainIdx(:,ti),:);
    Y_test = Y(testIdx(:,ti),:);
    %% Perform ridge Regression
    betarFull = [];
    for ii = 1:size(Y_train,2)
        betarFull(:,:,ii) = ridge(Y_train(:,ii),X_train,LambdaVals,0);
    end
    %% obtain predictions on test and train set
    for ll = 1:length(LambdaVals)
        Ypred_test{ti,ll}  = [ones(length(X_test),1) X_test]*squeeze(betarFull(:,ll,:));
        Ypred_train {ti,ll}= [ones(length(X_train),1) X_train]*squeeze(betarFull(:,ll,:));
        %T calculate R2
        TSS_test = sum((Y_test(:) - mean(Y_test(:))).^2);
        RSS_test_allLam(ti,ll) = sum((Ypred_test{ti,ll}(:) - Y_test(:)).^2);
        R2Full_test_allLam(ti,ll) = (1 - RSS_test_allLam(ti,ll)/TSS_test)*100;
        
        TSS_train = sum((Y_train(:) - mean(Y_train(:))).^2);
        RSS_train_allLam(ti,ll) = sum((Ypred_train{ti,ll}(:) - Y_train(:)).^2);
        R2Full_train_allLam (ti,ll)= (1 - RSS_train_allLam(ti,ll)/TSS_train)*100;
    end
    
    
end
toc
%% %%%%%%%%%%% find Optimal Lambda and beta Vals
RSS_test_allLamMean = mean(RSS_test_allLam);
[minRss optiLambdaLoc] =  min(RSS_test_allLamMean); %%% find lambda with minimum cv RSS
optiLambda = LambdaVals(optiLambdaLoc);
betarFull_opti = squeeze(betarFull(:,optiLambdaLoc,:));
betarBody_opti = betarFull_opti(2:end,:);
%% %%%%%%%%% obtain crossvalidated R2 for optimum beta valus
R2Full_test_Opti = R2Full_test_allLam(:,optiLambdaLoc);
R2Full_test_OptiMean = mean(R2Full_test_Opti);
%% Spatial projecion of bodyparts weights
spProjs = reshape(dU(:,1:ndDims)*betarBody_opti',dffVsz(1),dffVsz(2),size(X,2)) ;

%% %%%%%%%%%%%% explained cv test R2 based on Body parts

for jj = 1:size(X,2)
    for ti = 1:kF;
        XBody_test = X(testIdx(:,ti),jj);
        YpredBody_test = XBody_test * betarBody_opti(jj,:);
        YBody_test = Y(testIdx(:,ti),:);
        TSSbody = sum((YBody_test(:) - mean(YBody_test(:))).^2);
        RSSbody = sum((YBody_test(:) - YpredBody_test(:)).^2);
        R2Body_test_Opti(ti,jj) = (1 - (RSSbody/TSSbody))*100;%%cvR2 based on body parts
    end
end
R2Body_test_OptiMean = mean(R2Body_test_Opti);

%% meta parameters
metaParameters.maskedFrame = maskedFrame;
metaParameters.RSS_test_allLam = RSS_test_allLam;
metaParameters.R2_test_allLam = R2Full_test_allLam;
metaParameters.RSS_train_allLam = RSS_train_allLam;
metaParameters.R2_train_allLam  = R2Full_train_allLam ;
metaParameters.betarFull = betarFull;
metaParameters.optiLambda = optiLambda;
metaParameters.optiLambdaLoc = optiLambdaLoc;
metaParameters.betarFull_opti = betarFull_opti;
metaParameters.R2Full_test_Opti = R2Full_test_Opti;
metaParameters.R2Full_test_OptiMean  = R2Full_test_OptiMean;
metaParameters.betarBody_opti = betarBody_opti;
metaParameters.spProjs = spProjs;
metaParameters.R2Body_test_Opti = R2Body_test_Opti ;
metaParameters.R2Body_test_OptiMean = R2Body_test_OptiMean;
end


%% %%%%%%%%%%%%%% Function %%%%%%%%%%%%%%%%%%%
function [bMasks] = getBehMasks(filepathC2,bRedRat,bVidSz)
pcutoffC2 = 0.8;
[TrajDataC2 BodyPartsC2] =  ExtractBodyTraj(filepathC2,pcutoffC2);

close all
noseLoc = round(nanmean(TrajDataC2.nose(:,1:2))*bRedRat);
lowerlipLoc = round(nanmean(TrajDataC2.lowerlip(:,1:2))*bRedRat);
rhandLoc = round(nanmean(TrajDataC2.rhand(:,1:2))*bRedRat);

bMasks.whiskerMask = nan(bVidSz(1:2));bMasks.whiskerMask(noseLoc(2):noseLoc(2)+round(40*bRedRat), noseLoc(1)+round(42*bRedRat):noseLoc(1)+round(104*bRedRat)) = 1;
bMasks.noseMask = nan(bVidSz(1:2));bMasks.noseMask(noseLoc(2)-round(15*bRedRat) :noseLoc(2)+round(15*bRedRat), noseLoc(1)-round(15*bRedRat):noseLoc(1)+round(15*bRedRat)) = 1;
bMasks.mouthMask = nan(bVidSz(1:2));bMasks.mouthMask(lowerlipLoc(2)-round(10*bRedRat) :lowerlipLoc(2)+round(25*bRedRat), lowerlipLoc(1)-round(25*bRedRat):lowerlipLoc(1)+round(55*bRedRat)) = 1;
bMasks.handsMask = nan(bVidSz(1:2));bMasks.handsMask(rhandLoc(2)-round(60*bRedRat) :rhandLoc(2)+round(100*bRedRat), rhandLoc(1)-round(70*bRedRat):rhandLoc(1)+round(140*bRedRat)) = 1;
end

function [trainIdx,testIdx] = kFoldSplit(allIdx,kF)
allIdx = allIdx;
sigL = length(allIdx);
trainPer = 1 - 1/kF;
trainL = round(trainPer*sigL);
testL = sigL-trainL;
trainIdx = zeros(sigL ,1);
trainIdx(1:round(trainPer*sigL)) = ones;
testIdx = trainIdx==0;
for ii = 2:kF
    trainIdx(:,ii) = circshift(trainIdx(:,ii-1),testL);
end
testIdx = trainIdx==0;
trainIdx = logical(trainIdx);
testIdx = logical(testIdx);
end