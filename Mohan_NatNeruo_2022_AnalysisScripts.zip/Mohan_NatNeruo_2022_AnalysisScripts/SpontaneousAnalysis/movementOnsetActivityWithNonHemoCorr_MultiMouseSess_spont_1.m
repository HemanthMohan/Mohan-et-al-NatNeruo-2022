clear all; close all; clc
%%
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
cmapUse = cmap2; %% which cmap to use to plot
[fname fpath] = uigetfile('*.mat');
AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.

%% %%%%%%%%%%%%%%% enter details to group sessions %%%%%%%%%%%%%
mouseIds = ['c']; %%%% enter the mouse ID to concatenate activity or even a part of it to concatedate across differenct mice
mouseType = ['FezF2']; %% FezF2; PlexinD1
sessionType = ['spont'];
% dateIn = {'20201215'};
dateIn = {'20201214';'20201215';'20210126'};
% % %%%%%%%%%%%%%%%%%%% get file  name structure %%%%%%%%%%%%
parentFold = fileparts(fileparts(fpath));
foldNames = [];
if length(dateIn)>=1
    for ii = 1:length(dateIn)
        FoldCont = dir(fullfile(fileparts(fileparts(fpath)),[dateIn{ii} '*', mouseType '*', mouseIds '*',sessionType '*']));
        foldNames = [foldNames;{FoldCont.name}'];
    end
else
    FoldCont = dir(fullfile(fileparts(fileparts(fpath)),[dateIn '*', mouseType '*', mouseIds '*',sessionType '*']));
    foldNames = [foldNames;{FoldCont.name}];
end


%% %%%%%%%%%%%%%%% Extract activty from parital and hindlimb signals for all sessions  %%%%%
tic
dffAct_parietal_all = [];
dffAct_hindlimb_all = [];

dffCaAct_parietal_all = [];
dffCaAct_hindlimb_all = [];

dffHemoAct_parietal_all = [];
dffHemoAct_hindlimb_all = [];

for kk = 1:length(foldNames)
    disp(['Processing Data from ' foldNames{kk}]);
    %%%%%%%%%%%%%%%%% load allen dorasal map coordinates %%%%%
    fpath1 = [fullfile(parentFold,foldNames{kk}) '\'];
    fname1 = [foldNames{kk} '_dffV_1.mat'];
    [act{kk},caTm] = getActivity(fpath1,fname1);
    dffAct_parietal_all = [dffAct_parietal_all;act{kk}.dffAct_parietal];
    dffAct_hindlimb_all = [dffAct_hindlimb_all;act{kk}.dffAct_hindlimb];
    
    dffCaAct_parietal_all = [dffCaAct_parietal_all;act{kk}.dffCaAct_parietal];
    dffCaAct_hindlimb_all = [dffCaAct_hindlimb_all;act{kk}.dffCaAct_hindlimb];
    
    dffHemoAct_parietal_all = [dffHemoAct_parietal_all;act{kk}.dffHemoAct_parietal];
    dffHemoAct_hindlimb_all = [dffHemoAct_hindlimb_all;act{kk}.dffHemoAct_hindlimb];
end
toc/60
%% update data
data.alldffAct = act;
data.sigTm = caTm;
data.dffAct_parietal_all = dffAct_parietal_all;
data.dffAct_hindlimb_all  = dffAct_hindlimb_all ;
data.dffCaAct_parietal_all = dffCaAct_parietal_all;
data.dffCaAct_hindlimb_all = dffCaAct_hindlimb_all;
data.dffHemoAct_parietal_all = dffHemoAct_parietal_all;
data.dffHemoAct_hindlimb_all = dffHemoAct_hindlimb_all;
data.mouseType = mouseType;
data.sessions = foldNames;
data.date = date;
%% saving data
if contains(lower(mouseType),'fezf')
    CellType = 'FezF2Ai148'; %%%%% options 'FezF2Ai148'; 'PlexinD1Ai148'; 'Tle4Ai148'; 'CBAAi93h'
elseif contains(lower(mouseType),'plexin')
    CellType = 'PlexinD1Ai148';
end

if AskSaving == 1
    filename = CellType;
    saveData = input('Do you want to save the current data : ');
    if saveData == 1
        %%%% saving data
        datapath = fullfile(['G:\Hemanth_CSHL\WideField\Data_Analysis\SpontaneousData\AllenFOVRegistered\movementOnsetActivity'],[filename '_' cell2mat(dateIn') '_moveOnsetData.mat']);
        save(datapath,'data')
    end
end
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% function %%%%%%%%%%%%%%
function [act,caTm] = getActivity(fpath,fname)

%% %%%%%%% extracting signal file path
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
load('F:\Hemanth_CSHL\WideField\Data\cmap3.mat');
cmapUse = cmap2; %% which cmap to use to plot
AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.
%% %%%%%%% get behavior file path %%%%%%%%%%
[~,bFoldname] = fileparts(fileparts(fpath));
bFilename = [bFoldname '_c2_T_1.mp4']; %%%%% file name of c2 camera
bFilepath = fullfile(fileparts(fileparts(fileparts(fpath))),'BehaviorData',bFoldname,bFilename);
%% %%%%%%%%%%%%%%% load allen dorasal map coordinates %%%%%
dmName = [fname(1:end-10) 'dorsalMap.mat'];
load(fullfile(fpath,dmName));
tform = dorsalMaps.tform;
dmMap = dorsalMaps.edgeOutlineSplit;
%% %%%%%%%% loading FOV mask file %%%%%%%%%
[~,maskFold] = fileparts(fileparts(fpath));
maskPath = fullfile(fileparts(fileparts(fileparts(fpath))),['Data'],maskFold);
fovMask = load(fullfile(maskPath,[fname(1:end-10) 'refMask.mat']));
%% %%%%%% load parietal hindlimb roi mask
roiMasks = load('G:\Hemanth_CSHL\WideField\Data_Analysis\SpontaneousData\AllenFOVRegistered\spontaneousMovementRoiMasks.mat');
roiMasks = roiMasks.data.roiMasks;
%% %%%%%%%%%% Enter the ratio to scale down the images
redRat = 0.5;
%% %%%%%%%%%%% extract dffV Signal %%%%%%%%%%%%%%%%%
Fs = 30;
tic
disp(['Loading raw signal and building Matrix...'])
vfile = fullfile(fpath,fname);
vfileCa = fullfile(fileparts(fileparts(fileparts(fpath))),'Data_NoHemoCorrected',bFoldname,[fname(1:end-6) 'Ca_1.mat'] );
vfileHemo = fullfile(fileparts(fileparts(fileparts(fpath))),'Data_NoHemoCorrected',bFoldname,[fname(1:end-6) 'Hemo_1.mat']);
dffV = load(vfile); dffV = dffV.dffV;
dffVCa = load(vfileCa); dffVCa = dffVCa.dffVCa;
dffVHemo = load(vfileHemo); dffVHemo = dffVHemo.dffVHemo;

dffV= imwarp(dffV.*fovMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*dorsalMaps.maskScaled;
dffVCa = imwarp(dffVCa.*fovMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*dorsalMaps.maskScaled;
dffVHemo = imwarp(dffVHemo.*fovMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*dorsalMaps.maskScaled;

dffV = imresize(dffV,redRat);
dffVCa = imresize(dffVCa,redRat);
dffVHemo = imresize(dffVHemo,redRat);

dffVsz = size(dffV);
bpFreq = [0.01 5]; %%%%%%% bandpass frequence range
[dffVfilt] = single(filter_dffVFs(dffV,bpFreq,Fs));
[dffVCafilt] = single(filter_dffVFs(dffVCa,bpFreq,Fs));
[dffVHemofilt] = single(filter_dffVFs(dffVHemo,bpFreq,Fs));
sTm = linspace(0,dffVsz(3)/Fs,dffVsz(3)); %%%%%%% dffV time stamps
toc
%% %%%%%%% load Behavior file %%%%%%%%% Behavior is recored at 20 FPS
bFs = 20; %%% behavior video sampling frequency
disp(['Loading Behavior Video...'])
bRedRat = 0.4; %%%%% how much to reduce the behavior video size
vR = VideoReader(bFilepath);
bVlen =ceil(vR.Duration*vR.FrameRate);
bVid = [];
tic
for ii=1:bVlen
    bVid(:,:,ii) = imresize(rgb2gray(read(vR,ii)),bRedRat);
end
toc
bVid = single(bVid);
bVidSz = size(bVid);
bVidFilt = single(filter_dffVFs(bVid,bpFreq,bFs)); %%% filtered behavior 
bVidFiltME = diff(bVidFilt,1,3); bVidFiltME = cat(3,bVidFiltME(:,:,1),bVidFiltME);%
bVidFiltMEMat = reshape(bVidFiltME,bVidSz(1)*bVidSz(2),bVidSz(3));
bVidVar = var(bVidFiltMEMat,1);
bVidVar_rs = resample(double(bVidVar),dffVsz(3),bVidSz(3)); %%% upsampled bvid Variance
bTm = linspace(0,bVidSz(3)/bFs,bVidSz(3)); %%%%%%% behav video time stamps
%% extract movement active onset times
actThresh = 0.5*std(bVidVar)
% set(0,'DefaultFigureWindowStyle','docked')
% h1 = figure;
% 
% plot(sTm,bVidVar_rs); hold on; plot([0,sTm(end)],[actThresh,actThresh],'k--')
activeIdx = zeros(length(sTm),1);
activeIdx(find(bVidVar_rs>actThresh)) = 1;
activeIdx(1:29) = 0;activeIdx(end-30:end)=0; %% remove active index from the first one second and last one second
activeOnsetIdxAll = find(diff(activeIdx)==1);
activeOffsetIdxAll = find(diff(activeIdx)==-1);
activeOnsetTmAll = sTm(activeOnsetIdxAll)';
activeOffsetTmAll = sTm(activeOffsetIdxAll)';
% hold on
% plot(sTm,activeIdx*10)
% hold off
%% filtering and extracting relevant active times
activeOnsetIdx = activeOnsetIdxAll;
activeOffsetIdx = activeOffsetIdxAll;
activeOnsetTm = activeOnsetTmAll;
activeOffsetTm = activeOffsetTmAll; 
%%%%%% remove movments happeing too early after the end of previous
%%%%%% movement
interMovIntervalTh = 1; %% inter movement interval threshold in seconds
discardIdx = [];
for ii = 2:length(activeOnsetIdx)
    if activeOnsetTm(ii) - activeOffsetTm(ii-1) <= interMovIntervalTh
        discardIdx = [discardIdx;ii];
    end
end
activeOnsetIdx(discardIdx)=[];
activeOffsetIdx(discardIdx)=[];
activeOnsetTm(discardIdx)=[];
activeOffsetTm(discardIdx)=[];

%%%%%%% remove the active episodes if it starts to early and late
rmIdx = find(activeOnsetTm<=1 | activeOnsetTm >= (sTm(end)-2) );%%
activeOnsetIdx(rmIdx) = [];
activeOffsetIdx(rmIdx) = [];
activeOnsetTm(rmIdx) = [];
activeOffsetTm(rmIdx) = [];

%%%%%
% hold on
% plot(activeOnsetTm,20,'r.','MarkerSize',13)
% plot(activeOffsetTm,20,'m.','MarkerSize',13)
% plot(activeOnsetTmAll,10,'g.','MarkerSize',13)
% plot(activeOffsetTmAll,10,'b.','MarkerSize',13)
% hold off
%% %%%%%%%%%%%%%%%%%%% extracting calcium activity %%%%%%%%%%%%%%%%%%%%%%
%% %% get roi mask
parietalMask = imresize(double(roiMasks.ParietalCortex ),redRat); parietalMask(parietalMask==0) = nan;parietalMask(~isnan(parietalMask))=1; %%% parietal cortex Mask
hindlimbMask = imresize(double(roiMasks.HindlimbCortex ),redRat); hindlimbMask(hindlimbMask==0) = nan;hindlimbMask(~isnan(hindlimbMask))=1; %%% parietal cortex Mask
allMask = nanmean(cat(3,parietalMask,hindlimbMask),3);
% h2 = figure;
% imagesc(var(dffVfilt,[],3)); axis image; colormap hot;colorbar
% hold on
% for p = 1:length(dorsalMaps.edgeOutlineSplit)
%     plot( dorsalMaps.edgeOutlineSplit{p}(:, 2)*redRat,dorsalMaps.edgeOutlineSplit{p}(:, 1)*redRat,'color','w','LineWidth',0.5);
% end
% imagesc(double(allMask)*-1,'AlphaData',double(allMask),[0,1.3e-3]);
% hold off
%% %%%% extract signal from roi 
dff_parietal = squeeze(nanmean(nanmean(dffVfilt.*parietalMask)));
dff_hindlimb = squeeze(nanmean(nanmean(dffVfilt.*hindlimbMask)));

dffCa_parietal = squeeze(nanmean(nanmean(dffVCafilt.*parietalMask)));
dffCa_hindlimb = squeeze(nanmean(nanmean(dffVCafilt.*hindlimbMask)));

dffHemo_parietal = squeeze(nanmean(nanmean(dffVHemofilt.*parietalMask)));
dffHemo_hindlimb = squeeze(nanmean(nanmean(dffVHemofilt.*hindlimbMask)));

% h3 = figure;
% plot(sTm,bVidVar_rs*0.01,'k');
% hold on
% plot(sTm,dff_parietal,'r-');
% plot(sTm,dff_hindlimb,'g-');
% 
% plot(sTm,dffCa_parietal,'r--');
% plot(sTm,dffCa_hindlimb,'g--');
% 
% plot(sTm,dffHemo_parietal,'r-.');
% plot(sTm,dffHemo_hindlimb,'g-.');
% 
% hold off
%% %%%% compute movement centered activity
durBef = 1; %% duration before movement onset in seconds
durAft = 2; %% duration after movement onset in seconds

for ii = 1:length(activeOnsetIdx)
    act.dffAct_parietal(ii,:) = dff_parietal(activeOnsetIdx(ii)-Fs*durBef : activeOnsetIdx(ii)+ Fs*durAft); 
    act.dffAct_hindlimb(ii,:) = dff_hindlimb(activeOnsetIdx(ii)-Fs*durBef : activeOnsetIdx(ii)+ Fs*durAft); 
    
    act.dffCaAct_parietal(ii,:) = dffCa_parietal(activeOnsetIdx(ii)-Fs*durBef : activeOnsetIdx(ii)+ Fs*durAft); 
    act.dffCaAct_hindlimb(ii,:) = dffCa_hindlimb(activeOnsetIdx(ii)-Fs*durBef : activeOnsetIdx(ii)+ Fs*durAft);  
    
    act.dffHemoAct_parietal(ii,:) = dffHemo_parietal(activeOnsetIdx(ii)-Fs*durBef : activeOnsetIdx(ii)+ Fs*durAft); 
    act.dffHemoAct_hindlimb(ii,:) = dffHemo_hindlimb(activeOnsetIdx(ii)-Fs*durBef : activeOnsetIdx(ii)+ Fs*durAft);   
end


%% plotting singals
caTm = linspace(-durBef,durAft,size(act.dffAct_parietal,2));

end
