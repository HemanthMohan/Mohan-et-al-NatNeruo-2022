clear all; close all; clc;
%% Load Data
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
load('F:\Hemanth_CSHL\WideField\Data\cmap1.mat');
plexData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\SpontaneousData\AllenFOVRegistered\ActiveQuiescentVarianceMapData\PlexinD1Ai148_202012142020121520210126_AQvarianceData.mat');
plexData = plexData.data;
fezData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\SpontaneousData\AllenFOVRegistered\ActiveQuiescentVarianceMapData\FezF2Ai148_202012142020121520210126_AQvarianceData.mat');
fezData = fezData.data;
%% Sample dorsal map and mask path
dmName = ['20210126_PlexinD1Ai148_c8m2_spont_dorsalMap.mat'];
fpath = 'G:\Hemanth_CSHL\WideField\Data_Corrected\20210126_PlexinD1Ai148_c8m2_spont';
load(fullfile(fpath,dmName));
dmMap = dorsalMaps.edgeOutlineSplit;
redRat = plexData.redRat;
%% extract variance maps
varMap_act_plex = plexData.varMap_act;
varMap_pas_plex = plexData.varMap_pas;
varMap_act_fez = fezData.varMap_act;
varMap_pas_fez = fezData.varMap_pas;
numSes = length(plexData.sessions);
%% %%%%%%% perform PCA
grpIdx = [repmat({'plex'},numSes,1);repmat({'fez'},numSes,1)];
imSz = size(varMap_act_plex);
varMapAct = [reshape(varMap_act_plex,imSz(1)*imSz(2),imSz(3)) reshape(varMap_act_fez,imSz(1)*imSz(2),imSz(3))]';
varMapPas = [reshape(varMap_pas_plex,imSz(1)*imSz(2),imSz(3)) reshape(varMap_pas_fez,imSz(1)*imSz(2),imSz(3))]';
[coefAct,scoreAct] = pca(varMapAct);
[coefPas,scorePas] = pca(varMapPas);
tSneAct = tsne(varMapAct,'Algorithm','exact');
tSnePas = tsne(varMapPas,'Algorithm','exact');

%% %%%%%%%%%%% plotting PCA clusters
h1 = figure;h1.Position = [33         424        1380         554];
ax(1) = subplot(2,4,1);
gscatter(scoreAct(:,1),scoreAct(:,2),grpIdx); axis square
xlabel('PC1');ylabel('PC2')
title (' Active variance PCA Clusters')
ax(2) = subplot(2,4,2);
gscatter(scorePas(:,1),scorePas(:,2),grpIdx); axis square
xlabel('PC1');ylabel('PC2')
title ('Passive Variance PCA Clusters')

subplot(2,4,5)
imagesc(reshape(coefAct(:,1),imSz(1),imSz(2)),[-max(abs(coefAct(:,1))) max(abs(coefAct(:,1)))]);colormap(cmap);axis image; colorbar;
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','w');
end
hold off
title('Active PCA Dim 1')

subplot(2,4,6)
imagesc(reshape(coefAct(:,2),imSz(1),imSz(2)),[-max(abs(coefAct(:,2))) max(abs(coefAct(:,2)))]);colormap(cmap);axis image; colorbar;
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','w');
end
hold off
title('Active PCA Dim 2')

subplot(2,4,7)
imagesc(reshape(coefPas(:,1),imSz(1),imSz(2)),[-max(abs(coefPas(:,1))) max(abs(coefPas(:,1)))]);colormap(cmap);axis image; colorbar;
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','w');
end
hold off
title('Passive PCA Dim 1')

subplot(2,4,8)
imagesc(reshape(coefPas(:,2),imSz(1),imSz(2)),[-max(abs(coefPas(:,2))) max(abs(coefPas(:,2)))]);colormap(cmap);axis image; colorbar;
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','w');
end
hold off
title('Passive PCA Dim 2')
%% %%%%%%%%%%% plotting tSNe clusters
h2 = figure;h2.Position = [228   558   852   420];
subplot(1,2,1);
gscatter(tSneAct(:,1),tSneAct(:,2),grpIdx); axis square
xlabel('tsne1');ylabel('tsne2')
title (' Active variance tSne Clusters')
subplot(1,2,2);
gscatter(tSnePas(:,1),tSnePas(:,2),grpIdx); axis square
xlabel('tsne1');ylabel('tshe2')
title ('Passive Variance tSne Clusters')
% linkaxes(ax,'y')

%% %%%%%%%%%%%%% saving the figures %%%%%%%%%%

saveFolder = 'G:\Hemanth_CSHL\WideField\Data_Figures\SpontaneousPlots\VarianceMapsPCAclusteringPlots\';
fileName1 = ['ActivePassivePCAClustersDimensions.fig'];
savePath1 = fullfile(saveFolder,fileName1);
fileName2 = ['ActivePassiveTSneClusters.fig'];
savePath2 = fullfile(saveFolder,fileName2);
saveFig = input('Do you want to save the current figure : ');
if saveFig == 1
    savefig(h1,savePath1)
    saveas(h1,[savePath1(1:end-4) '.svg']);
    
    savefig(h2,savePath2)
    saveas(h2,[savePath2(1:end-4) '.svg']);
end