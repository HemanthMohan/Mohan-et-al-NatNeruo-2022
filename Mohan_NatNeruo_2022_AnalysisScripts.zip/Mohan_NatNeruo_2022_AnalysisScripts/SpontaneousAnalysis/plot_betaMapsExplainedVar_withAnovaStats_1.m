clear all; close all;clear mem; clc
%% load data
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
fezData = load(['G:\Hemanth_CSHL\WideField\Data_Analysis\SpontaneousData\AllenFOVRegistered\BodyPartsNeuralActEncodingData\' ...
    'FezF2Ai148_202012142020121520210126_BodyPartsNeuralActivity_OptiLambda_VarianceData.mat']);
fezData = fezData.data;

plexData = load(['G:\Hemanth_CSHL\WideField\Data_Analysis\SpontaneousData\AllenFOVRegistered\BodyPartsNeuralActEncodingData\' ...
    'PlexinD1Ai148_202012142020121520210126_BodyPartsNeuralActivity_OptiLambda_VarianceData.mat']);
plexData = plexData.data;

%% Sample dorsal map and mask path
dmName = ['20210126_PlexinD1Ai148_c8m2_spont_dorsalMap.mat'];
fpath = 'G:\Hemanth_CSHL\WideField\Data_Corrected\20210126_PlexinD1Ai148_c8m2_spont';
load(fullfile(fpath,dmName));
dmMap = dorsalMaps.edgeOutlineSplit;
%%
bodyMasks = plexData.bodyParts;
redRat = plexData.redRat;
%% %%%%%%%%%%%% get mean beta maps %%%%%%%%%
for ii = 1:length(plexData.sessions)
    for jj = 1:length(bodyMasks)
        plexMap.(bodyMasks{jj})(:,:,ii) = plexData.metaParameters{ii}.spProjs(:,:,jj);
        fezMap.(bodyMasks{jj})(:,:,ii) = fezData.metaParameters{ii}.spProjs(:,:,jj);
    end
end

for jj = 1:length(bodyMasks)
    plexMapMean.(bodyMasks{jj}) = mean(plexMap.(bodyMasks{jj}),3);
    fezMapMean.(bodyMasks{jj}) = mean(fezMap.(bodyMasks{jj}),3);

    plexMapMeanNorm.(bodyMasks{jj}) = plexMapMean.(bodyMasks{jj})./max(plexMapMean.(bodyMasks{jj})(:));
    fezMapMeanNorm.(bodyMasks{jj}) = fezMapMean.(bodyMasks{jj})./max(fezMapMean.(bodyMasks{jj})(:))  ;
end

%% %%%%%%%%%% plot average and normalized beta maps
close all
h(1) = figure(1);
set(gcf,'Position',[35 726 1878 291]);
imSclPlex = [-0.006,0.006];
for jj = 1:length(bodyMasks)
    subplot(1,length(bodyMasks),jj)
    imagesc(plexMapMean.(bodyMasks{jj}),imSclPlex)
    colormap(cmap2);axis image; colorbar
    hold on
    for p = 1:length(dmMap)
        plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','w');
    end
    hold off
    title(bodyMasks{jj})
end
sgtitle('PlexinD1')
h(2) = figure(2);
set(gcf,'Position',[32 660 1878 291]);
imSclPlexN = [-1,1];
for jj = 1:length(bodyMasks)  
    subplot(1,length(bodyMasks),jj)
    imagesc(plexMapMeanNorm.(bodyMasks{jj}),imSclPlexN)
    colormap(cmap2);axis image; colorbar
    hold on
    for p = 1:length(dmMap)
        plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','w');
    end
    hold off
    title(bodyMasks{jj})
end
sgtitle('PlexinD1-Normalized')

h(3) = figure(3);
set(gcf,'Position',[89 580 1878 291]);
imSclFez = [-0.007,0.007];
for jj = 1:length(bodyMasks)
    subplot(1,length(bodyMasks),jj)
    imagesc(fezMapMean.(bodyMasks{jj}),imSclFez)
    colormap(cmap2);axis image; colorbar
    hold on
    for p = 1:length(dmMap)
        plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','w');
    end
    hold off
    title(bodyMasks{jj})
end
sgtitle('FezF2')

h(4) = figure(4);
set(gcf,'Position',[166 455 1878 291]);
imSclFezN = [-1,1];
for jj = 1:length(bodyMasks)
    subplot(1,length(bodyMasks),jj)
    imagesc(fezMapMeanNorm.(bodyMasks{jj}),imSclFezN)
    colormap(cmap2);axis image; colorbar
    hold on
    for p = 1:length(dmMap)
        plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','w');
    end
    hold off
    title(bodyMasks{jj})
end
sgtitle('FezF2-Normalized')
%% perfrom two way Anova stats
plexSz = size(plexData.crossValTestR2BodyParts);
fezSz = size(fezData.crossValTestR2BodyParts);
temp1 = cellstr(repmat("Plex",plexSz(1),plexSz(2)));
temp2 = cellstr(repmat("Fez",plexSz(1),plexSz(2)));
temp3 = cellstr([repmat("whisker",plexSz(1),1) repmat("nose",plexSz(1),1) ...
    repmat("mouth",plexSz(1),1) repmat("hands",plexSz(1),1)]);

g1 = [temp1(:);temp2(:)];
g2 = [temp3(:);temp3(:)];
allBodyR2 = [plexData.crossValTestR2BodyParts(:); fezData.crossValTestR2BodyParts(:)];
figure;
[anova_p,tbl,stats] = anovan(allBodyR2,{g1,g2},'model','interaction','varnames',{'cellType','bodyPart'});
figure;
[mCompTable,~,~,gnames] = multcompare(stats,"Dimension",[1 2]);
plexVsFezWhisker_p = mCompTable(1,6);
plexVsFezNose_p = mCompTable(14,6);
plexVsFezMouth_p = mCompTable(23,6);
plexVsFezHands_p = mCompTable(28,6);
statsText = "Two Way Anova with multCompare" + newline + ...
    "Whiskers Plex Vs Fez :" + num2str(plexVsFezWhisker_p) + newline + ...
    "nose Plex Vs Fez :" + num2str(plexVsFezNose_p) + newline + ...
    "Mouth Plex Vs Fez :" + num2str(plexVsFezMouth_p) + newline + ...
    "Hands Plex Vs Fez :" + num2str(plexVsFezHands_p) + newline;
%% plot variance explained bar plots
h(5) = figure(5);
set(gcf,'Position',[284   558   956   420])
subplot(1,2,1)
boxplot(fezData.crossValTestR2BodyParts,'Labels',bodyMasks)
set(gca,'TickDir','out')
ylim([-5,45])
title('FezF2')
ylabel('CV Varience Explained')

subplot(1,2,2)
boxplot(plexData.crossValTestR2BodyParts,'Labels',bodyMasks)
set(gca,'TickDir','out')
ylim([-5,45])
ylabel('CV Varience Explained')
title('PlexinD1')
text(1,37,statsText)

annotation(h(5),'textbox', [0, 0.9, 0, 0], 'string', [fezData.sessions;plexData.sessions],'FontSize',7, 'Interpreter', 'none')
% annotation(h(6),'textbox', [0, 0.9, 0, 0], 'string', plexData.sessions,'FontSize',7, 'Interpreter', 'none')
%% Save figure

filename = ['plexFez_BodyPartsNeualActExpVar_figures_anovaStats.fig']
savedim = input('Do you want to save the current figure : ');
if savedim == 1
    savepath = fullfile(['G:\Hemanth_CSHL\WideField\Data_Figures\SpontaneousPlots\BodyPartsNeuralActEncodingPlots\'],filename);
    savefig(h,savepath)
end
