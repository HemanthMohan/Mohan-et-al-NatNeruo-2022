clear all; close all; clc
%%
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
cmapUse = cmap2; %% which cmap to use to plot
[fname fpath] = uigetfile('*.mat');
AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.
%% Sample dorsal map and mask path
dmName = [fname(1:end-10) 'dorsalMap.mat'];
load(fullfile(fpath,dmName));
dmMap = dorsalMaps.edgeOutlineSplit;
%% %%%%%%%%%%%%%%% enter details to group sessions %%%%%%%%%%%%%
mouseIds = ['c']; %%%% enter the mouse ID to concatenate activity or even a part of it to concatedate across differenct mice
mouseType = ['PlexinD1'];
sessionType = ['spont'];
% dateIn = {'20201214';'20201215'};
dateIn = {'20201214';'20201215';'20210126'};

% % %%%%%%%%%%%%%%%%%%% get file  name structure %%%%%%%%%%%%
parentFold = fileparts(fileparts(fpath));
foldNames = [];
if length(dateIn)>=1
    for ii = 1:length(dateIn)
        FoldCont = dir(fullfile(fileparts(fileparts(fpath)),[dateIn{ii} '*', mouseType '*', mouseIds '*',sessionType '*']));
        foldNames = [foldNames;{FoldCont.name}'];
    end
else
    FoldCont = dir(fullfile(fileparts(fileparts(fpath)),[dateIn '*', mouseType '*', mouseIds '*',sessionType '*']));
    foldNames = [foldNames;{FoldCont.name}];
end
%% extract varince maps
%% extract cvR2  %%%%%%%%%
bpFreq = [0.01 5]; %%%%%%% bandpass frequence range
redRat = 0.75;
tic
for kk = 1:length(foldNames)
    close all
    disp(['Processing Data from ' foldNames{kk}]);
    fpath1 = [fullfile(parentFold,foldNames{kk}) '\'];
    fname1 = [foldNames{kk} '_dffV_1.mat'];
    [varMap_act(:,:,kk),varMap_pas(:,:,kk),meanMap_act(:,:,kk) ...
        ,meanMap_pas(:,:,kk),bVidVar_rs(:,kk),dffVvar(:,kk),actThresh(kk)] = getVarMaps(fpath1,fname1,bpFreq,redRat);
end
toc
%% loading data
data.varMap_act = varMap_act;
data.varMap_pas = varMap_pas;
data.meanMap_act = meanMap_act;
data.meanMap_pas = meanMap_pas;
data.behavVidVariance = bVidVar_rs;
data.dffVvariance = dffVvar;
data.activeVarThresh = actThresh;
data.bpFreq = bpFreq;
data.redRat = redRat;
data.mouseType = mouseType;
data.sessions = foldNames;
data.date = date;
%% saving data
if contains(lower(mouseType),'fezf')
    CellType = 'FezF2Ai148'; %%%%% options 'FezF2Ai148'; 'PlexinD1Ai148'; 'Tle4Ai148'; 'CBAAi93h'
elseif contains(lower(mouseType),'plexin')
    CellType = 'PlexinD1Ai148';
end

if AskSaving == 1
    filename = CellType;
    saveData = input('Do you want to save the current data : ');
    if saveData == 1
        %%%% saving data
        datapath = fullfile(['G:\Hemanth_CSHL\WideField\Data_Analysis\SpontaneousData\AllenFOVRegistered\ActiveQuiescentVarianceMapData'],[filename '_' cell2mat(dateIn') '_AQvarianceData.mat']);
        save(datapath,'data')
    end
end
%% %%%%%%% extracting signal file path
function [varMap_act,varMap_pas,meanMap_act,meanMap_pas,bVidVar_rs,dffVvar,actThresh] = getVarMaps(fpath,fname,bpFreq,redRat)
%% %%%%%%% get behavior file path %%%%%%%%%%
[~,bFoldname] = fileparts(fileparts(fpath));
bFilename = [bFoldname '_c2_T_1.mp4']; %%%%% file name of c2 camera
bFilepath = fullfile(fileparts(fileparts(fileparts(fpath))),'BehaviorData',bFoldname,bFilename);
%% %%%%%%%%%%%%%%% load allen dorasal map coordinates %%%%%
dmName = [fname(1:end-10) 'dorsalMap.mat'];
load(fullfile(fpath,dmName));
tform = dorsalMaps.tform;
dmMap = dorsalMaps.edgeOutlineSplit;
%% %%%%%%%% loading FOV mask file %%%%%%%%%
[~,maskFold] = fileparts(fileparts(fpath));
maskPath = fullfile(fileparts(fileparts(fileparts(fpath))),['Data'],maskFold);
fovMask = load(fullfile(maskPath,[fname(1:end-10) 'refMask.mat']));
%% %%%%%%%%%% Enter the ratio to scale down the images
redRat = redRat;
%% %%%%%%%%%%% extract dffV Signal %%%%%%%%%%%%%%%%%
Fs = 30;
tic
disp(['Loading raw signal and building Matrix...'])
vfile = fullfile(fpath,fname);
load(vfile);
dffV= imwarp(dffV.*fovMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*dorsalMaps.maskScaled;
dffV = imresize(dffV,redRat);
dffVsz = size(dffV);
bpFreq = bpFreq; %%%%%%% bandpass frequence range
[dffVfilt] = single(filter_dffVFs(dffV,bpFreq,Fs));
sTm = linspace(0,dffVsz(3)/Fs,dffVsz(3)); %%%%%%% dffV time stamps
toc
%% %%%%%%% load Behavior file %%%%%%%%% Behavior is recored at 20 FPS
bFs = 20; %%% behavior video sampling frequency
disp(['Loading Behavior Video...'])
bRedRat = 0.4; %%%%% how much to reduce the behavior video size
vR = VideoReader(bFilepath);
bVlen =ceil(vR.Duration*vR.FrameRate);
bVid = [];
tic
for ii=1:bVlen
    bVid(:,:,ii) = imresize(rgb2gray(read(vR,ii)),bRedRat);
end
toc
bVid = single(bVid);
bVidSz = size(bVid);
bVidFilt = single(filter_dffVFs(bVid,bpFreq,bFs)); %%% filtered behavior 
bVidFiltME = diff(bVidFilt,1,3); bVidFiltME = cat(3,bVidFiltME(:,:,1),bVidFiltME);%
bVidFiltMEMat = reshape(bVidFiltME,bVidSz(1)*bVidSz(2),bVidSz(3));
bVidVar = var(bVidFiltMEMat,1);
bVidVar_rs = resample(double(bVidVar),dffVsz(3),bVidSz(3)); %%% upsampled bvid Variance
bTm = linspace(0,bVidSz(3)/bFs,bVidSz(3)); %%%%%%% behav video time stamps
%% Split DffV into active and passive blocks
actThresh = 0.2*std(bVidVar);
activeIdx = find(bVidVar_rs>actThresh);
passiveIdx = find(bVidVar_rs<=actThresh);
dffVfilt_act = dffVfilt(:,:,activeIdx);
dffVfilt_pas = dffVfilt(:,:,passiveIdx);
%% Active vs Passive Variance split
dffVfiltMat = reshape(dffVfilt,dffVsz(1)*dffVsz(2),dffVsz(3));
dffVvar = var(dffVfiltMat);
dffVvar_tot = sum(dffVvar);
dffVvar_act = sum(dffVvar(activeIdx));
dffVvar_pas = sum(dffVvar(passiveIdx));
dffVvar_actPer = dffVvar_act/dffVvar_tot*100;
dffVvar_pasPer = dffVvar_pas/dffVvar_tot*100;
%% Create Mean and Variance Maps
varMap_act = var(dffVfilt_act,[],3);
varMap_pas = var(dffVfilt_pas,[],3);
meanMap_act = nanmean(dffVfilt_act,3);
meanMap_pas = nanmean(dffVfilt_pas,3);
end
