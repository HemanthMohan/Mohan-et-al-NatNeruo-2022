clear all; close all;clear mem; clc
%% load data
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
plexData = load(['G:\Hemanth_CSHL\WideField\Data_Analysis\SpontaneousData\AllenFOVRegistered\movementOnsetActivity\' ...
    'PlexinD1Ai148_202012142020121520210126_moveOnsetData.mat']);
plexData = plexData.data;

fezData = load(['G:\Hemanth_CSHL\WideField\Data_Analysis\SpontaneousData\AllenFOVRegistered\movementOnsetActivity\' ...
    'FezF2Ai148_202012142020121520210126_moveOnsetData.mat']);
fezData = fezData.data;
%% peak difference comparison between hemo corrected and uncorrected signal
tmStSp = [0,1]; %% start and stop time of signals between which to consider peak values
sigTm = plexData.sigTm;
stSpIdx = find(sigTm>tmStSp(1) & sigTm<tmStSp(2));

dffActMax_parietal_fez = max(fezData.dffAct_parietal_all(:,stSpIdx),[],2);
dffCaActMax_parietal_fez = max(fezData.dffCaAct_parietal_all(:,stSpIdx),[],2);
diffMax_parietal_fez = dffCaActMax_parietal_fez - dffActMax_parietal_fez;

dffActMax_hindlimb_fez = max(fezData.dffAct_hindlimb_all(:,stSpIdx),[],2);
dffCaActMax_hindlimb_fez = max(fezData.dffCaAct_hindlimb_all(:,stSpIdx),[],2);
diffMax_hindlimb_fez = dffCaActMax_hindlimb_fez - dffActMax_hindlimb_fez;

dffActMax_parietal_plex = max(plexData.dffAct_parietal_all(:,stSpIdx),[],2);
dffCaActMax_parietal_plex = max(plexData.dffCaAct_parietal_all(:,stSpIdx),[],2);
diffMax_parietal_plex = dffCaActMax_parietal_plex - dffActMax_parietal_plex;

dffActMax_hindlimb_plex = max(plexData.dffAct_hindlimb_all(:,stSpIdx),[],2);
dffCaActMax_hindlimb_plex = max(plexData.dffCaAct_hindlimb_all(:,stSpIdx),[],2);
diffMax_hindlimb_plex = dffCaActMax_hindlimb_plex - dffActMax_hindlimb_plex;

% 
% diffMax_parietal_plex(find(diffMax_parietal_plex<-0.05))=[];
% diffMax_hindlimb_plex(find(diffMax_hindlimb_plex<-0.05))=[];
%% normalitu test
[~,normTest_p_dffMax] = kstest((diffMax_hindlimb_fez - nanmean(diffMax_hindlimb_fez))/nanstd(diffMax_hindlimb_fez))

%% two way anova of peak difference comparison
g1 = [repmat("plex",length(diffMax_parietal_plex),1);  repmat("fez",length(diffMax_parietal_fez),1); ...
    repmat("plex",length(diffMax_hindlimb_plex),1); repmat("fez",length(diffMax_hindlimb_fez),1);];
g2 = [repmat("parietal",length(diffMax_parietal_plex),1);  repmat("parietal",length(diffMax_parietal_fez),1); ...
    repmat("hindlimb",length(diffMax_hindlimb_plex),1); repmat("hindlimb",length(diffMax_hindlimb_fez),1);];
dffDat = [diffMax_parietal_plex ;diffMax_parietal_fez;diffMax_hindlimb_plex;diffMax_hindlimb_fez];

[anovaP,anovaTbl,anovaStats] = anovan(dffDat,{g1 g2},"Model","interaction", ...
    "Varnames",["CellType","Roi"]);

[multResults,~,~,gnames] = multcompare(anovaStats,"Dimension",[1 2]);
[~,ttestP_diffMax_parietal,~,ttestStats] = ttest2(diffMax_hindlimb_plex,diffMax_hindlimb_fez)

%% plot distribution of peak difference comparison
close all
clear h
h(1) = figure;
grpId = join([g1 g2],2);
boxplot(dffDat,grpId);
ylim([-0.05, 0.05])
ylabel('dff')
title('difference of peak activity between Hemo uncorrected and corrected signal. 0 to 1 sec after movement onset')
inTxt = [join([ string(anovaTbl(1:4,1))  string(anovaTbl(1:4,7))],2); " mult compare p";...
    string(num2str(multResults(:,[1,2,6])))]
text(1.3,0.03,inTxt)

%% correlation comparison between hemo corrected and uncorrected signal
sigTm = plexData.sigTm;
cc_parietal_fez = diag(corr(fezData.dffAct_parietal_all',fezData.dffCaAct_parietal_all')) ;
cc_hindlimb_fez = diag(corr(fezData.dffAct_hindlimb_all',fezData.dffCaAct_hindlimb_all')) ;

cc_parietal_plex = diag(corr(plexData.dffAct_parietal_all',plexData.dffCaAct_parietal_all')) ;
cc_hindlimb_plex = diag(corr(plexData.dffAct_hindlimb_all',plexData.dffCaAct_hindlimb_all')) ;
%% normalitu test
[~,normTest_p_cc] = kstest((cc_hindlimb_fez - nanmean(cc_hindlimb_fez))/nanstd(cc_hindlimb_fez));
%% two way anova of cross correlation comparison
g1 = [repmat("plex",length(cc_parietal_plex),1);  repmat("fez",length(cc_parietal_fez),1); ...
    repmat("plex",length(cc_hindlimb_plex),1); repmat("fez",length(cc_hindlimb_fez),1);];
g2 = [repmat("parietal",length(cc_parietal_plex),1);  repmat("parietal",length(cc_parietal_fez),1); ...
    repmat("hindlimb",length(cc_hindlimb_plex),1); repmat("hindlimb",length(cc_hindlimb_fez),1);];
dffDat_cc = [cc_parietal_plex ;cc_parietal_fez; cc_hindlimb_plex; cc_hindlimb_fez];

grpId = join([g1 g2],2);

[kw_p,kw_tbl,kw_stats] = kruskalwallis(dffDat_cc,grpId);
[multResults_cc] = multcompare(kw_stats);
[ranksumP_cc_hindlimb,~,Ranksumstats] = ranksum(cc_hindlimb_plex,cc_hindlimb_fez);

%% plot distribution of correlation comparison
h(2) = figure;
boxplot(dffDat_cc,grpId);
ylim([0.5, 1.1])
ylabel('cross correlation')
title('correlation between Hemo uncorrected and corrected signal')
inTxt = [['KruskalWallis P = ' num2str(kw_p) ]; " mult compare p";...
    string(num2str(multResults_cc(:,[1,2,6])))]
text(1.3,0.95,inTxt)
%% %%%%%%%%%% plot movement onset activity 
h(3) = figure;
subplot(2,2,1)
ax = gca;
plotMeanSem(sigTm,plexData.dffAct_parietal_all,2,'b',ax)
hold on
plotMeanSem(sigTm,plexData.dffCaAct_parietal_all,2,'k',ax)
ylim([-0.02 0.04])
legend('','dffHemoCorrected','','dffHemoUncorrected')
title('plex - Parietal')

subplot(2,2,2)
ax = gca;
plotMeanSem(sigTm,plexData.dffAct_hindlimb_all,2,'b',ax)
hold on
plotMeanSem(sigTm,plexData.dffCaAct_hindlimb_all,2,'k',ax)
ylim([-0.02 0.04])
legend('','dffHemoCorrected','','dffHemoUncorrected')
title('plex - Hindlimb')

subplot(2,2,3)
ax = gca;
plotMeanSem(sigTm,fezData.dffAct_parietal_all,2,'g',ax)
hold on
plotMeanSem(sigTm,fezData.dffCaAct_parietal_all,2,'k',ax)
ylim([-0.02 0.04])
legend('','dffHemoCorrected','','dffHemoUncorrected')
title('fez - parietal')

subplot(2,2,4)
ax = gca;
plotMeanSem(sigTm,fezData.dffAct_hindlimb_all,2,'g',ax)
hold on
plotMeanSem(sigTm,fezData.dffCaAct_hindlimb_all,2,'k',ax)
ylim([-0.02 0.04])
legend('','dffHemoCorrected','','dffHemoUncorrected')
title('fez - hindlimb')
%% Save figure
filename = ['plexFez_movementOnsetactivityWithHemoNonHemoComparison_figures.fig']
savedim = input('Do you want to save the current figure : ');
if savedim == 1
    savepath = fullfile(['G:\Hemanth_CSHL\WideField\Data_Figures\SpontaneousPlots\moveOnsetActivityWithHemoNoHemoComparison'],filename);
    savefig(h,savepath)
end
