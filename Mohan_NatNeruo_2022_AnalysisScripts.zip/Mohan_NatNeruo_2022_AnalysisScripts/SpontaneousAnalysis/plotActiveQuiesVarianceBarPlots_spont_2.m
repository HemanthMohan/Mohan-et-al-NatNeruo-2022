clear all; close all; clc
%%
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
plexData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\SpontaneousData\AllenFOVRegistered\ActiveQueiscentStdValues\PlexinD1Ai148_202012142020121520210126_AQStdVarData.mat');
plexData = plexData.data; 
fezData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\SpontaneousData\AllenFOVRegistered\ActiveQueiscentStdValues\FezF2Ai148_202012142020121520210126_AQStdVarData.mat');
fezData = fezData.data;
AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.

%% %%%%%%%%%% Generate average maps Maps %%%%%%%%%
varAct_fez = fezData.varAct;
varPas_fez = fezData.varPas;
varAct_plex = plexData.varAct;
varPas_plex = plexData.varPas;

%% perform stats
[pvalFez,~, statsFez] = signrank(varAct_fez,varPas_fez);
[pvalPlex,~, statsPlex] = signrank(varAct_plex,varPas_plex);
%% %%%%%%%%%%%% plotting std Barplotsmaps %%%%%%%%%%%%%%
grpVal = [repmat({'Quiescent'},size(varPas_fez,1),1);repmat({'Active'},size(varPas_fez,1),1)];
varPasAct_plex = [varPas_plex;varAct_plex];
varPasAct_fez = [varPas_fez;varAct_fez];
h1 = figure; h1.Position = [120   482   754   449];
ax1(1) = subplot(1,2,1);
boxplot(varPasAct_plex,grpVal)
text(1,2e-4,['signrank pVal = ' num2str(pvalPlex)])
title('Variance PlexinD1')


ax1(2) = subplot(1,2,2);
boxplot(varPasAct_fez,grpVal)
text(1,2e-4,['signrank pVal = ' num2str(pvalFez)])
title('Variance FezF2')
ylim([0 3.5e-4])

linkaxes(ax1)
annotation(h1,'textbox', [0, 0.9, 0, 0], 'string', [fezData.sessions;plexData.sessions],'FontSize',7, 'Interpreter', 'none')
%% %%%%%%%%%%%%% saving the figures %%%%%%%%%%
if AskSaving == 1
    saveFig = input('Do you want to save the current figures : ');
    if saveFig == 1
        %%% saving figures
        savepath1 = fullfile(['G:\Hemanth_CSHL\WideField\Data_Figures\SpontaneousPlots\ActiveQuiescentStdPlots\'], ...
            ['ActiveQuiescentVarianceBoxplot_PlexFez.fig']);
        savefig(h1,savepath1)
        saveas(h1,[savepath1(1:end-4) '.svg']);
        
    end
end
