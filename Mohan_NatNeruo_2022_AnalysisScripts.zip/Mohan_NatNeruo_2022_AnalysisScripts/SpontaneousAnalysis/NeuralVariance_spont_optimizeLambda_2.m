clear all; close all; clc
%%
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
cmapUse = cmap2; %% which cmap to use to plot
[fname fpath] = uigetfile('*.mat');
AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.
%% Sample dorsal map and mask path
dmName = [fname(1:end-10) 'dorsalMap.mat'];
load(fullfile(fpath,dmName));
dmMap = dorsalMaps.edgeOutlineSplit;
%% %%%%%%%%%%%%%%% enter details to group sessions %%%%%%%%%%%%%
mouseIds = ['c']; %%%% enter the mouse ID to concatenate activity or even a part of it to concatedate across differenct mice
mouseType = ['PlexinD1'];
sessionType = ['spont'];
% dateIn = {'20201214';'20201215'};
dateIn = {'20201214';'20201215';'20210126'};

% % %%%%%%%%%%%%%%%%%%% get file  name structure %%%%%%%%%%%%
parentFold = fileparts(fileparts(fpath));
foldNames = [];
if length(dateIn)>=1
    for ii = 1:length(dateIn)
        FoldCont = dir(fullfile(fileparts(fileparts(fpath)),[dateIn{ii} '*', mouseType '*', mouseIds '*',sessionType '*']));
        foldNames = [foldNames;{FoldCont.name}'];
    end
else
    FoldCont = dir(fullfile(fileparts(fileparts(fpath)),[dateIn '*', mouseType '*', mouseIds '*',sessionType '*']));
    foldNames = [foldNames;{FoldCont.name}];
end

%% extract cvR2  %%%%%%%%%
ndDims = 200; %%% number of neural activity dimentions to use as dependent variables
nbDims = 200; %%% number of behavior dimensions to use as independent variables
bpFreq = [0.01 5]; %%%%%%% bandpass frequence range
LambdaVals = 0:1500:100000;
redRat = 0.5; %% image size reduce ratio of dffV data
bRedRat = 0.4; %% image size reduce ratio of 
tic
for kk = 1:length(foldNames)
    close all
    disp(['Processing Data from ' foldNames{kk}]);
    fpath1 = [fullfile(parentFold,foldNames{kk}) '\'];
    fname1 = [foldNames{kk} '_dffV_1.mat'];
    [cvR2_test{kk},cvR2_train{kk},RSS_test{kk},RSS_train{kk}] = getR2(fpath1,fname1,ndDims,nbDims,bpFreq,LambdaVals,redRat,bRedRat );
end
toc

%% loading data
data.cvR2_test = cvR2_test;
data.cvR2_train = cvR2_train;
data.LambdaVals = LambdaVals;
data.ndDims = ndDims;
data.nbDims = nbDims;
data.bpFreq = bpFreq;
data.RSS_test = RSS_test;
data.RSS_train = RSS_train;
data.mouseType = mouseType;
data.sessions = foldNames;
data.date = date;
%% saving data
if contains(lower(mouseType),'fezf')
    CellType = 'FezF2Ai148'; %%%%% options 'FezF2Ai148'; 'PlexinD1Ai148'; 'Tle4Ai148'; 'CBAAi93h'
elseif contains(lower(mouseType),'plexin')
    CellType = 'PlexinD1Ai148';
end

if AskSaving == 1
    filename = CellType;
    saveData = input('Do you want to save the current data : ');
    if saveData == 1
        %%%% saving data
        datapath = fullfile(['G:\Hemanth_CSHL\WideField\Data_Analysis\SpontaneousData\AllenFOVRegistered\NeuralActivityVarianceData'],[filename '_' cell2mat(dateIn') '_OptiLambda_VarianceData.mat']);
        save(datapath,'data')
    end
end

%% %%%%%%%%%%%%%%%%% Functions %%%%%%%%%%%
function [R2_test, R2_train,RSS_test,RSS_train] = getR2(fpath,fname,ndDims,nbDims,bpFreq,LambdaVals,redRat,bRedRat)
%% %%%%%%% get behavior file path %%%%%%%%%%
[~,bFoldname] = fileparts(fileparts(fpath));
bFilename = [bFoldname '_c2_T_1.mp4']; %%%%% file name of c2 camera
bFilepath = fullfile(fileparts(fileparts(fileparts(fpath))),'BehaviorData',bFoldname,bFilename);
%% %%%%%%%%%%%%%%% load allen dorasal map coordinates %%%%%
dmName = [fname(1:end-10) 'dorsalMap.mat'];
load(fullfile(fpath,dmName));
tform = dorsalMaps.tform;
dmMap = dorsalMaps.edgeOutlineSplit;
%% %%%%%%%% loading FOV mask file %%%%%%%%%
[~,maskFold] = fileparts(fileparts(fpath));
maskPath = fullfile(fileparts(fileparts(fileparts(fpath))),['Data'],maskFold);
fovMask = load(fullfile(maskPath,[fname(1:end-10) 'refMask.mat']));
%% %%%%%%%%%% Enter the ratio to scale down the images
redRat = redRat;
%% %%%%%%%%%%% extract dffV Signal %%%%%%%%%%%%%%%%%
tic
disp(['Loading raw signal and building Matrix...'])
vfile = fullfile(fpath,fname);
load(vfile);
dffV= imwarp(dffV.*fovMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*dorsalMaps.maskScaled;
dffV = imresize(dffV,redRat);
dffVsz = size(dffV);
bpFreq = bpFreq; %%%%%%% bandpass frequence range
Fs = 30;
[dffVfilt] = single(filter_dffVFs(dffV,bpFreq,Fs));
toc
%% %%%%%%% load Behavior file %%%%%%%%% Behavior is recored at 20 FPS
disp(['Loading Behavior Video...'])
bRedRat = bRedRat; %%%%% how much to reduce the behavior video size
vR = VideoReader(bFilepath);
bVlen =ceil(vR.Duration*vR.FrameRate);
bVid = [];
tic
for ii=1:bVlen
    bVid(:,:,ii) = imresize(rgb2gray(read(vR,ii)),bRedRat);
end
toc
bVid = single(bVid);
bVidSz = size(bVid);
bFs = 20;
bVidFilt = single(filter_dffVFs(bVid,bpFreq,bFs)); %%% filtered behavior 
bVidFiltME = diff(bVidFilt,1,3); bVidFiltME = cat(3,bVidFiltME(:,:,1),bVidFiltME);%%%behavior  motion Energy of filterd signal
%% %%%%%%% Neural actvity svd Components %%%%%%%% 
tic
disp(['Perform SVD of dffV...'])
dffVMat = reshape(dffVfilt,dffVsz(1)*dffVsz(2),dffVsz(3));
[dU,dS,dV] = svd(dffVMat,'econ');
dffVar = var([dS*dV']');
dffCumVar = cumsum(dffVar/sum(dffVar))*100;
toc
%% %%%%%% behavior Motion energy svd components %%%%%%%%%%%
tic
disp(['Perform SVD of Behavior ME...'])
bVidMEMat = reshape(bVidFiltME,bVidSz(1)*bVidSz(2),bVidSz(3));
[bU,bS,bV] = svd(bVidMEMat,'econ');
bhvVar = var([bS*bV']');
bhvCumVar = cumsum(bhvVar/sum(bhvVar))*100;
toc
%% %%%%%%%% Build predictors and predited variables
disp(['Perform Regression...'])
ndDims = ndDims; %%% number of neural activity dimentions to use as dependent variables
nbDims = nbDims; %%% number of behavior dimensions to use as independent variables
%%%% build dependent variables of neural activity
Yall= [dS(1:ndDims,1:ndDims) * dV(:,1:ndDims)']'; %%% with out mean correction
%%%% build independent variables of behavior components
X_ME = single(resample(double([bS(1:nbDims,1:nbDims)*bV(:,1:nbDims)']'),dffVsz(3),bVidSz(3))); %%% sampling behav motion energy to size of cal sig
Xamp = abs(hilbert(X_ME)); %%% amplitude of the hilbert transform
%% %%%%%%%%%% split X and Y into training and Test Set with cross validation
X = zscore(Xamp);
Y = Yall;
allIdx = [1:size(X,1)]';
kF = 5; %%%%% k fold value
[trainIdx,testIdx] = kFoldSplit(allIdx,kF);

%% %%%% perfom k Fold CV with ridge regression
LambdaVals = LambdaVals;
tic
for  ti = 1:kF;
%% split
X_train = X(trainIdx(:,ti),:);
X_test = X(testIdx(:,ti),:);
Y_train = Y(trainIdx(:,ti),:);
Y_test = Y(testIdx(:,ti),:);
%% Perform ridge Regression 
% ridge regression
betar = [];
for ii = 1:size(Y_train,2)
    betar(:,:,ii) = ridge(Y_train(:,ii),X_train,LambdaVals,0);
end
%% obtain predictions on test and train set
for ll = 1:length(LambdaVals)
Ypred_test{ti,ll}  = [ones(length(X_test),1) X_test]*squeeze(betar(:,ll,:));
Ypred_train {ti,ll}= [ones(length(X_train),1) X_train]*squeeze(betar(:,ll,:));
%T calculate R2
TSS_test = sum((Y_test(:) - mean(Y_test(:))).^2);
RSS_test(ti,ll) = sum((Ypred_test{ti,ll}(:) - Y_test(:)).^2);
R2_test(ti,ll) = (1 - RSS_test(ti,ll)/TSS_test)*100;

TSS_train = sum((Y_train(:) - mean(Y_train(:))).^2);
RSS_train(ti,ll) = sum((Ypred_train{ti,ll}(:) - Y_train(:)).^2);
R2_train (ti,ll)= (1 - RSS_train(ti,ll)/TSS_train)*100;
end

end
toc
% % %%%%%%%%%%%%%
R2_testMean = mean(R2_test);
R2_trainMean = mean(R2_train);
disp([' Mean Test cvR2 = ' num2str(R2_testMean)])
end
%% %%%%%%%%%%%%%%%%% Functions %%%%%%%%%%%
function [trainIdx,testIdx] = kFoldSplit(allIdx,kF)
allIdx = allIdx;
sigL = length(allIdx);
trainPer = 1 - 1/kF;
trainL = round(trainPer*sigL);
testL = sigL-trainL;
trainIdx = zeros(sigL ,1);
trainIdx(1:round(trainPer*sigL)) = ones;
testIdx = trainIdx==0;
for ii = 2:kF
trainIdx(:,ii) = circshift(trainIdx(:,ii-1),testL);
end
testIdx = trainIdx==0;
trainIdx = logical(trainIdx);
testIdx = logical(testIdx);
end