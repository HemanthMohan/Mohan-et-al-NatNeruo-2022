clear all; close all; clc
%%
load('F:\Hemanth_CSHL\WideField\Data\cmapPlexFez.mat');
plexData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\SpontaneousData\AllenFOVRegistered\ActiveQuiescentVarianceMapData\PlexinD1Ai148_202012142020121520210126_AQvarianceData.mat');
plexData = plexData.data; 
fezData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\SpontaneousData\AllenFOVRegistered\ActiveQuiescentVarianceMapData\FezF2Ai148_202012142020121520210126_AQvarianceData.mat');
fezData = fezData.data;
AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.
%% Sample dorsal map and mask path
dmName = ['20210126_PlexinD1Ai148_c8m2_spont_dorsalMap.mat'];
fpath = 'G:\Hemanth_CSHL\WideField\Data_Corrected\20210126_PlexinD1Ai148_c8m2_spont';
load(fullfile(fpath,dmName));
dmMap = dorsalMaps.edgeOutlineSplit;
redRat = plexData.redRat;
%% perfrom statistical parametric maps with FDR calculation
mapSz = size(fezData.varMap_pas);
%%%% calculate varinace maps
fezMap_pasVar = reshape(fezData.varMap_pas,mapSz(1)*mapSz(2),mapSz(3))';
plexMap_pasVar = reshape(plexData.varMap_pas,mapSz(1)*mapSz(2),mapSz(3))';
fezMap_actVar = reshape(fezData.varMap_act,mapSz(1)*mapSz(2),mapSz(3))';
plexMap_actVar = reshape(plexData.varMap_act,mapSz(1)*mapSz(2),mapSz(3))';
pVal_pasVar = [];
pVal_actVar = [];
parfor ii = 1:size(fezMap_pasVar,2)
    [pVal_pasVar(1,ii)] = ranksum(fezMap_pasVar(:,ii),plexMap_pasVar(:,ii));
    [pVal_actVar(1,ii)] = ranksum(fezMap_actVar(:,ii),plexMap_actVar(:,ii));
    
%      [~,pVal_pasVar(1,ii)] = ttest2(fezMap_pasVar(:,ii),plexMap_pasVar(:,ii));
%     [~,pVal_actVar(1,ii)] = ttest2(fezMap_actVar(:,ii),plexMap_actVar(:,ii));
end
pValMap_pasVar = reshape(pVal_pasVar,mapSz(1),mapSz(2));
pValMap_actVar = reshape(pVal_actVar,mapSz(1),mapSz(2));


%%%% calculate mean maps

fezMap_pasMn = reshape(fezData.meanMap_pas,mapSz(1)*mapSz(2),mapSz(3))';
plexMap_pasMn = reshape(plexData.meanMap_pas,mapSz(1)*mapSz(2),mapSz(3))';
fezMap_actMn = reshape(fezData.meanMap_act,mapSz(1)*mapSz(2),mapSz(3))';
plexMap_actMn = reshape(plexData.meanMap_act,mapSz(1)*mapSz(2),mapSz(3))';
pVal_pasMn = [];
pVal_actMn = [];
parfor ii = 1:size(fezMap_pasVar,2)
    [pVal_pasMn(ii,1)] = ranksum(fezMap_pasMn(:,ii),plexMap_pasMn(:,ii));
    [pVal_actMn(ii,1)] = ranksum(fezMap_actMn(:,ii),plexMap_actMn(:,ii));
    
%     [~,pVal_pasMn(ii,1)] = ttest2(fezMap_pasMn(:,ii),plexMap_pasMn(:,ii));
%     [~,pVal_actMn(ii,1)] = ttest2(fezMap_actMn(:,ii),plexMap_actMn(:,ii));
end
pValMap_pasMn = reshape(pVal_pasMn,mapSz(1),mapSz(2));
pValMap_actMn = reshape(pVal_actMn,mapSz(1),mapSz(2));
%% %%% calculate the false discovery reate
q_fdr = 0.05; %% set the acceptable false discovery rate
[~,pCrt_pasVar] = fdr_bh(pVal_pasVar,q_fdr); %% alternate fdr_bh function
[~,pCrt_actVar] = fdr_bh(pVal_actVar,q_fdr); %% alternate fdr_bh function

[~,pCrt_pasMn] = fdr_bh(pVal_pasMn,q_fdr); %% alternate fdr_bh function
[~,pCrt_actMn] = fdr_bh(pVal_actMn,q_fdr); %% alternate fdr_bh function
%% generate pval masks
pMask_pasVar = pValMap_pasVar<pCrt_pasVar;
pMask_actVar = pValMap_actVar<pCrt_actVar;

pMask_pasMn = pValMap_pasMn<pCrt_pasMn;
pMask_actMn = pValMap_actMn<pCrt_actMn;
%% %%%%%%%%%% Generate difference maps  %%%%%%%%%
diffMap_pasVar = nanmean(plexData.varMap_pas,3) - nanmean(fezData.varMap_pas,3);
diffMap_actVar = nanmean(plexData.varMap_act,3) - nanmean(fezData.varMap_act,3);
diffMap_pasVarTh = diffMap_pasVar.*pMask_pasVar;
diffMap_actVarTh = diffMap_actVar.*pMask_actVar;

diffMap_pasMn = nanmean(plexData.meanMap_pas,3) - nanmean(fezData.meanMap_pas,3);
diffMap_actMn = nanmean(plexData.meanMap_act,3) - nanmean(fezData.meanMap_act,3);
diffMap_pasMnTh = diffMap_pasMn.*pMask_pasMn;
diffMap_actMnTh = diffMap_actMn.*pMask_actMn;
%% %%%%%%%%%%%% plotting difference variance maps %%%%%%%%%%%%%%
close all
h1 = figure; h1.Position = [153 143 1181 835];
ax1(1) = subplot(2,2,1);
imagesc(diffMap_pasVarTh,[-1e-4,1e-4]); axis image; colorbar;;colormap(cmap)
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','k');
end
hold off
title('Passive Varince Difference Map')
axis(gca,2*redRat*[12 280 44 268])

ax1(2) = subplot(2,2,2);
imagesc(diffMap_actVarTh,[-1e-4,1e-4]); axis image; colorbar;colormap(cmap)
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','k');
end
hold off
title('Active variance difference Map')
axis(gca,2*redRat*[12 280 44 268])

ax1(3) = subplot(2,2,3);
imagesc(diffMap_pasMnTh,[-1e-5,1e-5]); axis image; colorbar;colormap(cmap)
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','k');
end
hold off
title('Passive Mean Difference Map')
axis(gca,2*redRat*[12 280 44 268])

ax1(4) = subplot(2,2,4);
imagesc(diffMap_actMnTh,[-1e-5,1e-5]); axis image; colorbar;colormap(cmap)
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','k');
end
hold off
title('active Mean Difference Map')
axis(gca,2*redRat*[12 280 44 268])

sgtitle(['Statisical Parametric Maps With ranksum FDR value = ' num2str(q_fdr)]);
%% %%%%%%%%%%%%% saving the figures %%%%%%%%%%

    saveFig = input('Do you want to save the current figures : ');
    if saveFig == 1
        %%% saving figures
        savepath1 = fullfile(['G:\Hemanth_CSHL\WideField\Data_Figures\SpontaneousPlots\ActiveQuiescentVariancePlots\'], ...
            ['ActiveQuiescentStatisticalParamMaps_FezPlex.fig']);
        savefig(h1,savepath1)
        saveas(h1,[savepath1(1:end-4) '.svg']);
        
    end

