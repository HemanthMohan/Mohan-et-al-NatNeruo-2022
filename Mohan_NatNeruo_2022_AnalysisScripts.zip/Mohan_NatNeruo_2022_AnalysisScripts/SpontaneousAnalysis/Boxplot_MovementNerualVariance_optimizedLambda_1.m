clear all; close all; clc
%% load data
plexData = load(['G:\Hemanth_CSHL\WideField\Data_Analysis\SpontaneousData\AllenFOVRegistered\NeuralActivityVarianceData\' ...
    'PlexinD1Ai148_202012142020121520210126_OptiLambda_VarianceData.mat']);
plexData = plexData.data;

fezData = load(['G:\Hemanth_CSHL\WideField\Data_Analysis\SpontaneousData\AllenFOVRegistered\NeuralActivityVarianceData\' ...
    'FezF2Ai148_202012142020121520210126_OptiLambda_VarianceData.mat']);
fezData = fezData.data;
%% 
for ii = 1:length(plexData.sessions)
    [plex_cvr2(ii,:) lamLoc] = max(mean(plexData.cvR2_test{ii}));
    plex_lam(ii,1) = plexData.LambdaVals(lamLoc);
    
    [fez_cvr2(ii,:) lamLoc] = max(mean(fezData.cvR2_test{ii}));
    fez_lam(ii,1) = fezData.LambdaVals(lamLoc);
end
%% perform stats
[pVal,h,Stats] = ranksum(plex_cvr2,fez_cvr2);
%% plot box plot
grp = [repmat({'PlexinD1'},[length(plex_cvr2),1]);repmat({'FezF2'},[length(fez_cvr2),1])] ;
h1 = figure;
boxplot([plex_cvr2;fez_cvr2],grp)
ylim([0,60])
text(1.2,50,['ranksum pval : ' num2str(pVal)])
ylabel('cvR2')
title('PlexinVsFez Variance captured Test set')

%% Save figure

filename = ['plexFez_MovementNeuralVariance_optiLambda_boxplot.fig']
savedim = input('Do you want to save the current figure : ');
if savedim == 1
    savepath = fullfile(['G:\Hemanth_CSHL\WideField\Data_Figures\SpontaneousPlots\NeuralActivityVariancePlots\'],filename);
    savefig(h1,savepath)
    saveas(h1,[savepath(1:end-4) '.svg']);
end
