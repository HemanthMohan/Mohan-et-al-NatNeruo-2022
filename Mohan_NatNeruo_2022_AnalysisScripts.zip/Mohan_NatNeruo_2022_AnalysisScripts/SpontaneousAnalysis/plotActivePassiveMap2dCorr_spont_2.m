clear all; close all; clc;
%% Load Data
plexData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\SpontaneousData\AllenFOVRegistered\ActiveQuiescentVarianceMapData\PlexinD1Ai148_202012142020121520210126_AQvarianceData.mat');
plexData = plexData.data;
fezData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\SpontaneousData\AllenFOVRegistered\ActiveQuiescentVarianceMapData\FezF2Ai148_202012142020121520210126_AQvarianceData.mat');
fezData = fezData.data;
%% extract variance maps
varMap_act_plex = plexData.varMap_act;
varMap_pas_plex = plexData.varMap_pas;
varMap_act_fez = fezData.varMap_act;
varMap_pas_fez = fezData.varMap_pas;
varMap_act_plex(find(varMap_act_plex==0)) = NaN;
varMap_pas_plex(find(varMap_pas_plex==0)) = NaN;
varMap_act_fez(find(varMap_act_fez==0)) = NaN;
varMap_pas_fez(find(varMap_pas_fez==0)) = NaN;
numSes = length(plexData.sessions);
%% perform 2D Correlaions within and between types
ccIdx = nchoosek([1:numSes],2);
for ii = 1:length(ccIdx)
    ccAct_plex(ii,1) = corr(reshape(varMap_act_plex(:,:,ccIdx(ii,1)),[],1), reshape(varMap_act_plex(:,:,ccIdx(ii,2)),[],1),'Rows','complete');
    ccPas_plex(ii,1) = corr(reshape(varMap_pas_plex(:,:,ccIdx(ii,1)),[],1), reshape(varMap_pas_plex(:,:,ccIdx(ii,2)),[],1),'Rows','complete');
    ccAct_fez(ii,1) = corr(reshape(varMap_act_fez(:,:,ccIdx(ii,1)),[],1), reshape(varMap_act_fez(:,:,ccIdx(ii,2)),[],1),'Rows','complete');
    ccPas_fez(ii,1) = corr(reshape(varMap_pas_fez(:,:,ccIdx(ii,1)),[],1), reshape(varMap_pas_fez(:,:,ccIdx(ii,2)),[],1),'Rows','complete');
end

for ii =1:numSes
    for jj = 1:numSes
        ccAct_plexfezMat(ii,jj) = corr(reshape(varMap_act_plex(:,:,ii),[],1), reshape(varMap_act_fez(:,:,jj),[],1),'Rows','complete');
        ccPas_plexfezMat(ii,jj) = corr(reshape(varMap_pas_plex(:,:,ii),[],1), reshape(varMap_pas_fez(:,:,jj),[],1),'Rows','complete');
    end
end
ccAct_plexfez = ccAct_plexfezMat(:);
ccPas_plexfez = ccPas_plexfezMat(:);
%% Perform Stats
pCnt = length(ccAct_plex);
pfCnt = length(ccAct_plexfez);
grpId = [repmat({'plexVsPlex'},pCnt,1);repmat({'fezVsfez'},pCnt,1);repmat({'plexVsfez'},pfCnt,1) ];
[~,~,statsAct] = kruskalwallis([ccAct_plex;ccAct_fez;ccAct_plexfez],grpId);
[mCompAct,~,~,gnames] = multcompare(statsAct);
[~,~,statsPas] = kruskalwallis([ccPas_plex;ccPas_fez;ccPas_plexfez],grpId);
[mCompPas,~,~,gnames] = multcompare(statsPas);


statsTextAct = "KruskalWallisActive" + newline + ...
    gnames{mCompAct(1,1)} + " VS " + gnames{mCompAct(1,2)} + " = " + num2str(mCompAct(1,6)) + ...
    newline + gnames{mCompAct(2,1)} + " VS " + gnames{mCompAct(2,2)} + " = " + num2str(mCompAct(2,6)) + ...
    newline + gnames{mCompAct(3,1)} + " VS " + gnames{mCompAct(3,2)} + " = " + num2str(mCompAct(3,6));

statsTextPas = "KruskalWallisPassive" + newline + ...
    gnames{mCompPas(1,1)} + " VS " + gnames{mCompPas(1,2)} + " = " + num2str(mCompPas(1,6)) + ...
    newline + gnames{mCompPas(2,1)} + " VS " + gnames{mCompPas(2,2)} + " = " + num2str(mCompPas(2,6)) + ...
    newline + gnames{mCompPas(3,1)} + " VS " + gnames{mCompPas(3,2)} + " = " + num2str(mCompPas(3,6));
%% %%%%%%%%%%% plotting the distribution
h1 = figure; h1.Position = [228   558   852   420];
ax(1) = subplot(1,2,1);
boxplot([ccAct_plex;ccAct_fez;ccAct_plexfez],grpId)
ylabel('corr coef')
title (' Active variance 2D Correlation')
ax(2) = subplot(1,2,2);
boxplot([ccPas_plex;ccPas_fez;ccPas_plexfez],grpId)
ylabel('corr coef')
title (' Passive variance 2D Correlation')
linkaxes(ax,'y')
annotation(h1,'textbox', [0, 0.95, 0, 0], 'string', statsTextAct,'FontSize',8)
annotation(h1,'textbox', [0.9, 0.95, 0, 0], 'string', statsTextPas,'FontSize',8)
% annotation(h2,'textbox', [0, 0.99, 0, 0], 'string', [lift_fez.foldersAnalyzed; lift_plex.foldersAnalyzed],'FontSize',7, 'Interpreter', 'none')
%% %%%%%%%%%%%%% saving the figures %%%%%%%%%%

saveFolder = 'G:\Hemanth_CSHL\WideField\Data_Figures\SpontaneousPlots\2DSpatialMapSimilarityPlots\';
fileName1 = ['ActivePassiveSimilarity2DCorrelations.fig'];
savePath1 = fullfile(saveFolder,fileName1);
saveFig = input('Do you want to save the current figure : ');
if saveFig == 1
    savefig(h1,savePath1)
    saveas(h1,[savePath1(1:end-4) '.svg']);
end