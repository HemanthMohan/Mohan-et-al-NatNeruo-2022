clear all; close all; clc
fezData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\MeanActivityAroundPIM\FezF2Ai148_MeanActivityAroudPIM.mat');
plexData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\MeanActivityAroundPIM\PlexinD1Ai148_MeanActivityAroudPIM.mat');
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
load('F:\Hemanth_CSHL\WideField\Data\cmap3.mat');
askSaving = 0;
%% parameters for plotting
timeBeforePim = 1;%%%% duration to consider before pim onset. Should be less that the duration used for meanSequence
timeAfterPim = 2;%%%% duraiong to consider after pim onset. Should be less that the duration used for meanSequence
%% Load reuired Data
dorsalMaps = plexData.data.dorsalMap;
meanSeq_plex = plexData.data.meanFlow;
meanSeq_fez = fezData.data.meanFlow;
%% calculatin mean image
seqTm = linspace(-1*plexData.data.durBeforeOnset,plexData.data.durAfterOnset,size(meanSeq_plex,3));
useIdx = find(seqTm>= -1*timeBeforePim &  seqTm<=timeAfterPim);%% indexs used to make mean image;
meanImg_plex = mean(meanSeq_plex(:,:,useIdx),3);
meanImg_fez = mean(meanSeq_fez(:,:,useIdx),3);
meanImg_PlexFez = mean(cat(3,meanImg_plex,meanImg_fez),3);
%% generating initial Masks %%
close all
leftCortexMap = dorsalMaps.dorsalMapScaled; leftCortexMap(:,293:end) = 0;
rightCortexMap = dorsalMaps.dorsalMapScaled; rightCortexMap(:,1:293) = 0;
leftFrontalMask = zeros(size(meanImg_plex));
leftParietalMask = zeros(size(meanImg_plex));
leftFLAMask = zeros(size(meanImg_plex));
leftFLPMask = zeros(size(meanImg_plex));
rightFrontalMask = zeros(size(meanImg_plex));
rightParietalMask = zeros(size(meanImg_plex));
rightFLAMask = zeros(size(meanImg_plex));
rightFLPMask = zeros(size(meanImg_plex));

leftFrontalMask(find(leftCortexMap==21)) = 1;
leftParietalMask(find(leftCortexMap==43 | leftCortexMap==64 | leftCortexMap== 36 | ...
    leftCortexMap==268 | leftCortexMap==249 | leftCortexMap==136 | leftCortexMap==275 | ...
    leftCortexMap==71| leftCortexMap == 57)) = 1;
leftFLAMask(find(leftCortexMap==21 | leftCortexMap==15)) = 1;
leftFLPMask (find(leftCortexMap==50 | leftCortexMap==29)) = 1;

rightFrontalMask(find(rightCortexMap==21)) = 1;
rightParietalMask(find(rightCortexMap==43 | rightCortexMap==64 | rightCortexMap== 36 | ...
    rightCortexMap==268 | rightCortexMap==249 | rightCortexMap==136 | rightCortexMap==275 | ...
    rightCortexMap==71| rightCortexMap == 57)) = 1;
rightFLAMask(find(rightCortexMap==21 | rightCortexMap==15)) = 1;
rightFLPMask(find(rightCortexMap==50 | rightCortexMap==29)) = 1;
%% Extracting location of maximum activity from each area
[leftFrontalLoc(2) leftFrontalLoc(1)] =find((meanImg_fez.*leftFrontalMask) == max(meanImg_fez(:).*leftFrontalMask(:)));
[leftParietalLoc(2) leftParietalLoc(1)] =find((meanImg_fez.*leftParietalMask) == max(meanImg_fez(:).*leftParietalMask(:)));
[leftFLALoc(2) leftFLALoc(1)] =find((meanImg_plex.*leftFLAMask) == max(meanImg_plex(:).*leftFLAMask(:)));
[leftFLPLoc(2) leftFLPLoc(1)] =find((meanImg_plex.*leftFLPMask) == max(meanImg_plex(:).*leftFLPMask(:)));
[rightFrontalLoc(2) rightFrontalLoc(1)] =find((meanImg_fez.*rightFrontalMask) == max(meanImg_fez(:).*rightFrontalMask(:)));
[rightParietalLoc(2) rightParietalLoc(1)] =find((meanImg_fez.*rightParietalMask) == max(meanImg_fez(:).*rightParietalMask(:)));
[rightFLALoc(2) rightFLALoc(1)] =find((meanImg_plex.*rightFLAMask) == max(meanImg_plex(:).*rightFLAMask(:)));
[rightFLPLoc(2) rightFLPLoc(1)] =find((meanImg_plex.*rightFLPMask) == max(meanImg_plex(:).*rightFLPMask(:)));

%% Plotting the locations over the mean maps
fezScl = [-0.02 0.02];
plexScl = [-0.016 0.016];
h1 = figure;
h1.Position = [100 300 1072 420];
ax(1) = subplot(1,2,1);
imagesc(meanImg_fez,fezScl); axis image
colormap(cmap2)
hold on
for p = 1:length(dorsalMaps.edgeOutlineSplit)
    plot( dorsalMaps.edgeOutlineSplit{p}(:, 2),dorsalMaps.edgeOutlineSplit{p}(:, 1),'color','w','LineWidth',0.5);
end
colorbar

ax(2) = subplot(1,2,2);
imagesc(meanImg_plex,plexScl); axis image
colormap(cmap2)
hold on
for p = 1:length(dorsalMaps.edgeOutlineSplit)
    plot( dorsalMaps.edgeOutlineSplit{p}(:, 2),dorsalMaps.edgeOutlineSplit{p}(:, 1),'color','w','LineWidth',0.5);
end
colorbar
for ii = 1:2
plot(ax(ii),leftFrontalLoc(1),leftFrontalLoc(2),'co','MarkerSize',8,'LineWidth',2)
plot(ax(ii),leftParietalLoc(1),leftParietalLoc(2),'co','MarkerSize',8,'LineWidth',2)
plot(ax(ii),leftFLALoc(1),leftFLALoc(2),'bo','MarkerSize',8,'LineWidth',2)
plot(ax(ii),leftFLPLoc(1),leftFLPLoc(2),'bo','MarkerSize',8,'LineWidth',2)
plot(ax(ii),rightFrontalLoc(1),rightFrontalLoc(2),'co','MarkerSize',8,'LineWidth',2)
plot(ax(ii),rightParietalLoc(1),rightParietalLoc(2),'co','MarkerSize',8,'LineWidth',2)
plot(ax(ii),rightFLALoc(1),rightFLALoc(2),'bo','MarkerSize',8,'LineWidth',2)
plot(ax(ii),rightFLPLoc(1),rightFLPLoc(2),'bo','MarkerSize',8,'LineWidth',2)
end
%% %%%%%%%%%%%% Generating the Masks %%%%%%%%%%%%%%%%%%
h2 = figure;
imagesc(meanImg_PlexFez,plexScl); axis image
colormap(cmap2)
hold on
for p = 1:length(dorsalMaps.edgeOutlineSplit)
    plot( dorsalMaps.edgeOutlineSplit{p}(:, 2),dorsalMaps.edgeOutlineSplit{p}(:, 1),'color','w','LineWidth',0.5);
end
title('Mean Of PlexinD1 and FezF2')
%%%%%%%%
roiRadius = 14; %%%%% Radius of the ROI Mask
imask = [];
%%%%%%%%%% Genetrating the Left Frontal Mask %%%%%%
markerh = images.roi.Circle(gca,'Center',[leftFrontalLoc(1), leftFrontalLoc(2)],'Radius',roiRadius);
imask = createMask(markerh,meanImg_fez);
delete(markerh)
roiMasks.leftFrontal = imask; %%%%%%% storing Whisker Stimulation Mask
imagesc(double(roiMasks.leftFrontal)*-1,'AlphaData',double(imask)*0.7);


%%%%%%%%%% Genetrating the Left Parietal Mask %%%%%%
markerh = images.roi.Circle(gca,'Center',[leftParietalLoc(1), leftParietalLoc(2)],'Radius',roiRadius);
imask = createMask(markerh,meanImg_fez);
delete(markerh)
roiMasks.leftParietal = imask; %%%%%%% storing Whisker Stimulation Mask
imagesc(double(roiMasks.leftParietal)*-1,'AlphaData',double(imask)*0.7);


%%%%%%%%%% Genetrating the Left FLA Mask %%%%%%
markerh = images.roi.Circle(gca,'Center',[leftFLALoc(1), leftFLALoc(2)],'Radius',roiRadius);
imask = createMask(markerh,meanImg_fez);
delete(markerh)
roiMasks.leftFLA = imask; %%%%%%% storing Whisker Stimulation Mask
imagesc(double(roiMasks.leftFLA )*-1,'AlphaData',double(imask)*0.7);

%%%%%%%%%% Genetrating the Left FLP Mask %%%%%%
markerh = images.roi.Circle(gca,'Center',[leftFLPLoc(1), leftFLPLoc(2)],'Radius',roiRadius);
imask = createMask(markerh,meanImg_fez);
delete(markerh)
roiMasks.leftFLP = imask; %%%%%%% storing Whisker Stimulation Mask
imagesc(double(roiMasks.leftFLP )*-1,'AlphaData',double(imask)*0.7);

%%%%%%%%%% Genetrating the Right Frontal Mask %%%%%%
markerh = images.roi.Circle(gca,'Center',[rightFrontalLoc(1), rightFrontalLoc(2)],'Radius',roiRadius);
imask = createMask(markerh,meanImg_fez);
delete(markerh)
roiMasks.rightFrontal = imask; %%%%%%% storing Whisker Stimulation Mask
imagesc(double(roiMasks.rightFrontal)*-1,'AlphaData',double(imask)*0.7);


%%%%%%%%%% Genetrating the Right Parietal Mask %%%%%%
markerh = images.roi.Circle(gca,'Center',[rightParietalLoc(1), rightParietalLoc(2)],'Radius',roiRadius);
imask = createMask(markerh,meanImg_fez);
delete(markerh)
roiMasks.rightParietal = imask; %%%%%%% storing Whisker Stimulation Mask
imagesc(double(roiMasks.rightParietal)*-1,'AlphaData',double(imask)*0.7);


%%%%%%%%%% Genetrating the right FLA Mask %%%%%%
markerh = images.roi.Circle(gca,'Center',[rightFLALoc(1), rightFLALoc(2)],'Radius',roiRadius);
imask = createMask(markerh,meanImg_fez);
delete(markerh)
roiMasks.rightFLA = imask; %%%%%%% storing Whisker Stimulation Mask
imagesc(double(roiMasks.rightFLA )*-1,'AlphaData',double(imask)*0.7);

%%%%%%%%%% Genetrating the right FLP Mask %%%%%%
markerh = images.roi.Circle(gca,'Center',[rightFLPLoc(1), rightFLPLoc(2)],'Radius',roiRadius);
imask = createMask(markerh,meanImg_fez);
delete(markerh)
roiMasks.rightFLP = imask; %%%%%%% storing Whisker Stimulation Mask
imagesc(double(roiMasks.rightFLP )*-1,'AlphaData',double(imask)*0.7);

%% %%%%%%%%%%%%%%%%%%%%% saving the roi Mask data
if askSaving == 1
    savMasks = input('Do you want to save the Masks (0=No, 1=Yes) ? : ');
    if savMasks == 1
        data.sessionsUsed = [plexData.data.foldersAnalyzed;fezData.data.foldersAnalyzed];
        data.roiMasks = roiMasks;
        saveFolder = 'G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered';
        saveFile = 'behaviorActivityRoiMasks.mat';
        save(fullfile(saveFolder,saveFile),'data');
    end
end
