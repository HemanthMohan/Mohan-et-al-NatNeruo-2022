%%
% Built: 2019
% Creator: Hemanth Mohan, Cold Spring Harbor Laboratory
% Contact: mohan@cshl.edu
%%
clear; close; clc
[fname fpath] = uigetfile('*refimg.mat');
load(fullfile(fpath,fname));
h1 = figure(1);
imshow(refimg);
h1.Position = [10 10 632 583];
axis image
title('Draw ROI and Click Enter when Finished')
hRoi = drawpolygon(gca);
roiData = addlistener(hRoi,'MovingROI',@getROI);
pause;
imMask = createMask(roiData.Source{1, 1});
close(h1)
h2 = figure(2); 
imagesc(imMask)
axis image
%% Saving ROI Mask %%%%%%
pause(0.5)
Maskfile = [fname(1:find(fname == '_',1,'last')) 'refMask.mat'];
if exist(fullfile(fpath,Maskfile))
    ow = input('Another Mask already exists. Do you want to overwrite with current Mask? : ');
    if ow == 1
        save(fullfile(fpath,Maskfile),'imMask');
        disp('New ROI Mask overwrites old !!!')
    end
else
    save(fullfile(fpath,Maskfile),'imMask');
    disp('ROI Mask is saved !!!')
end


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     %%%%%%%%%%%%%%%%%%%%%%%%Functions%%%%%%%%%%%%%%%%%%%%%%%%%%

function[roiData] = getROI(src,evt)
roiData = evt;
end