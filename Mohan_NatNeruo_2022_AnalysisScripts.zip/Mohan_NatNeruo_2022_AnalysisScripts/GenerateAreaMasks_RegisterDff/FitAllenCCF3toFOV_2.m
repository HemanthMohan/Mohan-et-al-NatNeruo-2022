clear all; close all; clc
load('F:\Hemanth_CSHL\WideField\Data\cmap3.mat');
[fname fpath] = uigetfile('*.csv');
AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.
%% %%%%%%%%%%%%%%%% get file  name structure %%%%%%%%%%%%
[fnFeat, usFeat ] = getFileNameProperties(fpath);%%% get all fileNames variables
%% getting reference image
refFileName = [fnFeat.sname_ex(1:usFeat.us_idx-5) 'refimg.mat'];
[~,refFold] = fileparts(fnFeat.spath);
refFilePath = fullfile(fileparts(fileparts(fileparts(fpath))),'Data');
refIm = load(fullfile(refFilePath,refFold,refFileName)); refIm = refIm.refimg;

%% %%%%%%%%%%%%%%% Get Lick onset and pim onset Behavior Trials %%%%%%%%%%%%%%%
disp('Extracting Behavior Temporal features .... ')
ExtractManipulaion = 0;%%%%% Enter zero to not extract manipulation times and 1 to extract
[BData] = GetBehavEventTimes(fpath,ExtractManipulaion); %%%%% Enter second input as zero to not extract manipulation times. The third variable is are the file ids to consider
PimTrials = find(cell2mat(BData.Data(:,2)) == 1 & cell2mat(BData.Data(:,3)) == 1);
PimFileIds = cell2mat(BData.Data(PimTrials,1));
%% %%%%%% extracting Event Triggerg Frames %%%%%%%%
ID = PimFileIds(1:1); %%%% select number of files to consider
SigFs = 30;
BehFs = 100;
tbeftrig = 1; %%% time before PIM Onset to consider in sec
tafttrig = 3; %% time after PIM Onset to consider in sec
sigTime = 0:1/SigFs:15; sigTime(end) = [];
behTime = 0:1/BehFs:15; behTime(end) = [];
trigon_allFrms = [];
IDsThatMadeIt = []; %%%% ID's that made it to being plotted
BehaviorTimes = [];

trigCasigV = [];
for ii = 1:length(ID);
    %%%%%%%%% Extract Calcium Signal
    sname_in = [fnFeat.sname_ex(1:usFeat.us_idx) num2str(ID(ii)) '.mat']
    CaSig_in = load(fullfile(fnFeat.spath,sname_in));
    CaSig = CaSig_in.dffV;
    %%%%%%%%%%%%%%%%%%% Mean Correction %%%%%%%%%%%%%%%%%%%
    CaSigMean = mean((mean(CaSig,1)));
    CaSigCorr = CaSig - CaSigMean; %%%%%%%%%% mean correction
    %%%%%%%%% get onset of Lick and Handlift times %%%%%%%%%%
    starttime_pim = cell2mat(BData.Data((ID(ii)),10)); %%% PIMonset time
    %%%%%%%%%%%% Exract behavior relevant calcium activity %%%%%%%%%%%%%%%%%
    try
    lcsidx = find(sigTime>starttime_pim-tbeftrig & sigTime<starttime_pim+tafttrig); %% index between lick onset and hand lift
    catch
    continue
    end
    IDsThatMadeIt = [IDsThatMadeIt;ID(ii)];
    BehaviorTimes = [BehaviorTimes;starttime_pim ];
    trigon_allFrms =[trigon_allFrms lcsidx];
    trigCasigV_temp = CaSigCorr(:,:,lcsidx(:));
    trigCasigV = cat(3,trigCasigV,trigCasigV_temp);
end
%% %%%%%%%% Making Mean Activity Maps %%%%%%%%%%
dffVSz = size(CaSig);
meanIm= mean(trigCasigV,3);
meanImNorm = meanIm./max(max(meanIm));
%% %%%%%%%%%%%%%%% load and plot Old allen dorsal map coordinates if Exist %%%%%
dmName = [fnFeat.sname_ex(1:usFeat.us_idx-5) 'dorsalMap.mat'];
dmPath = fullfile(fnFeat.spath,dmName);
if exist(dmPath)
    load(fullfile(fnFeat.spath,dmName));
    tmMap = []; %%%%%%%%% transformed map of the whole cortex
    for p = 1:length(dorsalMaps.edgeOutlineSplit)
        tmMap{p,1} = dorsalMaps.labelsSplit(p);
        tmMap{p,2} = dorsalMaps.sidesSplit(p);
        tmMap{p,3} = transformPointsInverse(dorsalMaps.tform,[dorsalMaps.edgeOutlineSplit{p}(:, 2),dorsalMaps.edgeOutlineSplit{p}(:, 1)]);
    end
    h0 = figure;
    a1 = subplot(1,2,1);
    imagesc(refIm);
    axis image; hold on; colormap(a1,'gray');
    hold on
    for p = 1:length(dorsalMaps.edgeOutlineSplit)
        plot( tmMap{p,3}(:, 1),tmMap{p,3}(:, 2),'color','y','LineWidth',0.5);
    end
    hold off
    a2 = subplot(1,2,2);
    imagesc(meanImNorm,[-0.9 0.9]);
    axis image; hold on; colormap(a2,cmap3);
    hold on
    for p = 1:length(dorsalMaps.edgeOutlineSplit)
        plot( tmMap{p,3}(:, 1),tmMap{p,3}(:, 2),'color','w','LineWidth',0.5);
    end
    hold off
    h0.Position = [69,432,1031,468];
    sgtitle('Current Allen Map. Want to make new Allen Map ?')
    clc;
    MakeNewMap = input('Allen Map Exists. Make new Allen Map (Yes = 1, No = 0)? : ');
    if MakeNewMap ~= 1
        return
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% %%%%%%%%%%%%%%%%%%%%%% Generate new Allen Map %%%%%%%%%%%%%%%%%%%%%%%%%
close all; clc
[dorsalMaps,refpoints,rotpoints,tform] = align_to_allen(refIm);
dorsalMaps.tform = tform;
transformedMap = []; %%%%%%%%% transformed map of the whole cortex
for p = 1:length(dorsalMaps.edgeOutlineSplit)
    transformedMap{p,1} = dorsalMaps.labelsSplit(p);
    transformedMap{p,2} = dorsalMaps.sidesSplit(p);
    transformedMap{p,3} = transformPointsInverse(dorsalMaps.tform,[dorsalMaps.edgeOutlineSplit{p}(:, 2),dorsalMaps.edgeOutlineSplit{p}(:, 1)]);
end
% %

h2 = figure;
a1 = subplot(1,2,1);
imagesc(refIm);
axis image; hold on; colormap(a1,'gray');
hold on
for p = 1:length(dorsalMaps.edgeOutlineSplit)
    plot( transformedMap{p,3}(:, 1),transformedMap{p,3}(:, 2),'color','y','LineWidth',0.5);
end

hold off

a2 = subplot(1,2,2);
imagesc(meanImNorm,[-0.9 0.9]);
axis image; hold on; colormap(a2,cmap3);
hold on
for p = 1:length(dorsalMaps.edgeOutlineSplit)
    plot( transformedMap{p,3}(:, 1),transformedMap{p,3}(:, 2),'color','w','LineWidth',0.5);
end
hold off
h2.Position = [69,432,1031,468];
% % Saving the dorsal Maps data
saveMap = input('Do you want to save the dorsalMaps data: ');
dmname = [fnFeat.sname_ex(1:usFeat.us_idx-5) 'dorsalMap.mat'];
dmpath = fnFeat.spath;
if saveMap == 1
    save(fullfile(dmpath,dmname),'dorsalMaps');
    disp('DORSAL MAPS HAVE BEEN SAVED!!');
end



%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% %%%%%%%%%%%%%%%%% FUNCTIONS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [dorsalMaps,refpoints,rotpoints,tform] = align_to_allen(image)
%% Align recording to Allen CCF given an image 
% INPUTS
% image - this could be Kmeans map, or a mean of the gcamp activity
%
% alignareas - additional areas in the form 'L area', with a space between
% L/R and area name. the user should be fairly certain of identifying these areas.
%
% affine - do an affine transformation or not. default: not an affine
% transformation. The alternative is a non-reflective similarity, aka
% rotation, translation, and scaling.
%
% OUTPUT
% tform - transformation details that can be run with imwarp for subsequent frames.

% Author: Shreya Saxena (2018)
%%
alignareas={};
affine=0;

load('F:\Hemanth_CSHL\WideField\Data\AllenDorsalMap\allen_map\allenDorsalMap.mat');
         
OBrefs=[190.2623  101.4249;    % Base of L OB
        396.2620  101.4249];     % Base of R OB
    
OBRSrefs=[293.9059   97.5624;   % Center base of OBs
          293.9059  431.0245];  % Base of RS

Bregref=[293.9059  244.3372]; % Bregma Center

mean_points_refs=zeros(length(alignareas),2);
for i=1:length(alignareas)
    sidestr=alignareas{i}(1);
    try
        areaid=dorsalMaps.labelTable{strcmp(dorsalMaps.labelTable.abbreviation,alignareas{i}(3:end)),'id'};
    catch
        error('Please name additional areas in the form L/R area, with a space between L/R and area name');
    end
    dimsmap=size(dorsalMaps.dorsalMapScaled);
    [x,y]=find(dorsalMaps.dorsalMapScaled==areaid);
    if strcmp(sidestr,'R')
        x=x(y>=dimsmap(2)/2); y=y(y>=dimsmap(2)/2);
    elseif strcmp(sidestr,'L')
        x=x(y<dimsmap(2)/2); y=y(y<dimsmap(2)/2);
    end
    mean_points_refs(i,:)=[mean(y) mean(x)];
end

figure; %suptitle('Alignment to Allen CCF');
set(gcf,'Position',[-28 -320 1268 954])
subplot(221);
imagesc(dorsalMaps.dorsalMapScaled);
axis equal off;
hold on;
for p = 1:length(dorsalMaps.edgeOutline)
    plot(dorsalMaps.edgeOutline{p}(:, 2), dorsalMaps.edgeOutline{p}(:, 1));
end
set(gca, 'YDir', 'reverse');
plot(OBrefs(:,1),OBrefs(:,2),'-xr','linewidth',1,'markersize',3);
htext=text(50,600,'Base of L OB, R OB','color','w','fontsize',12);
title('Click on the corresponding points on your image from left to right, then press enter','fontsize',12);

handle=subplot(222);
imagesc(image); axis equal off; colormap(gca,'gray'); hold on;
[x,y] = getline(handle);
OBpoints=[x y];
plot(OBpoints(:,1),OBpoints(:,2),'-xk','linewidth',2,'markersize',3);

subplot(221);
plot(OBRSrefs(:,1),OBRSrefs(:,2),'-xr','linewidth',2,'markersize',3);
delete(htext);
htext=text(50,600,'Center base of L OB, Base of RS','color','w','fontsize',12);
title('Click on the corresponding points on your image from up to down, then press enter','fontsize',12);

handle=subplot(222);
[x,y] = getline(handle);
OBRSpoints=[x y];
plot(OBRSpoints(:,1),OBRSpoints(:,2),'-xk','linewidth',2,'markersize',3);

subplot(221);
plot(Bregref(:,1),Bregref(:,2),'xr','linewidth',2,'markersize',3);
delete(htext);
htext=text(50,600,'Bregma Center','color','w','fontsize',12);
title('Click on the corresponding point on your image, then press enter','fontsize',12);

handle=subplot(222);
[x,y] = getpts(handle);
Bregpoint=[x y];
plot(Bregpoint(:,1),Bregpoint(:,2),'xk','linewidth',2,'markersize',3);

mean_points=zeros(length(alignareas),2);
for i=1:length(alignareas)
    subplot(221);
    plot(mean_points_refs(i,1),mean_points_refs(i,2),'xr','linewidth',2,'markersize',3);
    delete(htext);
    htext=text(50,600,alignareas{i},'color','w','fontsize',12);
    title('Click on the corresponding point on your image, then press enter','fontsize',12);

    handle=subplot(222);
    [x,y] = getpts(handle);
    mean_points(i,:)=[x y];
    plot(mean_points(i,1),mean_points(i,2),'xk','linewidth',2);
end
subplot(221); title('All Done');

refpoints=[OBrefs;OBRSrefs;Bregref;mean_points_refs];
points=[OBpoints;OBRSpoints;Bregpoint;mean_points];

if affine, affinestr='affine'; else, affinestr='nonreflectivesimilarity'; end
tform = fitgeotrans(points,refpoints,affinestr);
rotpoints = transformPointsForward(tform,points);
image(isnan(image))=0;
imagereg = imwarp(image,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled)));

subplot(223);
plot(refpoints(:,1),refpoints(:,2),'xr',points(:,1),points(:,2),'xk',rotpoints(:,1),rotpoints(:,2),'ob','linewidth',2); 
set(gca, 'YDir', 'reverse','fontsize',12); title('Control points','fontsize',16);
legend('Allen Control Points','Unaligned Points','Points post-alignment')

subplot(224)
imagesc(imagereg);
axis equal off; hold on;
for p = 1:length(dorsalMaps.edgeOutline)
    plot(dorsalMaps.edgeOutline{p}(:, 2), dorsalMaps.edgeOutline{p}(:, 1));
end
plot(refpoints(:,1),refpoints(:,2),'xr',rotpoints(:,1),rotpoints(:,2),'ob','linewidth',2); 
set(gca, 'YDir', 'reverse');
colormap('gray')

end

function [fnFeat, usFeat ] = getFileNameProperties(fpath)
%%%%%%%%%%%%% getting signal file name %%%%%%%%%%%%%%
listing_csv = dir([fpath '\*.csv']);
[~, sflname] = fileparts(fileparts(fpath));
spath = fullfile(fileparts(fileparts(fileparts(fpath))), 'Data_Corrected', sflname);
listing_sig = dir([spath '\*.mat']);
sname_all = natsortfiles({listing_sig.name}');
sname_ex = sname_all{1};
us_idx = find(sname_ex == '_',1,'last');

%%%%%%%% getting body trajectory file name %%%%%%%%%%%%
fname_all = natsortfiles({listing_csv.name}');
fname_allC1 = fname_all( contains(fname_all,'c1_T'));
fname_allC2 = fname_all( contains(fname_all,'c2_T'));

fname_exC1 = fname_allC1{1};
fname_us_idxC1 = find(fname_exC1 == '_');
fname_deep_idxC1 = strfind(fname_exC1, 'Deep');
bidx_stC1 = fname_us_idxC1(end-4);
bidx_endC1 = fname_deep_idxC1;

fname_exC2 = fname_allC2{1};
fname_us_idxC2 = find(fname_exC2 == '_');
fname_deep_idxC2 = strfind(fname_exC2, 'Deep');
bidx_stC2 = fname_us_idxC2(end-4);
bidx_endC2 = fname_deep_idxC2;


%%% updating all properties
fnFeat.sname_all = sname_all;
fnFeat.fname_allC1 = fname_allC1;
fnFeat.fname_allC2 = fname_allC2;
fnFeat.sname_ex = sname_ex;
fnFeat.fname_exC1 = fname_exC1;
fnFeat.fname_exC2 = fname_exC2;
fnFeat.spath = spath;

usFeat.us_idx = us_idx;
usFeat.bidx_stC1 = bidx_stC1;
usFeat.bidx_endC1 = bidx_endC1;
usFeat.bidx_stC2 = bidx_stC2;
usFeat.bidx_endC2 = bidx_endC2;
end