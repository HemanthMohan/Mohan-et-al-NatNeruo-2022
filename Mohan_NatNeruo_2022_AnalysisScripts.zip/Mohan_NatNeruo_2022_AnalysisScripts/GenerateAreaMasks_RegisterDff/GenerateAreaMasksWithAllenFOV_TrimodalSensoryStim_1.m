clear all; close all; clc
%%
load('F:\Hemanth_CSHL\WideField\Data\cmap3.mat');
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
load('F:\Hemanth_CSHL\WideField\Data\cmap1.mat');
cmapUse = cmap2; %% which cmap to use to plot
[fname fpath1] = uigetfile('*.mat');
AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.
%% %%%%%%%%%%%%%%% enter details to group sessions %%%%%%%%%%%%%
% mouseIds = ['c9m2']; %%%% enter the mouse ID to concatenate activity or even a part of it to concatedate across differenct mice
mouseIds = ['c']; %%%% enter the mouse ID to concatenate activity or even a part of it to concatedate across differenct mice
mouseType = ['PlexinD1'];
sessionType = ['isoSensory'];
% dateIn = {'20210106';'20210108'};
dateIn = {'20210108'};
% % %%%%%%%%%%%%%%%%%%% get file  name structure %%%%%%%%%%%%
parentFold = fileparts(fileparts(fpath1));
foldNames = [];
if length(dateIn)>=1
    for ii = 1:length(dateIn)
        FoldCont = dir(fullfile(fileparts(fileparts(fpath1)),[dateIn{ii} '*', mouseType '*', mouseIds '*',sessionType '*']));
        foldNames = [foldNames;{FoldCont.name}'];
    end
else
    FoldCont = dir(fullfile(fileparts(fileparts(fpath1)),[dateIn '*', mouseType '*', mouseIds '*',sessionType '*']));
    foldNames = [foldNames;{FoldCont.name}];
end


% [~,refFold ] = fileparts(fileparts(fnFeat.spath));
%% Extract STA activity across sessions
%%%%%%%% Stimulus temporal parameters
sTime = linspace(0,15,450);
whiskTime = [3 4]; %%%% duration of tactile stimulatino to consider
oroTime = [7 8];
visTime = [11 12]; %%%% duration of visual stimualtion to consider
for kk = 1:length(foldNames)
disp(['Processing Data from ' foldNames{kk}]); 
%% %%%%%%%%%%%%%%% load allen dorasal map coordinates %%%%%
fpath = [fullfile(parentFold,foldNames{kk}) '\'];
%%
[fnFeat] = getFileNameProperties(fpath);%%% get all fileNames variables
dmName = [fnFeat.sname_ex(1:fnFeat.us_idx-5) 'dorsalMap.mat'];
load(fullfile(fnFeat.spath,dmName));
%% %%%%%%%% loading mask file %%%%%%%%%
[~,maskFold] = fileparts(fileparts(fpath));
maskPath = fullfile(fileparts(fileparts(fileparts(fpath))),['Data'],maskFold);
roiMask = load(fullfile(maskPath,[fnFeat.sname_ex(1:end-10) 'refMask.mat']));

%% %%%%%%%%%%%%%%%%
ID = [1:20];
dffV_Whisk = [];
dffV_Oro = [];
dffV_Vis = [];
tic;
parfor ii = 1:length(ID);
    %%%%%%%%% Extract Calcium Signal
    sname_in = [fnFeat.sname_ex(1:fnFeat.us_idx) num2str(ID(ii)) '.mat'];
    CaSig_in = load(fullfile(fnFeat.spath,sname_in));
    dffV = CaSig_in.dffV; %%%%%% mean Correction;
    dffV_Whisk(:,:,:,ii) = dffV(:,:,find(sTime>=whiskTime(1) & sTime<=whiskTime(2)));
    dffV_Oro(:,:,:,ii) = dffV(:,:,find(sTime>=oroTime(1) & sTime<=oroTime(2)));
    dffV_Vis(:,:,:,ii) = dffV(:,:,find(sTime>=visTime(1) & sTime<=visTime(2)));
end
toc/60
%% %%%%% fitting signal to allen map and applying Mask %%%%%%%%%%%
tform = dorsalMaps.tform;
dffV_Whisk = imwarp(dffV_Whisk .* roiMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*dorsalMaps.maskScaled;
dffV_Oro = imwarp(dffV_Oro .* roiMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*dorsalMaps.maskScaled;
dffV_Vis = imwarp(dffV_Vis .* roiMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*dorsalMaps.maskScaled; 
%% %%%% make mean activity %%%%%%%%%%
dffV_Whisk_mn(:,:,:,kk) = mean(dffV_Whisk,4);
dffV_Oro_mn(:,:,:,kk) = mean(dffV_Oro,4);
dffV_Vis_mn(:,:,:,kk) = mean(dffV_Vis,4);
end
%% Obtaining mean image data  
meanImg_Whisk = mean(mean(dffV_Whisk_mn,4),3);
meanImg_Oro = mean(mean(dffV_Oro_mn,4),3);
meanImg_Vis = mean(mean(dffV_Vis_mn,4),3);

%% %%%%%%%%%%% Choosing Locations for Making Sensory Masks %%%%%
imScl = [-0.04 0.04];
%%%%%% whisker Stimulatin Mask %%%%%%%%%%%%%
close all
h1 = figure;
h1.Position = [54 464 1726 473];
subplot(1,3,1)
imagesc(meanImg_Whisk,imScl);
axis image
colorbar
hold on
for p = 1:length(dorsalMaps.edgeOutlineSplit)
    plot( dorsalMaps.edgeOutlineSplit{p}(:, 2),dorsalMaps.edgeOutlineSplit{p}(:, 1),'color','w','LineWidth',0.5);
end
title(['Select Roi for Whisker Stimulation'])
colormap(cmapUse)

roiRadius = 14; %%%%% Radius of the ROI Mask
[roiX, roiY] = ginput(1);
markerh = images.roi.Circle(gca,'Center',[roiX, roiY],'Radius',roiRadius);
imask = createMask(markerh,meanImg_Whisk);
delete(markerh)
imagesc(double(imask)*-1,'AlphaData',double(imask)*0.7);
roiMasks.whiskStim = imask; %%%%%%% storing Whisker Stimulation Mask

%%%%%% orofacial Stimulatin Mask %%%%%%%%%%%%%
subplot(1,3,2)
imagesc(meanImg_Oro,imScl);
axis image
colorbar
hold on
for p = 1:length(dorsalMaps.edgeOutlineSplit)
    plot( dorsalMaps.edgeOutlineSplit{p}(:, 2),dorsalMaps.edgeOutlineSplit{p}(:, 1),'color','w','LineWidth',0.5);
end
title(['Select Roi for Orofacial Stimulation'])
colormap(cmapUse)

roiRadius = 14; %%%%% Radius of the ROI for extracting mean signal
[roiX, roiY] = ginput(1);
markerh = images.roi.Circle(gca,'Center',[roiX, roiY],'Radius',roiRadius);
imask = createMask(markerh,meanImg_Whisk);
delete(markerh)
imagesc(double(imask)*-1,'AlphaData',double(imask)*0.7);
roiMasks.oroStim = imask; %%%%%%% storing orofacial Stimulation Mask


%%%%%% visual Stimulatin Mask %%%%%%%%%%%%%
subplot(1,3,3)
imagesc(meanImg_Vis,imScl);
axis image
colorbar
hold on
for p = 1:length(dorsalMaps.edgeOutlineSplit)
    plot( dorsalMaps.edgeOutlineSplit{p}(:, 2),dorsalMaps.edgeOutlineSplit{p}(:, 1),'color','w','LineWidth',0.5);
end
title(['Select Roi for Visual Stimulation'])
colormap(cmapUse)
roiRadius = 14; %%%%% Radius of the ROI for extracting mean signal
[roiX, roiY] = ginput(1);
markerh = images.roi.Circle(gca,'Center',[roiX, roiY],'Radius',roiRadius);
imask = createMask(markerh,meanImg_Whisk);
delete(markerh)
imagesc(double(imask)*-1,'AlphaData',double(imask)*0.7);
roiMasks.visStim = imask; %%%%%%% storing Whisker Stimulation Mask
%% %%%%%%%%%%%%%%%%%%%%% saving the roi Mask data
data.sessionsUsed = foldNames;
data.roiMasks = roiMasks;
saveFolder = 'G:\Hemanth_CSHL\WideField\Data_Analysis\SensoryStimulationData';
saveFile = 'sensoryStimRoiMasks.mat';
save(fullfile(saveFolder,saveFile),'data');

%% %%%%%%%%% plotting spatial mean map with allen map %%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Functions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [fnFeat ] = getFileNameProperties(fpath)
%%%%%%%%%%%%% getting signal file name %%%%%%%%%%%%%%
[~, sflname] = fileparts(fileparts(fpath));
spath = fpath;
listing_sig = dir([spath '\*.mat']);
sname_all = natsortfiles({listing_sig.name}');
sname_ex = sname_all{1};
us_idx = find(sname_ex == '_',1,'last');

%%% updating all properties
fnFeat.sname_all = sname_all;
fnFeat.sname_ex = sname_ex;
fnFeat.spath = spath;
fnFeat.us_idx = us_idx;
end




