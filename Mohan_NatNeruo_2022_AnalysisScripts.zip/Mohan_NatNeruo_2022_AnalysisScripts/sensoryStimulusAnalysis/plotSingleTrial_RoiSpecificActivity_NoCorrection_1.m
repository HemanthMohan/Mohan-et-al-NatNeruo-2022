clear all; close all; clc
%%
[fname fpath] = uigetfile('*.mat');
AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.

%% %%%%%%%% generate Masks for differetn areas of interest %%%%%%%%%%
maskData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\SensoryStimulationData\sensoryStimRoiMasks.mat');
[fnFeat] = getFileNameProperties(fpath);%%% get all fileNames variables
dmName = [fnFeat.sname_ex(1:fnFeat.us_idx-5) 'dorsalMap.mat'];
load(fullfile(fnFeat.spath,dmName));
tform = dorsalMaps.tform;
whiskMask = double(maskData.data.roiMasks.whiskStim); whiskMask(whiskMask==0) = nan;
oroMask = double(maskData.data.roiMasks.oroStim); oroMask(oroMask==0) = nan;
visMask = double(maskData.data.roiMasks.visStim); visMask(visMask==0) = nan;

hMask = figure();
hMask.Position = [403   380   782   286];

subplot(1,3,1); imagesc(whiskMask); axis image;title('whisker mask');
hold on
for p = 1:length(dorsalMaps.edgeOutlineSplit)
    plot( dorsalMaps.edgeOutlineSplit{p}(:, 2),dorsalMaps.edgeOutlineSplit{p}(:, 1),'color','w','LineWidth',0.5);
end
hold off
subplot(1,3,2);imagesc(oroMask); axis image;title('orofacial mask');
hold on
for p = 1:length(dorsalMaps.edgeOutlineSplit)
    plot( dorsalMaps.edgeOutlineSplit{p}(:, 2),dorsalMaps.edgeOutlineSplit{p}(:, 1),'color','w','LineWidth',0.5);
end
hold off
subplot(1,3,3);imagesc(visMask); axis image;title('visual mask');
hold on
for p = 1:length(dorsalMaps.edgeOutlineSplit)
    plot( dorsalMaps.edgeOutlineSplit{p}(:, 2),dorsalMaps.edgeOutlineSplit{p}(:, 1),'color','w','LineWidth',0.5);
end
hold off
sgtitle(' Mask Images')
%% %%%%%% Stimulus temporal parameters %%%%%%%%
sTime = linspace(0,15,450);
whiskStart= 3; %%%% onset of tactile stimulatino to consider
oroStart = 7;
visStart = 11; %%%% onset of visual stimualtion to consider
stimDur = 1; %%% duration of Stimulation in seconds
stimArea = zeros(3,size(sTime,2))-0.03; 
stimArea(1,find(sTime>whiskStart,1):find(sTime>whiskStart+stimDur,1)) = 0.1;
stimArea(2,find(sTime>oroStart,1):find(sTime>oroStart+stimDur,1)) = 0.1;
stimArea(3,find(sTime>visStart,1):find(sTime>visStart+stimDur,1)) = 0.1;
%% %%%%%%%% loading mask file %%%%%%%%%
[~,maskFold] = fileparts(fileparts(fpath));
maskPath = fullfile(fileparts(fileparts(fileparts(fpath))),['Data'],maskFold);
roiMask = load(fullfile(maskPath,[fnFeat.sname_ex(1:end-10) 'refMask.mat']));

%% %%%%%%%%%%%%%%%%
ID = [1:20];
dffV_Whisk = [];
dffV_Oro = [];
dffV_Vis = [];
tic;
parfor ii = 1:length(ID);
    %%%%%%%%% Extract Calcium Signal
    sname_in = [fnFeat.sname_ex(1:fnFeat.us_idx) num2str(ID(ii)) '.mat'];
    CaSig_in = load(fullfile(fnFeat.spath,sname_in));
    dffV = CaSig_in.dffV; %%%%%% mean Correction;
    dffV_Whisk(ii,:) = nanmean(nanmean(imwarp(dffV .* roiMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*whiskMask,1),2);
    dffV_Oro(ii,:) = nanmean(nanmean(imwarp(dffV .* roiMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*oroMask,1),2);
    dffV_Vis(ii,:) = nanmean(nanmean(imwarp(dffV .* roiMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*visMask,1),2);
%     dffV_VisAct(:,:,:,ii) = imwarp(dffV .* roiMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*visMask;
    dffV_WhiskAct = imwarp(dffV .* roiMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*whiskMask;

end
toc/60
%% %%%% Plot Heat maps
hh = figure;
hscl = [-0.02 0.05];
subplot(1,3,1)
imagesc(dffV_Whisk)

subplot(1,3,2)
imagesc(dffV_Oro)

subplot(1,3,3)
imagesc(dffV_Vis)
hh.Position = [255 567 1513 420];
colormap jet
%% Plot Single trial activity %%%%%%
% trialId = 16; %% ENTER THE TRIAL IDX TO PLOT
if exist('h2')
    try
    close(h2)
    catch
    end
end
for ii = 1:length(ID)
trialId = ii; %% ENTER THE TRIAL IDX TO PLOT
h2 = figure;
h2.Position = [1668 371 545 565];
ax(1) = subplot(3,1,1);
hold on
ar(1,1) = area(sTime,stimArea(1,:),min(stimArea(:)),'FaceColor','red','EdgeColor','none'); ar(1,1).FaceAlpha = 0.2;
ar(1,2) = area(sTime,stimArea(2,:),min(stimArea(:)),'FaceColor','green','EdgeColor','none'); ar(1,2).FaceAlpha = 0.2;
ar(1,3) = area(sTime,stimArea(3,:),min(stimArea(:)),'FaceColor','cyan','EdgeColor','none'); ar(1,3).FaceAlpha = 0.2;


plot(sTime,dffV_Whisk(trialId,:),'LineWidth',1,'color','k')
hold off
title('Whisker Stimulation') 

ax(2) = subplot(3,1,2);
hold on
ar(2,1) = area(sTime,stimArea(1,:),min(stimArea(:)),'FaceColor','red','EdgeColor','none'); ar(2,1).FaceAlpha = 0.2;
ar(2,2) = area(sTime,stimArea(2,:),min(stimArea(:)),'FaceColor','green','EdgeColor','none'); ar(2,2).FaceAlpha = 0.2;
ar(2,3) = area(sTime,stimArea(3,:),min(stimArea(:)),'FaceColor','cyan','EdgeColor','none'); ar(2,3).FaceAlpha = 0.2;


plot(sTime,dffV_Oro(trialId,:),'LineWidth',1,'color','k')
hold off
title('Oro Stimulation') 

ax(3) = subplot(3,1,3);
hold on
ar(3,1) = area(sTime,stimArea(1,:),min(stimArea(:)),'FaceColor','red','EdgeColor','none'); ar(3,1).FaceAlpha = 0.2;
ar(3,2) = area(sTime,stimArea(2,:),min(stimArea(:)),'FaceColor','green','EdgeColor','none'); ar(3,2).FaceAlpha = 0.2;
ar(3,3) = area(sTime,stimArea(3,:),min(stimArea(:)),'FaceColor','cyan','EdgeColor','none'); ar(3,3).FaceAlpha = 0.2;

plot(sTime,dffV_Vis(trialId,:),'LineWidth',1,'color','k')
hold off
title('Visual Stimulation') 

linkaxes(ax,'xy')
xlim(ax,[2,13])
% ylim(ax,[-0.02 0.05])
sgtitle(['Mouse: ' fname(1:end-22) ', Trial Idx: ' num2str(trialId)],'interpreter','none','FontSize',12) 
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Functions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [fnFeat ] = getFileNameProperties(fpath)
%%%%%%%%%%%%% getting signal file name %%%%%%%%%%%%%%
[~, sflname] = fileparts(fileparts(fpath));
spath = fpath;
listing_sig = dir([spath '\*.mat']);
sname_all = natsortfiles({listing_sig.name}');
sname_ex = sname_all{1};
us_idx = find(sname_ex == '_',1,'last');

%%% updating all properties
fnFeat.sname_all = sname_all;
fnFeat.sname_ex = sname_ex;
fnFeat.spath = spath;
fnFeat.us_idx = us_idx;
end




