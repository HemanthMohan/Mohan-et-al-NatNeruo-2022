clear all; close all; clc;
%% Load Data
plexData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\SensoryStimulationData\STAMapData\PlexinD1Ai148_StaSensoryMaps.mat');
plexData = plexData.data;
fezData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\SensoryStimulationData\STAMapData\FezF2Ai148_StaSensoryMaps.mat');
fezData = fezData.data;
%% extract variance maps
whisk_plex = plexData.meanImg_Whisk;
oro_plex = plexData.meanImg_Oro;
vis_plex = plexData.meanImg_Vis;
whisk_fez = fezData.meanImg_Whisk;
oro_fez = fezData.meanImg_Oro;
vis_fez = fezData.meanImg_Vis;
whisk_plex(find(whisk_plex==0)) = NaN;
oro_plex(find(oro_plex==0)) = NaN;
vis_plex(find(vis_plex==0)) = NaN;
whisk_fez(find(whisk_fez==0)) = NaN;
oro_fez(find(oro_fez==0)) = NaN;
vis_fez(find(vis_fez==0)) = NaN;
numSes = length(plexData.sessions);
%% perform 2D Correlaions within and between types
ccIdx = nchoosek([1:numSes],2);
for ii = 1:length(ccIdx)
    ccWhisk_plex(ii,1) = corr(reshape(whisk_plex(:,:,ccIdx(ii,1)),[],1), reshape(whisk_plex(:,:,ccIdx(ii,2)),[],1),'Rows','complete');
    ccOro_plex(ii,1) = corr(reshape(oro_plex(:,:,ccIdx(ii,1)),[],1), reshape(oro_plex(:,:,ccIdx(ii,2)),[],1),'Rows','complete');
    ccVis_plex(ii,1) = corr(reshape(vis_plex(:,:,ccIdx(ii,1)),[],1), reshape(vis_plex(:,:,ccIdx(ii,2)),[],1),'Rows','complete');
    
    ccWhisk_fez(ii,1) = corr(reshape(whisk_fez(:,:,ccIdx(ii,1)),[],1), reshape(whisk_fez(:,:,ccIdx(ii,2)),[],1),'Rows','complete');
    ccOro_fez(ii,1) = corr(reshape(oro_fez(:,:,ccIdx(ii,1)),[],1), reshape(oro_fez(:,:,ccIdx(ii,2)),[],1),'Rows','complete');
    ccVis_fez(ii,1) = corr(reshape(vis_fez(:,:,ccIdx(ii,1)),[],1), reshape(vis_fez(:,:,ccIdx(ii,2)),[],1),'Rows','complete');
    
end

for ii =1:numSes
    for jj = 1:numSes
        ccWhisk_plexfezMat(ii,jj) = corr(reshape(whisk_plex(:,:,ii),[],1), reshape(whisk_fez(:,:,jj),[],1),'Rows','complete');
        ccOro_plexfezMat(ii,jj) = corr(reshape(oro_plex(:,:,ii),[],1), reshape(oro_fez(:,:,jj),[],1),'Rows','complete');
        ccVis_plexfezMat(ii,jj) = corr(reshape(vis_plex(:,:,ii),[],1), reshape(vis_fez(:,:,jj),[],1),'Rows','complete');
    end
end
ccWhisk_plexfez = ccWhisk_plexfezMat(:);
ccOro_plexfez = ccOro_plexfezMat(:);
ccVis_plexfez = ccVis_plexfezMat(:);
%% Perform Stats
pCnt = length(ccWhisk_plex);
pfCnt = length(ccWhisk_plexfez);
grpId = [repmat({'plexVsPlex'},pCnt,1);repmat({'fezVsfez'},pCnt,1);repmat({'plexVsfez'},pfCnt,1) ];

[~,~,statsWhisk] = kruskalwallis([ccWhisk_plex;ccWhisk_fez;ccWhisk_plexfez],grpId);
[mCompWhisk,~,~,gnames] = multcompare(statsWhisk);

[~,~,statsOro] = kruskalwallis([ccOro_plex;ccOro_fez;ccOro_plexfez],grpId);
[mCompOro,~,~,gnames] = multcompare(statsOro);

[~,~,statsVis] = kruskalwallis([ccVis_plex;ccVis_fez;ccVis_plexfez],grpId);
[mCompVis,~,~,gnames] = multcompare(statsVis);


statsTextWhisk = "KruskalWallisWhisk" + newline + ...
    gnames{mCompWhisk(1,1)} + " VS " + gnames{mCompWhisk(1,2)} + " = " + num2str(mCompWhisk(1,6)) + ...
    newline + gnames{mCompWhisk(2,1)} + " VS " + gnames{mCompWhisk(2,2)} + " = " + num2str(mCompWhisk(2,6)) + ...
    newline + gnames{mCompWhisk(3,1)} + " VS " + gnames{mCompWhisk(3,2)} + " = " + num2str(mCompWhisk(3,6));

statsTextOro = "KruskalWallisOro" + newline + ...
    gnames{mCompOro(1,1)} + " VS " + gnames{mCompOro(1,2)} + " = " + num2str(mCompOro(1,6)) + ...
    newline + gnames{mCompOro(2,1)} + " VS " + gnames{mCompOro(2,2)} + " = " + num2str(mCompOro(2,6)) + ...
    newline + gnames{mCompOro(3,1)} + " VS " + gnames{mCompOro(3,2)} + " = " + num2str(mCompOro(3,6));

statsTextVis = "KruskalWallisVis" + newline + ...
    gnames{mCompVis(1,1)} + " VS " + gnames{mCompVis(1,2)} + " = " + num2str(mCompVis(1,6)) + ...
    newline + gnames{mCompVis(2,1)} + " VS " + gnames{mCompVis(2,2)} + " = " + num2str(mCompVis(2,6)) + ...
    newline + gnames{mCompVis(3,1)} + " VS " + gnames{mCompVis(3,2)} + " = " + num2str(mCompVis(3,6));

%% %%%%%%%%%%% plotting the distribution
h1 = figure; h1.Position = [228         368        1477         610];

ax(1) = subplot(1,3,1);
boxplot([ccWhisk_plex;ccWhisk_fez;ccWhisk_plexfez],grpId)
ylabel('corr coef')
title (' Whisk activity 2D Correlation')

ax(2) = subplot(1,3,2);
boxplot([ccOro_plex;ccOro_fez;ccOro_plexfez],grpId)
ylabel('corr coef')
title (' Orofacial activity 2D Correlation')

ax(3) = subplot(1,3,3);
boxplot([ccVis_plex;ccVis_fez;ccVis_plexfez],grpId)
ylabel('corr coef')
title (' Visual activity 2D Correlation')


linkaxes(ax,'y')
annotation(h1,'textbox', [0, 0.95, 0, 0], 'string', statsTextWhisk,'FontSize',7)
annotation(h1,'textbox', [0, 0.55, 0, 0], 'string', statsTextOro,'FontSize',7)
annotation(h1,'textbox', [0.91, 0.95, 0, 0], 'string', statsTextVis,'FontSize',7)
%% %%%%%%%%%%%%% saving the figures %%%%%%%%%%

saveFolder = 'G:\Hemanth_CSHL\WideField\Data_Figures\SensoryStimActivityPlots\2DSpatialMapSimilarityPlots\';
fileName1 = ['SensoryMapsSimilarity2DCorrelations.fig'];
savePath1 = fullfile(saveFolder,fileName1);
saveFig = input('Do you want to save the current figure : ');
if saveFig == 1
    savefig(h1,savePath1)
    saveas(h1,[savePath1(1:end-4) '.svg']);
end