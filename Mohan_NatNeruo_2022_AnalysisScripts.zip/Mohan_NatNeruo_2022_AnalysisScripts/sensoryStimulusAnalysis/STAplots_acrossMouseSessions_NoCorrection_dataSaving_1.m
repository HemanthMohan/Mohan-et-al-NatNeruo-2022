clear all; close all; clc
%%
load('F:\Hemanth_CSHL\WideField\Data\cmap3.mat');
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
load('F:\Hemanth_CSHL\WideField\Data\cmap1.mat');
cmapUse = cmap2; %% which cmap to use to plot
[fname fpath1] = uigetfile('*.mat');
AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.
%% %%%%%%%%%%%%%%% enter details to group sessions %%%%%%%%%%%%%
% mouseIds = ['c9m2']; %%%% enter the mouse ID to concatenate activity or even a part of it to concatedate across differenct mice
mouseIds = ['c']; %%%% enter the mouse ID to concatenate activity or even a part of it to concatedate across differenct mice
mouseType = ['FezF2'];
sessionType = ['isoSensory'];
dateIn = {'20210106';'20210107'; '20210108'};
%% %%%%%%%%%%%%%%%%%%% get file  name structure %%%%%%%%%%%%
parentFold = fileparts(fileparts(fpath1));
foldNames = [];
if length(dateIn)>=1
    for ii = 1:length(dateIn)
        FoldCont = dir(fullfile(fileparts(fileparts(fpath1)),[dateIn{ii} '*', mouseType '*', mouseIds '*',sessionType '*']));
        foldNames = [foldNames;{FoldCont.name}'];
    end
else
    FoldCont = dir(fullfile(fileparts(fileparts(fpath1)),[dateIn '*', mouseType '*', mouseIds '*',sessionType '*']));
    foldNames = [foldNames;{FoldCont.name}];
end


% [~,refFold ] = fileparts(fileparts(fnFeat.spath));
%% Extract STA activity across sessions
%%%%%%%% Stimulus temporal parameters
sTime = linspace(0,15,450);
whiskTime = [3 4]; %%%% duration of tactile stimulatino to consider
oroTime = [7 8];
visTime = [11 12]; %%%% duration of visual stimualtion to consider
for kk = 1:length(foldNames)
disp(['Processing Data from ' foldNames{kk}]); 
%% %%%%%%%%%%%%%%% load allen dorasal map coordinates %%%%%
fpath = [fullfile(parentFold,foldNames{kk}) '\'];
%%
[fnFeat] = getFileNameProperties(fpath);%%% get all fileNames variables
dmName = [fnFeat.sname_ex(1:fnFeat.us_idx-5) 'dorsalMap.mat'];
load(fullfile(fnFeat.spath,dmName));
%% %%%%%%%% loading mask file %%%%%%%%%
[~,maskFold] = fileparts(fileparts(fpath));
maskPath = fullfile(fileparts(fileparts(fileparts(fpath))),['Data'],maskFold);
roiMask = load(fullfile(maskPath,[fnFeat.sname_ex(1:end-10) 'refMask.mat']));

%% %%%%%%%%%%%%%%%%
ID = [1:20];
dffV_Whisk = [];
dffV_Oro = [];
dffV_Vis = [];
tic;
parfor ii = 1:length(ID);
    %%%%%%%%% Extract Calcium Signal
    sname_in = [fnFeat.sname_ex(1:fnFeat.us_idx) num2str(ID(ii)) '.mat'];
    CaSig_in = load(fullfile(fnFeat.spath,sname_in));
    dffV = CaSig_in.dffV; %%%%%% mean Correction;
    dffV_Whisk(:,:,:,ii) = dffV(:,:,find(sTime>=whiskTime(1) & sTime<=whiskTime(2)));
    dffV_Oro(:,:,:,ii) = dffV(:,:,find(sTime>=oroTime(1) & sTime<=oroTime(2)));
    dffV_Vis(:,:,:,ii) = dffV(:,:,find(sTime>=visTime(1) & sTime<=visTime(2)));
end
toc/60
%% %%%%% fitting signal to allen map and applying Mask %%%%%%%%%%%
tform = dorsalMaps.tform;
dffV_Whisk = imwarp(dffV_Whisk .* roiMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*dorsalMaps.maskScaled;
dffV_Oro = imwarp(dffV_Oro .* roiMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*dorsalMaps.maskScaled;
dffV_Vis = imwarp(dffV_Vis .* roiMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*dorsalMaps.maskScaled; 
%% %%%% make mean activity %%%%%%%%%%
dffV_Whisk_mn(:,:,:,kk) = mean(dffV_Whisk,4);
dffV_Oro_mn(:,:,:,kk) = mean(dffV_Oro,4);
dffV_Vis_mn(:,:,:,kk) = mean(dffV_Vis,4);
end
%% Obtaining mean image data  
meanImg_Whisk = squeeze(mean(dffV_Whisk_mn,3));
meanImg_Oro = squeeze(mean(dffV_Oro_mn,3));
meanImg_Vis = squeeze(mean(dffV_Vis_mn,3));
for jj = 1:length(foldNames)
    meanImg_Whisk_norm(:,:,jj) = meanImg_Whisk(:,:,jj)./max(max(meanImg_Whisk(:,:,jj)));
    meanImg_Oro_norm(:,:,jj) = meanImg_Oro(:,:,jj)./max(max(meanImg_Oro(:,:,jj)));
    meanImg_Vis_norm(:,:,jj) = meanImg_Vis(:,:,jj)./max(max(meanImg_Vis(:,:,jj)));
end
%% %%%%%%%%% load data %%%%%%
if contains(lower(fnFeat.sname_ex(1:end-10)),'fezf')
    MouseType = 'FezF2Ai148'; %%%%% options 'FezF2Ai148'; 'PlexinD1Ai148'; 'Tle4Ai148'; 'CBAAi93h'
elseif contains(lower(fnFeat.sname_ex(1:end-10)),'plexin')
    MouseType = 'PlexinD1Ai148';
end


data.whiskTime = whiskTime;
data.oroTime = oroTime;
data.visTime = visTime;
data.meanImg_Whisk = meanImg_Whisk;
data.meanImg_Oro = meanImg_Oro;
data.meanImg_Vis = meanImg_Vis;
data.meanImg_Whisk_norm = meanImg_Whisk_norm;
data.meanImg_Oro_norm = meanImg_Oro_norm;
data.meanImg_Vis_norm = meanImg_Vis_norm;
data.meanImgSeq_Whisk = dffV_Whisk_mn;
data.meanImgSeq_Oro = dffV_Oro_mn;
data.meanImgSeq_Vis = dffV_Vis_mn;
data.sessions = foldNames;
data.MouseType = MouseType;

%% %%%%%%%%%%%%%%%%%%% Saving images %%%%%%%%%%%%%%%%%%%%%

if AskSaving == 1
    filename = [MouseType '_StaSensoryMaps.mat'];
    saveFig = input('Do you want to save the current data: ');
    if saveFig == 1
        savepath = fullfile(['G:\Hemanth_CSHL\WideField\Data_Analysis\SensoryStimulationData\STAMapData\'],filename);
        save(savepath,'data','-v7.3');
        disp('Data is Saved !')
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Functions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [fnFeat ] = getFileNameProperties(fpath)
%%%%%%%%%%%%% getting signal file name %%%%%%%%%%%%%%
[~, sflname] = fileparts(fileparts(fpath));
spath = fpath;
listing_sig = dir([spath '\*.mat']);
sname_all = natsortfiles({listing_sig.name}');
sname_ex = sname_all{1};
us_idx = find(sname_ex == '_',1,'last');

%%% updating all properties
fnFeat.sname_all = sname_all;
fnFeat.sname_ex = sname_ex;
fnFeat.spath = spath;
fnFeat.us_idx = us_idx;
end




