clear all; close all; clc
%%
foldPlex = 'G:\Hemanth_CSHL\WideField\Data_Analysis\SensoryStimulationData\NoCorrection\PlexinD1Ai148\';
foldFez = 'G:\Hemanth_CSHL\WideField\Data_Analysis\SensoryStimulationData\NoCorrection\FezF2Ai148\';
AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.
%% %%%%%%%%%%%%%% Extracting Data %%%%%%%%%%%%%%
filesPlex = dir(fullfile(foldPlex,'*.mat'));filesPlex = {filesPlex.name}';
filesFez = dir(fullfile(foldFez,'*.mat'));filesFez = {filesFez.name}';
plexData.whiskAct = []; plexData.oroAct = []; plexData.visAct = [];
inData = [];
for ii = 1:length(filesPlex)
    inData = load(fullfile(foldPlex,filesPlex{ii}));
    plexData.whiskAct = [plexData.whiskAct; inData.data.whiskAct];
    plexData.oroAct = [plexData.oroAct; inData.data.oroAct];
    plexData.visAct = [plexData.visAct; inData.data.visAct];
end


fezData.whiskAct = []; fezData.oroAct = []; fezData.visAct = [];
for ii = 1:length(filesFez)
    inData = load(fullfile(foldFez,filesFez{ii}));
    fezData.whiskAct = [fezData.whiskAct; inData.data.whiskAct];
    fezData.oroAct = [fezData.oroAct; inData.data.oroAct];
    fezData.visAct = [fezData.visAct; inData.data.visAct];
end
sigTime = inData.data.sigTime;
%% %%%%%%%%%%%%%% calculating AUC activiry for the two cell types %%%%%%%%%%
%%%%% parameters for integration %%%%%%%%
startTm = 0; %% start time to integrate signal
endTm = 1; %% end time to integrae signal
startIdx= find(sigTime >= startTm, 1); %%% start index for the signals used to auc activity
endIdx= find(sigTime >= endTm, 1); %%% end index for the signals used to auc activity

%%% Integrating Activity %%%%%%%%

whiskAuc_plex = trapz(sigTime(startIdx:endIdx),plexData.whiskAct(:,startIdx:endIdx),2);
oroAuc_plex = trapz(sigTime(startIdx:endIdx),plexData.oroAct(:,startIdx:endIdx),2);
visAuc_plex = trapz(sigTime(startIdx:endIdx),plexData.visAct(:,startIdx:endIdx),2);

whiskAuc_fez = trapz(sigTime(startIdx:endIdx),fezData.whiskAct(:,startIdx:endIdx),2);
oroAuc_fez = trapz(sigTime(startIdx:endIdx),fezData.oroAct(:,startIdx:endIdx),2);
visAuc_fez = trapz(sigTime(startIdx:endIdx),fezData.visAct(:,startIdx:endIdx),2);
%% perfrom anova %%%%%%%%%%%%
g1 = [repmat("plex",length(whiskAuc_plex),1);repmat("plex",length(oroAuc_plex),1);repmat("plex",length(visAuc_plex),1); ...
    repmat("fez",length(whiskAuc_fez),1); repmat("fez",length(oroAuc_fez),1); repmat("fez",length(visAuc_fez),1)];
g2 = [repmat("Whisk",length(whiskAuc_plex),1);repmat("Oro",length(oroAuc_plex),1);repmat("Vis",length(visAuc_plex),1); ...
    repmat("Whisk",length(whiskAuc_fez),1); repmat("Oro",length(oroAuc_fez),1); repmat("Vis",length(visAuc_fez),1)];

dataIn = [whiskAuc_plex; oroAuc_plex; visAuc_plex; ...
    whiskAuc_fez; oroAuc_fez; visAuc_fez];
[~,~,stats] = anovan(dataIn,{g1 g2},"Model","interaction", ...
    "Varnames",["CellType","Stimulus"]);
[results,~,~,gnames] = multcompare(stats,"Dimension",[1 2]);

pWhisk = results(find(results(:,1) == 1 & results(:,2) == 2),6);
pOro = results(find(results(:,1) == 3 & results(:,2) == 4),6);
pVis = results(find(results(:,1)== 5 & results(:,2) == 6),6);
%% %%%%%%%%%%%%%%% perform statistics and plot activity %%%%%%%%%%%%%
h1 = figure();
ax(1) = subplot(2,3,1);
boxplot([whiskAuc_plex,whiskAuc_fez],'Labels',{'Plex', 'Fez'})
text(ax(1),1.1 ,0.07,['p=' num2str(pWhisk)])
title('Whisker AUC')

ax(2) = subplot(2,3,2);
boxplot([oroAuc_plex,oroAuc_fez],'Labels',{'Plex', 'Fez'})
text(ax(2),1.1 ,0.07,['p=' num2str(pOro)])
title('Oro AUC')

ax(3) = subplot(2,3,3);
boxplot([visAuc_plex,visAuc_fez],'Labels',{'Plex', 'Fez'})
text(ax(3),1.1 ,0.07,['p=' num2str(pVis)])
title('Visual AUC')
 ylim([-0.02,0.1])
linkaxes(ax, 'y')
h1.Position = [240   209   950   741];
sgtitle('Two Way Anova')
annotation(h1,'textbox', [0, 0.5, 0, 0], 'string', [filesPlex;filesFez],'FontSize',7, 'Interpreter', 'none')
%% save figure
savePath = 'G:\Hemanth_CSHL\WideField\Data_Figures\SensoryStimActivityPlots\RoiSpecificAUC\SensoryroiSpecificAUCPlotAnovaStats.fig';
savefig(h1,savePath)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Functions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [fnFeat ] = getFileNameProperties(fpath)
%%%%%%%%%%%%% getting signal file name %%%%%%%%%%%%%%
[~, sflname] = fileparts(fileparts(fpath));
spath = fpath;
listing_sig = dir([spath '\*.mat']);
sname_all = natsortfiles({listing_sig.name}');
sname_ex = sname_all{1};
us_idx = find(sname_ex == '_',1,'last');

%%% updating all properties
fnFeat.sname_all = sname_all;
fnFeat.sname_ex = sname_ex;
fnFeat.spath = spath;
fnFeat.us_idx = us_idx;
end




