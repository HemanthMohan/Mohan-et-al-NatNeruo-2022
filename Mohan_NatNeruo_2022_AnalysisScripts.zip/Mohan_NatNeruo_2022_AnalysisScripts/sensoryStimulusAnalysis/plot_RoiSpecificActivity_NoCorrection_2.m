clear all; close all; clc
%%
load('F:\Hemanth_CSHL\WideField\Data\cmap3.mat');
load('F:\Hemanth_CSHL\WideField\Data\cmap2.mat');
load('F:\Hemanth_CSHL\WideField\Data\cmap1.mat');
cmapUse = cmap2; %% which cmap to use to plot
[fname fpath1] = uigetfile('*.mat');
AskSaving = 1; %%%  Enter 1 if you want to ask the figure saving question.
%% %%%%%%%%%%%%%%% enter details to group sessions %%%%%%%%%%%%%
% dateIn = {'20210107'; '20210108'}; %%% use for plexinD1
% dateIn = {'20210106'; '20210108'}; %%% use for fezF2
dateIn = {'20210106'; '20210108'}; %%% use for fezF2
mouseType = ['FezF2'];
mouseIds = ['c9m3']; %%%% enter the mouse ID to concatenate activity or even a part of it to concatedate across differenct mice
sessionType = ['isoSensory'];

% % %%%%%%%%%%%%%%%%%%% get file  name structure %%%%%%%%%%%%
parentFold = fileparts(fileparts(fpath1));
foldNames = [];
if length(dateIn)>=1
    for ii = 1:length(dateIn)
        FoldCont = dir(fullfile(fileparts(fileparts(fpath1)),[dateIn{ii} '*', mouseType '*', mouseIds '*',sessionType '*']));
        foldNames = [foldNames;{FoldCont.name}'];
    end
else
    FoldCont = dir(fullfile(fileparts(fileparts(fpath1)),[dateIn '*', mouseType '*', mouseIds '*',sessionType '*']));
    foldNames = [foldNames;{FoldCont.name}];
end
%% %%%%%%%% load Masks for differetn areas of interest %%%%%%%%%%
maskData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\SensoryStimulationData\sensoryStimRoiMasks.mat');
[fnFeat] = getFileNameProperties(fpath1);%%% get all fileNames variables
dmName = [fnFeat.sname_ex(1:fnFeat.us_idx-5) 'dorsalMap.mat'];
load(fullfile(fnFeat.spath,dmName));

whiskMask = double(maskData.data.roiMasks.whiskStim); whiskMask(whiskMask==0) = nan;
oroMask = double(maskData.data.roiMasks.oroStim); oroMask(oroMask==0) = nan;
visMask = double(maskData.data.roiMasks.visStim); visMask(visMask==0) = nan;

hMask = figure();
hMask.Position = [403   380   782   286];

subplot(1,3,1); imagesc(whiskMask); axis image;title('whisker mask');
hold on
for p = 1:length(dorsalMaps.edgeOutlineSplit)
    plot( dorsalMaps.edgeOutlineSplit{p}(:, 2),dorsalMaps.edgeOutlineSplit{p}(:, 1),'color','w','LineWidth',0.5);
end
hold off
subplot(1,3,2);imagesc(oroMask); axis image;title('orofacial mask');
hold on
for p = 1:length(dorsalMaps.edgeOutlineSplit)
    plot( dorsalMaps.edgeOutlineSplit{p}(:, 2),dorsalMaps.edgeOutlineSplit{p}(:, 1),'color','w','LineWidth',0.5);
end
hold off
subplot(1,3,3);imagesc(visMask); axis image;title('visual mask');
hold on
for p = 1:length(dorsalMaps.edgeOutlineSplit)
    plot( dorsalMaps.edgeOutlineSplit{p}(:, 2),dorsalMaps.edgeOutlineSplit{p}(:, 1),'color','w','LineWidth',0.5);
end
hold off
sgtitle(' Mask Images')
%% Extract STA activity across sessions
%%%%%%%% Stimulus temporal parameters
sTime = linspace(0,15,450);
whiskStart= 3; %%%% onset of tactile stimulatino to consider
oroStart = 7;
visStart = 11; %%%% onset of visual stimualtion to consider
sigDur = 2; %%% signal duration to collect before and after stimulus onset
fnFeat = [];
whiskActMat = []; oroActMat = []; visActMat = [];
for kk = 1:length(foldNames)
disp(['Processing Data from ' foldNames{kk}]); 
%% %%%%%%%%%%%%%%% load allen dorasal map coordinates %%%%%
fpath = [fullfile(parentFold,foldNames{kk}) '\'];
%%
[fnFeat] = getFileNameProperties(fpath);%%% get all fileNames variables
dmName = [fnFeat.sname_ex(1:fnFeat.us_idx-5) 'dorsalMap.mat'];
load(fullfile(fnFeat.spath,dmName));
%% %%%%%%%% loading mask file %%%%%%%%%
[~,maskFold] = fileparts(fileparts(fpath));
maskPath = fullfile(fileparts(fileparts(fileparts(fpath))),['Data'],maskFold);
roiMask = load(fullfile(maskPath,[fnFeat.sname_ex(1:end-10) 'refMask.mat']));

%% %%%%%%%%%%%%%%%%
ID = [1:20];
dffV_Whisk = [];
dffV_Oro = [];
dffV_Vis = [];
tic;
parfor ii = 1:length(ID);
    %%%%%%%%% Extract Calcium Signal
    sname_in = [fnFeat.sname_ex(1:fnFeat.us_idx) num2str(ID(ii)) '.mat'];
    CaSig_in = load(fullfile(fnFeat.spath,sname_in));
    dffV = CaSig_in.dffV; %%%%%% mean Correction;
    dffV_Whisk(:,:,:,ii) = dffV(:,:,find(sTime>=whiskStart-sigDur & sTime<=whiskStart+sigDur));
    dffV_Oro(:,:,:,ii) = dffV(:,:,find(sTime>=oroStart-sigDur & sTime<=oroStart+sigDur));
    dffV_Vis(:,:,:,ii) = dffV(:,:,find(sTime>=visStart-sigDur & sTime<=visStart+sigDur));
end
toc/60
%% %%%%% fitting signal to allen map and applying Mask %%%%%%%%%%%
tform = dorsalMaps.tform;
dffV_Whisk = imwarp(dffV_Whisk .* roiMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*whiskMask;
dffV_Oro = imwarp(dffV_Oro .* roiMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*oroMask;
dffV_Vis = imwarp(dffV_Vis .* roiMask.imMask,tform,'OutputView',imref2d(size(dorsalMaps.dorsalMapScaled))).*visMask ;
%% %%%%%%% calculating Roi Specific activity %%%%%%%%%
whiskAct(:,:,kk) = squeeze(nanmean(nanmean(dffV_Whisk,1),2))';
oroAct(:,:,kk) = squeeze(nanmean(nanmean(dffV_Oro,1),2))';
visAct(:,:,kk) = squeeze(nanmean(nanmean(dffV_Vis,1),2))';


whiskActMat = [whiskActMat;whiskAct(:,:,kk)];
oroActMat = [oroActMat;oroAct(:,:,kk)];
visActMat = [visActMat;visAct(:,:,kk)];

end

dffV_Whisk = [];
dffV_Oro = [];
dffV_Vis = [];
%% %%%% obtain statistical properties %%%%%%%%%
whiskMean = mean(whiskActMat,1); whiskSem = std(whiskActMat,1)/sqrt(size(whiskActMat,1));
oroMean = mean(oroActMat,1); oroSem = std(oroActMat,1)/sqrt(size(oroActMat,1));
visMean = mean(visActMat,1); visSem = std(visActMat,1)/sqrt(size(visActMat,1));

%% %%%% plotting Activity %%%%%%%%%%%%
actSz = size(whiskActMat);
hmScl = [-0.05 0.05]; %%%% scaling of heat map colors
mnYScl = [-0.03 0.08]; %%% y axis scale of mean activity 
sigTm = linspace(-sigDur,sigDur,actSz(2)); %%% signal time axis

h1 = figure();
h1.Position = [10 170 1091 476];
%%%%%%% Plotting heat map %%%%%%%%%
ax = [];
ax(1,1) = subplot(2,3,1);
imagesc(sigTm,[1:actSz(1)],whiskActMat,hmScl);colorbar;
hold on
plot([0 0],[1 actSz(1)+0.5],'w--','LineWidth',1)
hold off
title('Whisker Stim')

ax(1,2) = subplot(2,3,2);
imagesc(sigTm,[1:actSz(1)],oroActMat,hmScl);colorbar;
hold on
plot([0 0],[1 actSz(1)+0.5],'w--','LineWidth',1)
hold off
title('Oro Stim')

ax(1,3) = subplot(2,3,3);
imagesc(sigTm,[1:actSz(1)],visActMat,hmScl);colorbar;
hold on
plot([0 0],[1 actSz(1)+0.5],'w--','LineWidth',1)
hold off
title('Visual Stim')

colormap(cmapUse);
set(ax,'YDir','normal')

% set(ax,'TickDir','out')
%%%%%%% Plotting Mean Trace %%%%%%%%%
ax(2,1) = subplot(2,3,4);
plot(sigTm,whiskMean,'k-','LineWidth',1)
hold on
fill([sigTm fliplr(sigTm)],[[whiskMean + 2*whiskSem]   ...
    fliplr([whiskMean - 2*whiskSem])],'k','FaceAlpha',0.3,'EdgeColor','none')
hold on
plot([0,0],[mnYScl(1) mnYScl(2)],'r--')
hold off
title('Whisker Stim')
% set(gca,'TickDir', 'out')

ax(2,2) = subplot(2,3,5);
plot(sigTm,oroMean,'k-','LineWidth',1)
hold on
fill([sigTm fliplr(sigTm)],[[oroMean + 2*oroSem]   ...
    fliplr([oroMean - 2*oroSem])],'k','FaceAlpha',0.3,'EdgeColor','none')
hold on
plot([0,0],[mnYScl(1) mnYScl(2)],'r--')
hold off
title('Oro Stim')
% set(gca,'TickDir', 'out')

ax(2,3) = subplot(2,3,6);
plot(sigTm,visMean,'k-','LineWidth',1)
hold on
fill([sigTm fliplr(sigTm)],[[visMean + 2*visSem]   ...
    fliplr([visMean - 2*visSem])],'k','FaceAlpha',0.3,'EdgeColor','none')
hold on
plot([0,0],[mnYScl(1) mnYScl(2)],'r--')
hold off
title('Visual Stim')
% set(gca,'TickDir', 'out')

set(ax,'Xlim',[-1,2])
set(ax(2,:),'Ylim',mnYScl)
set(ax,'TickDir','out')
annotation(h1,'textbox', [0, 0.55, 0, 0], 'string', foldNames,'FontSize',7, 'Interpreter', 'none')
%% %%%%%%%%%%% storing  Activity and Meta Data %%%%%%%%%%
data.MasksUsed = maskData.data.roiMasks;
data.whiskAct = whiskActMat;
data.oroAct = oroActMat;
data.visAct = visActMat;
data.sigTime = sigTm;
data.whiskStart = whiskStart; %%%% onset of tactile stimulatino to consider
data.oroStart = oroStart;
data.visStart = visStart; %%%% onset of visual stimualtion to consider
data.sigDur = sigDur; %%% signal duration to collect before and after stimulus onset
data.Sessions = foldNames;
%% %%%%%%%%%%%%%%%%%%% Saving images %%%%%%%%%%%%%%%%%%%%%
if contains(lower(fnFeat.sname_ex(1:end-10)),'fezf')
    MouseType = 'FezF2Ai148'; %%%%% options 'FezF2Ai148'; 'PlexinD1Ai148'; 'Tle4Ai148'; 'CBAAi93h'
elseif contains(lower(fnFeat.sname_ex(1:end-10)),'plexin')
    MouseType = 'PlexinD1Ai148';
end

if AskSaving == 1
    filename = [];
    for ii = 1:length(foldNames)
    filename = [filename foldNames{ii}];
    end
    disp(filename)
    saveFig = input('Do you want to save the Activity data AND current figure : ');
    if saveFig == 1
        saveDpath = fullfile(['G:\Hemanth_CSHL\WideField\Data_Analysis\SensoryStimulationData\NoCorrection\' MouseType],filename);
        saveFpath = fullfile(['G:\Hemanth_CSHL\WideField\Data_Figures\SensoryStimActivityPlots\NoCorrection\' MouseType],filename);
        
        save(saveDpath,'data');
        savefig(h1,saveFpath)
%         saveas(h1,[savepath(1:end-4) '.tif']);
        saveas(h1,[saveFpath(1:end-4) '.svg']);
        disp('Data and Figures are Saved !')
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Functions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [fnFeat ] = getFileNameProperties(fpath)
%%%%%%%%%%%%% getting signal file name %%%%%%%%%%%%%%
[~, sflname] = fileparts(fileparts(fpath));
spath = fpath;
listing_sig = dir([spath '\*.mat']);
sname_all = natsortfiles({listing_sig.name}');
sname_ex = sname_all{1};
us_idx = find(sname_ex == '_',1,'last');

%%% updating all properties
fnFeat.sname_all = sname_all;
fnFeat.sname_ex = sname_ex;
fnFeat.spath = spath;
fnFeat.us_idx = us_idx;
end




