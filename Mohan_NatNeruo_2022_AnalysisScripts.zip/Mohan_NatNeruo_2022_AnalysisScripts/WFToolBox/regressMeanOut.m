function [dffVcorr] = regressMeanOut(dffV)
dffVSz = size(dffV);
dffVMean(:,1) = squeeze(mean((mean(dffV,1))));
dffVMat = reshape(dffV,dffVSz(1)*dffVSz(2),dffVSz(3))';
% dffVBeta = dffVMean\dffVMat; %% beta obtained without smoothing the data
dffVBeta = dffVMean\movmean(dffVMat,10); %% Beta obtained after smooting the data by 10 moving average of 10 frames
dffVCorrMat = [dffVMat - dffVMean*dffVBeta]';
dffVcorr = reshape(dffVCorrMat,dffVSz);