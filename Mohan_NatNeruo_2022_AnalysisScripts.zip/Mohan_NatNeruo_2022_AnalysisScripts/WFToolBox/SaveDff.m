function SaveDff(dffV,fpath,fname)
[~,sfold] = fileparts(fileparts(fpath));
spath = fileparts(fileparts(fileparts(fpath)));
Vsavepath = fullfile(spath,['Data_Corrected\' sfold]);
us_loc = find(fname == '_',1,'last');
dot_loc = find(fname == '.',1,'last');
sfname = [fname(1:us_loc) 'dffV_' fname(us_loc+1:dot_loc-1)];
sfullpath = fullfile(Vsavepath,[sfname '.mat'])
if exist(Vsavepath) == 0
    mkdir(Vsavepath);
end

save(sfullpath,'dffV','-v7.3');
disp('Saving the Signal File')

end

