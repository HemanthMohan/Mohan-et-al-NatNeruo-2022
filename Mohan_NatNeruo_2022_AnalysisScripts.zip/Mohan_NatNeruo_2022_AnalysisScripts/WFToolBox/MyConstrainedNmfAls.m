function [H,W,hb,wb,HUnit,WUnit,HVar,HUnitVar,sqErr] = MyConstrainedNmfAls(A,nnmfRank,nmfIter,U,S,V)
%%%% NMF algorithm stops at either ate the inflection point of the squared
%%%% error difference or it ends at the last iteration where the inflection
%%%% point hasnt been achieved yet
A(find(A<0)) = 0;
if nargin < 4
    Wtemp = rand(size(A,1),nnmfRank);
    Wtemp(Wtemp<0) = 0;
    Htemp = rand(nnmfRank, size(A,2));
    Htemp(Htemp<0) = 0;
else
    Wtemp = U(:,1:nnmfRank) * S(1:nnmfRank, 1:nnmfRank);
    Wtemp(Wtemp<0) = 0;
    Htemp = S(1:nnmfRank, 1:nnmfRank)*V(:,1:nnmfRank)';
    Htemp(Htemp<0) = 0;
end

hb(1,:) = ones(1,size(Htemp,2)) ;
% hb(1,:) = mean(A,1);hb(hb<0) = 0;
wb = [];
sqErr = [];
for ii = 1:nmfIter
    disp(['iteration : ' num2str(ii)]);
    wb(:,1) = inv(hb*hb') * (A - Wtemp*Htemp)*hb';wb(wb<0) = 0;
    Htemp = inv(Wtemp'*Wtemp)*Wtemp'*(A - wb*hb);Htemp(Htemp<0) = 0;
    Wtemp1 = inv(Htemp*Htemp')*Htemp*(A - wb*hb)'; Wtemp1(Wtemp1<0) = 0;
    Wtemp = normalize(Wtemp1',1,'range',[0,1]);
    Atest = Wtemp*Htemp;
    sqErr(ii) = sum(sum((A - wb*hb - Atest).^2));
%     if ii == 1
%         continue
%     end
%     sqErrDiff = sqErr(ii) - sqErr(ii-1);
%     if sqErrDiff > 0
%         disp(['Inflection point of Squared Error difference has reached. Terminating Algorithm at iteration : ' num2str(ii)]);
%         break
%     end
    H = Htemp;
    W = Wtemp;
end
HUnit = H./sqrt(diag(H*H'));
WUnit = W./sqrt(diag(W'*W))';
HUnitVar = var(HUnit');
HVar = var(H');
end