function GenerateAndUpdateROILocation(imageIn,imscale,roiName,roiPath)
if nargin<2
    imscale = [-0.05 0.05];
end
Im = imageIn;
if nargin<3
    [fname fpath] = uigetfile('*.mat','Select dffV file in Folder with the corresponding roiData file');
    us_loc = find(fname == '_',2,'last');
    dot_loc = find(fname == '.',1,'last');
    roiFname = [fname(1:us_loc(1)) 'roiData.mat'];
    load(fullfile(fpath, roiFname));
else
    roiFname = roiName;
    fpath = roiPath;
    load(fullfile(fpath, roiFname));
end

load('E:\BACKUP\DESKTOP\Hemanth_CSHL\WideField\Data\cmap3.mat');
%% reset basis
origin = round(roi.Basis{1,2});
[ImRows, ImCols] = size(Im);
XAxData = [1:ImCols] - origin(1);
YAxData = [1:ImRows] - origin(2);
basis1 = roi.Basis{3,2} - origin;
basis2 = roi.Basis{2,2} - origin;
%% Obtain ROI Location
roi_locNames = roi.Nodes_Actual(:,1);
figure(2)
imagesc(imgaussfilt(Im,2), 'XData', XAxData, 'YData', YAxData,imscale);

colormap(cmap3)
axis image
axis on;
colorbar
title('Select ROI by clicking' )
hold on
plot(0,0,'c.','MarkerSize',12)
plot([0 basis1(1)], [0 basis1(2)], 'g-','LineWidth',1)
plot([0 basis2(1)], [0 basis2(2)], 'g-','LineWidth',1)
set(gcf,'Position',[2115 338 759 568]);
[xloc yloc] = ginput(1);
plotv([xloc;yloc],'c')


disp('      ROI LOCATION IDS     ')
for dd = 1:length(roi_locNames)
disp(['       ' num2str(dd) '. ' roi_locNames{dd} '(' num2str(dd) ')' ]);
end

ROI_ID = input('Enter the ID for the ROI choosen: ');
roi.Nodes_Actual{ROI_ID,2} = [xloc yloc];

%% Generate Weights
BasisVec = [basis1' basis2'];
basisChangeMat = inv(BasisVec);
LocWeights = basisChangeMat* [xloc;yloc] ;
roi.Weights{ROI_ID, 2} = LocWeights';
%% save updated roi file
savepath1 = fullfile(fpath,roiFname);

spath2 = fileparts(fileparts(fileparts(fpath)));
[~,sfold2] = fileparts(fileparts(fpath));
savepath2 = fullfile(spath2,['Data\' sfold2],roiFname);

save(savepath1,'roi');
save(savepath2,'roi');
disp(['Saved the UPDATED ' roi_locNames{ROI_ID} ' roi Data File In: '])
savepath1;
savepath2;