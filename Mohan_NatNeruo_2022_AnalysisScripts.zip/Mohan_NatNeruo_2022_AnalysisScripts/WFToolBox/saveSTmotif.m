%% saving the motifs
function saveSTmotif(W ,vidFullPath,vScl,cMap,FrameRate,slowFactor,transformedMap,reduceRatio)
% vidFullPath = vidFullPath;
% vScl = vScl;
% FrameRate = FrameRate;
% slowFactor = slowFactor;
% transformedMap = transformedMap;
% reduceRatio = reduceRatio;
% cMap = cMap;

v = VideoWriter(vidFullPath);
v.FrameRate = FrameRate*slowFactor; %%%%%%%%%%%%%%% enter the frame rate %%%%%%%%%%%%%
open(v)
for i = 1:size(W,3)
    figure(3)
    imagesc(imgaussfilt(W(:,:,i),2),vScl)
    hold on
    for p = 1:length(transformedMap)
        plot(transformedMap{p,1}(:, 2)*reduceRatio, transformedMap{p,1}(:, 1)*reduceRatio,'color','w');
    end
    hold off
    colormap(cMap)
    axis image
    colorbar
    set(gca,'XTick',[])
    set(gca,'YTick',[])
    frame = getframe(gcf);
    writeVideo(v,frame);   
end
close(v)