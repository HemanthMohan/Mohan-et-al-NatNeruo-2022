function[chewTimeOnOff,chewTime] =  getChewTimes (fpath,fnFeat,usFeat,fileIndex,stdThresh,freqRange,Fs,pcutoffC1)
fIdx = fileIndex;
fnameinC1 = [fnFeat.fname_exC1(1:usFeat.bidx_stC1) num2str(fIdx) fnFeat.fname_exC1(usFeat.bidx_endC1:end)];
filepathC1 = fullfile(fpath,fnameinC1);
fnameinC2 = [fnFeat.fname_exC2(1:usFeat.bidx_stC2) num2str(fIdx) fnFeat.fname_exC2(usFeat.bidx_endC2:end)];
filepathC2 = fullfile(fpath,fnameinC2);

pcutoffC1 = pcutoffC1;
[TrajDataC1 BodyPartsC1] =  ExtractBodyTraj(filepathC1,pcutoffC1);
[TrajDataC2 BodyPartsC2] =  ExtractBodyTraj(filepathC2,pcutoffC1);
% lowerlipY = TrajDataC1.lowerlip(:,2);
lowerlipY = TrajDataC2.lowerlip(:,2);
lowerlipYZ = (lowerlipY - nanmean(lowerlipY))./nanstd(lowerlipY);
%% peform spectrogram
inSig = sin(lowerlipYZ);
inSigMed = nanmedian(inSig);
inSigFilt = inSig; inSigFilt(isnan(inSig)) = inSigMed;
WinLen = 1; %%% in seconds
WinStep = 0.01; %%% in seconds
Win = [WinLen,WinStep];
params.Fs = Fs;
params.tapers = [2,3];
params.fpass = [0,10];
[sxx,t,f] = mtspecgramc(inSigFilt,Win,params);sxx = sxx';
fRng = freqRange;
sigPow = mean(sxx(f >= fRng(1) & f<=fRng(2),:));
pThresh = mean(sigPow) + stdThresh*std(sigPow);
%% get chew index and times
chewIdx = (sigPow>pThresh);
if chewIdx(1) == 1
    chewIdx(1) = 0;
end
chewTime = t(sigPow>pThresh);
chewDiff = diff(chewIdx);
chewTimeOnOff(1,:) = t(find(chewDiff==1)+1);
if length(find(chewDiff== -1)) == length(find(chewDiff==1))
    chewTimeOnOff(2,:) = t(find(chewDiff== -1));
elseif length(find(chewDiff== -1)) < length(find(chewDiff==1))
    chewTimeOnOff(2,:) = [t(find(chewDiff== -1)), t(end)];
end
end