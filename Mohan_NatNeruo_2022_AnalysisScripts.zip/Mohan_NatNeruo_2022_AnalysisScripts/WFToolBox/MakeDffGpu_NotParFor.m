function [videoBc_norm] = MakeDffGpu_NotParFor(vB,vV,VidSz)
vsize1 = [round(size(vB,1)/2) size(vB,2)]; 
vsize2 = [(vsize1(1)+1) size(vB,2)]; 
vB_hf1 = gpuArray(vB(1:vsize1(1),:));
TrB_nm_hf1= gather((vB_hf1 - nanmedian(vB_hf1,2))./nanmedian(vB_hf1,2));
clear vB_hf1
vB_hf2 = gpuArray(vB(vsize2(1):end,:));
TrB_nm_hf2= gather((vB_hf2 - nanmedian(vB_hf2,2))./nanmedian(vB_hf2,2));
clear vB_hf2
TrB_nm = cat(1,TrB_nm_hf1, TrB_nm_hf2);
clear TrB_nm_hf1 TrB_nm_hf2
vV_hf1 = gpuArray(vV(1:vsize1(1),:));
TrV_nm_hf1= gather((vV_hf1 - nanmedian(vV_hf1,2))./nanmedian(vV_hf1,2));
clear vV_hf1
vV_hf2 = gpuArray(vV(vsize2(1):end,:));
TrV_nm_hf2= gather((vV_hf2 - nanmedian(vV_hf2,2))./nanmedian(vV_hf2,2));
clear vV_hf2
TrV_nm = cat(1,TrV_nm_hf1, TrV_nm_hf2);
clear TrV_nm_hf1 TrV_nm_hf2


for ii=1:size(vB,1)
    TrRcoef = [ones(size(TrV_nm(ii,:),2),1) movmean(TrV_nm(ii,:),10)'] \ TrB_nm(ii,:)'; %% Signal B is regressed with moving averaged for 10 frames(340ms) signal V
    Tr_corrected = TrB_nm(ii,:)-([ones(size(TrV_nm(ii,:),2),1) (TrV_nm(ii,:))']*TrRcoef)';
    videoBc_norm(ii,:) = Tr_corrected;
end
videoBc_norm = reshape(videoBc_norm, VidSz(1),  VidSz(2),  VidSz(3));
clearvars -except videoBc_norm
end

