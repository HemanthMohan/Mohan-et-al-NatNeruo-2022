function [dffVfilt] = filter_dffVFs(dffV,bpFreq,Fs)
%% 100th order fir bandpass filter %%%
if nargin<2
    bpFreq = [0.1 5]; %%% band pass frequecny in Hz
end
dffVsize = size(dffV);
if length(dffVsize) == 3
    dffVmat = reshape(dffV,dffVsize(1)*dffVsize(2),dffVsize(3))';
    Fs = Fs;
    bpFilt = designfilt('bandpassfir','FilterOrder',100, ...
        'CutoffFrequency1',bpFreq(1),'CutoffFrequency2',bpFreq(2), ...
        'SampleRate',Fs,'window','chebwin');
    dffVfilt = reshape(filtfilt(bpFilt,double(dffVmat))',dffVsize);
elseif length(dffVsize) == 2
    dffVmat = dffV;
    Fs = Fs;
    bpFilt = designfilt('bandpassfir','FilterOrder',100, ...
        'CutoffFrequency1',bpFreq(1),'CutoffFrequency2',bpFreq(2), ...
        'SampleRate',Fs,'window','chebwin');
    dffVfilt = filtfilt(bpFilt,double(dffVmat));
end

end