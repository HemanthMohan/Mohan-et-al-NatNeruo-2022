function [BregmaLoc] = SaveBregmaLocation(FiltImg,imscale,FileId)

if isempty(gcp('nocreate')) == 1
    parpool('local',8);
end
if nargin<1
    FiltImg = 1;
    imscale = [0 0.5];
    FileId = 1;
elseif nargin<2
    imscale = [0 0.5];
    FileId = 1;
elseif nargin<2
    FileId = 1;
end

[fname fpath] = uigetfile('*.mj2');
listing_mj2 = dir([fpath '\*.mj2']);
listing_bin = dir([fpath '\*.bin']);
fname_mj2_all = natsortfiles({listing_mj2.name}');
fname_bin_all = natsortfiles({listing_bin.name}');

%%
fidx = FileId; %%% Enter the id of the video for analysis
cur_fname = fname_mj2_all{fidx};
vfile = fullfile(fpath,cur_fname);
filenum = str2num(cur_fname(find(cur_fname == '_',1,'last')+1 : find(cur_fname == '.',1,'last')-1));
[Fr_Sig, ~] = fread(fopen(fullfile(fpath,fname_bin_all{fidx})),[3,inf],'double');
Fr_b_first = find(Fr_Sig(2,:)>3,1);
Fr_v_first = find(Fr_Sig(3,:)>3,1);
if (Fr_b_first - Fr_v_first)<0
    BlueFirst = 1;
elseif (Fr_b_first - Fr_v_first)>0
    BlueFirst = 0;
end

coorfile = [cur_fname(1:find(cur_fname == '_',1,'last')) 'coor.mat'];

if exist(fullfile(fpath,coorfile))
    load(fullfile(fpath,coorfile));
    disp('Loading PreExisting Coordinate Location for cropping!!')
else
    [cpos, refimg] = MakeCoorFile(fpath,vfile,coorfile,BlueFirst);
end

%%
tic
[videoB videoV Bfi Vfi] = SplitVideo(vfile,BlueFirst,cpos); %% Bfi and Vfi are frame indices of blue and violet frames
toc
%%
meanViolet = mean(videoV,3);
imsize = size(meanViolet);
MV_normLin = normalize(meanViolet(:),'range');
MV_norm = reshape(MV_normLin,imsize(1), imsize(2));

h1 = figure(1);
sharpImg = imsharpen(MV_norm, 'Radius',3, 'Amount',2, 'Threshold', 0);
if FiltImg == 1
    imagesc(sharpImg,imscale)
else
    imagesc(MV_norm,imscale)
end
axis image
colormap gray
h1.Position = [870 219 1011 761];

%%
[xpos,ypos] = ginput(1);
BregmaLoc = [xpos,ypos];
[~,sfold] = fileparts(fileparts(fpath));
spath = fileparts(fileparts(fileparts(fpath)));
Vsavepath = fullfile(spath,['Data_Corrected\' sfold]);
us_loc = find(fname == '_',1,'last');
dot_loc = find(fname == '.',1,'last');
sfname = [fname(1:us_loc) 'BregmaLoc'];
sfullpath = fullfile(Vsavepath,[sfname '.mat']);
sfullpath2 = fullfile(fpath,[sfname '.mat']);
if isfile(sfullpath)
    disp('BREGMA LOCATION FILE EXISTS ALREADY. DELETE PREVIOUS FILE AND RUN AGAIN.')
else
    save(sfullpath,'BregmaLoc');
    save(sfullpath2,'BregmaLoc');
    disp('Saving the Bregma Location File In: ')
    sfullpath
    sfullpath2
end

