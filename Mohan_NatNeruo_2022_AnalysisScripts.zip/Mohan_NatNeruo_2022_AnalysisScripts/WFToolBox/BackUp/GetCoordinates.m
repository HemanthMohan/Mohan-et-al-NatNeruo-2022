function [Location_mm Location_pix] =  GetCoordinates(imageIn,fpath,cmap)
%   GetCoordinates : Obtains the selected coordinate
%   Inputs: imageIn - The image used to get the coordinate
%           fpath - the path to the folder containing the BregmaLoc File
%   Outputs: Loc_ML_AP_mm - Coordinates in mm. First MedioLateral distance Second Anterior posterior distance        
%            Loc_ML_AP_pix - Same coordinates in pixes values wrt the bregma location

if nargin < 3
    cmap = 'hot';
end

fnameB_struct = dir(fullfile(fpath, '*BregmaLoc.mat'));
fnameB = fnameB_struct.name;
load(fullfile(fpath, fnameB));
ScaleFac = (11/540) ; %%% in mm
%%
h1 = figure(1);
imagesc(imageIn)
colormap(cmap)
axis image

oldYTick = get(h1.CurrentAxes,'YTick'); %get the current tick points of the y axis
oldXTick = get(h1.CurrentAxes,'XTick'); %get the current tick points of the y axis

oldYTick_rescl = oldYTick - BregmaLoc(2);
oldXTick_rescl = oldXTick - BregmaLoc(1);

newYTickStr = cellstr(num2str(round(oldYTick_rescl'.*ScaleFac,2))); %create a cell array of strings
newXTickStr = cellstr(num2str(round(oldXTick_rescl'.*ScaleFac,2))); %create a cell array of strings
set(h1.CurrentAxes,'YTickLabel',newYTickStr)
set(h1.CurrentAxes,'XTickLabel',newXTickStr)

hold on
plot(BregmaLoc(1),BregmaLoc(2),'g.','MarkerSize',30)
title('Click On Location to obtain Coordinate')
[xloc yloc] = ginput(1);
plot(xloc,yloc,'mo','LineWidth',2,'MarkerSize',6)
hold off

%% Extract Distances
xdist_pix = xloc - BregmaLoc(1);
ydist_pix = yloc - BregmaLoc(2);

xdist_mm = xdist_pix.* ScaleFac;
ydist_mm = ydist_pix.* ScaleFac;

Location_mm.ML = xdist_mm;
Location_mm.AP = ydist_mm;

Location_pix.ML = xdist_pix; 
Location_pix.AP = ydist_pix;