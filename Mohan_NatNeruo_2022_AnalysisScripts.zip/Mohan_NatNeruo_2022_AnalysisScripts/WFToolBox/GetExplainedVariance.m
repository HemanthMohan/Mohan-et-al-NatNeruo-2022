
function [r2] = GetExplainedVariance(d1,d2)
n = length(d1);
r = (n*(d1'*d2) - (sum(d1)*sum(d2))) / (sqrt( (n*sum(d1.^2) - sum(d1).^2) * (n*sum(d2.^2) - sum(d2).^2)));
r2 = r.^2;