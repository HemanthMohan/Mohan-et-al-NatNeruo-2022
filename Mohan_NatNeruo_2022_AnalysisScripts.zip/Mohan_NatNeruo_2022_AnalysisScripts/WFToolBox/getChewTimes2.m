function[chewTimeOnOff,chewTime] =  getChewTimes2 (lowerlipY,prm)
 %lowerlipY = TrajDataC2.lowerlip(:,2);
lowerlipY = lowerlipY;  %TrajDataC2.lowerlip(:,2);
lowerlipYZ = (lowerlipY - nanmean(lowerlipY))./nanstd(lowerlipY);
%% peform spectrogram
inSig = sin(lowerlipYZ);
inSigMed = nanmedian(inSig);
inSigFilt = inSig; inSigFilt(isnan(inSig)) = inSigMed;
WinLen = 1; %%% in seconds
WinStep = 0.01; %%% in seconds
Win = [WinLen,WinStep];
params.Fs = prm.Fs;
params.tapers = [2,3];
params.fpass = [0,10];
[sxx,t,f] = mtspecgramc(inSigFilt,Win,params);sxx = sxx';
fRng = prm.freqRange;
sigPow = mean(sxx(f >= fRng(1) & f<=fRng(2),:));
pThresh = mean(sigPow) + prm.stdThresh*std(sigPow);
%% get chew index and times
chewIdx = (sigPow>pThresh);
if chewIdx(1) == 1
    chewIdx(1) = 0;
end
chewTime = t(sigPow>pThresh);
chewDiff = diff(chewIdx);
chewTimeOnOff(1,:) = t(find(chewDiff==1)+1);
if length(find(chewDiff== -1)) == length(find(chewDiff==1))
    chewTimeOnOff(2,:) = t(find(chewDiff== -1));
elseif length(find(chewDiff== -1)) < length(find(chewDiff==1))
    chewTimeOnOff(2,:) = [t(find(chewDiff== -1)), t(end)];
end
end