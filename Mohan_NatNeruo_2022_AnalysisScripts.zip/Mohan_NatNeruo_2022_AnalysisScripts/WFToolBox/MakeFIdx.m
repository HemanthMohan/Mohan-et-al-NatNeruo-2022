function [spidx] = MakeFIdx(flength,bsize)
% Making the file index for batch processing
%   b_sz is the size of a batch of files
%   v_sz is the size of the total number of files
b_sz = bsize;
v_sz = flength;
spl_sz = diff([0:b_sz:v_sz-1,v_sz])';
spidx = [1];
for ii = 2:length(spl_sz)
   spidx(ii,1) = spidx(end)+spl_sz(ii-1);
end
spidx(:,2) = spidx(:,1)+(spl_sz-1);

end

