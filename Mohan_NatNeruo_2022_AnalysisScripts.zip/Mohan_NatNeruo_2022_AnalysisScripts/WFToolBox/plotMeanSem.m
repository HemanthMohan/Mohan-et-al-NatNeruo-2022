function plotMeanSem(x,Y,alpha,clr,ax)
%%%%%%%%%%%%
% x = xaxis 
% Y = data matrix
% alpha = how much to multipy the sem
% clr = color of the plot
% ax = which axis to plot it
%%%%%%%%%%%%%
Ymn = mean(Y);
Ysem = std(Y,[],1)/sqrt(size(Y,1));
fill(ax,[x fliplr(x)],[(Ymn + alpha*Ysem ) fliplr((Ymn - alpha*Ysem))],clr,'FaceAlpha',0.3,'EdgeColor','none')
hold on
plot(x,  Ymn,'color',clr, 'Parent', ax)
hold off