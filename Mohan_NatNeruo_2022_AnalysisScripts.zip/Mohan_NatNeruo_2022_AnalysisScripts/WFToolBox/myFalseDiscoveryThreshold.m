% Executes the Benjamini & Hochberg (1995) procedure for controlling the 
% false discovery rate (FDR) of a family of hypothesis tests.
% adapted from " https://matthew-brett.github.io/teaching/fdr.html "

function [fdrPVal] = myFalseDiscoveryThreshold(pVals,q)
% inputs: vector  of pvalues, fdr threshold to identify p value
% ouput: fdr corrected pvalue threshold

pValFilt = pVals(:);
pValFilt(isnan(pVals(:))) = [];
pValSort = sort(pValFilt);
totTests = length(pValFilt);
numTests = [1:totTests]';
expFD = pValSort.*totTests; % expected number of false discoveries
pval_adj = expFD./numTests; % proportion of false discoveries
q_fdr = q;
% fdrTh = max(pValSort(pval_adj<q_fdr)); %% method 1
%% method 2
qTh = (q_fdr*numTests)/totTests;
below = pValSort < qTh;
max_below = max(find(below));
fdrPVal = pValSort(max_below);%% via method 2
end