function [videoB videoV Bfi Vfi] = SplitVideo(vfile,BlueFirst,cpos)
v = VideoReader(vfile);
framesize = round(v.FrameRate*v.Duration);
videoB=[];
videoV=[];
Vfi = [];
Bfi = [];
if BlueFirst == 1
    parfor fi = 1:framesize
        if rem(fi,2) == 1
            videoB_temp = imcrop(read(v,fi),cpos);
            videoB = [videoB videoB_temp];
            Bfi = [Bfi;fi]; % Frame numbers of blue frames
        else
            videoV_temp= imcrop(read(v,fi),cpos);
            videoV = [videoV videoV_temp];
            Vfi = [Vfi;fi]; % Frame numbers of violet frames
        end
    end
else
    parfor fi = 1:framesize
        if rem(fi,2) == 1
            videoV_temp= imcrop(read(v,fi),cpos);
            videoV = [videoV videoV_temp];
            Vfi = [Vfi;fi]; % Frame numbers of violet frames
        else
            videoB_temp = imcrop(read(v,fi),cpos);
            videoB = [videoB videoB_temp];
            Bfi = [Bfi;fi]; % Frame numbers of blue frames
        end
    end
end
Imsize = size(imcrop(read(v,1),cpos));
 videoB = reshape(videoB,Imsize(1),Imsize(2),framesize/2);
 videoV = reshape(videoV,Imsize(1),Imsize(2),framesize/2);
end

