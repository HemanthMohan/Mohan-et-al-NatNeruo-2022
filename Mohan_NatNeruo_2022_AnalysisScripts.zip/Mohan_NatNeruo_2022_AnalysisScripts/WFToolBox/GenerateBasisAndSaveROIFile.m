function GenerateBasisAndSaveROIFile(FiltImg,imscale)

if isempty(gcp('nocreate')) == 1
    parpool('local',8);
end

if nargin<1
    FiltImg = 1;
    imscale = [0 0.5];
elseif nargin<2
    imscale = [0 0.5];
end

[fname fpath] = uigetfile('*.mj2');
listing_mj2 = dir([fpath '\*.mj2']);
listing_bin = dir([fpath '\*.bin']);
fname_mj2_all = natsortfiles({listing_mj2.name}');
fname_bin_all = natsortfiles({listing_bin.name}');
%%
vfile = fullfile(fpath,fname);
filenum = str2num(fname(find(fname == '_',1,'last')+1 : find(fname == '.',1,'last')-1));
[Fr_Sig, ~] = fread(fopen(fullfile(fpath,fname_bin_all{filenum})),[3,inf],'double');
Fr_b_first = find(Fr_Sig(2,:)>3,1);
Fr_v_first = find(Fr_Sig(3,:)>3,1);
if (Fr_b_first - Fr_v_first)<0
    BlueFirst = 1;
elseif (Fr_b_first - Fr_v_first)>0
    BlueFirst = 0;
end

coorfile = [fname(1:find(fname == '_',1,'last')) 'coor.mat'];

if exist(fullfile(fpath,coorfile))
    load(fullfile(fpath,coorfile));
    disp('Loading PreExisting Coordinate Location for cropping!!')
else
    [cpos, refimg] = MakeCoorFile(fpath,vfile,coorfile,BlueFirst);
end

%%
tic
[videoB videoV Bfi Vfi] = SplitVideo(vfile,BlueFirst,cpos); %% Bfi and Vfi are frame indices of blue and violet frames
toc

%%
meanViolet = mean(videoV,3);
imsize = size(meanViolet);
MV_normLin = normalize(meanViolet(:),'range');
MV_norm = reshape(MV_normLin,imsize(1), imsize(2));

%% Bregma Location
h1 = figure(1);
sharpImg = imsharpen(MV_norm, 'Radius',3, 'Amount',2, 'Threshold', 0);

if FiltImg == 1
    imagesc(sharpImg,imscale)
else
    imagesc(MV_norm,imscale)
end
grid on
axis image
colormap gray
h1.Position = [450 219 1011 761];
title('Select Bregma Location')

[xpos_breg,ypos_breg] = ginput(1);
BregmaLoc = [xpos_breg,ypos_breg];
close(h1)

%% Lambda Location
h2 = figure(2);
if FiltImg == 1
    imagesc(sharpImg,imscale)
else
    imagesc(MV_norm,imscale)
end
grid on
hold on
plot(BregmaLoc(1), BregmaLoc(2),'g.','MarkerSize',12)
axis image
colormap gray
h2.Position = [450 219 1011 761];
title('Select Lambda Location')

[xpos_lamb,ypos_lamb] = ginput(1);
LambdaLoc = [xpos_lamb,ypos_lamb];
close(h2)

%%
h3 = figure(3);
if FiltImg == 1
    imagesc(sharpImg,imscale)
else
    imagesc(MV_norm,imscale)
end
grid on
hold on
plot(BregmaLoc(1), BregmaLoc(2),'g.','MarkerSize',12)
plot([BregmaLoc(1) LambdaLoc(1)] ,[BregmaLoc(2) LambdaLoc(2)],'r','MarkerSize',1)

axis image
colormap gray
h3.Position = [450 219 1011 761];
title('Select Right Edge Location')

[xpos_REdge,ypos_REdge] = ginput(1);
REdgeLoc = [xpos_REdge,ypos_REdge];
plot([BregmaLoc(1) REdgeLoc(1)] ,[BregmaLoc(2) REdgeLoc(2)],'c','MarkerSize',1)
% close(h3)

%%
roi.Basis{1,1}= 'Bregma';
roi.Basis{2,1}= 'Lambda';
roi.Basis{3,1}= 'RightEdge';
roi.Basis{1,2} = BregmaLoc ;
roi.Basis{2,2} = LambdaLoc;
roi.Basis{3,2} = REdgeLoc;
roi.Nodes_Actual = {};
roi.Nodes_Estimated = {};
roi.Weights ={};

roi.Nodes_Actual{1,1} = 'LeftFrontal';
roi.Nodes_Actual{2,1} = 'LeftParietal';
roi.Nodes_Actual{3,1} = 'LeftFrontoLateralAnterior';
roi.Nodes_Actual{4,1} = 'LeftFrontoLateralPosterior';
roi.Nodes_Actual{5,1} = 'RightFrontal';
roi.Nodes_Actual{6,1} = 'RightParietal';
roi.Nodes_Actual{7,1} = 'RightFrontoLateralAnterior';
roi.Nodes_Actual{8,1} = 'RightFrontoLateralPosterior';

roi.Nodes_Estimated = roi.Nodes_Actual;
roi.Weights = roi.Nodes_Actual;
%% Saving parameters
[~,sfold1] = fileparts(fileparts(fpath));
spath = fileparts(fileparts(fileparts(fpath)));
Vsavepath1 = fullfile(spath,['Data_Corrected\' sfold1]);
us_loc = find(fname == '_',1,'last');
dot_loc = find(fname == '.',1,'last');
sfname = [fname(1:us_loc) 'roiData'];
sfullpath1 = fullfile(Vsavepath1,[sfname '.mat']);
sfullpath2 = fullfile(fpath,[sfname '.mat']);
if sum(isfile(sfullpath1) +  isfile(sfullpath2)) == 2
    disp('ROI LOCATION FILE EXISTS ALREADY. DELETE PREVIOUS FILE AND RUN AGAIN.')
else
    save(sfullpath1,'roi');
    save(sfullpath2,'roi');
    disp('Saving the roi Data File In: ')
    sfullpath1
    sfullpath2
end



