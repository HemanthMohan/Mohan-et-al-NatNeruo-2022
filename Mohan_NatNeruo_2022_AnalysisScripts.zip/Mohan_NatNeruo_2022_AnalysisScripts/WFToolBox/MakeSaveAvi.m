function MakeSaveAvi(inVid,saveName,saveFolder,clMap,Fs,slowFac,vidScl,redRat,dmMap,nFrms)
if nargin<4
    clMap = 'jet';Fs = 30;slowFac = 0.3;vidScl = [-max(inVid(:)) , max(inVid(:))];redRat = 1;
elseif nargin<5
    Fs = 30;slowFac = 0.3;vidScl = [-max(inVid(:)) , max(inVid(:))];redRat = 1;
elseif nargin<6
    slowFac = 0.3;vidScl = [-max(inVid(:)) , max(inVid(:))];redRat = 1;
elseif nargin<7
    vidScl = [-max(inVid(:)) , max(inVid(:))];redRat = 1;
elseif nargin<8
    redRat = 1;
end


if ~exist(saveFolder , 'dir')
    mkdir(saveFolder)
end


vidSz = size(inVid);
savePath = fullfile(saveFolder,saveName);
vScl = vidScl;
v = VideoWriter(savePath);
v.FrameRate = slowFac*Fs; %%%%%%%%%%%%%%% enter the frame rate %%%%%%%%%%%%%
open(v)
if nargin == 10
    vLen = nFrms;
else
    vLen = vidSz(3);
end
h1 = figure(1);
h1.Visible = 'off';
for ii = 1:vLen
    imagesc(inVid(:,:,ii),vScl)
    hold on
    
    for p = 1:length(dmMap)
        plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','w','LineWidth',0.1);
    end
    
    hold off
    colormap(clMap);
    axis image
    colorbar
    set(gca,'XTick',[])
    set(gca,'YTick',[])
    text(3,3,num2str(ii),'color','w')
    title(saveName(1:end-4),'Interpreter','none')
    frame = getframe(gcf);
    writeVideo(v,frame);
end
disp(['Done Saving : '  saveName])
close(v)


