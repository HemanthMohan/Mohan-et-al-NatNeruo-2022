
function [ErrorFiles] =  DetectErrorDff( ids, ErrorThresh)
% ErrorThresh: the signal above which the activity of the file is
% considered noisy
% ids : the ids of the files you want to check for defect
if nargin < 2
    ErrorThresh = 0.3;
end
[fname fpath] = uigetfile('*.mat');
load('F:\Hemanth_CSHL\WideField\Data\cmap3.mat');
[~,maskFold] = fileparts(fileparts(fpath));
maskPath = fullfile(fileparts(fileparts(fileparts(fpath))),['Data'],maskFold);
roiMask = load(fullfile(maskPath,[fname(1:find(fname == '_',2,'last')) 'refMask.mat']));
%%%% get file  name structure
listing_sig = dir(fullfile(fpath,'*.mat'));
sname_all = natsortfiles({listing_sig.name}');
sname_ed = sname_all{3};
us_idx = find(sname_ed == '_',1,'last');
if nargin < 1
    ids = [1:length(sname_all)];
end
% ids = [1:10];
%% %% get error files
ErrorFiles = [];
dffV = [];
parfor fi = 1:length(ids)
    fi;
    fnameA = [fname(1:us_idx) num2str(ids(fi)) '.mat']
    vfile = fullfile(fpath,fnameA);
    try
        dffV = load(vfile);
    catch
        continue
    end
    dffVchk = reshape(dffV.dffV,size(dffV.dffV,1)*size(dffV.dffV,2),size(dffV.dffV,3)) ;
    dffVchk(find(roiMask.imMask(:) == 0),:) = 0;
    ErrorCheck = find(dffVchk > ErrorThresh | dffVchk < -1*ErrorThresh);
    if length(ErrorCheck)>= 2000
        ErrorFiles = [ErrorFiles;ids(fi)];
    end
end
