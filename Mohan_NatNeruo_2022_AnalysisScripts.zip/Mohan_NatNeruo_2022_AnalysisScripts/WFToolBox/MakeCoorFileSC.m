%%
% Built: 2018
% Creator: Hemanth Mohan, Cold Spring Harbor Laboratory
% Contact: mohan@cshl.edu
%%

function [cpos, refimg] = MakeCoorFile(fpath,vfile,coorfile,BlueFirst,askSave)
    v1 = VideoReader(vfile);
    figure
    if BlueFirst == 1
        [refimg,cpos] = imcrop(imadjust(read(v1,1),[0 0.3]));
    else
        [refimg,cpos] = imcrop(imadjust(read(v1,2),[0 0.3]));
    end
     close(gcf)
     if askSave == 1
        coorsave = input('Do you want to save the coordinate position (Yes = 1, No = 0): ');
        if coorsave == 1
            save(fullfile(fpath,coorfile), 'cpos');
            save(fullfile(fpath,[coorfile(1:end-8) 'refimg']),'refimg');
        end
     end
end

