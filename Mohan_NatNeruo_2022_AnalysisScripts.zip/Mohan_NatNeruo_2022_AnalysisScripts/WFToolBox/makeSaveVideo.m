function makeSaveVideo(dffVid,FullPath,scl,Fs,slowFac,cmap,smFac,frmSE)
% slowFac: How much do you want to slow down the video. If 1, no slow down.
% smFac: spatial smooth factor for gaussian filter
% frmSE: frame Start to frame end to make video
if nargin<3
    scl = 0.03;
    Fs = 30;
    slowFac = 1;
    cmap = 'cmap3';
    smFac = 1;
    frmSE = [1,size(dffVid,3)];
elseif nargin<4
    Fs = 30;
    slowFac = 1;
    cmap = 'cmap3';
    smFac = 1;
    frmSE = size(dffVid,3);
elseif nargin<5
    slowFac = 1;
    cmap = 'cmap3';
    smFac = 1;
    frmSE = [1,size(dffVid,3)];
elseif nargin<6
    cmap = 'cmap3';
    smFac = 1;
    frmSE = [1,size(dffVid,3)];
end

if length(scl) == 1
    vScl = [-scl scl];
else
    vScl = scl;
end
try
    cmapdata = cmap;
catch
    load(['F:\Hemanth_CSHL\WideField\Data\' cmap '.mat']);
    cmapdata = eval(cmap);
end

vidPath = fileparts(FullPath);
if ~exist(vidPath , 'dir')
    mkdir(vidPath )
end

vidFullPath = [FullPath(1:end-4) '.avi'];
h1 = figure();
v = VideoWriter(vidFullPath,'Motion JPEG AVI');
v.FrameRate = slowFac*Fs; %%%%%%%%%%%%%%% enter the frame rate %%%%%%%%%%%%%
v.Quality = 50;
open(v)
for ii = frmSE(1):frmSE(2)
    imagesc(imgaussfilt(dffVid(:,:,ii),smFac),vScl)
    text(3,3,num2str(ii),'color','w')
    colormap(cmapdata)
    axis image
    colorbar
    set(gca,'XTick',[])
    set(gca,'YTick',[])
    frame = getframe(gcf);
    writeVideo(v,frame); 
end
close(v)
end