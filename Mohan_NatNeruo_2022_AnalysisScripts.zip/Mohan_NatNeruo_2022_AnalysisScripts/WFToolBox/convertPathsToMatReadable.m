
function [pathsIn] = convertPathsToMatReadable(textFilePath)
%%
% input the path to the text file containing the list of folders
% outputs the folders in type cell
%%
fid=fopen(textFilePath);
tline = fgetl(fid);
pathsIn = [];
ii = 1;
while ischar(tline)
    pathsIn{ii,1} = tline;
    tline = fgetl(fid);
    ii = ii+1;
end
fclose(fid);