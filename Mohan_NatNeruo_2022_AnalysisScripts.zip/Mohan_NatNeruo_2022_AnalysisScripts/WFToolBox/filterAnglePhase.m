
function[dffVfilt,ampVid,phVid] = filterAnglePhase(dffV,f0,W0,Fs)
%% Filter data and obtain Angle and phase. Scripted by Partha P Mitra
%% f0: central Frequency. W0 bandwidth around f0 in Hz
dffVsize = size(dffV);
dffVMat = reshape(dffV,dffVsize(1)*dffVsize(2),dffVsize(3));
nt = dffVsize(3);
p = (nt/Fs)*W0;  % p= W T, W=1Hz, T=nt/Fs
[e v] = dpss(5400,p); 
shifter=exp(2*pi*sqrt(-1)*f0*[1:nt]'/Fs);
projfilt = e*e';
% Compute filtered time series 
filtSig = conj(shifter).*(projfilt*(dffVMat'.*shifter));
filtSig2 = shifter.*(projfilt*(dffVMat'.*conj(shifter))); 
dffVFiltMat = real(filtSig)+real(filtSig2);
dffVfilt = reshape(dffVFiltMat',dffVsize);
%% %%%%%%% compute phase and amplitude values
phSig = [];
ampSig = [];
SigTemp =projfilt*(dffVMat'.*shifter);
phSig= angle(SigTemp);
ampSig=abs(SigTemp);
phVid = reshape(phSig',dffVsize);
ampVid = reshape(ampSig',dffVsize);
