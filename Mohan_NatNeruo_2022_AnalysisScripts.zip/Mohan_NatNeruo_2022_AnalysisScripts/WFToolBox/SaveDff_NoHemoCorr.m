function SaveDff_NoHemoCorr(dffVCa,dffVHemo,fpath,fname)
[~,sfold] = fileparts(fileparts(fpath));
spath = fileparts(fileparts(fileparts(fpath)));
Vsavepath = fullfile(spath,['Data_NoHemoCorrected\' sfold]);
us_loc = find(fname == '_',1,'last');
dot_loc = find(fname == '.',1,'last');
sfnameCa = [fname(1:us_loc) 'dffVCa_' fname(us_loc+1:dot_loc-1)];
sfullpathCa = fullfile(Vsavepath,[sfnameCa '.mat'])

sfnameHemo = [fname(1:us_loc) 'dffVHemo_' fname(us_loc+1:dot_loc-1)];
sfullpathHemo = fullfile(Vsavepath,[sfnameHemo '.mat'])
if exist(Vsavepath) == 0
    mkdir(Vsavepath);
end
disp('Saving the Signal File')
save(sfullpathCa,'dffVCa','-v7.3');
save(sfullpathHemo,'dffVHemo','-v7.3');


end

