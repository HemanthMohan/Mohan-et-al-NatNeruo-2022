function [H,W,HUnit,WUnit,HVar,HUnitVar,sqErr] = MyNmfAls(A,nnmfRank,nmfIter,U,S)
%%%% NMF algorithm stops at either ate the inflection point of the squared
%%%% error difference or it ends at the last iteration where the inflection
%%%% point hasnt been achieved yet
A(find(A<0)) = 0;
if nargin < 4
    Wtemp = rand(size(A,1),nnmfRank);
else
    Wtemp = U(:,1:nnmfRank) * S(1:nnmfRank, 1:nnmfRank);
end
Htemp = [];
sqErr = [];
for ii = 1:nmfIter
    disp(['iteration : ' num2str(ii)]);
    Htemp = Wtemp\A;Htemp(Htemp<0) = 0;
    Wtemp = A/Htemp;Wtemp(Wtemp<0) = 0;
    Atest = Wtemp*Htemp;
    sqErr(ii) = sum((A(:) - Atest(:)).^2);
    if ii == 1
        continue
    end
    sqErrDiff = sqErr(ii) - sqErr(ii-1);
    if sqErrDiff > 0
        disp(['Inflection point of Squared Error difference has reached. Terminating Algorithm at iteration : ' num2str(ii)]);
        break
    end
    H = Htemp;
    W = Wtemp;
end
HUnit = H./sqrt(diag(H*H'));
WUnit = W./sqrt(diag(W'*W))';
HUnitVar = var(HUnit');
HVar = var(H');
end