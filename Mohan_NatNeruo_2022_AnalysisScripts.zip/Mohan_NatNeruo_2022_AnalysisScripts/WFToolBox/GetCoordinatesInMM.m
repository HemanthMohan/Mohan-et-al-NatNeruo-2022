function [Location_mm Location_pix] =  GetCoordinatesInMM(imageIn,fpath,fname,cmap,Imscale)
%   GetCoordinates : Obtains the selected coordinate
%   Inputs: imageIn - The image used to get the coordinate
%           fpath - the path to the folder containing the roi File
%           fname - the name of the dffV file in .mat
%   Outputs: Loc_ML_AP_mm - Coordinates in mm. First MedioLateral distance Second Anterior posterior distance        
%            Loc_ML_AP_pix - Same coordinates in pixes values wrt the bregma location

if nargin < 4
    cmap = 'hot';
    Imscale = [-3 3];
elseif nargin < 5
    Imscale = [-3 3];
end

us_loc = find(fname == '_',2,'last');
dot_loc = find(fname == '.',1,'last');
roiFname = [fname(1:us_loc(1)) 'roiData.mat'];
load(fullfile(fpath, roiFname));

BregmaLoc = roi.Basis{1,2};
ScaleFac = (11/540) ; %%% in mm
%%
h2 = figure(2);
imagesc(imageIn,Imscale)
colormap(cmap)
axis image


oldYTick = get(h2.CurrentAxes,'YTick'); %get the current tick points of the y axis
oldXTick = get(h2.CurrentAxes,'XTick'); %get the current tick points of the y axis

oldYTick_rescl = BregmaLoc(2) - oldYTick ;
oldXTick_rescl = BregmaLoc(1) - oldXTick ;

newYTickStr = cellstr(num2str(round(oldYTick_rescl'.*ScaleFac,2))); %create a cell array of strings
newXTickStr = cellstr(num2str(round(oldXTick_rescl'.*ScaleFac,2))); %create a cell array of strings
set(h2.CurrentAxes,'YTickLabel',newYTickStr)
set(h2.CurrentAxes,'XTickLabel',newXTickStr)

hold on
plot(BregmaLoc(1),BregmaLoc(2),'g.','MarkerSize',30)

title('Click On Location to obtain Coordinate')
[xloc yloc] = ginput(1);
plot(xloc,yloc,'mo','LineWidth',2,'MarkerSize',6)
hold off

%% Extract Distances
xdist_pix = BregmaLoc(1) - xloc;
ydist_pix = BregmaLoc(2) - yloc;

xdist_mm = xdist_pix.* ScaleFac;
ydist_mm = ydist_pix.* ScaleFac;

Location_mm.AP = ydist_mm;
Location_mm.ML = xdist_mm;

Location_pix.AP = ydist_pix;
Location_pix.ML = xdist_pix; 
