%clear 
%reset -f
import os as os
from allensdk.core.reference_space_cache import ReferenceSpaceCache
import matplotlib.pyplot as plt
import skimage.io as io
from sklearn.linear_model import LinearRegression,Ridge
import numpy as np
import tkinter as tk
from tkinter import filedialog
#%% Enter paths to analys
filePaths = [r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\181030_JH_HK0056_PlexinD1LSLflp_MOp_RFO_male_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\190315_JH_HK0119_PlexinD1LSLflp_MOp_RFO_female_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\190318_JH_HK0120_PlexinD1LSLflp_SSp_CFO_female_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\190502_JH_HK0141_PlexinD1LSLflp_SSp_CFO_female_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\190702_JH_HK0181_PlexinD1LSLflp_MOp_RFO_male_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\190809_JH_HK0202_PlexinD1LSLflp_MOp_RFO_male_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\190516_JH_HK0145_Fezf2LSLflp_PL_female_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\190819_JH_HK0206_Fezf2LSLflp_VISa_parietal_female_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\190826_JH_HK0209_Fezf2LSLflp_PL_male_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\191029_JH_HK0232_Fezf2LSLflp_VISa_parietal_male_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\200110_JH_HK0252_FezF2LSLflp_VISa_parietal_male_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\200113_JH_HK0253_FezF2LSLflp_VISa_parietal_male_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\200122_JH_HK0264_FezF2LSLflp_VISa_parietal_female_processed\cellfinder\registration'
             ]
#%%
def binarize(fpath):
    #%% Load data and registred allen atlas
    # root = tk.Tk()
    # root.withdraw()
    dataPath = os.path.join(fpath,'downsampled_bgCorr.tif')
    data = io.imread(dataPath).astype(np.float32)
    #% Load Registered Atlas
    atlasPath = os.path.split(dataPath)[0] + '/registered_atlas.tiff';
    boundaryPath = os.path.split(dataPath)[0] + '/boundaries.tiff';
    atlas = io.imread(atlasPath)
    boundary = io.imread(boundaryPath)
    #%% load thresh value
    threshPath = os.path.split(dataPath)[0] + '/thresh.txt';
    thresh = np.loadtxt(threshPath).astype(np.float32)
    #%% remove non brain regions
    brainMask = atlas
    brainMask[atlas>0] = 1;
    data = data*brainMask.astype(np.float32);
    #%% Z scoreting the imageing per frame
    dataNan = np.copy(data)
    dataNan[data==0] = np.nan
    dataMn = np.nanmean(dataNan)
    dataStd = np.nanstd(dataNan)
    dataZscore = (data - dataMn)/dataStd
    dataZscore[data==0] = 0
    #%% binarize projections
    dataBin = np.zeros(data.shape).astype(np.uint8)
    dataBin[dataZscore>thresh] = 1
    #%% saving the data
    savePath = dataPath[:-4] + '_binarized.tiff'
    io.imsave(savePath,dataBin)
    print('Saved : ' + savePath)
#%% pefrom batch analysis
for i in np.arange(0,len(filePaths),1):
    fpath = filePaths[i]
    binarize(fpath)