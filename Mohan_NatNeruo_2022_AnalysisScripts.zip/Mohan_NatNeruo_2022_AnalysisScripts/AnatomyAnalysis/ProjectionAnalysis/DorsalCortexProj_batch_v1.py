# %clear
# %reset -f
import os as os
from allensdk.core.reference_space_cache import ReferenceSpaceCache
import matplotlib.pyplot as plt
import skimage.io as io
from sklearn.linear_model import LinearRegression,Ridge
import numpy as np
import tkinter as tk
from tkinter import filedialog
from scipy.ndimage import zoom
from skimage import filters
from os.path import split
#%% Enter paths to analys
filePaths = [
            r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\181030_JH_HK0056_PlexinD1LSLflp_MOp_RFO_male_processed\cellfinder\registration',
              r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\190315_JH_HK0119_PlexinD1LSLflp_MOp_RFO_female_processed\cellfinder\registration',
              r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\190318_JH_HK0120_PlexinD1LSLflp_SSp_CFO_female_processed\cellfinder\registration',
              r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\190502_JH_HK0141_PlexinD1LSLflp_SSp_CFO_female_processed\cellfinder\registration',
              r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\190702_JH_HK0181_PlexinD1LSLflp_MOp_RFO_male_processed\cellfinder\registration',
              r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\190809_JH_HK0202_PlexinD1LSLflp_MOp_RFO_male_processed\cellfinder\registration',
              #  r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\190516_JH_HK0145_Fezf2LSLflp_PL_female_processed\cellfinder\registration',
              # r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\190819_JH_HK0206_Fezf2LSLflp_VISa_parietal_female_processed\cellfinder\registration',
              #  r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\190826_JH_HK0209_Fezf2LSLflp_PL_male_processed\cellfinder\registration',
              # r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\191029_JH_HK0232_Fezf2LSLflp_VISa_parietal_male_processed\cellfinder\registration',
              # r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\200110_JH_HK0252_FezF2LSLflp_VISa_parietal_male_processed\cellfinder\registration',
              # r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\200113_JH_HK0253_FezF2LSLflp_VISa_parietal_male_processed\cellfinder\registration',
              # r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\200122_JH_HK0264_FezF2LSLflp_VISa_parietal_female_processed\cellfinder\registration'
             ]

#%% Load data and registred allen atlas
def dorsalProj(fpath):
    # root = tk.Tk()
    # root.withdraw()
    dataPath = os.path.join(fpath,'downsampled_bgCorr_binarized.tiff')
    # dataPath = filedialog.askopenfilename(initialdir = os.getcwd(),filetypes=[("image files", '*binarized.tiff')])
    data = io.imread(dataPath).astype(np.float32)
    #% Load Registered Atlas
    atlasPath = os.path.split(dataPath)[0] + '/registered_atlas.tiff';
    boundaryPath = os.path.split(dataPath)[0] + '/boundaries.tiff';
    atlas = io.imread(atlasPath)
    boundary = io.imread(boundaryPath)
    #%% get reference allen map
    reference_space_key = r'G:\Hemanth_CSHL\MyScripts\PythonScripts\AnatomyScripts\annotation\ccf_2017'
    annPath = r'G:\Hemanth_CSHL\MyScripts\PythonScripts\AnatomyScripts\annotation\ccf_2017\annotation_25.nrrd'
    os.listdir(reference_space_key)
    resolution = 25
    rspc = ReferenceSpaceCache(resolution, reference_space_key, manifest='manifest.json')
    # ID 1 is the adult mouse structure graph
    tree = rspc.get_structure_tree(structure_graph_id=1)
    #%% areas to highlight
    # arHl = ['FRP','MOp','MOs','SSp-n','SSp-bfd','SSp-ll','SSp-m','SSp-ul','SSp-tr','SSp-un','SSs','AUD',
    #         'VISal','VISam','VISl','VISp','VISpl','VISpm','VISli','VISpor','ACA','RSP','PTLp']
    arHl = ['FRP','MOp','MOs','SSp-n','SSp-bfd','SSp-ll','SSp-m','SSp-ul','SSp-tr','SSp-un','SSs','AUD',
            'VISal','VISam','VISl','VISp','VISpl','VISpm','VISli','VISpor','RSP','PTLp','TEa']
    areaMask = np.zeros(atlas.shape).astype(np.uint8)
    k = 1
    for i in arHl:
        print(k)
        roi = i
        roiId = tree.get_structures_by_acronym([roi])[0]['id']
        roiDes = tree.descendant_ids([roiId])
        areaMask[np.where(np.isin(atlas,roiDes))]=k
        k = k+1
    areaMaskBin = np.zeros(atlas.shape).astype(np.uint8)
    areaMaskBin[areaMask>0] = 1 
    #%% generate edge mask
    areaMaskEdge = np.zeros(atlas.shape).astype(np.uint8)
    for i in range(0,atlas.shape[0],1):
        print(i)
        areaMaskEdge[i,:,:] = (filters.roberts(areaMask[i,:,:])>0).astype(np.uint8)
    dorsalAtlas = np.mean(areaMaskEdge,1)
    dorsalAtlasEdge = (filters.roberts(np.max(areaMaskEdge,1))>0).astype(np.uint8)
    edgeCoor = np.where(dorsalAtlasEdge==1)
    #%% dorsal Projection of tracing
    dorsalProj = np.mean(areaMaskBin*data,1)
    dorsalProj[dorsalProj==0]=np.nan
    #%% plot data
    plt.close('all')
    fig,ax = plt.subplots(1,2,figsize=(10,6))
    ax[0].imshow(dorsalProj,cmap='Blues',vmin=0,vmax = 0.05,aspect='equal')
    ax[0].plot(edgeCoor[1],edgeCoor[0],'.',   markersize=1,c='c')
    ax[1].imshow(dorsalAtlas,cmap='Blues',vmin=0,vmax=0.05)
    #%% save images
    saveFold = r'G:\Hemanth_CSHL\WideField\Data_Figures\STPdata\DorsalCortexProjection'
    fileName = split(split(split(split(dataPath)[0])[0])[0])[1] + '_dorsalProj.svg'
    filePath = os.path.join(saveFold,fileName)
    fig.savefig(filePath)
    plt.close(fig)
#%% batch processing
for j in np.arange(0,len(filePaths),1):
    fpath = filePaths[j]
    dorsalProj(fpath)
    print( 'analzed: ' + fpath)