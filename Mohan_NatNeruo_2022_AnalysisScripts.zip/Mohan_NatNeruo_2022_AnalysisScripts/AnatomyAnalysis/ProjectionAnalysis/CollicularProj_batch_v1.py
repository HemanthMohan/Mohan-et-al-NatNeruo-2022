%reset -f
import os as os
from allensdk.core.reference_space_cache import ReferenceSpaceCache
import matplotlib.pyplot as plt
import skimage.io as io
from sklearn.linear_model import LinearRegression,Ridge
import numpy as np
import tkinter as tk
from tkinter import filedialog
from scipy.ndimage import zoom
from skimage import filters
from os.path import split
%config InlineBackend.figure_format = 'retina'
#%% Enter paths to analys
filePaths = [
                r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\190516_JH_HK0145_Fezf2LSLflp_PL_female_processed\cellfinder\registration',
                r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\190826_JH_HK0209_Fezf2LSLflp_PL_male_processed\cellfinder\registration',
               r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\200113_JH_HK0253_FezF2LSLflp_VISa_parietal_male_processed\cellfinder\registration',
               r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\200122_JH_HK0264_FezF2LSLflp_VISa_parietal_female_processed\cellfinder\registration'
             ]
#%% Load data and registred allen atlas
def batchAnalysis(fpath):
    # root = tk.Tk()
    # root.withdraw()
    # dataPath = filedialog.askopenfilename(initialdir = os.getcwd(),filetypes=[("image files", '*binarized.tiff')])
    dataPath = os.path.join(fpath,'downsampled_bgCorr_binarized.tiff')
    data = io.imread(dataPath).astype(np.float32)
    def getLeftHemiMask(data,dataPath):
        hemisphere = io.imread(os.path.split(dataPath)[0] + '/registered_hemispheres.tiff');
        leftHemi = np.zeros(data.shape).astype(np.uint8)
        leftHemi[hemisphere==2] = 1
        return leftHemi
    leftHemiMask = getLeftHemiMask(data,dataPath)
    #% Load Registered Atlas
    atlasPath = os.path.split(dataPath)[0] + '/registered_atlas.tiff';
    boundaryPath = os.path.split(dataPath)[0] + '/boundaries.tiff';
    atlas = io.imread(atlasPath)
    # boundary = io.imread(boundaryPath)
    # root.destroy()
    #%% get reference allen map
    reference_space_key = r'G:\Hemanth_CSHL\MyScripts\PythonScripts\AnatomyScripts\annotation\ccf_2017'
    annPath = r'G:\Hemanth_CSHL\MyScripts\PythonScripts\AnatomyScripts\annotation\ccf_2017\annotation_25.nrrd'
    os.listdir(reference_space_key)
    resolution = 25
    rspc = ReferenceSpaceCache(resolution, reference_space_key, manifest='manifest.json')
    # ID 1 is the adult mouse structure graph
    tree = rspc.get_structure_tree(structure_graph_id=1)
    #%% make stiratum Mask
    regions = ['SCs','SCm','IC']
    def getMask(regions):
        areaMask = np.zeros(atlas.shape).astype(np.float32)
        cMask = np.zeros(atlas.shape).astype(np.uint8)
        tempMask = np.zeros(atlas.shape).astype(np.uint8)
        coronalMask = []
        coronalEdge = []
        sagittalMask = []
        sagittalEdge = []
        for i in regions:
            cMaskMeanCor = []
            cMaskEdge = []
            roi = i
            roiId = tree.get_structures_by_acronym([roi])[0]['id']
            roiDes = tree.descendant_ids([roiId])
            areaMask[np.where(np.isin(atlas,roiDes))]=1
            cMask[np.where(np.isin(atlas,roiDes))] = 1
            cMaskMeanCor = (np.mean(cMask,0)>0).astype(np.uint8)
            cMaskCorEdge = np.where((filters.roberts(cMaskMeanCor)>0).astype(np.uint8) == 1)
            cMaskMeanSag = (np.mean(cMask*leftHemiMask,2)>0).astype(np.uint8)
            cMaskSagEdge = np.where((filters.roberts(cMaskMeanSag)>0).astype(np.uint8) == 1)
            coronalMask.append(cMaskMeanCor*(len(coronalMask)+1))
            coronalEdge.append(cMaskCorEdge)
            sagittalMask.append(cMaskMeanSag)
            sagittalEdge.append(cMaskSagEdge)
            cMask = np.copy(tempMask)
        return areaMask,coronalMask,coronalEdge,sagittalMask,sagittalEdge
    
    areaMask,coronalMask,coronalEdge,sagittalMask,sagittalEdge = getMask(regions)
    
    #%% Get striatal Projections
    areaMaskNan = np.copy(areaMask)
    areaMaskNan[areaMask==0] = np.nan
    areaProj = data*areaMaskNan
    areaCorMean = np.nanmean(areaProj,0)
    areaCorMean[areaCorMean==0] = np.nan
    areaSagMean = np.nanmean(areaProj*leftHemiMask,2)
    areaSagMean[areaSagMean==0] = np.nan
    #%%
    plt.close('all')
    fig,ax = plt.subplots(2,1,figsize=(7,9))
    # plt.imshow(sum(coronalMask),cmap= 'Greys',vmax = 1,alpha=0.1)
    [ax[0].plot(coronalEdge[i][1],coronalEdge[i][0],'.',markersize=0.3)  for i in np.arange(0,len(coronalEdge),1)]
    ax[0].imshow(areaCorMean,vmax = np.nanmedian(areaCorMean),cmap='Greens')
    ax[0].set_title('Coronal View')
    ax[0].legend(regions)
    [ax[1].plot(sagittalEdge[i][0],sagittalEdge[i][1],'.',markersize=0.3)  for i in np.arange(0,len(coronalEdge),1)]
    ax[1].imshow(areaSagMean.T,vmax = np.nanmedian(areaSagMean),cmap='Greens')
    ax[1].set_title('Sagittal View')
    ax[1].legend(regions)
    #%% save images
    saveFold = r'G:\Hemanth_CSHL\WideField\Data_Figures\STPdata\CollicularProjection'
    fileName = split(split(split(split(dataPath)[0])[0])[0])[1] + '_collicularProj.svg'
    filePath = os.path.join(saveFold,fileName)
    fig.savefig(filePath,dpi=300)
    plt.close(fig)
#%% batch processing
for j in np.arange(0,len(filePaths),1):
    fpath = filePaths[j]
    batchAnalysis(fpath)
    print( 'analzed: ' + fpath)