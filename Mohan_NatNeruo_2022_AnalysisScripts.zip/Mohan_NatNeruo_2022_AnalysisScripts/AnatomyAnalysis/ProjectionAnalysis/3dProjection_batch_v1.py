# %clear
# %reset -f
import os as os
from allensdk.core.reference_space_cache import ReferenceSpaceCache
# import matplotlib.pyplot as plt
import skimage.io as io
# from sklearn.linear_model import LinearRegression,Ridge
import numpy as np
# import tkinter as tk
# from tkinter import filedialog
from scipy.ndimage import zoom
import plotly.graph_objects as go
from plotly.offline import plot
import plotly.io as pio
pio.renderers.default = 'browser'
#%% Enter paths to analys
filePaths = [
            # r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\181030_JH_HK0056_PlexinD1LSLflp_MOp_RFO_male_processed\cellfinder\registration',
            #  r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\190315_JH_HK0119_PlexinD1LSLflp_MOp_RFO_female_processed\cellfinder\registration',
            #  r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\190318_JH_HK0120_PlexinD1LSLflp_SSp_CFO_female_processed\cellfinder\registration',
            #  r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\190502_JH_HK0141_PlexinD1LSLflp_SSp_CFO_female_processed\cellfinder\registration',
            #  r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\190702_JH_HK0181_PlexinD1LSLflp_MOp_RFO_male_processed\cellfinder\registration',
            #  r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\190809_JH_HK0202_PlexinD1LSLflp_MOp_RFO_male_processed\cellfinder\registration',
              # r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\190516_JH_HK0145_Fezf2LSLflp_PL_female_processed\cellfinder\registration',
              r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\190819_JH_HK0206_Fezf2LSLflp_VISa_parietal_female_processed\cellfinder\registration',
              # r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\190826_JH_HK0209_Fezf2LSLflp_PL_male_processed\cellfinder\registration',
              r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\191029_JH_HK0232_Fezf2LSLflp_VISa_parietal_male_processed\cellfinder\registration',
              r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\200110_JH_HK0252_FezF2LSLflp_VISa_parietal_male_processed\cellfinder\registration',
              r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\200113_JH_HK0253_FezF2LSLflp_VISa_parietal_male_processed\cellfinder\registration',
              r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\200122_JH_HK0264_FezF2LSLflp_VISa_parietal_female_processed\cellfinder\registration'
             ]


#%%

def projection(fpath):
    dataPath = os.path.join(fpath,'downsampled_bgCorr_binarized.tiff')
    data = io.imread(dataPath).astype(np.float32)
    #% Load Registered Atlas
    atlasPath = os.path.split(dataPath)[0] + '/registered_atlas.tiff';
    boundaryPath = os.path.split(dataPath)[0] + '/boundaries.tiff';
    atlas = io.imread(atlasPath)
    boundary = io.imread(boundaryPath)
    #%% get allen map
    reference_space_key = r'G:\Hemanth_CSHL\MyScripts\PythonScripts\AnatomyScripts\annotation\ccf_2017'
    annPath = r'G:\Hemanth_CSHL\MyScripts\PythonScripts\AnatomyScripts\annotation\ccf_2017\annotation_25.nrrd'
    os.listdir(reference_space_key)
    resolution = 25
    rspc = ReferenceSpaceCache(resolution, reference_space_key, manifest='manifest.json')
    # ID 1 is the adult mouse structure graph
    tree = rspc.get_structure_tree(structure_graph_id=1)
    #%% areas to highlight
    isoCortexId = [315]
    # arHl = ['MOs', 'MOp','SSp-m','CP']
    # arHl = ['MOs','TH','CP','SCm','P','MY']
    arHl = ['PTLp','TH','CP','SCm','P','MY']
    areaMask = np.zeros(atlas.shape).astype(np.uint8)
    roiId = isoCortexId.copy()
    roiDes = tree.descendant_ids(roiId)
    areaMask[np.where(np.isin(atlas,roiDes))]=1
    k = 2
    for i in arHl:
        roi = i
        roiId = tree.get_structures_by_acronym([roi])[0]['id']
        roiDes = tree.descendant_ids([roiId])
        areaMask[np.where(np.isin(atlas,roiDes))]=k
        k = k+1
    #%% downsampled data
    scFac = 0.2
    areaMaskDs = zoom(areaMask,(scFac,scFac,scFac)).astype(np.uint8);
    dataDs = zoom(data,(scFac,scFac,scFac)).astype(np.uint8)
    #%%
    x = np.arange(0,dataDs.shape[1],1)
    y = np.arange(0,dataDs.shape[0],1)
    z = np.arange(0,dataDs.shape[2],1)
    xx,yy,zz = np.meshgrid(x,y,z)
    #%%
    fig = go.Figure(data=[go.Volume(
        x=xx.flatten(),
        y=yy.flatten(),
        z=zz.flatten(),
        value=dataDs.flatten(),
        isomin=0.5,
        isomax=1,
        opacity=1, # needs to be small to see through all surfaces
        surface_count = 4, # needs to be a large number for good volume rendering
        colorscale='Greens' # colorscale='Greens' colorscale='Blues' 
        ),
        go.Volume(
        x=xx.flatten(),
        y=yy.flatten(),
        z=zz.flatten(),
        value=areaMaskDs.flatten(),
        isomin=0.5,
        isomax=len(arHl),
        opacity=0.03, # needs to be small to see through all surfaces
        surface_count=len(arHl), # needs to be a large number for good volume rendering
        colorscale='Plasma',
        caps= dict(x_show=False, y_show=False, z_show=False), # no caps
        )
        ]
        )
    fig.update_layout(scene_xaxis_showticklabels=False,
                      scene_yaxis_showticklabels=False,
                      scene_zaxis_showticklabels=False,
                      )
    fig.update_layout(scene = dict(xaxis = dict(showbackground=False),
                                   yaxis = dict(showbackground=False),
                                   zaxis = dict(showbackground=False)
        ))
    fig.write_html(os.path.split(dataPath)[0] + '/3dRender.html')

#%% pefrom batch analysis
for j in np.arange(0,len(filePaths),1):
    fpath = filePaths[j]
    projection(fpath)
    print( 'analzed: ' + fpath)