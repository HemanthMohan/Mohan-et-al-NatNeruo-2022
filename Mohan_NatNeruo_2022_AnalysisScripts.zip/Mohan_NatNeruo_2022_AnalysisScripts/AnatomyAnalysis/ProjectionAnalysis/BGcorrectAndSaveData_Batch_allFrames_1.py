import os as os
from allensdk.core.reference_space_cache import ReferenceSpaceCache
import matplotlib.pyplot as plt
import skimage.io as io
from sklearn.linear_model import LinearRegression,Ridge
import numpy as np
import tkinter as tk
from tkinter import filedialog
#%% Enter paths to analys
filePaths = [r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\181030_JH_HK0056_PlexinD1LSLflp_MOp_RFO_male_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\190315_JH_HK0119_PlexinD1LSLflp_MOp_RFO_female_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\190318_JH_HK0120_PlexinD1LSLflp_SSp_CFO_female_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\190502_JH_HK0141_PlexinD1LSLflp_SSp_CFO_female_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\190702_JH_HK0181_PlexinD1LSLflp_MOp_RFO_male_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\190809_JH_HK0202_PlexinD1LSLflp_MOp_RFO_male_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\190516_JH_HK0145_Fezf2LSLflp_PL_female_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\190819_JH_HK0206_Fezf2LSLflp_VISa_parietal_female_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\190826_JH_HK0209_Fezf2LSLflp_PL_male_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\191029_JH_HK0232_Fezf2LSLflp_VISa_parietal_male_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\200110_JH_HK0252_FezF2LSLflp_VISa_parietal_male_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\200113_JH_HK0253_FezF2LSLflp_VISa_parietal_male_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\200122_JH_HK0264_FezF2LSLflp_VISa_parietal_female_processed\cellfinder\registration'
             ]

#%% peform correction for all files
def bgCorr(fpath):
    #%% Load data and registred allen atlas
    # root = tk.Tk()
    # root.withdraw()
    dataPathCh1 = os.path.join(fpath,'downsampled.tiff')
    # dataPathCh1 = filedialog.askopenfilename(initialdir = os.getcwd(),filetypes=[("image files", 'downsampled.tiff')])
    dataPathCh2 = dataPathCh1[:-5] + '_channel_0.tiff'
    dataCh1 = io.imread(dataPathCh1).astype(np.float32)
    dataCh2 = io.imread(dataPathCh2).astype(np.float32)
    #% Load Registered Atlas
    atlasPath = os.path.split(dataPathCh1)[0] + '/registered_atlas.tiff';
    atlas = io.imread(atlasPath)
    #%% get allen map
    reference_space_key = r'G:\Hemanth_CSHL\MyScripts\PythonScripts\AnatomyScripts\annotation\ccf_2017'
    annPath = r'G:\Hemanth_CSHL\MyScripts\PythonScripts\AnatomyScripts\annotation\ccf_2017\annotation_25.nrrd'
    os.listdir(reference_space_key)
    resolution = 25
    rspc = ReferenceSpaceCache(resolution, reference_space_key, manifest='manifest.json')
    # ID 1 is the adult mouse structure graph
    tree = rspc.get_structure_tree(structure_graph_id=1)
    #%% make brain mask
    brainMask = np.copy(atlas)
    brainMask[atlas>0] = 1
    #%%%% add cerebellum mask
    allBrainNodes = tree.nodes()
    cerebellumId = 512
    cblAreas = tree.descendants([cerebellumId])
    cblAreasId = tree.descendant_ids([cerebellumId])[0]
    brainMask[np.where(np.isin(atlas,cblAreasId))]=0
    #%% adding brain mask
    dataCh1 = (dataCh1*brainMask).astype(np.float32)
    dataCh2 = (dataCh2*brainMask).astype(np.float32)
    #%% data correction
    lr = LinearRegression()
    dataCorr = np.empty(dataCh1.shape).astype(np.float32)
    intercept = []
    beta = []
    for i in range(0,dataCh1.shape[0],1):
        X = np.matrix.flatten(dataCh1[i,::]).reshape(-1,1).astype(np.float32)
        y = np.matrix.flatten(dataCh2[i,::]).reshape(-1,1).astype(np.float32)
        lr.fit(X,y)
        intercept.append(lr.intercept_)
        beta.append(lr.coef_)
    intercept_mean = np.array(intercept).reshape(-1).mean()
    beta_mean = np.array(beta).reshape(-1).mean()
    dataCorr = dataCh2 - (intercept_mean + beta_mean*dataCh1)
    #%% remove non brian areas from corrected data
    dataCorr = dataCorr*brainMask.astype(np.float32);
    #%% saving the data
    savePath = dataPathCh1[:-5] + '_bgCorr.tif'
    io.imsave(savePath,dataCorr)
    print('Saved : ' + savePath)
#%% pefrom batch analysis
for i in np.arange(0,len(filePaths),1):
    fpath = filePaths[i]
    bgCorr(fpath)
