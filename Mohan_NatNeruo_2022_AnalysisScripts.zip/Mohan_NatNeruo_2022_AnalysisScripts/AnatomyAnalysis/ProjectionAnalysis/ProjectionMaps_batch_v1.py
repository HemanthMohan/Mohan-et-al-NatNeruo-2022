%reset -f
import os as os
from allensdk.core.reference_space_cache import ReferenceSpaceCache
import matplotlib.pyplot as plt
import skimage.io as io
import numpy as np
import tkinter as tk
from tkinter import filedialog
from os.path import split
from pandas import read_csv
from joblib import Parallel, delayed
import time
%config InlineBackend.figure_format = 'retina'
#%% 10 um allen map volume
# At 10 μm voxel resolution, the average template contains ∼506 million voxels. 
# Its dimensions are 1,320 (anterior to posterior, 13.2 mm) × 1,140 (left to right, 11.4 mm) × 800 voxels (dorsal to ventral, 8.0 mm).
#%% Enter paths to analys
filePaths = [
            # r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\181030_JH_HK0056_PlexinD1LSLflp_MOp_RFO_male_processed\cellfinder\registration',
              # r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\190315_JH_HK0119_PlexinD1LSLflp_MOp_RFO_female_processed\cellfinder\registration',
              # r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\190318_JH_HK0120_PlexinD1LSLflp_SSp_CFO_female_processed\cellfinder\registration',
              # r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\190502_JH_HK0141_PlexinD1LSLflp_SSp_CFO_female_processed\cellfinder\registration',
              r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\190708_JH_HK0182_PlexinD1LSLflp_SSp_CFO_male_processed\cellfinder\registration',
              # r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\190702_JH_HK0181_PlexinD1LSLflp_MOp_RFO_male_processed\cellfinder\registration',
              # r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\PlexinD1\190809_JH_HK0202_PlexinD1LSLflp_MOp_RFO_male_processed\cellfinder\registration',
              #   r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\190516_JH_HK0145_Fezf2LSLflp_PL_female_processed\cellfinder\registration',
              #  r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\190819_JH_HK0206_Fezf2LSLflp_VISa_parietal_female_processed\cellfinder\registration',
              #   r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\190826_JH_HK0209_Fezf2LSLflp_PL_male_processed\cellfinder\registration',
              #  r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\191029_JH_HK0232_Fezf2LSLflp_VISa_parietal_male_processed\cellfinder\registration',
              #  r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\200110_JH_HK0252_FezF2LSLflp_VISa_parietal_male_processed\cellfinder\registration',
              #  r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\200113_JH_HK0253_FezF2LSLflp_VISa_parietal_male_processed\cellfinder\registration',
              #  r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\FezF2\200122_JH_HK0264_FezF2LSLflp_VISa_parietal_female_processed\cellfinder\registration'
             ]
#%% Load data and registred allen atlas
def projMaps(fpath):
    # root = tk.Tk()
    # root.withdraw()
    # dataPath = filedialog.askopenfilename(initialdir = os.getcwd(),filetypes=[("image files", '*binarized.tiff')])
    dataPath = os.path.join(fpath,'downsampled_bgCorr_binarized.tiff')
    data = io.imread(dataPath).astype(np.uint8)
    def getLeftHemiMask(data,dataPath):
        hemisphere = io.imread(os.path.split(dataPath)[0] + '/registered_hemispheres.tiff');
        leftHemi = np.zeros(data.shape).astype(np.uint8)
        leftHemi[hemisphere==2] = 1
        return leftHemi
    leftHemiMask = getLeftHemiMask(data,dataPath)
    #% Load Registered Atlas
    
    def getAtlas(dataPath):
        atlasPath = os.path.split(dataPath)[0] + '/registered_atlas.tiff';
        atlas = io.imread(atlasPath)
        reference_space_key = r'G:\Hemanth_CSHL\MyScripts\PythonScripts\AnatomyScripts\annotation\ccf_2017'
        annPath = r'G:\Hemanth_CSHL\MyScripts\PythonScripts\AnatomyScripts\annotation\ccf_2017\annotation_25.nrrd'
        os.listdir(reference_space_key)
        resolution = 25
        rspc = ReferenceSpaceCache(resolution, reference_space_key, manifest='manifest.json')
        tree = rspc.get_structure_tree(structure_graph_id=1)# ID 1 is the adult mouse structure graph
        return atlas,tree
    atlas,tree = getAtlas(dataPath)
    
    #%% extact only left hemisphere data and atlas
    data= data*leftHemiMask ## get only left hemisphere data
    atlas = atlas*leftHemiMask ## get only left hemisphere allen mask
    del leftHemiMask
    #%% load and export rois to analyze
    roiPath = r'G:\Hemanth_CSHL\WideField\Data_Anatomy\ProjectionData\ProjectionAreas.csv' 
    roiNamesFull = read_csv(roiPath)
    roiAcr = list(roiNamesFull['ROIS'])
    roiNames =  list(roiNamesFull['ROI NAMES'])
    voxelVolmm = 0.01*0.01*0.01
    #%% compute projection intensity
    def getProjIntensity(roi):
        roiMask = np.zeros(atlas.shape).astype(np.uint8)
        roiId = tree.get_structures_by_acronym([roi])[0]['id']
        roiDes = tree.descendant_ids([roiId])
        roiMask[np.where(np.isin(atlas,roiDes))] = 1
        roiProj = data*roiMask
        projCount = np.sum(roiProj)
        roiVol = np.sum(roiMask)*voxelVolmm
        projIntensity = projCount/roiVol
        return projIntensity,projCount,roiVol
    
    tstartParallel = time.time()
    paraOut = Parallel(n_jobs=5)(delayed(getProjIntensity)(roi=i) for i in roiAcr)
    tendParallel = time.time()
    print(tendParallel - tstartParallel)
    projIntensity = [item[0] for item in paraOut]
    projCount = [item[1] for item in paraOut]
    roiVol = [item[2] for item in paraOut]
    #%% normalize projection values
    projIntNorm = np.array(projIntensity).reshape(-1,1) / np.max(projIntensity)
    projCountNorm = np.array(projCount).reshape(-1,1) / np.max(projCount)
    #%% plot projection intensityies
    projIntMat = np.repeat(projIntNorm,10,axis=1)
    projCntMat = np.repeat(projCountNorm,10,axis=1)
    fig,ax = plt.subplots(1,2,figsize=(6,7))
    im = ax[0].imshow(projIntMat,cmap='gist_heat_r')
    ax[0].set_yticks(ticks=np.arange(0,len(roiAcr),1))
    ax[0].set_yticklabels(roiAcr)
    ax[0].set_xticks(ticks=[])
    ax[0].set_title('norm proj/mm3')
    fig.colorbar(im,ax=ax[0])
    
    im = ax[1].imshow(projCntMat,cmap='gist_heat_r')
    ax[1].set_yticks(ticks=np.arange(0,len(roiAcr),1))
    ax[1].set_yticklabels(roiAcr)
    ax[1].set_xticks(ticks=[])
    ax[1].set_title('norm proj count')
    fig.colorbar(im,ax=ax[1])
    # plt.xticks(ticks=np.arange(0,len(roiAcr),1));plt.yticks(ticks=[])
    #%% save images
    saveFold = r'G:\Hemanth_CSHL\WideField\Data_Figures\STPdata\ProjectionIntensity'
    fileName = split(split(split(split(dataPath)[0])[0])[0])[1] + '_ProjInt.svg'
    filePath = os.path.join(saveFold,fileName)
    fig.savefig(filePath,dpi=300)
    plt.close(fig)
#%% batch processing
for j in np.arange(0,len(filePaths),1):
    fpath = filePaths[j]
    projMaps(fpath)
    print( 'analzed: ' + fpath)
