clear all; close all; clc;
%% Load Spontaneous Data
plexSpontData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\SpontaneousData\AllenFOVRegistered\ActiveQuiescentVarianceMapData\PlexinD1Ai148_202012142020121520210126_AQvarianceData.mat');
plexSpontData = plexSpontData.data;
fezSpontData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\SpontaneousData\AllenFOVRegistered\ActiveQuiescentVarianceMapData\FezF2Ai148_202012142020121520210126_AQvarianceData.mat');
fezSpontData = fezSpontData.data;
%% Load Feeding Activity Data
plexFeedData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\MeanActivityAroundPIM\PlexinD1Ai148_MeanActivityAroudPIM_Full.mat');
plexFeedData = plexFeedData.data;
fezFeedData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\BehaviorActivityData\AllenFOVRegistered\MeanActivityAroundPIM\FezF2Ai148_MeanActivityAroudPIM_Full.mat');
fezFeedData = fezFeedData.data;
%% Load Ketamine FreqSpecific Amplitude Data 
plexKetData_06_09Hz = load('G:\Hemanth_CSHL\WideField\Data_Analysis\KetamineData\AllenFOVRegistered\FrequencySpecificAmplitudeData\PlexinD1Ai148_202012092020121020201211_FreqBand-0.6-0.9Hz_freqAmpData.mat');
plexKetData_06_09Hz = plexKetData_06_09Hz.data;

plexKetData_1_14Hz = load('G:\Hemanth_CSHL\WideField\Data_Analysis\KetamineData\AllenFOVRegistered\FrequencySpecificAmplitudeData\PlexinD1Ai148_202012092020121020201211_FreqBand-1-1.4Hz_freqAmpData.mat');
plexKetData_1_14Hz = plexKetData_1_14Hz.data;

fezKetData_06_09Hz = load('G:\Hemanth_CSHL\WideField\Data_Analysis\KetamineData\AllenFOVRegistered\FrequencySpecificAmplitudeData\FezF2Ai148_202012092020121020201211_FreqBand-0.6-0.9Hz_freqAmpData.mat');
fezKetData_06_09Hz = fezKetData_06_09Hz.data;

fezKetData_1_14Hz = load('G:\Hemanth_CSHL\WideField\Data_Analysis\KetamineData\AllenFOVRegistered\FrequencySpecificAmplitudeData\FezF2Ai148_202012092020121020201211_FreqBand-1-1.4Hz_freqAmpData.mat');
fezKetData_1_14Hz = fezKetData_1_14Hz.data;
%% Load GCamp Distribution Data
distData = load('G:\Hemanth_CSHL\WideField\Data_Analysis\DorsalGcampDistribution\dorsalGcampDist.mat');
distData = distData.data;
%% Sample dorsal map and mask path
dmName = ['20210126_PlexinD1Ai148_c8m2_spont_dorsalMap.mat'];
fpath = 'G:\Hemanth_CSHL\WideField\Data_Corrected\20210126_PlexinD1Ai148_c8m2_spont';
load(fullfile(fpath,dmName));
dmMap = dorsalMaps.edgeOutlineSplit;
redRat = plexSpontData.redRat;

%% %%%%%%% Variance maps
fezVarMaps_act = fezSpontData.varMap_act; fezVarMaps_act(find(fezVarMaps_act==0)) = nan;
fezVarMaps_pas = fezSpontData.varMap_pas; fezVarMaps_pas(find(fezVarMaps_pas==0)) = nan;
plexVarMaps_act = plexSpontData.varMap_act; plexVarMaps_act(find(plexVarMaps_act==0)) = nan;
plexVarMaps_pas = plexSpontData.varMap_pas; plexVarMaps_pas(find(plexVarMaps_pas==0)) = nan;

fezVarMaps_actMean = nanmean(fezVarMaps_act,3);
fezVarMaps_pasMean = nanmean(fezVarMaps_pas,3);
plexVarMaps_actMean = nanmean(plexVarMaps_act,3);
plexVarMaps_pasMean = nanmean(plexVarMaps_pas,3);
%% %%%%%% mean Feeding ACtiviyt maps
plexFeedMap = imresize(squeeze(mean(plexFeedData.meanFlowAll,3)),redRat);
plexFeedMap(find(plexFeedMap==0)) = NaN;
plexFeedMapMean = nanmean(plexFeedMap,3);

fezFeedMap = imresize(squeeze(mean(fezFeedData.meanFlowAll,3)),redRat);
fezFeedMap(find(fezFeedMap==0)) = NaN;
fezFeedMapMean = nanmean(fezFeedMap,3);

%% ketamime power amplitude maps
ketSz = size(plexKetData_06_09Hz.freqBandPowAmpNormMap);
ketN = length(plexKetData_06_09Hz.sessions);
plexKetMap_0609 = imresize(reshape(plexKetData_06_09Hz.freqBandPowAmp ,ketSz(1),ketSz(2),[]),size(plexVarMaps_actMean));
plexKetMap_0609(plexKetMap_0609==0) = NaN;
plexKetMap_114 = imresize(reshape(plexKetData_1_14Hz.freqBandPowAmp ,ketSz(1),ketSz(2),[]),size(plexVarMaps_actMean));
plexKetMap_114(plexKetMap_114==0) = NaN;

fezKetMap_0609 = imresize(reshape(fezKetData_06_09Hz.freqBandPowAmp ,ketSz(1),ketSz(2),[]),size(plexVarMaps_actMean));
fezKetMap_0609(fezKetMap_0609==0) = NaN;
fezKetMap_114 = imresize(reshape(fezKetData_1_14Hz.freqBandPowAmp ,ketSz(1),ketSz(2),[]),size(plexVarMaps_actMean));
fezKetMap_114(fezKetMap_114==0) = NaN;

plexKetMap_0609mn = nanmean(plexKetMap_0609,3);
plexKetMap_114mn = nanmean(plexKetMap_114,3);
fezKetMap_0609mn = nanmean(fezKetMap_0609,3);
fezKetMap_114mn = nanmean(fezKetMap_114,3);
%% GCaMP distribtuion
for ii = 1:size(distData.fezDistributionAll,1)
fezDist(:,:,ii) = imresize(squeeze(distData.fezDistributionAll(ii,:,:)),size(fezVarMaps_actMean));
plexDist(:,:,ii) = imresize(squeeze(distData.plexDistributionAll(ii,:,:)),size(plexVarMaps_actMean));
end

fezDistMean = squeeze(nanmean(distData.fezDistributionAll,1));
plexDistMean = squeeze(nanmean(distData.plexDistributionAll,1));

fezDistMeanRs = imresize(fezDistMean,size(fezVarMaps_actMean));
plexDistMeanRs = imresize(plexDistMean,size(plexVarMaps_actMean));
%% %%%%% plot  maps
close all
h(1) = figure;h(1).Position = [120         387        2128         584];
subplot(2,6,1)
imagesc(fezDistMeanRs,[-2,2]); axis image; colormap parula; colorbar
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','w');
end
hold off
title('FezF2 GCaMP Distribution')
axis(gca,1.5*[12 280 44 268])

subplot(2,6,2); 
imagesc(fezVarMaps_actMean,[0,3.5e-4]); axis image; colormap parula;colorbar
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','w');
end
hold off
title('FezF2 Active Variance map')
axis(gca,1.5*[12 280 44 268])

subplot(2,6,3); 
imagesc(fezVarMaps_pasMean,[0,1e-4]); axis image; colormap parula;colorbar
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','w');
end
hold off
title('FezF2 Passive Variance map')
axis(gca,1.5*[12 280 44 268])

subplot(2,6,4); 
fezFeedMapMean(isnan(fezFeedMapMean)) = 0;
imagesc(fezFeedMapMean,[-0.017,0.017]); axis image; colormap parula;colorbar
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','w');
end
hold off
title('FezF2 Feeding Activity map')
axis(gca,1.5*[12 280 44 268])

subplot(2,6,5); 
imagesc(fezKetMap_0609mn,[0,6e-4]); axis image; colormap parula;colorbar
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','w');
end
hold off
title('FezF2 Ketamine Freq Power Map 0.6-0.9 Hz')
axis(gca,1.5*[12 280 44 268])

subplot(2,6,6); 
imagesc(fezKetMap_114mn,[0,6e-4]); axis image; colormap parula;colorbar
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','w');
end
hold off
title('FezF2 Ketamine Freq Power Map 1-1.4 Hz')
axis(gca,1.5*[12 280 44 268])

subplot(2,6,7)
imagesc(plexDistMeanRs,[-2,2]); axis image; colormap parula; colorbar
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','w');
end
hold off
title('PlexinD1 GCaMP Distribution')
axis(gca,1.5*[12 280 44 268])

subplot(2,6,8); 
imagesc(plexVarMaps_actMean,[0,3e-4]); axis image; colormap parula;colorbar
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','w');
end
hold off
title('PlexinD1 Active Variance map')
axis(gca,1.5*[12 280 44 268])

subplot(2,6,9); 
imagesc(plexVarMaps_pasMean,[0,2e-4]); axis image; colormap parula;colorbar
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','w');
end
hold off
title('PlexinD1 Passive Variance map')
axis(gca,1.5*[12 280 44 268])

subplot(2,6,10); 
plexFeedMapMean(isnan(plexFeedMapMean)) = 0;
imagesc(plexFeedMapMean,[-0.017,0.017]); axis image; colormap parula;colorbar

hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','w');
end
hold off
title('PlexinD1 Feeding Activity map')
axis(gca,1.5*[12 280 44 268])

subplot(2,6,11); 
imagesc(plexKetMap_0609mn,[0,6e-4]); axis image; colormap parula;colorbar
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','w');
end
hold off
title('PlexD1 Ketamine Freq Power Map 0.6-0.9 Hz')
axis(gca,1.5*[12 280 44 268])

subplot(2,6,12); 
imagesc(plexKetMap_114mn,[0,6e-4]); axis image; colormap parula;colorbar
hold on
for p = 1:length(dmMap)
    plot( dmMap{p}(:, 2)*redRat,dmMap{p}(:, 1)*redRat,'color','w');
end
hold off
title('PlexD1 Ketamine Freq Power Map 1-1.4 Hz')
axis(gca,1.5*[12 280 44 268])
%% measure correlation between GCaMP distribution and Variance maps
% 
% for ii = 1:size(fezVarMaps_act,3)
%    fezDistFezVarCorr_act(ii,1) =  corr(reshape(fezDistMeanRs,[],1), reshape(fezVarMaps_act(:,:,ii),[],1),'rows','complete');
%    fezDistFezVarCorr_pas(ii,1) =  corr(reshape(fezDistMeanRs,[],1), reshape(fezVarMaps_pas(:,:,ii),[],1),'rows','complete');
%    
%    plexDistPlexVarCorr_act(ii,1) =  corr(reshape(plexDistMeanRs,[],1), reshape(plexVarMaps_act(:,:,ii),[],1),'rows','complete');
%    plexDistPlexVarCorr_pas(ii,1) =  corr(reshape(plexDistMeanRs,[],1), reshape(plexVarMaps_pas(:,:,ii),[],1),'rows','complete');
%    
% end
for jj = 1:size(fezDist,3)
    
    for ii = 1:size(fezVarMaps_act,3)
        fezDistFezVarCorr_act(ii,jj) =  corr(reshape(squeeze(fezDist(:,:,jj)),[],1), reshape(fezVarMaps_act(:,:,ii),[],1),'rows','complete');
        fezDistFezVarCorr_pas(ii,jj) =  corr(reshape(squeeze(fezDist(:,:,jj)),[],1), reshape(fezVarMaps_pas(:,:,ii),[],1),'rows','complete');
        
        plexDistPlexVarCorr_act(ii,jj) =  corr(reshape(squeeze(plexDist(:,:,jj)),[],1), reshape(plexVarMaps_act(:,:,ii),[],1),'rows','complete');
        plexDistPlexVarCorr_pas(ii,jj) =  corr(reshape(squeeze(plexDist(:,:,jj)),[],1), reshape(plexVarMaps_pas(:,:,ii),[],1),'rows','complete');
        
    end
end

%% measure correlation between GCaMP distribution and Feeding Activity maps

for jj = 1:size(fezDist,3)
    for ii = 1:size(fezFeedMap,3)
        fezDistFezFeedCorr(ii,jj) =  corr(reshape(squeeze(fezDist(:,:,jj)),[],1), reshape(fezFeedMap(:,:,ii),[],1),'rows','complete');
    end
end

for jj = 1:size(plexDist,3)
    for ii = 1:size(plexFeedMap,3)
        plexDistPlexFeedCorr(ii,jj) =  corr(reshape(squeeze(plexDist(:,:,jj)),[],1), reshape(plexFeedMap(:,:,ii),[],1),'rows','complete');
    end
end

%% measure correlation between GCaMP distribution and Ketamine Power Maps

for jj = 1:size(fezDist,3)
    
    for ii = 1:size(fezKetMap_0609,3)
        fezDistFezKetPowCorr_0609(ii,jj) =  corr(reshape(squeeze(fezDist(:,:,jj)),[],1), reshape(fezKetMap_0609(:,:,ii),[],1),'rows','complete');
        fezDistFezKetPowCorr_114(ii,jj) =  corr(reshape(squeeze(fezDist(:,:,jj)),[],1), reshape(fezKetMap_114(:,:,ii),[],1),'rows','complete');
        
        plexDistPlexKetPowCorr_0609(ii,jj) =  corr(reshape(squeeze(plexDist(:,:,jj)),[],1), reshape(plexKetMap_0609(:,:,ii),[],1),'rows','complete');
        plexDistPlexKetPowCorr_114(ii,jj) =  corr(reshape(squeeze(plexDist(:,:,jj)),[],1), reshape(plexKetMap_114(:,:,ii),[],1),'rows','complete');
        
    end
end
%% structure the data and id
g2 = [repmat("fezDist",length(fezDistFezVarCorr_act(:)),1); repmat("fezDist",length(fezDistFezVarCorr_pas(:)),1); ...
    repmat("fezDist",length(fezDistFezFeedCorr(:)),1);repmat("fezDist",length(fezDistFezKetPowCorr_0609(:)),1); ...
    repmat("fezDist",length(fezDistFezKetPowCorr_114(:)),1);repmat("plexDist",length(plexDistPlexVarCorr_act(:)),1); ...
    repmat("plexDist",length(plexDistPlexVarCorr_pas(:)),1); repmat("plexDist",length(plexDistPlexFeedCorr(:)),1); ...
    repmat("plexDist",length(plexDistPlexKetPowCorr_0609(:)),1); repmat("plexDist",length(plexDistPlexKetPowCorr_114(:)),1)];

g1 = [repmat("SpontVar_act",length(fezDistFezVarCorr_act(:)),1); repmat("SpontVar_pas",length(fezDistFezVarCorr_pas(:)),1); ...
    repmat("FeedAct",length(fezDistFezFeedCorr(:)),1);repmat("KetPow_0609",length(fezDistFezKetPowCorr_0609(:)),1); ...
    repmat("KetPow_114",length(fezDistFezKetPowCorr_114(:)),1);repmat("SpontVar_act",length(plexDistPlexVarCorr_act(:)),1); ...
    repmat("SpontVar_pas",length(plexDistPlexVarCorr_pas(:)),1); repmat("FeedAct",length(plexDistPlexFeedCorr(:)),1); ...
    repmat("KetPow_0609",length(plexDistPlexKetPowCorr_0609(:)),1); repmat("KetPow_114",length(plexDistPlexKetPowCorr_114(:)),1)];



allData = [fezDistFezVarCorr_act(:);fezDistFezVarCorr_pas(:);fezDistFezFeedCorr(:);fezDistFezKetPowCorr_0609(:);fezDistFezKetPowCorr_114(:); ...
    plexDistPlexVarCorr_act(:);plexDistPlexVarCorr_pas(:);plexDistPlexFeedCorr(:);plexDistPlexKetPowCorr_0609(:); plexDistPlexKetPowCorr_114(:)];

grpId = join([g1 g2], "-");
[anovaP,tbl,stats] = anova1(allData,grpId);
[results,~,~,gnames] = multcompare(stats);


statsText = "AnovaTest" + newline + ...
    [num2str(results(:,1)) + " VS " + num2str(results(:,2)) + " = " + num2str(results(:,6))];
%% plot data
h(2) = figure;h(2).Position = [96 188 1244 769];
boxplot(allData,grpId);
ylabel('corr coef')
title (' GCamp Distribution and activty correlation')
ylim([-1,1])
text(1.2,0,statsText(1:22),'FontSize',8)
text(7.2,0,statsText(23:end),'FontSize',8)
xtickangle(45)
%% %%%%%%%%%%%%% saving the figures %%%%%%%%%%
saveFolder = 'G:\Hemanth_CSHL\WideField\Data_Figures\STPdata\DorsalGcampActivityMapCorr\';
fileName1 = ['dorsalGCampDistVsActivityMapCorrPlots_anovaStats.fig'];
savePath1 = fullfile(saveFolder,fileName1);
saveFig = input('Do you want to save the current figure : ');
if saveFig == 1
    savefig(h,savePath1)
end