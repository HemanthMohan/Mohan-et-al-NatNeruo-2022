# %clear
# %reset -f
import os as os
from allensdk.core.reference_space_cache import ReferenceSpaceCache
import matplotlib.pyplot as plt
plt.rcParams['svg.fonttype'] = 'none'
import skimage.io as io
from sklearn.linear_model import LinearRegression,Ridge
import numpy as np
import tkinter as tk
from tkinter import filedialog
from scipy.ndimage import zoom
from skimage import filters
from os.path import split
from scipy.io import savemat
#%% Enter paths to analys
filePathsPlex = [r'G:\Hemanth_CSHL\WideField\Data_Anatomy\DistributionData\210226_JH_HM_PlexinD1_Ai14_C10M1_male_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\DistributionData\210310_JH_HM_PlexinD1_Ai148_C11M1_female_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\DistributionData\210312_JH_HM_PlexinD1_Ai148_C11M2_female_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\DistributionData\210318_JH_HM_PlexinD1_Ai148_C10M2_male_processed\cellfinder\registration'
             ]

filePathsFez = [r'G:\Hemanth_CSHL\WideField\Data_Anatomy\DistributionData\210303_JH_HM_Fezf2_Ai148_C13M1_female_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\DistributionData\210311_JH_HM_FezF2_Ai148_C12M1_female_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\DistributionData\210315_JH_HM_FezF2_Ai148_C12M2_female_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\DistributionData\210319_JH_HM_FezF2_Ai148_C12M3_female_processed\cellfinder\registration'
             ]
#%% generate atlas relevant area mask
#Load Registered Atlas
atlasPath = r'G:\Hemanth_CSHL\MyScripts\PythonScripts\AnatomyScripts\annotation\allenMap_10um\allenMap10.tiff'
atlas = io.imread(atlasPath).astype(np.float32)
# get allen map
reference_space_key = r'G:\Hemanth_CSHL\MyScripts\PythonScripts\AnatomyScripts\annotation\ccf_2017'
annPath = r'G:\Hemanth_CSHL\MyScripts\PythonScripts\AnatomyScripts\annotation\ccf_2017\annotation_10.nrrd'
os.listdir(reference_space_key)
resolution = 10
rspc = ReferenceSpaceCache(resolution, reference_space_key, manifest='manifest.json')
# ID 1 is the adult mouse structure graph
tree = rspc.get_structure_tree(structure_graph_id=1)
rsp = rspc.get_reference_space(annotation_file_name=annPath)
isocortexId = 315
wholeCortexMask = rsp.make_structure_mask([isocortexId])
cortexMask = np.copy(wholeCortexMask)
cortexMask[:,300:-1,:] = 0
boundaryFilt = atlas*cortexMask
dorsalMap = np.nanmean(boundaryFilt,axis=1)

#%%
def getDorsalDistribution(fpath,cortexMask):
    # Load data and registred allen atlas
    dataPath = os.path.join(fpath,'downsampled_standard_bgCorrZscored.tif')
    print('analyzing : ' + dataPath)
    dataZscr = io.imread(dataPath).astype(np.float32)
    dataZscr[dataZscr==0] = np.nan
    # apply area mask to the cortex 
    dataZscrFilt = dataZscr*cortexMask
    dorsalDist = np.nanmean(dataZscrFilt,axis=1)
    return dorsalDist
#%%
plexDist = []
fezDist = []
for i in np.arange(0,len(filePathsPlex),1):
    fpath = filePathsPlex[i]
    plexDist.append(getDorsalDistribution(fpath,cortexMask))

for i in np.arange(0,len(filePathsFez),1):
    fpath = filePathsFez[i]
    fezDist.append(getDorsalDistribution(fpath,cortexMask))
#%%
plexDistMean = np.nanmean(np.asarray(plexDist),axis=0)
fezDistMean = np.nanmean(np.asarray(fezDist),axis=0)
#%% plot and save the figure
plt.close('all')
fig, ax = plt.subplots(1,3,figsize=(15,6))
im0 = ax[0].imshow(plexDistMean,vmin=-1.5, vmax=1.5)
fig.colorbar(im0,ax=ax[0])
im1 = ax[1].imshow(fezDistMean,vmin=-1.5, vmax=1.5)
fig.colorbar(im1,ax=ax[1])
im2 = ax[2].imshow(dorsalMap,vmax=350)
fig.colorbar(im2,ax=ax[2])
ax[0].set_title('PlexinD1 GCaMP Distribution',fontsize= 12 )
ax[1].set_title('FezF2 GCaMP Distribution',fontsize= 12 )
ax[2].set_title('Dorsal Allen Map projection')
#%% saving the data
dataPath =r'G:\Hemanth_CSHL\WideField\Data_Analysis\DorsalGcampDistribution\dorsalGcampDist.mat'
# data = {"plexDistributionAll": np.asarray(plexDist),"fezDistributionAll": np.asarray(fezDist)}
data = {"plexDistributionAll": plexDist,"fezDistributionAll": fezDist,"dorsalMap": dorsalMap, "PlexPaths": filePathsPlex,"FezPaths": filePathsFez}

savemat(dataPath,{"data": data})
#%% saving figure
saveFold = r'G:\Hemanth_CSHL\WideField\Data_Figures\STPdata\DorsalGCaMPDistribution'
fileName = 'Plexin_Fez_Average_dorsalGCampDistribution.svg'
filePath = os.path.join(saveFold,fileName)
fig.savefig(filePath)

# #%% plot image sequence
# fig, ax = plt.subplots()
# im = []
# for i in range(0,980,1):
#     if i == 0: 
#         im = ax.imshow(areaMask[i,::],cmap='gray',vmin=0,vmax=1)
#         plt.pause(0.01)
#     else:
        
#         im.set_data(areaMask[i,::])
#         txt = plt.text(50,50,str(i),c='white')
#         plt.pause(0.01)
#         txt.remove()
# plt.draw()
# #%%
# plt.imshow(areaMask[550,:,:])
