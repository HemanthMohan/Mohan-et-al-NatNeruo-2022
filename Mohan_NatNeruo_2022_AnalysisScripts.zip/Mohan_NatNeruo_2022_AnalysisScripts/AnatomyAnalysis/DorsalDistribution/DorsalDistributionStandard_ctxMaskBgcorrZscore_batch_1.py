# %clear
# %reset -f
import os as os
from allensdk.core.reference_space_cache import ReferenceSpaceCache
import matplotlib.pyplot as plt
import skimage.io as io
from sklearn.linear_model import LinearRegression,Ridge
import numpy as np
import tkinter as tk
from tkinter import filedialog
from scipy.ndimage import zoom
from skimage import filters
from os.path import split
#%% Enter paths to analys
filePaths = [r'G:\Hemanth_CSHL\WideField\Data_Anatomy\DistributionData\210303_JH_HM_Fezf2_Ai148_C13M1_female_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\DistributionData\210310_JH_HM_PlexinD1_Ai148_C11M1_female_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\DistributionData\210311_JH_HM_FezF2_Ai148_C12M1_female_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\DistributionData\210312_JH_HM_PlexinD1_Ai148_C11M2_female_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\DistributionData\210315_JH_HM_FezF2_Ai148_C12M2_female_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\DistributionData\210318_JH_HM_PlexinD1_Ai148_C10M2_male_processed\cellfinder\registration',
             r'G:\Hemanth_CSHL\WideField\Data_Anatomy\DistributionData\210319_JH_HM_FezF2_Ai148_C12M3_female_processed\cellfinder\registration'
             ]
#%% peform correction for all files

def bgCorrZscore(fpath):
    dataPathCh1 = os.path.join(fpath,'downsampled_standard.tiff')
    print(['Analyzing : ' + dataPathCh1])
    dataPathCh2 = dataPathCh1[:-5] + '_channel_0.tiff'
    dataCh1 = io.imread(dataPathCh1).astype(np.float32)
    dataCh2 = io.imread(dataPathCh2).astype(np.float32)
    #% Load Registered Atlas
    atlasPath = r'G:\Hemanth_CSHL\MyScripts\PythonScripts\AnatomyScripts\annotation\allenMap_10um\allenMap10.tiff'
    atlas = io.imread(atlasPath)
    #% % get allen map
    reference_space_key = r'G:\Hemanth_CSHL\MyScripts\PythonScripts\AnatomyScripts\annotation\ccf_2017'
    annPath = r'G:\Hemanth_CSHL\MyScripts\PythonScripts\AnatomyScripts\annotation\ccf_2017\annotation_25.nrrd'
    os.listdir(reference_space_key)
    resolution = 25
    rspc = ReferenceSpaceCache(resolution, reference_space_key, manifest='manifest.json')
    # ID 1 is the adult mouse structure graph
    tree = rspc.get_structure_tree(structure_graph_id=1)
    #% % make cortex mask
    cortexMask = np.zeros(np.shape(atlas))
    allBrainNodes = tree.nodes()
    isoCortexId = 315
    ctxAreas = tree.descendants([isoCortexId])
    ctxAreasId = tree.descendant_ids([isoCortexId])[0]
    cortexMask[np.where(np.isin(atlas,ctxAreasId))]=1
    #% % adding brain mask
    dataCh1 = (dataCh1*cortexMask).astype(np.float32)
    dataCh2 = (dataCh2*cortexMask).astype(np.float32)
    #% % data correction
    lr = LinearRegression()
    dataCorr = np.empty(dataCh1.shape).astype(np.float32)
    intercept = []
    beta = []
    for i in range(0,dataCh1.shape[0],1):
        X = np.matrix.flatten(dataCh1[i,::]).reshape(-1,1).astype(np.float32)
        y = np.matrix.flatten(dataCh2[i,::]).reshape(-1,1).astype(np.float32)
        lr.fit(X,y)
        intercept.append(lr.intercept_)
        beta.append(lr.coef_)
    intercept_mean = np.array(intercept).reshape(-1).mean()
    beta_mean = np.array(beta).reshape(-1).mean()
    dataCorr = dataCh2 - (intercept_mean + beta_mean*dataCh1)
    #% % make non cortex areas 0
    dataCorr = dataCorr*cortexMask.astype(np.float32);
    #% % Z scoreting the data
    dataNan = np.copy(dataCorr)
    dataNan[dataCorr==0] = np.nan
    dataMn = np.nanmean(dataNan).astype(np.float16)
    dataStd = np.nanstd(dataNan).astype(np.float16)
    dataZscore = (dataCorr - dataMn)/dataStd
    dataZscore[dataCorr==0] = 0
    #% % saving the data
    print('saving...')
    savePath = dataPathCh1[:-5] + '_bgCorrZscored.tif'
    io.imsave(savePath,dataZscore)
    print('saved!')

#%% pefrom batch analysis
# for i in np.arange(0,len(filePaths),1):
#     fpath = filePaths[i]
#     bgCorrZscore(fpath)
    
fpath = filePaths[0]
bgCorrZscore(fpath)